# Manuscript-to-artifact map

Paths in this table are relative to
`artifacts/Model-Notebooks/llama3-notebooks/`. Article labels identify the
corresponding tables and figures independently of printed numbering.

| Article item | Supporting artifacts |
|---|---|
| Candidate-level physics feedback; `fig:candidate_physics_feedback` | `output_gridrank_select_extension_v2_20260726/gridrank_select_extension_gate.json` for the 64-state, three-seed panels; `output_gridrank_label_controls_extension_v1_20260812/gridrank_label_controls_extension_gate.json` for the 128-state matched-label panel |
| Locked-test results; `tab:locked_test_results` | `output_gridrank_dynamic_confirmation_v1_20260829_hotfix1/gridrank_dynamic_confirmation_records.jsonl`: seed 42, full test and `maintenance_voltage` subset |
| Seed/network robustness; `fig:seed_network_robustness` | Confirmation records for seeds 42, 123, and 2025; `gridrank_dynamic_multiseed_v1_20260901_aggregate.json` |
| Instruction/component ablations; `fig:instruction_component_ablation` | Confirmation instruction interventions; `gridrank_dynamic_physics_ablation_v1_20260902_aggregate.json`; `gridrank_dynamic_factorization_multiseed_v1_20260904_aggregate.json` |
| Physical execution; `fig:physical_execution_ablation` | `gridrank_dynamic_supplement_v1_20260908_hotfix2_cached.json`: `matched_ranking_controls` and `safety_and_maintenance_mask` |
| Cross-topology results; `tab:cross_topology_absolute` | `output_gridrank_dynamic_cross_topology_v1_20260907/gridrank_dynamic_cross_topology_records.jsonl` and its gate/statistics |
| Operating robustness; `fig:operating_robustness` | Supplement cached operating-regime results; `output_gridrank_dynamic_observation_robustness_v1_20260909_hotfix2/` records and gate |
| Appendix A.1; `tab:app_network_specific_results` | Cross-topology records/gate, grouped by network on the held-out combination |
| Appendix B.1; `tab:app_reproducibility_configuration` | Training/evaluation preflights, `environment/recorded_runtimes.json`, model catalog, and experiment protocols |
| Appendix C.1; `tab:app_separate_scoring` | Factorization multi-seed aggregate and matched joint/factorized confirmation records |
| Appendix C.2; `tab:app_dynamic_feedback_2x2` | `gridrank_dynamic_physics_factorial_v1_20260905_aggregate.json` and the four matched initialization/loss cells |
| Appendix C.3; `tab:app_maintenance_filtering` | Supplement cached `safety_and_maintenance_mask`: all instructions and maintenance subset |
| Appendix C.4; `tab:app_equal_budget_ranking` | Supplement cached `matched_ranking_controls`: Top-1 plus no-op for all rankers |
| Appendix C.5; `tab:app_safety_certification_decomposition` | Supplement cached `safety_and_maintenance_mask`: pre/post-certification decomposition |
| Appendix D.1; `tab:app_instruction_interventions` | Dynamic multi-seed aggregate, confirmation interventions, and cross-topology paired statistics |
| Appendix D.2; `tab:app_operating_regimes` | Supplement cached `simbench_operating_regimes` |
| Appendix D.3; `tab:app_measurement_noise` | Observation-robustness records/gate: `experiment_axis == "measurement_noise"` |
| Appendix D.4; `tab:app_operating_point_shifts` | Observation-robustness records/gate: `experiment_axis == "operating_shift"`, including initially infeasible cases |
| Appendix E.1; `tab:app_model_memory` | `gridrank_dynamic_supplement_v1_20260908_hotfix2_latency.json`: cold loading and GPU memory |
| Appendix E.2; `tab:app_latency_breakdown` | Same latency file: component/end-to-end measurements for 32 instruction-state records |
| Appendix E.3; `tab:app_ac_query_budget` | Candidate counts, saved call-accounting fields, and the static/dynamic/supplement protocols |

The core model archive contains the frozen SFT reference, three static
GridRank-Select adapters, and three factorized dynamic adapters. The
supplementary archive contains two matched-label adapters, three joint-card
adapters, three adapters without the dynamic physics-feedback loss, and six
SFT-initialized factorial-control adapters. All 21 adapters correspond to the
initialization references or experiments described in the article.
