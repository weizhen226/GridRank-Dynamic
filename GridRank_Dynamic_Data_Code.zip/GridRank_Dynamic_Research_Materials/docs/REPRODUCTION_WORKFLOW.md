# Reproduction workflow

## Stored-data analysis

From the package root:

```bash
python -B tools/verify_package.py
python -B tools/recompute_point_estimates.py
```

The first command validates checksums, schemas, benchmark alignment, selected
partitions, and the robustness schedule. The second recomputes principal
point estimates from stored records. Neither command loads a model or
generates new AC outcomes. The point-estimate tool does not re-estimate every
confidence interval or timing measurement.

Statistical implementations are the `aggregate_*` and `verify_*` scripts in
`artifacts/Model-Notebooks/llama3-notebooks/`; their experimental definitions
are in `artifacts/docs/`. Source-hash relationships are recorded in
`manifests/file_provenance.json` and `experiment_hash_bindings.json`.
Stored experiment hashes describe their source artifacts; current package
hashes are listed separately in `SHA256SUMS.txt`.

The cross-topology result corpus contains the 14 methods and conditions used
in the article. Use the method identifiers and evaluation scopes defined in
the data dictionary when aggregating results.

## Model inference and AC replay

1. Work in a separate writable copy of the package.
2. Extract both LoRA archives into its `artifacts/` directory, preserving the
   stored `Model-Notebooks/llama3-notebooks/` hierarchy.
3. Obtain Meta-Llama-3.1-8B-Instruct separately under its own terms. Set
   `BASE_MODEL` to that directory.
4. Prepare a compatible Linux/CUDA environment using `environment/`.
5. Review the target runner's inputs and CLI. Generate a current preflight
   with a distinct `TAG` and a separate output directory.

The saved manifests include experiment-host paths and source hashes. They
document the recorded run; they are not execution locks for a relocated host.
Create a preflight for the actual inputs, code, runtime, and model files used
on that host. Do not overwrite the supplied datasets or result directories.
The recorded static preflight uses the 16-state exclusion dataset and its
associated check records to verify separation from previously evaluated
states. These inputs are not additional final test observations.

For cross-topology replay, the runner uses the fixed SimBench pair dataset and
three factorized adapters. Its default is CPU preflight only. Full inference
requires the external base model, the extracted adapters, and
`PREFLIGHT_ONLY=0`. Complete GPU inference and retraining have not been tested
as part of package validation.

The recorded GPU is an RTX 4090 with 24 GB memory. Four-bit CUDA loading and
the timing measurements are hardware/software dependent. Do not assume a
macOS CPU run reproduces those measurements. Load only trusted model files.

## Retraining and interpretation

Use 64 static training states and the 114/96 selected dynamic
training/development records. Follow the recorded schedules and seeds
42, 123, and 2025. Test labels must not enter fitting, threshold selection,
or checkpoint selection. Matching seeds alone does not ensure bitwise
identical GPU training.

The seed replications and supplementary ablations use the same fixed
confirmation benchmark, not additional independent test datasets. Report
negative effects and intervals crossing zero. Safety results depend on the
evaluated physical settings and, where stated, a feasible initial no-op.
