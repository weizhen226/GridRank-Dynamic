# Rights and attribution

The study-generated instruction datasets and simulation results use established
physical benchmarks. Cite the associated article and the underlying IEEE and
SimBench sources when using these materials.

Meta-Llama-3.1-8B-Instruct is an external dependency. Its license and
acceptable-use conditions also need to be considered when using the task-specific
LoRA adapters. Built with Llama. The adapter archives include the Llama 3.1
Community License and attribution notice. The applicable use policy is at
https://www.llama.com/llama3_1/use-policy. Full base-model weights are not
distributed here. The released adapter family is named Llama-GridRank-Dynamic;
GridRank-Dynamic remains the method name used in the article.

SimBench, pandapower, PEFT, PyTorch, and other external dependencies retain their
respective licenses and attribution requirements. They are not relicensed by
this package. Use the repository's stated data/code license for the authors'
materials; where no such license is stated, no additional reuse permission is
granted by this document.
