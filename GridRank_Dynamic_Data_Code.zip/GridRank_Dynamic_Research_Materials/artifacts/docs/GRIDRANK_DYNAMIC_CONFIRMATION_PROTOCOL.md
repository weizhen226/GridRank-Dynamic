# IEEE locked confirmation

Evaluate the fixed factorized model on IEEE 33-bus and 69-bus states, loads,
and wording excluded from training/development. Construction uses strict
state-only views and model-independent candidate selection.

Each network contributes 12 objective-change pairs, 12 maintenance-loss pairs,
and 24 maintenance-voltage pairs. Total: 192 records, 96 pairs, and 66 states.
The held-out-combination population is 96 records, 48 pairs, and 48 states.

State/load exclusions apply to training/development sources. Prior
evaluation sources are excluded by physical-state identity. Pairs are admitted
when AC-optimal actions differ and the fixed gap requirement is met;
this outcome-informed construction is not model-score selection.

Methods share the same 15 exchanges, LinDistFlow interface, and Top-1-plus-no-op
budget. GT semantics uses reference labels; exhaustive AC uses the full pool.
The fully supervised TF-IDF variant is a positive control.
Reference labels and AC outcomes are not rendered in language-model prompts.

The primary effect is composition-withheld TF-IDF regret minus factorized LLM
regret, averaged within the 48 maintenance-voltage pairs. Use 10,000
pair/state-cluster resamples. Keep feasibility, violations, instruction
interventions, and per-network effects distinct from artifact-integrity checks.
