# Operating-shift and observation-noise evaluation

Use 48 primary SimBench states, 96 paired instructions, and the fixed outputs
of model seeds 42, 123, and 2025. Do not retrain or resample language predictions.

Operating shifts change one axis at a time:
load scaling 0.85/1.15 or DER scaling 0.80/1.20, plus the clean reference.
Active/reactive loads scale together. DER changes have no physical effect
in load-only states but remain an identified condition.
Shift evaluation recomputes the full 32-exchange-plus-no-op physical pool.

Measurement noise affects observed device scaling while true states remain
fixed. Noise levels are 1%, 3%, and 5%, with three replicas each; Gaussian
perturbations are clipped at three standard deviations and keyed by state,
device, replica, and seed 20260909.
Ranking and certification use observations; deployed actions are audited
against clean-state AC truth. Explicit maintenance restrictions remain
independent hard execution boundaries.

The recorded schedule has 1,440 shift and 2,592 noise evaluations.
Average correlated endpoints, seeds, and replicas within physical state
before 10,000 state-cluster bootstrap resamples.

Report regret change, action flips, observed gate rejection and anchor
feasibility, true feasibility, violations, and no-op rate.
Initially infeasible shifted states are reported separately; no-op fallback
does not restore feasibility in those cases. Scientific thresholds and
artifact-integrity checks are evaluated independently.
