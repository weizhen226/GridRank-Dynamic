# Static locked-test confirmation

The dataset has 64 training states and 64 test states: 32 per IEEE network
in each partition. Loads and physical states are disjoint between training
and test; test states also exclude the ancillary pilot.

The candidate pool is 15 topology-valid exchanges plus no-op. Exchange
ranking uses the YES/NO interface, four training epochs, learning rate
`2e-6`, and seeds 42, 123, and 2025. Deployment verifies Top-3 plus no-op.

Comparators are frozen SFT, always-no-op, the exact mean over all
`C(15,3)=455` random Top-3 subsets, and exhaustive AC evaluation.
Report per-seed effects, state-cluster and two-way seed/state bootstrap
intervals, per-network effects, and live certification agreement.

The confirmation result and test population remain separate from the
independent 64-state extension. Test outcomes do not select training settings.
