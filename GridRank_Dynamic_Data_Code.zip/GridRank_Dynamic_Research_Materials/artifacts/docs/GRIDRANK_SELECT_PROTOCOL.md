# Static candidate comparison

GridRank-Select learns to compare 15 topology-valid single-step exchanges for
active-power loss reduction. The no-op is a separate certification anchor and
does not occupy a language-model ranking slot.

Each exchange is scored independently using the native YES/NO logit difference.
Canonical action ordering makes batching independent of storage permutation.
AC feedback supervises acceptance, relative utility, and listwise targets.
The complete objective is BCE + 0.5 listwise CE + hard-negative loss +
0.02 frozen-reference KL. The hard-negative loss uses a smooth softplus margin.

All methods use the same Top-3-plus-no-op verification budget: four AC calls
rather than 16 for the complete pool. The certification layer checks physical
feasibility, usefulness, and cached/live agreement.

The corpus uses 64 training and 64 confirmation states, with a separate
64-state test extension. Follow the corresponding dataset/preflight for
each population.
Training uses four epochs, learning rate `2e-6`, and temperature 0.20.
Final static adapters use seeds 42, 123, and 2025.

Report safe regret, loss reduction, accepted-shortlist recall, final feasibility,
and paired state-cluster effects. Mechanism validity and scientific confidence
bounds are separate conditions.
