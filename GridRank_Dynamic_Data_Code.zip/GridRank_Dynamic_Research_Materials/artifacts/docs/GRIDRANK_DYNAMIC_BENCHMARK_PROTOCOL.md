# Dynamic language benchmark

This development benchmark evaluates natural-language interpretation of loss
or voltage objectives and temporary maintenance constraints. It is not the
final locked confirmation test.

Pairs share state and 15 exchanges but require different AC-optimal actions.
Development wording is disjoint from training wording. The held-out-combination
track excludes `maintenance_voltage` examples from baseline fitting.

Interfaces are fixed-loss LinDistFlow, frozen rules, factorized TF-IDF with
two logistic-regression heads, GT semantics, and exhaustive AC evaluation.
Deployable interfaces share Top-1 ranking and no-op certification.
The fully supervised TF-IDF variant is a positive control, not the
equal-information held-out-combination comparator.

Report normalized regret, optimum-hit rate, semantic accuracy, action flips,
and constraint violations. Development qualification is not fresh-test evidence.
