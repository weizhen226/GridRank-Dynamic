# Joint strategy-card training

The joint-card ablation scores four combinations of loss/voltage and
none/maintenance with the native YES/NO interface. The chosen card configures
LinDistFlow Top-1 ranking and independent AC/no-op certification.

Training uses 114 physically certified records. The voltage-plus-maintenance
combination is absent; its objective and constraint are observed separately.
Reference actions, AC outcomes, and structured labels are not inference inputs.

The joint-card objective combines semantic CE, AC-derived card-listwise CE,
a softplus hard margin, and frozen-reference KL. Score-space derivatives
are replayed one card at a time to limit GPU graph memory.

Instruction-removed and paired-counterfactual conditions test instruction
dependence. This development experiment and its gates are separate from
the locked confirmation evaluation.
