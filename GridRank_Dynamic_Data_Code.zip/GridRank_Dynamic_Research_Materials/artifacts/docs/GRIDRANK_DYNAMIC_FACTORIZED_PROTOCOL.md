# Factorized dynamic training

The instruction-only language interface scores loss/voltage objectives and
none/maintenance constraints separately. Strategy-card scores are
`F(o,c)=z_o[o]+z_c[c]`; square brackets select vector components.
No extra trainable classifier or AC solver is placed inside the language model.

Use the 114 selected training records and 96 development records.
The `maintenance_voltage` combination is excluded from fitting.
The starting adapter is static GridRank-Select; the reference copy is fixed.

The loss is
`0.5 CE_objective + 0.5 CE_constraint + 1.0 AC_listwise
+ 0.5 axis_hard + 0.01 reference_KL`.
The hard term averages objective-axis and constraint-axis softplus margins.
Score-space gradient replay is checked to tolerance `1e-4`.

The dynamic schedule is four epochs, learning rate `5e-6`, batch size 1,
gradient accumulation 4, and maximum sequence length 512.
Evaluation uses LinDistFlow Top-1 plus no-op, with independent AC certification.
Development evaluation is not the final confirmation test.
