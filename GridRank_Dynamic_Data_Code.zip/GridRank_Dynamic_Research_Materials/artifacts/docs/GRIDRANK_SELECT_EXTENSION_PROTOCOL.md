# Static independent test extension

The extension evaluates frozen SFT and three static adapters on 64 unused
states, 32 per IEEE network. Prior training, confirmation, and pilot loads
and states are excluded before selection. The row seed is 20260726 and the
candidate seed 20260721.

The adapters remain fixed. Every state has 15 exchanges and a no-op anchor;
Top-3-plus-no-op live replay must match cached outcomes. No optimizer or
backward pass is used.

The 64-state extension is the primary population; the combined 128-state
analysis is secondary. Report all seeds, per-network effects, 10,000-resample
state-cluster and two-way seed/state intervals, exact random Top-3 expectation,
and exhaustive AC references.

The preceding confirmation two-way CI lower bound was negative. Its stored
result remains distinct from the extension; adding states does not alter that
earlier result. The extension does not change models or thresholds.
