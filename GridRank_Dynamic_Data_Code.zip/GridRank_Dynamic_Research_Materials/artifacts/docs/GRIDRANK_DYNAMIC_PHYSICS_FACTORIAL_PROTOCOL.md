# Initialization and dynamic-feedback factorial study

The two factors are static GridRank versus frozen-SFT initialization, and
dynamic AC-listwise coefficient 1 versus 0. Each of four cells uses the same
114/96 selected records, factorized interface, four-epoch training schedule,
seeds 42/123/2025, and fixed confirmation evaluation.

Let `R_G1,R_G0,R_S1,R_S0` be the four regrets.
Static-initialization effect:
`0.5*((R_S1-R_G1)+(R_S0-R_G0))`.
Dynamic-listwise effect:
`0.5*((R_G0-R_G1)+(R_S0-R_S1))`.
Interaction:
`(R_S0-R_S1)-(R_G0-R_G1)`.
Pipeline contrast:
`R_S0-R_G1`.

The SFT/zero-listwise cell still uses physically certified training data.
Thus the pipeline contrast is not a comparison with all physical information absent.

Average by pair and physical state. Use 10,000 state-cluster, two-way
seed/state, and hierarchical seed/state/pair resamples. Report interaction
without a directional superiority requirement. This fixed-confirmation
sensitivity study does not select the main model.
