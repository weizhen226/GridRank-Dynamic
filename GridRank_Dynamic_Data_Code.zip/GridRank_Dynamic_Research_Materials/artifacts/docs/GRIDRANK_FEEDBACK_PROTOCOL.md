# Candidate-level physics feedback

The causal language model scores individual exchange candidates with
`logit(YES)-logit(NO)`. Prompts contain state, instruction, action, and
non-AC features; reference actions and AC outcomes are not model inputs.

Strict state views contain only `instance_id`, `load_id`, `prompt`, and
`split`. Candidate membership is determined from topology and a fixed hash,
not outcome quality. Training, online-stream, and test partitions are disjoint.

Offline AC feedback supplies soft utility targets, a hard-negative ordering
term, and a frozen-SFT distribution reference. The diagnostic online path
queries policy Top-2, an uncertain candidate, and one fixed-hash exploration
candidate. Only physically verified local orderings enter its replay buffer.
Failure to find improvement is not evidence that no improvement exists.

For evaluation, cached full-pool outcomes support paired metrics; a separate
live Top-k-plus-no-op replay checks feedback and selected-action agreement.
Logical deployment counts and actual backend calls are recorded separately.
Final safety certification fails closed. CPU preflight does not load the LLM;
GPU execution consumes the preflight and refuses existing output directories.

This diagnostic feedback corpus supplies candidate-level labels used by the
static ranking experiments. Its online-update route is not the final
GridRank-Dynamic deployment method.
