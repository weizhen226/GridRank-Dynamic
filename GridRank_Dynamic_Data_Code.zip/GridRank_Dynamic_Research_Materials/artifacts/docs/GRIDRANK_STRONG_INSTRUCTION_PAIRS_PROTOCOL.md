# Paired instruction construction

Each pair holds state, exchange candidates, and physical feedback fixed while
changing only the instruction. The three types are objective change,
maintenance under loss, and maintenance under voltage.

Pairs must change the AC-optimal action and exceed the recorded regret-gap
threshold. Maintenance pair construction restricts a branch used by the
unconstrained optimum. This is outcome-informed benchmark construction;
selection outcomes and labels are not language-model inputs.

Training and development states, loads, and template banks are disjoint.
The construction is cache-based and does not load models. Fixed-loss,
rule-parser, GT-semantics, and exhaustive AC results provide qualification
controls. The language interface is evaluated with Top-1 plus no-op.
