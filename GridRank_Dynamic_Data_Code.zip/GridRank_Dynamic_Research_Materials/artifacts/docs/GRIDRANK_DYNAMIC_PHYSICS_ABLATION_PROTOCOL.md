# Direct AC-listwise loss ablation

For each seed 42, 123, and 2025, compare the full factorized objective with
`lambda_physics=0`. The full coefficients are
`(objective,constraint,physics,axis-hard,reference-KL)=(0.5,0.5,1,0.5,0.01)`.

All other settings, initialization, 114/96 selected records, and confirmation
cases are fixed. The zero-weight model still uses the physically certified
corpus and semantic labels; it is not a no-physics-information model.

Define improvement as ablated regret minus full-method regret. Report
state-cluster, two-way seed/state, and hierarchical seed/state/pair intervals
with 10,000 resamples, all seed effects, network effects, and safety metrics.

This is supplementary sensitivity analysis on the fixed confirmation corpus.
A failed scientific gate remains a valid recorded result if structural
integrity is established.
