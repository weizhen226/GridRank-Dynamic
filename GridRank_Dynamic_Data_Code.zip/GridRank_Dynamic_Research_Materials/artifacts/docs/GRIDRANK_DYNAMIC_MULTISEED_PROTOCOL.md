# Dynamic seed replication

Use seeds 42, 123, and 2025 with identical initialization, 114/96 selected
training/development records, prompts, four-epoch schedule, and losses.
All structurally valid seed runs enter evaluation regardless of development
efficacy. Do not select the best seed.

Seeds 123 and 2025 reuse the fixed confirmation corpus for robustness;
they are not additional independent test sets.

The comparator identified by `tfidf_logreg_withheld_composition` uses shared
word/character TF-IDF features and separate objective/constraint logistic
heads. Its voltage-plus-maintenance fitting examples are excluded.

Within each seed, average endpoints by pair and pairs by physical state.
Report state-cluster, two-way seed/state, and hierarchical seed/state/pair
bootstrap intervals. The 48 primary pairs correspond to 48 distinct states;
all 96 pairs share 66 states. Use 10,000 resamples and report every seed.
