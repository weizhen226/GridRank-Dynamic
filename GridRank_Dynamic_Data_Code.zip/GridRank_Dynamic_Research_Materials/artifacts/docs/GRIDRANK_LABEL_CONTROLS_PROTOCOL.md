# Matched label controls

The controls share frozen SFT initialization, 64 training states, 64 test states,
15 exchanges, the YES/NO scorer, four-epoch schedule, seed 42, and
Top-3-plus-no-op certification. Only the supervision triples
`accepted_by_gate`, `target_prob`, and `safe_utility` differ.

The shuffled-label control uses a fixed state-hash derangement of complete
supervision triples across candidates. The LinDistFlow-label control uses
relative resistive-loss reduction, a positive-score acceptance label,
temperature-0.2 softmax targets, and proxy utility. AC outcomes do not enter
that proxy supervision.

Compare each with full AC-feedback training using paired physical-state
bootstrap intervals. A valid mechanism audit does not imply significant
AC-versus-proxy superiority.
