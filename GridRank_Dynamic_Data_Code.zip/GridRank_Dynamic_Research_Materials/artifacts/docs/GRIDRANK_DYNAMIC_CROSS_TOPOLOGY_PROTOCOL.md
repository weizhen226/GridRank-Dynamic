# Cross-topology evaluation

Evaluate fixed factorized language interfaces with topology-specific
LinDistFlow ranking and AC/no-op certification on:
`1-MV-rural--2-sw`, `1-MV-semiurb--2-sw`, and `1-MV-urban--2-sw`.

These exact scenario-2 networks do not enter dynamic training.
Their topology families overlap earlier static diagnostics; they are not
wholly unexamined topology families. The language interface reads instructions,
not network topology.

Each network contributes 16 maintenance-voltage, 8 objective-change, and
8 maintenance-loss pairs. Total: 192 records, 96 pairs, and 63 states.
The primary 48 pairs correspond to 48 states. Each state has 32 exchanges
and no-op. Pair construction requires a changed optimum and regret gap
at least 0.02, without using model scores.

The result corpus contains 14 methods/conditions: correct, removed, and
counterfactual instructions for three LLM seeds, plus five baselines/references.
GT semantics receives reference labels; exhaustive AC evaluates the full pool.
Neither is an equal-information, equal-budget deployment baseline.

Report pooled and network-specific regret, paired effects, state/seed bootstrap
intervals, feasibility, and violations. Pooled improvement does not imply
improvement on every network. Inconclusive and negative network effects
remain part of the evidence.

For inference replay, use the fixed pair dataset and create a preflight for
the actual runtime and code. The runner defaults to CPU preflight only and
refuses existing output directories. Package verification does not include
a complete GPU inference rerun.
