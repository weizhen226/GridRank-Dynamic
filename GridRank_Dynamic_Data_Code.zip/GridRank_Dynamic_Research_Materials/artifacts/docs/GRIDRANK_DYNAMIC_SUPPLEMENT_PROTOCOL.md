# Physical execution and efficiency analysis

Use the fixed SimBench test records and three language-model seeds.

Safety decomposition compares LinDistFlow Top-1 before and after AC/no-op
certification. Maintenance-mask counterfactuals are offline diagnostics.
Report physical infeasibility, maintenance violations, objective protection,
minimum-gain rejection, unsafe union, no-op rate, and final feasibility.
Objective-protection rejection is not identical to physical unsafety.

Equal-budget rankers share predicted strategy, maintenance filtering, Top-1,
and no-op certification. Fixed ranking uses canonical action order.
Random Top-1 performance is the exact average over eligible candidates,
not a finite Monte Carlo sample.

Operating regimes are fixed by `state_index mod 3`: load-only, moderate DER,
and high DER. Report full and maintenance-voltage results without selecting
states from performance.

Timing uses 32 identity-stratified records and four methods. Report semantic
interpretation, ranking, AC/no-op certification, and total latency; cold
loading and TF-IDF fitting are separate. Every decision verifies one exchange
and one no-op: two AC calls versus 33 for the full SimBench pool.
Warm-up calls are accounted for separately.

Latency and GPU memory are observations on RTX 4090 and the recorded software
stack, not platform-independent guarantees. Cached analysis and live timing
replay are separate procedures.
