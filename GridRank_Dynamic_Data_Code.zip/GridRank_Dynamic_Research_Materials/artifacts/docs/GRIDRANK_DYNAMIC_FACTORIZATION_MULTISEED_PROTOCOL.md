# Multi-seed interface ablation

Match joint-card and factorized models for seeds 42, 123, and 2025.
Initialization, 114 selected training records, loss coefficients, four-epoch
schedule, four scoring calls, and physical execution are shared.

The main effect is joint-card regret minus factorized regret on
`maintenance_voltage`; also report full-set and per-network results.
Aggregate endpoints within pairs and pairs within physical states.
Use state-cluster, two-way seed/state, and hierarchical seed/state/pair
bootstrap intervals with 10,000 resamples.

The fixed confirmation set is reused for sensitivity analysis. Complete
adapters remain eligible even when their development efficacy gate fails.
An interval crossing zero is an inconclusive result, not an integrity failure.
