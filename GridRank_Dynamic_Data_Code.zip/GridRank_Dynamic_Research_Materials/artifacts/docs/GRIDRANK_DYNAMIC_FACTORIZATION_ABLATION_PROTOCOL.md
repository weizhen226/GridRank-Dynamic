# Joint-versus-factorized interface ablation

Compare native Llama LoRA interfaces with four joint strategy-card scores
versus two objective scores plus two constraint scores. Both use four native
YES/NO scoring calls, the same 114 training records, fixed initialization,
loss budget, four epochs, and Top-1 physical execution.

The withheld combination is `maintenance_voltage`. Evaluation uses the
same 192-record confirmation corpus; it is supplementary analysis, not a new
independent confirmation set.

Define the effect as joint-card regret minus factorized regret. Report
semantic accuracy, physical optimum-hit rate, feasibility, violations, and
pair/state-cluster bootstrap intervals. Positive effects favor factorization.
The comparison concerns these implementations, not every possible
non-factorized neural architecture.
