# Matched-label test extension

Evaluate the fixed AC-label, shuffled-label, and LinDistFlow-label adapters on
64 independent states and the combined 128-state cohort. No training or
parameter updates occur. All use Top-3-plus-no-op with live AC certification.

Define `Delta(A,B)=regret(B)-regret(A)`; positive values favor A.
Use 10,000 physical-state bootstrap resamples. The combined-cohort
AC-versus-shuffled comparison tests label correspondence. AC-versus-LinDistFlow
is a separate specificity comparison; report its interval even if it crosses zero.
