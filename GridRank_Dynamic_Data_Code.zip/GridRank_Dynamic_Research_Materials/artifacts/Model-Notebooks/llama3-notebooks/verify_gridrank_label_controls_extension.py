"""Validate GridRank label controls extension."""

from __future__ import annotations

import argparse
import ast
import json
from pathlib import Path

from eval_gridrank_label_controls_extension import _paired, SCHEMA
from preflight_gridrank_label_controls_extension import EXPERIMENT_ID, METHODS


HERE = Path(__file__).resolve().parent


def _call_names(path):
    tree = ast.parse(Path(path).read_text(encoding="utf-8"))
    output = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Call):
            try:
                output.append(ast.unparse(node.func))
            except Exception:
                pass
    return output


def dependency_regression():
    before = [{
        "instance_id": "a", "network": "33", "physical_state_sha256": "1",
        "safe_regret": 2.0, "safe_feasible": True,
    }]
    after = [{
        "instance_id": "a", "network": "33", "physical_state_sha256": "1",
        "safe_regret": 1.0, "safe_feasible": True,
    }]
    paired = _paired(before, after, 100, 9)
    calls = _call_names(HERE / "eval_gridrank_label_controls_extension.py")
    forbidden = [
        name for name in calls
        if name.endswith(".backward") or "optimizer" in name.lower()
        or name.endswith("train") or name.endswith("train_model")
    ]
    checks = {
        "paired_orientation": paired["safe_regret_improvement_mean"] == 1.0,
        "paired_ci": paired["state_cluster_bootstrap_ci95"] == [1.0, 1.0],
        "no_training_calls": not forbidden,
        "three_methods": METHODS
            == ("full_gridrank", "shuffled_labels", "lindistflow_labels"),
    }
    result = {
        "msg": "GridRank label-controls extension dependency regression",
        "checks": checks,
        "forbidden_calls": forbidden,
        "verification_pass": all(checks.values()),
    }
    print(json.dumps(result, ensure_ascii=False))
    if not result["verification_pass"]:
        raise SystemExit(2)


def verify_result(path):
    result = json.load(open(path, encoding="utf-8"))
    extension = result.get("extension_64_state_primary", {})
    combined = result.get("combined_128_state_primary", {})
    checks = {
        "schema": result.get("schema") == SCHEMA,
        "experiment_id": result.get("experiment_id") == EXPERIMENT_ID,
        "evaluation_only": result.get("training_performed") is False
            and result.get("parameter_updates") == 0
            and result.get("model_forward_only") is True,
        "evaluation_gate_pass": result.get("evaluation_gate_pass") is True,
        "extension_64": extension.get("n_states") == 64,
        "combined_128": combined.get("n_states") == 128,
        "all_methods": set(extension.get("summaries", {}))
            == {"frozen_sft", *METHODS},
        "comparisons_present": {
            "full_gridrank_vs_shuffled_labels",
            "full_gridrank_vs_lindistflow_labels",
        }.issubset(combined.get("comparisons", {})),
        "causal_decision_present": isinstance(result.get("causal_decision"), dict),
    }
    payload = {
        "msg": "GridRank label-controls extension result verification",
        "checks": checks,
        "verification_pass": all(checks.values()),
        "causal_decision": result.get("causal_decision"),
        "combined_key_comparisons": {
            key: combined.get("comparisons", {}).get(key)
            for key in (
                "full_gridrank_vs_shuffled_labels",
                "full_gridrank_vs_lindistflow_labels",
            )
        },
    }
    print(json.dumps(payload, ensure_ascii=False))
    if not payload["verification_pass"]:
        raise SystemExit(2)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--gate")
    args = parser.parse_args()
    verify_result(args.gate) if args.gate else dependency_regression()


if __name__ == "__main__":
    main()
