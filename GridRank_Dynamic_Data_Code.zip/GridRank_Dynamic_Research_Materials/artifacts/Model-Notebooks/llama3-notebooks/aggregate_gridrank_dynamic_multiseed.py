"""Aggregate GridRank dynamic multiseed."""

from __future__ import annotations

import argparse
import hashlib
import json
import random
from collections import defaultdict
from pathlib import Path


SCHEMA = "gridrank-dynamic-multiseed-aggregate-v1"
EXPERIMENT_ID = "gridrank-factorized-dynamic-three-seed-robustness-v1"
SEEDS = (42, 123, 2025)
PRIMARY_PAIR_TYPE = "maintenance_voltage"
ALIGNED = "physics_aligned_factorized_llm"
WITHHELD = "tfidf_logreg_withheld_composition"
REMOVED = "instruction_removed"
COUNTERFACTUAL = "instruction_counterfactual"


def file_sha256(path):
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def parse_key_values(values, label):
    output = {}
    for value in values:
        if "=" not in value:
            raise ValueError(f"{label} must use SEED=PATH: {value}")
        raw_seed, path = value.split("=", 1)
        seed = int(raw_seed)
        if seed in output:
            raise ValueError(f"duplicate {label} seed {seed}")
        output[seed] = path
    if tuple(sorted(output)) != SEEDS:
        raise ValueError(f"{label} seeds must be exactly {SEEDS}, got {sorted(output)}")
    return output


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--seed_gate", action="append", required=True)
    parser.add_argument("--seed_records", action="append", required=True)
    parser.add_argument("--fresh_summary", required=True)
    parser.add_argument("--factorized_tfidf_audit", required=True)
    parser.add_argument("--bootstrap_reps", type=int, default=10000)
    parser.add_argument("--bootstrap_seed", type=int, default=20260901)
    parser.add_argument("--output", required=True)
    return parser.parse_args()


def mean(values):
    return sum(values) / len(values) if values else None


def quantile_interval(values):
    ordered = sorted(values)
    return [
        ordered[int(0.025 * (len(ordered) - 1))],
        ordered[int(0.975 * (len(ordered) - 1))],
    ]


def read_records(path):
    methods = defaultdict(list)
    with open(path, encoding="utf-8") as handle:
        for line in handle:
            if not line.strip():
                continue
            row = json.loads(line)
            method = row.pop("method")
            methods[method].append(row)
    return dict(methods)


def method_index(methods, method, pair_type=None):
    rows = methods[method]
    if pair_type is not None:
        rows = [row for row in rows if row["pair_type"] == pair_type]
    return {row["instance_id"]: row for row in rows}


def pair_effects(methods, before, after, pair_type=None):
    left = method_index(methods, before, pair_type)
    right = method_index(methods, after, pair_type)
    if set(left) != set(right):
        raise ValueError(f"paired IDs differ for {before} vs {after}")
    grouped = defaultdict(list)
    networks = {}
    for instance_id in sorted(left):
        pair_id = left[instance_id]["pair_id"]
        grouped[pair_id].append(
            float(left[instance_id]["normalised_regret"])
            - float(right[instance_id]["normalised_regret"])
        )
        networks[pair_id] = str(left[instance_id]["network"])
    return {key: mean(value) for key, value in grouped.items()}, networks


def physical_state_units(summary_path):
    summary = json.load(open(summary_path, encoding="utf-8"))
    manifest = summary.get("pairs", {}).get("manifest", [])
    if not manifest:
        raise ValueError("fresh summary has no pair manifest")
    pair_to_state, state_network = {}, {}
    for row in manifest:
        pair_id = row["pair_id"]
        state = str(row["physical_state_sha256"])
        network = str(row["network_id"])
        if pair_id in pair_to_state and pair_to_state[pair_id] != state:
            raise ValueError(f"pair maps to multiple states: {pair_id}")
        if state in state_network and state_network[state] != network:
            raise ValueError(f"state maps to multiple networks: {state}")
        pair_to_state[pair_id] = state
        state_network[state] = network
    return pair_to_state, state_network, manifest


def bootstrap_state_matrix(pair_matrix, pair_to_state, state_network, reps, seed):
    seeds = sorted(pair_matrix)
    pairs = sorted(next(iter(pair_matrix.values())))
    if any(set(values) != set(pairs) for values in pair_matrix.values()):
        raise ValueError("pair clusters differ across seeds")
    missing = sorted(set(pairs).difference(pair_to_state))
    if missing:
        raise ValueError(f"pair clusters missing physical-state mapping: {missing[:3]}")
    state_pairs = defaultdict(list)
    for pair_id in pairs:
        state_pairs[pair_to_state[pair_id]].append(pair_id)
    states = sorted(state_pairs)
    state_matrix = {
        model_seed: {
            state: mean([pair_matrix[model_seed][pair_id] for pair_id in state_pairs[state]])
            for state in states
        }
        for model_seed in seeds
    }
    per_seed = {
        str(value): mean(list(state_matrix[value].values())) for value in seeds
    }
    state_means = {
        state: mean([state_matrix[value][state] for value in seeds])
        for state in states
    }
    rng_state = random.Random(seed)
    state_draws = [
        mean([state_means[states[rng_state.randrange(len(states))]] for _ in states])
        for _ in range(reps)
    ]
    rng_two_way = random.Random(seed + 1)
    two_way_draws = []
    for _ in range(reps):
        sampled_seeds = [seeds[rng_two_way.randrange(len(seeds))] for _ in seeds]
        sampled_states = [states[rng_two_way.randrange(len(states))] for _ in states]
        two_way_draws.append(mean([
            state_matrix[model_seed][state]
            for model_seed in sampled_seeds for state in sampled_states
        ]))

    rng_hierarchical = random.Random(seed + 2)
    hierarchical_draws = []
    for _ in range(reps):
        sampled_seeds = [
            seeds[rng_hierarchical.randrange(len(seeds))] for _ in seeds
        ]
        sampled_states = [
            states[rng_hierarchical.randrange(len(states))] for _ in states
        ]
        cells = []
        for model_seed in sampled_seeds:
            for state in sampled_states:
                nested = state_pairs[state]
                cells.append(mean([
                    pair_matrix[model_seed][
                        nested[rng_hierarchical.randrange(len(nested))]
                    ]
                    for _ in nested
                ]))
        hierarchical_draws.append(mean(cells))

    def network_result(network):
        selected = [state for state in states if state_network[state] == network]
        values = [state_means[state] for state in selected]
        if not values:
            return {
                "physical_state_clusters": 0,
                "improvement_mean": None,
                "physical_state_cluster_ci95": None,
            }
        rng = random.Random(seed + int(network))
        draws = [
            mean([values[rng.randrange(len(values))] for _ in values])
            for _ in range(reps)
        ]
        return {
            "physical_state_clusters": len(values),
            "improvement_mean": mean(values),
            "physical_state_cluster_ci95": quantile_interval(draws),
        }

    return {
        "seeds": seeds,
        "pair_clusters": len(pairs),
        "physical_state_clusters": len(states),
        "states_with_multiple_pairs": sum(len(value) > 1 for value in state_pairs.values()),
        "max_pairs_per_state": max(map(len, state_pairs.values())),
        "improvement_mean": mean(list(state_means.values())),
        "per_seed_improvement_mean": per_seed,
        "positive_seed_count": sum(value > 0 for value in per_seed.values()),
        "physical_state_cluster_bootstrap_ci95": quantile_interval(state_draws),
        "two_way_seed_state_bootstrap_ci95": quantile_interval(two_way_draws),
        "hierarchical_seed_state_pair_bootstrap_ci95": quantile_interval(
            hierarchical_draws
        ),
        "by_network": {network: network_result(network) for network in ("33", "69")},
    }


def baseline_signature(methods):
    return {
        row["instance_id"]: {
            "pair_id": row["pair_id"],
            "normalised_regret": row["normalised_regret"],
            "safe_action": row["safe_action"],
        }
        for row in methods[WITHHELD]
    }


def safety_summary(methods):
    rows = methods[ALIGNED]
    return {
        "rows": len(rows),
        "safe_feasible_rate": mean([float(row["safe_feasible"]) for row in rows]),
        "constraint_violation_rate": mean([
            float(row["constraint_violation"]) for row in rows
        ]),
        "normalised_regret_mean": mean([float(row["normalised_regret"]) for row in rows]),
        "physics_optimal_rate": mean([float(row["physics_optimal"]) for row in rows]),
        "semantic_accuracy": mean([float(row["semantic_correct"]) for row in rows]),
    }


def build(
    seed_gates, seed_records, fresh_summary, factorized_tfidf_audit,
    reps, bootstrap_seed,
):
    gates, records = {}, {}
    integrity = {}
    for seed in SEEDS:
        gate_path, records_path = seed_gates[seed], seed_records[seed]
        gate = json.load(open(gate_path, encoding="utf-8"))
        values = read_records(records_path)
        gates[seed], records[seed] = gate, values
        integrity[f"seed_{seed}_gate_schema"] = (
            gate.get("schema") == "gridrank-dynamic-fresh-confirmation-gate-v1"
        )
        integrity[f"seed_{seed}_evaluation_only"] = (
            gate.get("evaluation_only") is True
            and gate.get("training_performed") is False
            and gate.get("fresh_outcomes_used_for_fit") is False
        )
        integrity[f"seed_{seed}_records_hash"] = (
            gate.get("records", {}).get("sha256") == file_sha256(records_path)
        )
        integrity[f"seed_{seed}_method_set"] = all(
            method in values for method in (ALIGNED, WITHHELD, REMOVED, COUNTERFACTUAL)
        )

    reference_signature = baseline_signature(records[42])
    integrity["withheld_tfidf_baseline_identical_across_seeds"] = all(
        baseline_signature(records[seed]) == reference_signature for seed in SEEDS
    )
    tfidf_audit = json.load(open(factorized_tfidf_audit, encoding="utf-8"))
    integrity["factorized_tfidf_audit_schema"] = (
        tfidf_audit.get("schema") == "gridrank-factorized-tfidf-audit-v1"
    )
    integrity["factorized_tfidf_audit_pass"] = tfidf_audit.get("audit_pass") is True
    integrity["factorized_tfidf_replay_exact"] = tfidf_audit.get("checks", {}).get(
        "replay_exactly_matches_locked_records"
    ) is True
    pair_to_state, state_network, state_manifest = physical_state_units(fresh_summary)
    integrity["fresh_summary_pair_manifest_present"] = bool(state_manifest)
    integrity["fresh_summary_96_pair_clusters"] = len(pair_to_state) == 96
    integrity["fresh_summary_66_unique_states"] = len(state_network) == 66

    primary_matrix, primary_networks = {}, None
    removed_matrix, removed_networks = {}, None
    counterfactual_matrix, counterfactual_networks = {}, None
    for seed in SEEDS:
        primary_matrix[seed], networks = pair_effects(
            records[seed], WITHHELD, ALIGNED, PRIMARY_PAIR_TYPE
        )
        removed_matrix[seed], removed_networks_value = pair_effects(
            records[seed], REMOVED, ALIGNED
        )
        counterfactual_matrix[seed], counterfactual_networks_value = pair_effects(
            records[seed], COUNTERFACTUAL, ALIGNED
        )
        primary_networks = networks if primary_networks is None else primary_networks
        removed_networks = (
            removed_networks_value if removed_networks is None else removed_networks
        )
        counterfactual_networks = (
            counterfactual_networks_value
            if counterfactual_networks is None else counterfactual_networks
        )

    primary = bootstrap_state_matrix(
        primary_matrix, pair_to_state, state_network, reps, bootstrap_seed + 100
    )
    correct_vs_removed = bootstrap_state_matrix(
        removed_matrix, pair_to_state, state_network, reps, bootstrap_seed + 200
    )
    correct_vs_counterfactual = bootstrap_state_matrix(
        counterfactual_matrix, pair_to_state, state_network, reps, bootstrap_seed + 300
    )
    integrity["primary_pair_is_physical_state_unique"] = (
        primary["pair_clusters"] == primary["physical_state_clusters"] == 48
        and primary["states_with_multiple_pairs"] == 0
    )
    safety = {str(seed): safety_summary(records[seed]) for seed in SEEDS}
    robustness = {
        "at_least_2_of_3_seeds_positive": primary["positive_seed_count"] >= 2,
        "pooled_physical_state_ci_lower_positive": (
            primary["physical_state_cluster_bootstrap_ci95"][0] > 0
        ),
        "two_way_seed_state_ci_lower_positive": (
            primary["two_way_seed_state_bootstrap_ci95"][0] > 0
        ),
        "both_networks_positive": all(
            primary["by_network"][network]["improvement_mean"] > 0
            for network in ("33", "69")
        ),
        "all_seed_feasibility_100pct": all(
            value["safe_feasible_rate"] == 1.0 for value in safety.values()
        ),
        "all_seed_constraint_violation_zero": all(
            value["constraint_violation_rate"] == 0.0 for value in safety.values()
        ),
        "correct_vs_removed_two_way_seed_state_ci_lower_positive": (
            correct_vs_removed["two_way_seed_state_bootstrap_ci95"][0] > 0
        ),
        "correct_vs_counterfactual_two_way_seed_state_ci_lower_positive": (
            correct_vs_counterfactual["two_way_seed_state_bootstrap_ci95"][0] > 0
        ),
        "correct_vs_removed_hierarchical_ci_lower_positive": (
            correct_vs_removed[
                "hierarchical_seed_state_pair_bootstrap_ci95"
            ][0] > 0
        ),
        "correct_vs_counterfactual_hierarchical_ci_lower_positive": (
            correct_vs_counterfactual[
                "hierarchical_seed_state_pair_bootstrap_ci95"
            ][0] > 0
        ),
    }
    audit_pass = all(integrity.values())
    robustness_pass = audit_pass and all(robustness.values())
    return {
        "msg": "GridRank factorized dynamic three-seed robustness aggregate",
        "schema": SCHEMA,
        "experiment_id": EXPERIMENT_ID,
        "seeds": list(SEEDS),
        "bootstrap_reps": reps,
        "bootstrap_seed": bootstrap_seed,
        "training_performed": False,
        "model_loaded": False,
        "power_flow_calls": 0,
        "confirmation_reuse_disclosed": True,
        "freshness_boundary": (
            "seed 42 retains the one-time fresh-confirmation claim; seeds 123 and "
            "2025 are post-confirmation robustness replications on identical frozen bytes"
        ),
        "inputs": {
            "fresh_summary": {
                "path": str(Path(fresh_summary).resolve()),
                "sha256": file_sha256(fresh_summary),
            },
            "factorized_tfidf_audit": {
                "path": str(Path(factorized_tfidf_audit).resolve()),
                "sha256": file_sha256(factorized_tfidf_audit),
            },
            "seeds": {
                str(seed): {
                    "gate": {"path": str(Path(seed_gates[seed]).resolve()), "sha256": file_sha256(seed_gates[seed])},
                    "records": {"path": str(Path(seed_records[seed]).resolve()), "sha256": file_sha256(seed_records[seed])},
                }
                for seed in SEEDS
            },
        },
        "primary": {
            "comparison": "factorized_withheld_tfidf_regret_minus_factorized_llm_regret",
            "pair_type": PRIMARY_PAIR_TYPE,
            "independence_note": (
                "all 48 primary pairs map one-to-one to 48 physical states; "
                "therefore the historical primary pair-cluster CI is numerically "
                "a physical-state cluster CI"
            ),
            **primary,
        },
        "causal_controls": {
            "correct_vs_removed": correct_vs_removed,
            "correct_vs_counterfactual": correct_vs_counterfactual,
        },
        "per_seed_aligned_summary": safety,
        "integrity_checks": integrity,
        "robustness_checks": robustness,
        "audit_pass": audit_pass,
        "robustness_gate_pass": robustness_pass,
        "failed_integrity": [key for key, value in integrity.items() if not value],
        "failed_robustness": [key for key, value in robustness.items() if not value],
        "decision": (
            "authorize_three_seed_dynamic_adaptation_claim"
            if robustness_pass else "retain_single_seed_confirmatory_claim_and_report_seed_variance"
        ),
    }


def main():
    args = parse_args()
    output = Path(args.output)
    if output.exists():
        raise FileExistsError(f"refusing to overwrite aggregate: {output}")
    gates = parse_key_values(args.seed_gate, "seed_gate")
    records = parse_key_values(args.seed_records, "seed_records")
    result = build(
        gates, records, args.fresh_summary, args.factorized_tfidf_audit,
        args.bootstrap_reps, args.bootstrap_seed
    )
    output.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(result, ensure_ascii=False))
    if not result["audit_pass"]:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
