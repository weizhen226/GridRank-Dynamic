"""Validate GridRank dynamic physics ablation."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import aggregate_gridrank_dynamic_physics_ablation as aggregate


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--result", required=True)
    return parser.parse_args()


def main():
    args = parse_args()
    result = json.load(open(args.result, encoding="utf-8"))
    input_checks = {}
    groups = {
        name: {} for name in (
            "full_gate", "full_records", "full_factor_preflight",
            "full_confirmation_preflight", "ablation_gate", "ablation_records",
            "ablation_factor_preflight", "ablation_confirmation_preflight",
        )
    }
    for raw_seed, items in result.get("inputs", {}).get("seeds", {}).items():
        seed = int(raw_seed)
        for name, item in items.items():
            groups[name][seed] = item["path"]
            input_checks[f"seed_{seed}_{name}"] = (
                Path(item["path"]).is_file()
                and aggregate.file_sha256(item["path"]) == item["sha256"]
            )
    fresh = result.get("inputs", {}).get("fresh_summary", {})
    input_checks["fresh_summary"] = (
        Path(fresh.get("path", "")).is_file()
        and aggregate.file_sha256(fresh["path"]) == fresh.get("sha256")
    )
    rebuilt = aggregate.build(
        groups,
        fresh["path"],
        result["bootstrap_reps"],
        result["bootstrap_seed"],
    )
    checks = {
        "schema": result.get("schema") == aggregate.SCHEMA,
        "experiment_id": result.get("experiment_id") == aggregate.EXPERIMENT_ID,
        "all_inputs_current": bool(input_checks) and all(input_checks.values()),
        "exact_recomputation": rebuilt == result,
        "audit_consistent": result.get("audit_pass")
        == all(result.get("integrity_checks", {}).values()),
        "safety_consistent": result.get("safety_pass")
        == all(result.get("safety_checks", {}).values()),
        "decision_consistent": result.get("decision") == (
            "authorize_direct_ac_listwise_incremental_contribution_claim"
            if result.get("physics_loss_contribution_gate_pass")
            else "retain_physics_listwise_without_significant_incremental_claim"
        ),
        "post_confirmation_boundary_present": bool(
            result.get("post_confirmation_supplement")
            and result.get("freshness_boundary")
        ),
    }
    verification = {
        "msg": "GridRank dynamic physics-loss ablation result verification",
        "checks": checks,
        "input_checks": input_checks,
        "verification_pass": all(checks.values()),
        "audit_pass": result.get("audit_pass"),
        "physics_loss_contribution_gate_pass": result.get(
            "physics_loss_contribution_gate_pass"
        ),
        "decision": result.get("decision"),
        "failed_contribution": result.get("failed_contribution"),
    }
    print(json.dumps(verification, ensure_ascii=False))
    if not verification["verification_pass"]:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
