"""Build GridRank dynamic confirmation."""

from __future__ import annotations

import argparse
import hashlib
import itertools
import json
from collections import Counter, defaultdict
from pathlib import Path
from types import SimpleNamespace

import build_gridrank_feedback as feedback
from build_gridrank_instruction_pairs import (
    PAIR_TYPES,
    TRAIN_TEMPLATES,
    VALIDATION_TEMPLATES,
    baseline_records,
    candidate_pairs,
)
from build_gridrank_instruct_identifiability import NOOP, edge_text


SCHEMA = "gridrank-dynamic-fresh-confirmation-v1"
PAIR_SCHEMA = "gridrank-dynamic-fresh-confirmation-pair-v1"
PRIMARY_PAIR_TYPE = "maintenance_voltage"

CONFIRMATION_TEMPLATES = {
    "loss": (
        "For this dispatch interval, choose the safe single exchange with the lowest real-power dissipation.",
        "Operate for maximum electrical efficiency; keep the present topology when no admissible exchange saves real power.",
        "Among feasible one-exchange topologies, prefer the one that removes the most conductor loss.",
        "Reduce resistive feeder waste as far as a safe branch exchange permits.",
    ),
    "voltage": (
        "For this interval, maximize the voltage floor; a real-power-loss rise above one-half percent is unacceptable.",
        "Protect the weakest-node voltage first, provided the candidate is safe and stays inside the 0.5 percent loss allowance.",
        "Select the admissible exchange that lifts the minimum per-unit voltage most without breaching the efficiency cap.",
        "Voltage-floor support has priority today, with at most a half-percent increase in active-power loss.",
    ),
    "maintenance_loss": (
        "Efficiency remains the objective, but crew clearance makes branch {edges} non-operable during this interval.",
        "Seek the lowest-loss safe topology while every switching action touching {edges} is prohibited.",
        "The work permit locks out {edges}; from the remaining exchanges choose the greatest real-power saving.",
        "Minimize resistive loss under a temporary hard switching embargo on {edges}.",
    ),
    "maintenance_voltage": (
        "Protect the voltage floor during the outage window: switching {edges} is prohibited, and the loss penalty cannot exceed 0.5 percent.",
        "With {edges} locked out by the crew, raise the weakest-node voltage subject to the half-percent loss allowance.",
        "The temporary permit forbids operating {edges}; among allowed safe exchanges, prioritize minimum-voltage support.",
        "Improve the lowest bus voltage while treating {edges} as untouchable and respecting the stated efficiency tolerance.",
    ),
}


def file_sha256(path):
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def jsonl(path):
    return [json.loads(line) for line in open(path, encoding="utf-8") if line.strip()]


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", action="append", required=True, help="NETWORK=STATE_ONLY")
    parser.add_argument("--exclude_jsonl", action="append", required=True)
    parser.add_argument("--exclude_state_jsonl", action="append", default=[])
    parser.add_argument("--physics_python", required=True)
    parser.add_argument("--physics_timeout_s", type=float, default=60.0)
    parser.add_argument(
        "--physics_backend", choices=("pandapower-subprocess",),
        default="pandapower-subprocess",
    )
    parser.add_argument("--candidate_pool_size", type=int, default=16)
    parser.add_argument("--candidate_seed", type=int, default=20260721)
    parser.add_argument("--row_seed", type=int, default=20260829)
    parser.add_argument("--selection_seed", type=int, default=20260829)
    parser.add_argument("--target_temperature", type=float, default=0.20)
    parser.add_argument("--seen_pairs_per_network", type=int, default=12)
    parser.add_argument("--hidden_pairs_per_network", type=int, default=24)
    parser.add_argument("--max_scanned_states_per_network", type=int, default=160)
    parser.add_argument("--min_objective_pair_gap", type=float, default=0.02)
    parser.add_argument("--min_constraint_pair_gap", type=float, default=0.20)
    parser.add_argument("--cache_out", required=True)
    parser.add_argument("--pairs_out", required=True)
    parser.add_argument("--summary_out", required=True)
    return parser.parse_args()


def parse_sources(specs):
    result = {}
    for spec in specs:
        network, path = spec.split("=", 1)
        if network in result:
            raise ValueError(f"duplicate source network: {network}")
        result[network] = {
            "path": str(Path(path).resolve()),
            "rows": feedback.read_state_only(path, "validation"),
            "sha256": file_sha256(path),
        }
    if set(result) != {"33", "69"}:
        raise ValueError("fresh confirmation requires exactly networks 33 and 69")
    return result


def exclusion_identities(paths):
    states, loads, artifacts = set(), set(), []
    for raw in paths:
        path = Path(raw).resolve()
        if not path.is_file():
            raise FileNotFoundError(path)
        rows = jsonl(path)
        for row in rows:
            network = str(row.get("network_id", row.get("network", "")))
            state = row.get("physical_state_sha256")
            load = str(row.get("load_id", ""))
            if network and state:
                states.add((network, str(state)))
            if network and load:
                loads.add((network, load if ":" in load else f"{network}:{load}"))
        artifacts.append({"path": str(path), "sha256": file_sha256(path)})
    return states, loads, artifacts


def exclusion_states(paths):
    states, artifacts = set(), []
    for raw in paths:
        path = Path(raw).resolve()
        if not path.is_file():
            raise FileNotFoundError(path)
        for row in jsonl(path):
            network = str(row.get("network_id", row.get("network", "")))
            state = row.get("physical_state_sha256")
            if network and state:
                states.add((network, str(state)))
        artifacts.append({"path": str(path), "sha256": file_sha256(path)})
    return states, artifacts


def quota(pair_type, args):
    return (
        args.hidden_pairs_per_network
        if pair_type == PRIMARY_PAIR_TYPE
        else args.seen_pairs_per_network
    )


def pair_args(args):
    return SimpleNamespace(
        target_temperature=args.target_temperature,
        min_objective_pair_gap=args.min_objective_pair_gap,
        min_constraint_pair_gap=args.min_constraint_pair_gap,
    )


def rank_pair(item, args):
    payload = (
        f"{args.selection_seed}|fresh-confirmation|{item['network_id']}|"
        f"{item['pair_type']}|{item['load_id']}|{item['physical_state_sha256']}"
    )
    return hashlib.sha256(payload.encode("utf-8")).digest()


def selected_pairs(pool, args):
    selected = []
    for network, pair_type in itertools.product(("33", "69"), PAIR_TYPES):
        values = [
            item for item in pool
            if item["network_id"] == network and item["pair_type"] == pair_type
        ]
        selected.extend(sorted(values, key=lambda item: rank_pair(item, args))[: quota(pair_type, args)])
    return selected


def counts_by_network_type(values):
    counts = Counter((item["network_id"], item["pair_type"]) for item in values)
    return {
        f"{network}:{pair_type}": counts[(network, pair_type)]
        for network, pair_type in itertools.product(("33", "69"), PAIR_TYPES)
    }


def quotas_met(pool, args):
    counts = counts_by_network_type(pool)
    return all(
        counts[f"{network}:{pair_type}"] >= quota(pair_type, args)
        for network, pair_type in itertools.product(("33", "69"), PAIR_TYPES)
    )


def template_index(pair_id, side, family):
    values = CONFIRMATION_TEMPLATES[family]
    digest = hashlib.sha256(f"{pair_id}|{side}|{family}".encode("utf-8")).digest()
    return int.from_bytes(digest[:4], "big") % len(values)


def decorate(row, item, pair_id, side):
    family = row["instruction_id"]
    index = template_index(pair_id, side, family)
    forbidden = item["forbidden_edges"] if side == "right" else ()
    value = dict(row)
    value.update({
        "schema": PAIR_SCHEMA,
        "instance_id": f"{pair_id}:{side}",
        "partition": "fresh_confirmation",
        "pair_id": pair_id,
        "pair_type": item["pair_type"],
        "pair_side": side,
        "paraphrase_index": 0,
        "template_id": f"fresh:{family}:{index}",
        "instruction_style": "fresh_confirmation",
        "instruction_text": CONFIRMATION_TEMPLATES[family][index].format(
            edges=edge_text(forbidden)
        ),
        "pair_selection_gap": float(item["strength"]),
        "oracle_structured_instruction": {
            "objective": row["base_objective"],
            "forbidden_edges": [list(edge) for edge in forbidden],
            "hard_constraint": bool(forbidden),
            "loss_increase_limit_pct": 0.5 if row["base_objective"] == "voltage" else None,
        },
    })
    return value


def emit(selected):
    rows, manifest = [], []
    ordered = sorted(
        selected,
        key=lambda item: (
            item["network_id"], item["pair_type"],
            item["physical_state_sha256"], item["load_id"],
        ),
    )
    for index, item in enumerate(ordered):
        pair_id = (
            f"gridrank-fresh-confirm:{item['network_id']}:"
            f"{item['physical_state_sha256']}:{item['pair_type']}:{index}"
        )
        left = decorate(item["left"], item, pair_id, "left")
        right = decorate(item["right"], item, pair_id, "right")
        rows.extend((left, right))
        manifest.append({
            "pair_id": pair_id,
            "network_id": item["network_id"],
            "load_id": item["load_id"],
            "physical_state_sha256": item["physical_state_sha256"],
            "pair_type": item["pair_type"],
            "left_desired_action": item["left"]["desired_action"],
            "right_desired_action": item["right"]["desired_action"],
            "forbidden_edges": [list(edge) for edge in item["forbidden_edges"]],
            "strength": float(item["strength"]),
            "directional_gaps": [float(value) for value in item["directional_gaps"]],
        })
    return rows, manifest


def write_jsonl_exclusive(path, rows):
    with open(path, "x", encoding="utf-8", newline="\n") as handle:
        for row in rows:
            handle.write(json.dumps(row, ensure_ascii=False, sort_keys=True) + "\n")


def main():
    args = parse_args()
    outputs = [Path(args.cache_out), Path(args.pairs_out), Path(args.summary_out)]
    if any(path.exists() for path in outputs):
        raise FileExistsError(f"refusing to overwrite fresh confirmation outputs: {outputs}")
    if args.candidate_pool_size != 16:
        raise ValueError("fresh confirmation locks the same 16-action candidate pool")
    if min(args.seen_pairs_per_network, args.hidden_pairs_per_network) <= 0:
        raise ValueError("pair quotas must be positive")

    sources = parse_sources(args.source)
    excluded_states, excluded_loads, exclusions = exclusion_identities(args.exclude_jsonl)
    evaluation_states, evaluation_exclusions = exclusion_states(args.exclude_state_jsonl)
    counters = Counter()
    cache, pool, source_trace = [], [], {}
    p_args = pair_args(args)

    for network, source in sorted(sources.items()):
        ordered = feedback._state_rows_by_load(source["rows"], network, args.row_seed)
        trace = []
        for raw in ordered[: args.max_scanned_states_per_network]:
            base = feedback.base_state(
                raw, network, args.candidate_pool_size, args.candidate_seed
            )
            state_key = (network, base["physical_state_sha256"])
            load_key = (network, base["load_id"])
            if (
                state_key in excluded_states
                or state_key in evaluation_states
                or load_key in excluded_loads
            ):
                raise RuntimeError(
                    f"state-view exclusion boundary failed before physics: {state_key} {load_key}"
                )
            scored = feedback.score_state(base, args, counters)
            operational = feedback.noop_is_operational(scored["candidates"])
            trace.append({
                "source_instance_id": str(raw["instance_id"]),
                "load_id": str(raw["load_id"]),
                "physical_state_sha256": scored["physical_state_sha256"],
                "operational_anchor": operational,
                "candidate_evaluations": len(scored["candidates"]),
            })
            if operational:
                cache.append(scored)
                pool.extend(candidate_pairs(scored, "validation", p_args))
            network_pool = [item for item in pool if item["network_id"] == network]
            if all(
                len([item for item in network_pool if item["pair_type"] == pair_type])
                >= quota(pair_type, args)
                for pair_type in PAIR_TYPES
            ):
                break
        source_trace[network] = trace
        network_pool = [item for item in pool if item["network_id"] == network]
        if not all(
            len([item for item in network_pool if item["pair_type"] == pair_type])
            >= quota(pair_type, args)
            for pair_type in PAIR_TYPES
        ):
            raise RuntimeError(
                f"network {network}: insufficient informative fresh states after "
                f"{len(trace)} scans; availability={counts_by_network_type(network_pool)}"
            )

    selected = selected_pairs(pool, args)
    rows, pair_manifest = emit(selected)
    available = counts_by_network_type(pool)
    selected_counts = counts_by_network_type(selected)
    state_keys = {(item["network_id"], item["physical_state_sha256"]) for item in selected}
    load_keys = {(item["network_id"], item["load_id"]) for item in selected}
    old_text = {
        text
        for bank in (TRAIN_TEMPLATES, VALIDATION_TEMPLATES)
        for values in bank.values() for text in values
    }
    fresh_text = {text for values in CONFIRMATION_TEMPLATES.values() for text in values}
    baselines, parser_accuracy = baseline_records(rows, 1)
    checks = {
        "pair_quotas_exact": all(
            selected_counts[f"{network}:{pair_type}"] == quota(pair_type, args)
            for network, pair_type in itertools.product(("33", "69"), PAIR_TYPES)
        ),
        "primary_hidden_pairs_48_or_more": (
            sum(item["pair_type"] == PRIMARY_PAIR_TYPE for item in pair_manifest) >= 48
        ),
        "all_pairs_have_two_endpoints": len(rows) == 2 * len(pair_manifest),
        "all_pairs_change_ac_optimum": all(
            item["left_desired_action"] != item["right_desired_action"]
            for item in pair_manifest
        ),
        "material_pair_gaps": all(
            item["strength"] + 1e-12 >= (
                args.min_objective_pair_gap
                if item["pair_type"] == "objective"
                else args.min_constraint_pair_gap
            )
            for item in pair_manifest
        ),
        "fresh_state_disjoint_exclusions": not state_keys.intersection(
            excluded_states.union(evaluation_states)
        ),
        "fresh_load_disjoint_exclusions": not load_keys.intersection(excluded_loads),
        "fresh_templates_exact_text_disjoint": not fresh_text.intersection(old_text),
        "fixed_candidate_count": all(
            row["candidate_count"] == 15 and len(row["candidates"]) == 15
            for row in rows
        ),
        "separate_noop_anchor": all(
            row["gate_anchor"]["action"] == NOOP
            and all(item["action"] != NOOP for item in row["candidates"])
            for row in rows
        ),
        "all_feedback_valid": all(
            all(bool(item.get("feedback_valid")) for item in state["candidates"])
            for state in cache
        ),
        "model_scores_unused": True,
    }
    write_jsonl_exclusive(args.cache_out, cache)
    write_jsonl_exclusive(args.pairs_out, rows)
    summary = {
        "msg": "GridRank fresh dynamic-instruction confirmation build",
        "schema": SCHEMA,
        "primary_pair_type": PRIMARY_PAIR_TYPE,
        "coverage_pass": all(checks.values()),
        "training_performed": False,
        "model_loaded": False,
        "model_scores_used": False,
        "construction_disclosure": (
            "Frozen identity hashing chooses the scan order; authoritative AC outcomes "
            "identify materially separating instruction pairs before any model is loaded."
        ),
        "settings": vars(args),
        "sources": {
            network: {key: value for key, value in source.items() if key != "rows"}
            for network, source in sources.items()
        },
        "exclusions": exclusions,
        "state_only_exclusions": evaluation_exclusions,
        "power_flow_calls": dict(counters),
        "scan_trace": source_trace,
        "cache": {
            "states": len(cache),
            "network_mix": dict(Counter(item["network_id"] for item in cache)),
        },
        "pairs": {
            "rows": len(rows),
            "pair_clusters": len(pair_manifest),
            "unique_states": len(state_keys),
            "unique_loads": len(load_keys),
            "available_by_network_type": available,
            "selected_by_network_type": selected_counts,
            "strength_min": min(item["strength"] for item in pair_manifest),
            "strength_mean": sum(item["strength"] for item in pair_manifest) / len(pair_manifest),
            "manifest": pair_manifest,
        },
        "cached_baselines": baselines,
        "frozen_rule_parser_accuracy": parser_accuracy,
        "checks": checks,
        "artifacts": {},
    }
    summary["artifacts"] = {
        "cache": {"path": str(Path(args.cache_out).resolve()), "sha256": file_sha256(args.cache_out)},
        "pairs": {"path": str(Path(args.pairs_out).resolve()), "sha256": file_sha256(args.pairs_out)},
    }
    with open(args.summary_out, "x", encoding="utf-8", newline="\n") as handle:
        json.dump(summary, handle, ensure_ascii=False, indent=2, sort_keys=True)
        handle.write("\n")
    print(json.dumps(summary, ensure_ascii=False))
    if not summary["coverage_pass"]:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
