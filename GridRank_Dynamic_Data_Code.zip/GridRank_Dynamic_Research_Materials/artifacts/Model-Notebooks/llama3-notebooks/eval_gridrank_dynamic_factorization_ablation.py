"""Evaluate GridRank dynamic factorization ablation."""

from __future__ import annotations

import argparse
import gc
import json
import random
from pathlib import Path
from types import SimpleNamespace

import aggregate_gridrank_dynamic_multiseed as aggregate
import preflight_gridrank_dynamic_factorization_ablation as preflight
import train_gridrank_dynamic_policy as joint


FACTORIZED = "physics_aligned_factorized_llm"
JOINT = "physics_aligned_joint_card_llm"
JOINT_REMOVED = "joint_instruction_removed"
JOINT_COUNTERFACTUAL = "joint_instruction_counterfactual"
PRIMARY = preflight.PRIMARY_PAIR_TYPE


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--preflight_manifest", required=True)
    parser.add_argument("--joint_adapter", required=True)
    parser.add_argument("--base_model", required=True)
    parser.add_argument("--output_dir", required=True)
    parser.add_argument("--max_length", type=int, required=True)
    parser.add_argument("--card_batch_size", type=int, required=True)
    parser.add_argument("--topk", type=int, required=True)
    parser.add_argument("--bootstrap_reps", type=int, required=True)
    parser.add_argument("--seed", type=int, required=True)
    parser.add_argument(
        "--gradient_checkpointing", type=int, choices=(0, 1), required=True
    )
    return parser.parse_args()


def read_rows(path):
    return [
        json.loads(line) for line in open(path, encoding="utf-8") if line.strip()
    ]


def write_records(path, records):
    with open(path, "x", encoding="utf-8", newline="\n") as handle:
        for method in sorted(records):
            for row in records[method]:
                handle.write(
                    json.dumps(
                        {"method": method, **row},
                        ensure_ascii=False,
                        sort_keys=True,
                    )
                    + "\n"
                )


def locked_preflight_args(args, manifest):
    artifacts = manifest["artifacts"]
    adapters = manifest["adapters"]
    values = {
        "fresh_pairs": artifacts["fresh_pairs"]["path"],
        "fresh_summary": artifacts["fresh_summary"]["path"],
        "fresh_audit": artifacts["fresh_audit"]["path"],
        "joint_preflight": artifacts["joint_preflight"]["path"],
        "joint_gate": artifacts["joint_gate"]["path"],
        "joint_adapter": adapters["joint_card"]["path"],
        "factorized_preflight": artifacts["factorized_preflight"]["path"],
        "factorized_gate": artifacts["factorized_gate"]["path"],
        "factorized_adapter": adapters["factorized"]["path"],
        "factorized_confirmation_preflight": artifacts[
            "factorized_confirmation_preflight"
        ]["path"],
        "factorized_confirmation_gate": artifacts[
            "factorized_confirmation_gate"
        ]["path"],
        "factorized_confirmation_records": artifacts[
            "factorized_confirmation_records"
        ]["path"],
        "base_model": manifest["base_model"],
        "output": args.preflight_manifest,
        **preflight.schedule(args),
    }
    return SimpleNamespace(**values)


def comparison(methods, before, after, pair_to_state, state_network, reps, seed, pair_type=None):
    pair_values, _ = aggregate.pair_effects(methods, before, after, pair_type)
    state_result = aggregate.bootstrap_state_matrix(
        {42: pair_values}, pair_to_state, state_network, reps, seed
    )
    before_rows = methods[before]
    after_rows = methods[after]
    if pair_type is not None:
        before_rows = joint.subset(before_rows, pair_type)
        after_rows = joint.subset(after_rows, pair_type)
    return {
        "orientation": f"{before}_regret_minus_{after}_regret",
        "positive_favors": after,
        "pair_cluster_bootstrap": joint.paired(
            before_rows, after_rows, reps, seed + 1
        ),
        "physical_state_statistics": state_result,
    }


def main():
    import torch
    import grpo_train as training

    args = parse_args()
    output = Path(args.output_dir)
    if output.exists():
        raise FileExistsError(
            f"refusing to overwrite factorization-ablation output: {output}"
        )
    manifest = json.load(open(args.preflight_manifest, encoding="utf-8"))
    preflight.verify(locked_preflight_args(args, manifest))
    if not torch.cuda.is_available():
        raise RuntimeError("factorization-ablation evaluation requires CUDA")
    random.seed(args.seed)
    torch.manual_seed(args.seed)
    torch.cuda.manual_seed_all(args.seed)

    artifacts = manifest["artifacts"]
    fresh_rows = read_rows(artifacts["fresh_pairs"]["path"])
    factorized_methods = aggregate.read_records(
        artifacts["factorized_confirmation_records"]["path"]
    )
    factorized_records = factorized_methods[FACTORIZED]
    if {row["instance_id"] for row in factorized_records} != {
        row["instance_id"] for row in fresh_rows
    }:
        raise RuntimeError("factorized confirmation records do not match fresh rows")

    model_args = SimpleNamespace(
        base_model=args.base_model,
        resume_adapter_path=args.joint_adapter,
        output_dir=args.output_dir,
        gradient_checkpointing=args.gradient_checkpointing,
    )
    model, tokenizer = training.build_model_and_tokenizer(model_args)
    for parameter in model.parameters():
        parameter.requires_grad_(False)
    model.eval()
    model.config.use_cache = False
    score_args = SimpleNamespace(
        max_length=args.max_length,
        card_batch_size=args.card_batch_size,
    )
    correct_scores = joint.score_cache(
        model, tokenizer, fresh_rows, score_args, "default", "correct"
    )
    removed_scores = joint.score_cache(
        model,
        tokenizer,
        fresh_rows,
        score_args,
        "default",
        "instruction_removed",
    )
    counterfactual_scores = joint.score_cache(
        model,
        tokenizer,
        fresh_rows,
        score_args,
        "default",
        "instruction_counterfactual",
    )
    gc.collect()
    torch.cuda.empty_cache()

    methods = {
        FACTORIZED: factorized_records,
        JOINT: joint.records_from_scores(
            fresh_rows, correct_scores, "correct"
        ),
        JOINT_REMOVED: joint.records_from_scores(
            fresh_rows, removed_scores, "instruction_removed"
        ),
        JOINT_COUNTERFACTUAL: joint.records_from_scores(
            fresh_rows, counterfactual_scores, "instruction_counterfactual"
        ),
    }
    summaries = {name: joint.summarize(values) for name, values in methods.items()}
    pair_to_state, state_network, state_manifest = aggregate.physical_state_units(
        artifacts["fresh_summary"]["path"]
    )
    comparisons = {
        "factorized_vs_joint_all": comparison(
            methods,
            JOINT,
            FACTORIZED,
            pair_to_state,
            state_network,
            args.bootstrap_reps,
            args.seed + 100,
        ),
        "factorized_vs_joint_primary": comparison(
            methods,
            JOINT,
            FACTORIZED,
            pair_to_state,
            state_network,
            args.bootstrap_reps,
            args.seed + 200,
            PRIMARY,
        ),
        "joint_correct_vs_removed": comparison(
            methods,
            JOINT_REMOVED,
            JOINT,
            pair_to_state,
            state_network,
            args.bootstrap_reps,
            args.seed + 300,
        ),
        "joint_correct_vs_counterfactual": comparison(
            methods,
            JOINT_COUNTERFACTUAL,
            JOINT,
            pair_to_state,
            state_network,
            args.bootstrap_reps,
            args.seed + 400,
        ),
    }
    primary = comparisons["factorized_vs_joint_primary"][
        "physical_state_statistics"
    ]
    factor_primary = summaries[FACTORIZED]["by_pair_type"][PRIMARY]
    joint_primary = summaries[JOINT]["by_pair_type"][PRIMARY]
    factor_cards = {row["instance_id"]: row["selected_card"] for row in factorized_records}
    joint_cards = {row["instance_id"]: row["selected_card"] for row in methods[JOINT]}
    card_changes = sum(factor_cards[key] != joint_cards[key] for key in factor_cards)
    mechanism_checks = {
        "predictions_not_identical": card_changes > 0,
        "factorized_primary_semantic_accuracy_higher": factor_primary[
            "semantic_accuracy"
        ]
        > joint_primary["semantic_accuracy"],
    }
    efficacy_checks = {
        "primary_physical_state_ci_lower_positive": primary[
            "physical_state_cluster_bootstrap_ci95"
        ][0]
        > 0,
        "primary_factorized_positive_both_networks": all(
            primary["by_network"][network]["improvement_mean"] > 0
            for network in ("33", "69")
        ),
    }
    safety_checks = {
        "factorized_feasible_100pct": summaries[FACTORIZED][
            "safe_feasible_rate"
        ]
        == 1.0,
        "factorized_constraint_violation_zero": summaries[FACTORIZED][
            "constraint_violation_rate"
        ]
        == 0.0,
    }
    integrity_checks = {
        "evaluation_only_no_training": True,
        "fresh_outcomes_not_used_for_fit": True,
        "fresh_record_ids_exact": len(factorized_records) == len(fresh_rows) == 192,
        "fresh_manifest_96_pairs": len(pair_to_state) == 96,
        "fresh_manifest_66_states": len(state_network) == 66,
        "state_manifest_nonempty": bool(state_manifest),
        "primary_48_pairs_are_48_states": primary["pair_clusters"]
        == primary["physical_state_clusters"]
        == 48,
        "joint_adapter_unchanged_on_disk": preflight.adapter_hash(
            args.joint_adapter
        )
        == manifest["adapters"]["joint_card"]["sha256"],
        "factorized_records_unchanged_on_disk": preflight.file_sha256(
            artifacts["factorized_confirmation_records"]["path"]
        )
        == artifacts["factorized_confirmation_records"]["sha256"],
    }
    output.mkdir(parents=True, exist_ok=False)
    records_path = output / "gridrank_dynamic_factorization_ablation_records.jsonl"
    write_records(
        records_path,
        {
            JOINT: methods[JOINT],
            JOINT_REMOVED: methods[JOINT_REMOVED],
            JOINT_COUNTERFACTUAL: methods[JOINT_COUNTERFACTUAL],
        },
    )
    gate_pass = all(
        [
            *integrity_checks.values(),
            *mechanism_checks.values(),
            *efficacy_checks.values(),
            *safety_checks.values(),
        ]
    )
    checks = {
        **{f"integrity:{key}": value for key, value in integrity_checks.items()},
        **{f"mechanism:{key}": value for key, value in mechanism_checks.items()},
        **{f"efficacy:{key}": value for key, value in efficacy_checks.items()},
        **{f"safety:{key}": value for key, value in safety_checks.items()},
    }
    result = {
        "msg": "GridRank matched factorized-vs-joint-card fresh ablation",
        "schema": "gridrank-dynamic-factorization-ablation-gate-v1",
        "experiment_id": preflight.EXPERIMENT_ID,
        "preflight_sha256": preflight.file_sha256(args.preflight_manifest),
        "evaluation_only": True,
        "training_performed": False,
        "fresh_outcomes_used_for_fit": False,
        "confirmation_reuse_disclosed": True,
        "freshness_boundary": manifest["freshness_boundary"],
        "primary_pair_type": PRIMARY,
        "matched_training_contract": manifest["matched_training_contract"],
        "summaries": summaries,
        "comparisons": comparisons,
        "selected_card_changed_rows": card_changes,
        "causal_score_max_abs_delta": {
            "joint_correct_vs_removed": joint.max_score_delta(
                removed_scores, correct_scores
            ),
            "joint_correct_vs_counterfactual": joint.max_score_delta(
                counterfactual_scores, correct_scores
            ),
        },
        "integrity_checks": integrity_checks,
        "mechanism_checks": mechanism_checks,
        "efficacy_checks": efficacy_checks,
        "safety_checks": safety_checks,
        "checks": checks,
        "factorization_gate_pass": gate_pass,
        "failed_checks": [key for key, value in checks.items() if not value],
        "records": {
            "path": str(records_path.resolve()),
            "sha256": preflight.file_sha256(records_path),
            "methods": sorted((JOINT, JOINT_REMOVED, JOINT_COUNTERFACTUAL)),
            "rows": 3 * len(fresh_rows),
        },
        "interpretation_boundary": (
            "This matched ablation isolates the semantic representation: a direct "
            "four-card joint interface versus two factorized objective scores and "
            "two factorized constraint scores. It does not establish that every "
            "possible non-factorized architecture would fail."
        ),
        "decision": (
            "authorize_joint_card_seed123_2025_replication"
            if gate_pass
            else "do_not_expand_joint_card_ablation"
        ),
    }
    gate_path = output / "gridrank_dynamic_factorization_ablation_gate.json"
    gate_path.write_text(
        json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps(result, ensure_ascii=False))
    if not gate_pass:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
