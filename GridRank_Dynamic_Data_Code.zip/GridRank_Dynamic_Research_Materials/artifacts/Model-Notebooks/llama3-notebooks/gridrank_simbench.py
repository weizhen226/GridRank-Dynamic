"""Gridrank simbench utilities."""

from __future__ import annotations

import copy
import hashlib
import importlib.metadata
import json
import math
import re
from collections import deque
from functools import lru_cache


PANDAPOWER_VERSION = "3.4.0"
SIMBENCH_MAJOR_MINOR = "1.6"
PREDECLARED_CODES = (
    "1-MV-rural--0-sw",
    "1-MV-semiurb--0-sw",
    "1-MV-urban--0-sw",
)
VMIN = 0.90
VMAX = 1.10
SBASE_MVA = 10.0
DEADBAND_PCT = 0.05
NOOP = "Action: none"
ACTION_RE = re.compile(
    r"^Action: Replace \((\d+), (\d+)\) with \((\d+), (\d+)\)$"
)


def _edge(a, b):
    return tuple(sorted((int(a), int(b))))


def _canonical(value):
    try:
        import numpy as np

        if isinstance(value, np.generic):
            value = value.item()
    except Exception:
        pass
    if value is None:
        return None
    if isinstance(value, bool):
        return value
    if isinstance(value, int):
        return int(value)
    if isinstance(value, float):
        return None if not math.isfinite(value) else round(float(value), 12)
    return str(value)


def _table_records(frame, columns):
    records = []
    for index in sorted(frame.index):
        row = {"index": _canonical(index)}
        for column in columns:
            if column in frame.columns:
                row[column] = _canonical(frame.at[index, column])
        records.append(row)
    return records


def simbench_version():
    return importlib.metadata.version("simbench")


def runtime_versions():
    import pandapower

    return {
        "pandapower": str(pandapower.__version__),
        "simbench": simbench_version(),
    }


def _check_runtime():
    versions = runtime_versions()
    if versions["pandapower"] != PANDAPOWER_VERSION:
        raise RuntimeError(
            f"SimBench benchmark requires pandapower {PANDAPOWER_VERSION}; "
            f"found {versions['pandapower']}"
        )
    if not versions["simbench"].startswith(SIMBENCH_MAJOR_MINOR + "."):
        raise RuntimeError(
            f"SimBench benchmark requires simbench {SIMBENCH_MAJOR_MINOR}.x; "
            f"found {versions['simbench']}"
        )
    return versions


def available_mv_codes():
    import simbench as sb

    values = sb.collect_all_simbench_codes()
    return tuple(sorted(str(value) for value in values if "-MV-" in str(value)))


def verify_predeclared_codes():
    available = set(available_mv_codes())
    missing = [code for code in PREDECLARED_CODES if code not in available]
    return {
        "predeclared_codes": list(PREDECLARED_CODES),
        "missing_codes": missing,
        "available_mv_code_count": len(available),
        "pass": not missing,
    }


@lru_cache(maxsize=None)
def _base_template(code):
    import pandapower.toolbox as toolbox
    import simbench as sb

    _check_runtime()
    if code not in PREDECLARED_CODES:
        raise ValueError(f"code is outside the predeclared suite: {code}")
    code_check = verify_predeclared_codes()
    if not code_check["pass"]:
        raise RuntimeError(f"predeclared SimBench code drift: {code_check}")
    net = sb.get_simbench_net(code)
    toolbox.create_continuous_bus_index(net, start=1)
    expected = list(range(1, len(net.bus) + 1))
    if list(sorted(map(int, net.bus.index))) != expected:
        raise RuntimeError(f"continuous bus indexing failed for {code}")
    return net


def base_network(code):
    return copy.deepcopy(_base_template(code))


def network_id(code):
    return "simbench:" + str(code)


def network_inventory(code, net=None):
    if net is None:
        net = _base_template(code)
    return {
        "buses": len(net.bus),
        "lines": len(net.line),
        "loads": len(net.load),
        "sgens": len(net.sgen),
        "generators": len(net.gen),
        "storages": len(net.storage),
        "trafos": len(net.trafo),
        "ext_grids": len(net.ext_grid),
        "switches": len(net.switch),
        "open_line_indices": list(open_line_indices(code, net)),
    }


def network_fingerprint(code, net=None):
    if net is None:
        net = _base_template(code)
    payload = {
        "simbench_code": code,
        "runtime": runtime_versions(),
        "bus": _table_records(net.bus, ("name", "vn_kv", "type", "in_service")),
        "line": _table_records(
            net.line,
            (
                "name", "from_bus", "to_bus", "length_km", "r_ohm_per_km",
                "x_ohm_per_km", "c_nf_per_km", "max_i_ka", "in_service",
            ),
        ),
        "trafo": _table_records(
            net.trafo,
            (
                "name", "hv_bus", "lv_bus", "sn_mva", "vn_hv_kv", "vn_lv_kv",
                "vk_percent", "vkr_percent", "tap_pos", "in_service",
            ),
        ),
        "load": _table_records(
            net.load, ("name", "bus", "p_mw", "q_mvar", "scaling", "in_service")
        ),
        "sgen": _table_records(
            net.sgen, ("name", "bus", "p_mw", "q_mvar", "scaling", "in_service")
        ),
        "gen": _table_records(
            net.gen, ("name", "bus", "p_mw", "vm_pu", "scaling", "in_service")
        ),
        "storage": _table_records(
            net.storage, ("name", "bus", "p_mw", "q_mvar", "scaling", "in_service")
        ),
        "ext_grid": _table_records(
            net.ext_grid, ("name", "bus", "vm_pu", "va_degree", "in_service")
        ),
        "switch": _table_records(
            net.switch, ("name", "bus", "element", "et", "closed", "type")
        ),
    }
    encoded = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()
    return hashlib.sha256(encoded).hexdigest()


def open_line_indices(code, net=None):
    if net is None:
        net = _base_template(code)
    opened = set()
    for _, row in net.switch.iterrows():
        if str(row.et) == "l" and not bool(row.closed):
            opened.add(int(row.element))
    for index, row in net.line.iterrows():
        if not bool(row.in_service):
            opened.add(int(index))
    return tuple(sorted(opened))


def line_edge(net, line_index):
    row = net.line.loc[int(line_index)]
    return _edge(row.from_bus, row.to_bus)


def source_roots(net):


    roots = tuple(sorted(set(map(
        int, net.trafo.loc[net.trafo.in_service, "lv_bus"]
    ))))
    if roots:
        return roots
    return tuple(sorted(map(int, net.ext_grid.loc[net.ext_grid.in_service, "bus"])))


def _trafo_is_closed(net, index):
    relevant = net.switch.loc[
        (net.switch.et.astype(str) == "t")
        & (net.switch.element.astype(int) == int(index))
    ]
    return bool(relevant.empty or relevant.closed.astype(bool).all())


def line_graph(code, net, open_lines):
    import networkx as nx

    graph = nx.Graph()


    branch_buses = set(source_roots(net))
    branch_buses.update(map(int, net.load.loc[net.load.in_service, "bus"]))
    for _, row in net.line.loc[net.line.in_service].iterrows():
        branch_buses.update((int(row.from_bus), int(row.to_bus)))
    graph.add_nodes_from(branch_buses)
    opened = set(map(int, open_lines))
    for index, row in net.line.loc[net.line.in_service].iterrows():
        if int(index) in opened:
            continue
        a, b = int(row.from_bus), int(row.to_bus)
        if graph.has_edge(a, b):
            raise RuntimeError(f"parallel active branch is outside protocol: {(a, b)}")
        graph.add_edge(a, b, kind="line", element=int(index))
    for index, row in net.switch.iterrows():
        if str(row.et) != "b" or not bool(row.closed):
            continue
        a, b = int(row.bus), int(row.element)
        if a not in branch_buses or b not in branch_buses:
            continue
        if a == b or graph.has_edge(a, b):
            continue
        graph.add_edge(a, b, kind="bus_switch", element=int(index))
    return graph


def topology_audit(code, net=None, open_lines=None):
    import networkx as nx

    if net is None:
        net = _base_template(code)
    if open_lines is None:
        open_lines = open_line_indices(code, net)
    graph = line_graph(code, net, open_lines)
    roots = source_roots(net)
    components = list(nx.connected_components(graph))
    component_for = {bus: i for i, buses in enumerate(components) for bus in buses}
    internal = []
    intersource = []
    for index in open_lines:
        if int(index) not in net.line.index:
            continue
        a, b = line_edge(net, index)
        if a not in component_for or b not in component_for:
            continue
        target = internal if component_for[a] == component_for[b] else intersource
        target.append(int(index))
    root_counts = [sum(root in buses for root in roots) for buses in components]
    active_load_buses = set(map(int, net.load.loc[net.load.in_service, "bus"]))
    supplied_buses = set().union(*(
        buses for buses in components if any(root in buses for root in roots)
    )) if components else set()
    checks = {
        "roots_present": bool(roots),
        "acyclic_forest": len(nx.cycle_basis(graph)) == 0,
        "all_components_have_source": all(value >= 1 for value in root_counts),
        "edge_count_is_forest": (
            graph.number_of_edges() == graph.number_of_nodes() - len(components)
        ),
        "all_active_loads_supplied": active_load_buses.issubset(supplied_buses),
        "has_internal_tie": bool(internal),
    }
    return {
        "nodes": graph.number_of_nodes(),
        "edges": graph.number_of_edges(),
        "components": len(components),
        "roots": list(roots),
        "root_counts": root_counts,
        "open_line_indices": list(map(int, open_lines)),
        "internal_tie_line_indices": sorted(internal),
        "intersource_open_line_indices": sorted(intersource),
        "checks": checks,
    }


@lru_cache(maxsize=None)
def complete_actions(code):
    import networkx as nx

    net = _base_template(code)
    base_open = set(open_line_indices(code, net))
    audit = topology_audit(code, net, base_open)
    structural = tuple(key for key in audit["checks"] if key != "has_internal_tie")
    if not all(audit["checks"][key] for key in structural):
        raise RuntimeError(f"base topology is outside the radial protocol: {audit}")
    graph = line_graph(code, net, base_open)
    actions = []
    for close_line in audit["internal_tie_line_indices"]:
        close_edge = line_edge(net, close_line)
        path = nx.shortest_path(graph, *close_edge)
        for a, b in zip(path, path[1:]):
            edge_data = graph[a][b]
            if edge_data.get("kind") != "line":
                continue
            open_line = int(edge_data["element"])
            open_edge = line_edge(net, open_line)
            new_open = (base_open - {close_line}) | {open_line}
            candidate = topology_audit(code, net, new_open)
            required = (
                "acyclic_forest", "all_components_have_source", "edge_count_is_forest",
                "all_active_loads_supplied",
            )
            if not all(candidate["checks"][key] for key in required):
                continue
            actions.append({
                "action": (
                    f"Action: Replace ({close_edge[0]}, {close_edge[1]}) "
                    f"with ({open_edge[0]}, {open_edge[1]})"
                ),
                "close_line": int(close_line),
                "open_line": int(open_line),
                "close_edge": list(close_edge),
                "open_edge": list(open_edge),
            })
    actions.sort(key=lambda item: item["action"])
    if len({item["action"] for item in actions}) != len(actions):
        raise RuntimeError(f"duplicate branch-exchange action in {code}")
    return tuple(actions)


def parse_action(code, action):
    if action == NOOP:
        return None
    match = ACTION_RE.fullmatch(str(action))
    if not match:
        raise ValueError(f"invalid action: {action!r}")
    allowed = {item["action"]: item for item in complete_actions(code)}
    if action not in allowed:
        raise ValueError(f"action outside complete K=1 pool for {code}: {action}")
    item = allowed[action]
    if _edge(match.group(1), match.group(2)) != tuple(item["close_edge"]):
        raise ValueError("parsed close edge disagrees with manifest")
    if _edge(match.group(3), match.group(4)) != tuple(item["open_edge"]):
        raise ValueError("parsed open edge disagrees with manifest")
    return item


def action_open_lines(code, action):
    opened = set(open_line_indices(code))
    if action == NOOP:
        return tuple(sorted(opened))
    item = parse_action(code, action)
    opened.remove(item["close_line"])
    opened.add(item["open_line"])
    return tuple(sorted(opened))


def apply_open_lines(code, net, opened):
    opened = set(map(int, opened))
    line_switches = net.switch.index[net.switch.et.astype(str) == "l"]
    net.switch.loc[line_switches, "closed"] = True
    net.line.loc[:, "in_service"] = True
    for line in opened:
        switches = sorted(map(int, net.switch.index[
            (net.switch.et.astype(str) == "l")
            & (net.switch.element.astype(int) == int(line))
        ]))
        if switches:
            net.switch.at[switches[0], "closed"] = False
        elif int(line) in net.line.index:
            net.line.at[int(line), "in_service"] = False
        else:
            raise RuntimeError(f"unknown line index {line} in {code}")


def _hash_unit(*parts):
    digest = hashlib.sha256("|".join(map(str, parts)).encode()).digest()
    return int.from_bytes(digest[:8], "big") / float(2**64 - 1)


def _finite_or(value, default):
    try:
        result = float(value)
    except Exception:
        return float(default)
    return result if math.isfinite(result) else float(default)


def operating_regime(state_index):
    return ("load_only", "moderate_der", "high_der")[int(state_index) % 3]


def state_network(code, state_index, scenario_seed):
    if int(state_index) < 0:
        raise ValueError("state_index must be non-negative")
    net = base_network(code)


    global_factor = 0.75 + 0.95 * _hash_unit(
        code, scenario_seed, state_index, "global"
    )
    zone_count = 12
    zone_factors = {
        zone: 0.65 + 0.70 * _hash_unit(code, scenario_seed, state_index, "zone", zone)
        for zone in range(zone_count)
    }
    for index, row in net.load.iterrows():
        bus = int(row.bus)
        base_scaling = _finite_or(row.get("scaling", 1.0), 1.0)
        local = 0.90 + 0.20 * _hash_unit(
            code, scenario_seed, state_index, "load", bus, index
        )
        scale = base_scaling * global_factor * zone_factors[bus % zone_count] * local
        net.load.at[index, "scaling"] = min(1.80, max(0.30, scale))


    regime = operating_regime(state_index)
    if len(net.sgen):
        if regime == "load_only":
            net.sgen.loc[:, "scaling"] = 0.0
        else:
            low, span = (0.45, 0.55) if regime == "moderate_der" else (0.95, 0.85)
            global_der = low + span * _hash_unit(
                code, scenario_seed, state_index, "der_global"
            )
            for index, row in net.sgen.iterrows():
                base_scaling = _finite_or(row.get("scaling", 1.0), 1.0)
                local = 0.85 + 0.30 * _hash_unit(
                    code, scenario_seed, state_index, "sgen", int(row.bus), index
                )
                net.sgen.at[index, "scaling"] = min(
                    1.80, max(0.0, base_scaling * global_der * local)
                )
    if len(net.gen):
        net.gen.loc[:, "scaling"] = 0.0
    if len(net.storage):
        net.storage.loc[:, "scaling"] = 0.0
    apply_open_lines(code, net, open_line_indices(code, net))
    return net


def bus_demands(net):
    values = {int(bus): 0j for bus in net.bus.index}
    for _, row in net.load.loc[net.load.in_service].iterrows():
        scaling = _finite_or(row.get("scaling", 1.0), 1.0)
        values[int(row.bus)] += complex(float(row.p_mw), float(row.q_mvar)) * scaling
    for table_name in ("sgen", "storage"):
        table = getattr(net, table_name)
        for _, row in table.loc[table.in_service].iterrows():
            scaling = _finite_or(row.get("scaling", 1.0), 1.0)
            values[int(row.bus)] -= complex(float(row.p_mw), float(row.q_mvar)) * scaling
    return values


def state_identity(code, net, state_index, scenario_seed):
    demand = bus_demands(net)
    payload = {
        "network_id": network_id(code),
        "network_fingerprint": network_fingerprint(code),
        "state_index": int(state_index),
        "scenario_seed": int(scenario_seed),
        "operating_regime": operating_regime(state_index),
        "open_lines": [list(line_edge(net, item)) for item in open_line_indices(code, net)],
        "net_demand_mva": [
            [int(bus), round(value.real, 12), round(value.imag, 12)]
            for bus, value in sorted(demand.items())
        ],
        "exchange_budget": 1,
        "vmin": VMIN,
        "vmax": VMAX,
    }
    encoded = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()
    return hashlib.sha256(encoded).hexdigest()


def state_text(code, net):
    demand = bus_demands(net)
    n_bus = len(net.bus)
    bin_count = 32
    aggregates = [0j for _ in range(bin_count)]
    for bus, value in demand.items():
        index = min(bin_count - 1, (int(bus) - 1) * bin_count // max(1, n_bus))
        aggregates[index] += value
    load_text = ",".join(
        f"({value.real / SBASE_MVA:.4f}{value.imag / SBASE_MVA:+.4f}j)"
        for value in aggregates
    )
    total = sum(demand.values())
    opened = ",".join(
        f"({a},{b})"
        for a, b in sorted(line_edge(net, item) for item in open_line_indices(code, net))
    )
    return (
        f"Power Distribution Network: Busses={n_bus}, Sources={len(source_roots(net))}, "
        f"Existing Open Lines=[{opened}], System Load Aggregates(32 bins)=[{load_text}], "
        f"Total Load pu=({total.real / SBASE_MVA:.4f}{total.imag / SBASE_MVA:+.4f}j)\n"
        "Budget: N_branch_exchanges <= 1\n"
        f"Voltage bounds: {VMIN:.2f} <= Vm_pu <= {VMAX:.2f}"
    )


def select_action_pool(code, state_sha, size, candidate_seed):
    full = list(complete_actions(code))
    if size <= 0 or size > len(full):
        raise ValueError(f"candidate pool size must be in [1,{len(full)}]")
    ranked = sorted(
        full,
        key=lambda item: hashlib.sha256(
            f"{candidate_seed}|{code}|{state_sha}|{item['action']}".encode()
        ).digest(),
    )
    return ranked[:size]


def _line_impedance(net):
    return {
        int(index): (
            float(row.r_ohm_per_km) * float(row.length_km),
            float(row.x_ohm_per_km) * float(row.length_km),
        )
        for index, row in net.line.iterrows()
    }


def _median_positive(values):
    values = sorted(abs(float(value)) for value in values if abs(float(value)) > 0)
    return values[len(values) // 2] if values else 1.0


def _feature_summary(code, net, action):
    opened = action_open_lines(code, action)
    graph = line_graph(code, net, opened)
    roots = source_roots(net)
    impedance = _line_impedance(net)
    demands = bus_demands(net)
    parent = {}
    depth = {}
    order = []
    for root in roots:
        parent[root] = None
        depth[root] = 0
    queue = deque(roots)
    while queue:
        bus = queue.popleft()
        order.append(bus)
        for neighbor in sorted(graph.neighbors(bus)):
            if neighbor in parent:
                continue
            parent[neighbor] = bus
            depth[neighbor] = depth[bus] + 1
            queue.append(neighbor)
    active_load_buses = set(map(int, net.load.loc[net.load.in_service, "bus"]))
    if not active_load_buses.issubset(parent):
        raise RuntimeError("feature forest does not reach every active load")
    downstream = {bus: demands.get(bus, 0j) for bus in graph.nodes}
    for bus in reversed(order):
        if parent[bus] is not None:
            downstream[parent[bus]] += downstream[bus]
    positive_p = [value.real for value in demands.values() if value.real > 0]
    positive_q = [value.imag for value in demands.values() if value.imag > 0]
    p_scale = sum(positive_p) / max(1, len(positive_p))
    q_scale = sum(positive_q) / max(1, len(positive_q))
    total_p = max(sum(positive_p), 1e-8)
    total_q = max(sum(positive_q), 1e-8)
    nominal = sorted(float(value) for value in net.bus.vn_kv if float(value) > 1.0)
    nominal_kv = nominal[len(nominal) // 2] if nominal else 20.0
    zbase = nominal_kv**2 / SBASE_MVA
    approximate_drop = {root: 0.0 for root in roots}
    resistance_scale = _median_positive(value[0] for value in impedance.values())
    reactance_scale = _median_positive(value[1] for value in impedance.values())
    loss_proxy = 0.0
    for bus in order:
        if parent[bus] is None:
            continue
        edge_data = graph[bus][parent[bus]]
        if edge_data.get("kind") == "line":
            resistance, reactance = impedance[int(edge_data["element"])]
        else:
            resistance, reactance = 0.0, 0.0
        flow = downstream[bus] / SBASE_MVA
        approximate_drop[bus] = approximate_drop[parent[bus]] + (
            resistance * flow.real + reactance * flow.imag
        ) / max(zbase, 1e-8)
        loss_proxy += abs(resistance) / resistance_scale * (
            (downstream[bus].real / total_p) ** 2
            + (downstream[bus].imag / total_q) ** 2
        )
    parsed = parse_action(code, action)
    close_edge = tuple(parsed["close_edge"]) if parsed else ()
    open_edge = tuple(parsed["open_edge"]) if parsed else ()
    n_bus = len(net.bus)

    def mean_at(edge, getter):
        values = [getter(bus) for bus in edge]
        return sum(values) / len(values) if values else 0.0

    if parsed:
        close_r, close_x = impedance[parsed["close_line"]]
        open_r, open_x = impedance[parsed["open_line"]]
        action_values = {
            "close_u": close_edge[0] / n_bus,
            "close_v": close_edge[1] / n_bus,
            "close_span": abs(close_edge[1] - close_edge[0]) / n_bus,
            "open_u": open_edge[0] / n_bus,
            "open_v": open_edge[1] / n_bus,
            "open_span": abs(open_edge[1] - open_edge[0]) / n_bus,
            "close_r": close_r / resistance_scale,
            "close_x": close_x / reactance_scale,
            "open_r": open_r / resistance_scale,
            "open_x": open_x / reactance_scale,
        }
    else:
        action_values = {key: 0.0 for key in (
            "close_u", "close_v", "close_span", "open_u", "open_v", "open_span",
            "close_r", "close_x", "open_r", "open_x",
        )}
    return {
        "candidate_type": "noop" if action == NOOP else "exchange",
        **action_values,
        "tree_depth_max": max(depth.values()) / max(1, n_bus - 1),
        "downstream_p_max": max(value.real / total_p for value in downstream.values()),
        "downstream_q_max": max(value.imag / total_q for value in downstream.values()),
        "voltage_drop_proxy_max": max(approximate_drop.values()),
        "loss_proxy": loss_proxy,
        "close_local_p_mean": mean_at(
            close_edge, lambda bus: demands.get(bus, 0j).real / max(p_scale, 1e-8)
        ),
        "close_downstream_p_mean": mean_at(
            close_edge, lambda bus: downstream.get(bus, 0j).real / total_p
        ),
        "close_drop_mean": mean_at(
            close_edge, lambda bus: approximate_drop.get(bus, 0.0)
        ),
        "open_local_p_mean": mean_at(
            open_edge, lambda bus: demands.get(bus, 0j).real / max(p_scale, 1e-8)
        ),
        "open_downstream_p_mean": mean_at(
            open_edge, lambda bus: downstream.get(bus, 0j).real / total_p
        ),
        "open_drop_mean": mean_at(
            open_edge, lambda bus: approximate_drop.get(bus, 0.0)
        ),
    }


def candidate_feature_texts(code, net, actions):
    baseline = _feature_summary(code, net, NOOP)
    baseline_loss = max(abs(float(baseline["loss_proxy"])), 1e-8)
    output = {}
    for action in [NOOP, *actions]:
        item = _feature_summary(code, net, action)
        delta = 100.0 * (baseline["loss_proxy"] - item["loss_proxy"]) / baseline_loss
        ordered = [
            ("type", item["candidate_type"]),
            ("close_uv", f'{item["close_u"]:.4f},{item["close_v"]:.4f}'),
            ("open_uv", f'{item["open_u"]:.4f},{item["open_v"]:.4f}'),
            ("close_span", f'{item["close_span"]:.4f}'),
            ("open_span", f'{item["open_span"]:.4f}'),
            ("close_rx", f'{item["close_r"]:.4f},{item["close_x"]:.4f}'),
            ("open_rx", f'{item["open_r"]:.4f},{item["open_x"]:.4f}'),
            ("tree_depth_max", f'{item["tree_depth_max"]:.4f}'),
            ("downstream_pq_max", f'{item["downstream_p_max"]:.4f},{item["downstream_q_max"]:.4f}'),
            ("voltage_drop_proxy_max", f'{item["voltage_drop_proxy_max"]:.6f}'),
            ("loss_proxy", f'{item["loss_proxy"]:.6f}'),
            ("loss_proxy_delta_pct", f'{delta:.4f}'),
            ("close_endpoint_local_p", f'{item["close_local_p_mean"]:.4f}'),
            ("close_endpoint_downstream_p", f'{item["close_downstream_p_mean"]:.4f}'),
            ("close_endpoint_drop", f'{item["close_drop_mean"]:.6f}'),
            ("open_endpoint_local_p", f'{item["open_local_p_mean"]:.4f}'),
            ("open_endpoint_downstream_p", f'{item["open_downstream_p_mean"]:.4f}'),
            ("open_endpoint_drop", f'{item["open_drop_mean"]:.6f}'),
        ]
        output[action] = "; ".join(f"{key}={value}" for key, value in ordered)
    return output


def proxy_score(candidate_feature_text):
    match = re.search(
        r"(?:^|; )loss_proxy_delta_pct=(-?\d+(?:\.\d+)?)",
        str(candidate_feature_text),
    )
    if not match:
        raise ValueError("candidate feature text lacks loss_proxy_delta_pct")
    return float(match.group(1))


def _run_power_flow(code, net, opened):
    import pandapower as pp

    apply_open_lines(code, net, opened)
    topology = topology_audit(code, net, opened)
    required = (
        "acyclic_forest", "all_components_have_source", "edge_count_is_forest",
        "all_active_loads_supplied",
    )
    radial = all(topology["checks"][key] for key in required)
    try:
        pp.runpp(
            net, algorithm="nr", calculate_voltage_angles=False, init="auto",
            max_iteration=50, tolerance_mva=1e-8, check_connectivity=True,
            numba=False,
        )
    except Exception as exc:
        return {
            "feedback_valid": True, "converged": False, "feasible": False,
            "reason": f"power_flow:{type(exc).__name__}", "loss_kw": None,
            "min_vm_pu": None, "max_vm_pu": None, "radial": radial,
        }
    voltages = [float(value) for value in net.res_bus.vm_pu if math.isfinite(float(value))]
    if not voltages:
        return {
            "feedback_valid": False, "converged": bool(net.converged),
            "feasible": False, "reason": "missing_voltage", "loss_kw": None,
            "min_vm_pu": None, "max_vm_pu": None, "radial": radial,
        }
    line_loss = float(net.res_line.pl_mw.sum()) if len(net.res_line) else 0.0
    trafo_loss = float(net.res_trafo.pl_mw.sum()) if len(net.res_trafo) else 0.0
    loss_kw = 1000.0 * (line_loss + trafo_loss)
    minimum, maximum = min(voltages), max(voltages)
    voltage_ok = minimum >= VMIN - 1e-9 and maximum <= VMAX + 1e-9
    feasible = bool(net.converged and radial and voltage_ok and math.isfinite(loss_kw))
    reason = "ok" if feasible else (
        "non_radial" if not radial else "voltage" if not voltage_ok else "nonconverged"
    )
    return {
        "feedback_valid": True, "converged": bool(net.converged),
        "feasible": feasible, "reason": reason, "loss_kw": loss_kw,
        "min_vm_pu": minimum, "max_vm_pu": maximum, "radial": radial,
    }


def score_state(code, state_index, scenario_seed, actions):
    net = state_network(code, state_index, scenario_seed)
    anchor = _run_power_flow(code, copy.deepcopy(net), open_line_indices(code, net))
    if not anchor["feedback_valid"] or not anchor["feasible"]:
        return anchor, []
    outcomes = []
    for action in actions:
        item = _run_power_flow(code, copy.deepcopy(net), action_open_lines(code, action))
        reduction = None
        if item["feedback_valid"] and item["loss_kw"] is not None:
            reduction = 100.0 * (anchor["loss_kw"] - item["loss_kw"]) / anchor["loss_kw"]
        item = dict(item)
        item["action"] = action
        item["reduction_pct"] = reduction
        outcomes.append(item)
    return anchor, outcomes
