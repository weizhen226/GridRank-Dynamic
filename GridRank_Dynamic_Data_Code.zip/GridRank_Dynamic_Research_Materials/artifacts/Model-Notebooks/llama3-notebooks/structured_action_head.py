"""Structured action head utilities."""

import json
import math
from pathlib import Path

from state_to_delta_csv import delta_label


FEATURE_DIM = 10


def _edge(edge):
    return tuple(sorted(int(value) for value in edge))


def _edge_metadata(engine):
    table = {}
    resistances = []
    reactances = []
    for a, b, resistance, reactance in engine.ALL_BRANCHES:
        key = engine._key(a, b)
        resistance = float(resistance)
        reactance = float(reactance)
        table[key] = (resistance, reactance)
        resistances.append(abs(resistance))
        reactances.append(abs(reactance))

    def robust_scale(values):
        positive = sorted(value for value in values if value > 0)
        return positive[len(positive) // 2] if positive else 1.0

    return table, robust_scale(resistances), robust_scale(reactances)


def action_features(engine, remove_edge, add_edge):
    
    remove_edge = _edge(remove_edge)
    add_edge = _edge(add_edge)
    table, resistance_scale, reactance_scale = _edge_metadata(engine)
    if remove_edge not in table or add_edge not in table:
        raise ValueError(f"unknown branch in action: remove={remove_edge}, add={add_edge}")
    remove_r, remove_x = table[remove_edge]
    add_r, add_x = table[add_edge]
    n_bus = float(engine.N_BUS)
    return [
        remove_edge[0] / n_bus,
        remove_edge[1] / n_bus,
        abs(remove_edge[1] - remove_edge[0]) / n_bus,
        add_edge[0] / n_bus,
        add_edge[1] / n_bus,
        abs(add_edge[1] - add_edge[0]) / n_bus,
        remove_r / resistance_scale,
        remove_x / reactance_scale,
        add_r / resistance_scale,
        add_x / reactance_scale,
    ]


def enumerate_radial_actions(engine, existing_open):
    
    existing = tuple(sorted(engine._key(*edge) for edge in existing_open))
    existing_set = set(existing)
    active = sorted(
        engine._key(a, b) for a, b, _, _ in engine.ALL_BRANCHES
        if engine._key(a, b) not in existing_set
    )
    actions = []
    for remove_edge in existing:
        for add_edge in active:
            candidate = tuple(sorted((existing_set - {remove_edge}) | {add_edge}))
            if not engine._radial_ok(candidate):
                continue
            actions.append({
                "action": delta_label(existing, candidate),
                "remove_edge": list(remove_edge),
                "add_edge": list(add_edge),
                "features": action_features(engine, remove_edge, add_edge),
            })
    actions.sort(key=lambda item: item["action"])
    return actions


def build_head(hidden_size, action_dim=128, feature_dim=FEATURE_DIM):
    import torch

    class StructuredActionHead(torch.nn.Module):
        def __init__(self):
            super().__init__()
            self.prompt_projection = torch.nn.Sequential(
                torch.nn.LayerNorm(hidden_size),
                torch.nn.Linear(hidden_size, action_dim),
                torch.nn.Tanh(),
            )
            self.action_projection = torch.nn.Sequential(
                torch.nn.Linear(feature_dim, action_dim),
                torch.nn.GELU(),
                torch.nn.Linear(action_dim, action_dim),
            )
            self.action_bias = torch.nn.Sequential(
                torch.nn.Linear(feature_dim, action_dim // 2),
                torch.nn.GELU(),
                torch.nn.Linear(action_dim // 2, 1),
            )
            self.gate = torch.nn.Linear(action_dim, 1)

        def forward(self, prompt_hidden, candidate_features):
            dtype = self.prompt_projection[0].weight.dtype
            prompt_hidden = prompt_hidden.to(dtype=dtype)
            candidate_features = candidate_features.to(dtype=dtype)
            query = self.prompt_projection(prompt_hidden)
            keys = self.action_projection(candidate_features)
            scores = (keys * query.unsqueeze(0)).sum(dim=-1) / math.sqrt(action_dim)
            scores = scores + self.action_bias(candidate_features).squeeze(-1)
            gate_logit = self.gate(query).squeeze(-1)
            return gate_logit, scores

    return StructuredActionHead()


def prompt_hidden(model, tokenizer, prompt, max_prompt_len):
    
    formatted = f"<|user|>\n{prompt}</s>\n<|assistant|>\n"
    encoded = tokenizer(
        formatted,
        return_tensors="pt",
        truncation=True,
        max_length=max_prompt_len,
    )
    device = next(model.parameters()).device
    encoded = {key: value.to(device) for key, value in encoded.items()}
    causal_lm = model.get_base_model()
    backbone = getattr(causal_lm, "model", None)
    if backbone is None:
        raise RuntimeError(f"unsupported causal LM backbone: {type(causal_lm).__name__}")
    output = backbone(**encoded, use_cache=False, return_dict=True)
    return output.last_hidden_state[0, -1, :]


def save_head(head, output_dir, metadata):
    import torch

    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    torch.save(head.state_dict(), output_dir / "action_head.pt")
    with open(output_dir / "action_head_config.json", "w", encoding="utf-8") as handle:
        json.dump(metadata, handle, indent=2, ensure_ascii=False)


def load_head(head_dir, hidden_size, device):
    import torch

    head_dir = Path(head_dir)
    with open(head_dir / "action_head_config.json", encoding="utf-8") as handle:
        metadata = json.load(handle)
    if int(metadata["hidden_size"]) != int(hidden_size):
        raise ValueError(
            f"hidden-size mismatch: checkpoint={metadata['hidden_size']} model={hidden_size}"
        )
    head = build_head(
        hidden_size,
        action_dim=int(metadata["action_dim"]),
        feature_dim=int(metadata["feature_dim"]),
    ).to(device)
    state = torch.load(head_dir / "action_head.pt", map_location=device, weights_only=True)
    head.load_state_dict(state)
    return head, metadata
