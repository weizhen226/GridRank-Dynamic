"""Train GridRank dynamic factorized."""

from __future__ import annotations

import argparse
import gc
import json
import random
from pathlib import Path
from types import SimpleNamespace

import preflight_gridrank_dynamic_benchmark as benchmark
import preflight_gridrank_dynamic_factorized as preflight
import preflight_gridrank_dynamic_policy as joint_preflight
import train_gridrank_dynamic_policy as joint
import train_gridrank_select as select
from gridrank_dynamic_factorized_llm import (
    PRIMITIVES, compose_card_scores, primitive_scores, selected_axes,
)
from gridrank_dynamic_llm import oracle_card_id


WITHHELD_COMPOSITION = "maintenance_voltage"


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--train_jsonl", required=True)
    parser.add_argument("--validation_jsonl", required=True)
    parser.add_argument("--pair_summary", required=True)
    parser.add_argument("--benchmark_manifest", required=True)
    parser.add_argument("--joint_preflight", required=True)
    parser.add_argument("--joint_gate", required=True)
    parser.add_argument("--preflight_manifest", required=True)
    parser.add_argument("--resume_adapter_path", required=True)
    parser.add_argument("--sft_adapter_path", required=True)
    parser.add_argument("--output_dir", required=True)
    parser.add_argument("--base_model", required=True)
    parser.add_argument("--max_length", type=int, required=True)
    parser.add_argument("--primitive_batch_size", type=int, required=True)
    parser.add_argument("--epochs", type=int, required=True)
    parser.add_argument("--learning_rate", type=float, required=True)
    parser.add_argument("--grad_accum", type=int, required=True)
    parser.add_argument("--max_grad_norm", type=float, required=True)
    parser.add_argument("--target_temperature", type=float, required=True)
    parser.add_argument("--lambda_objective", type=float, required=True)
    parser.add_argument("--lambda_constraint", type=float, required=True)
    parser.add_argument("--lambda_physics", type=float, required=True)
    parser.add_argument("--lambda_hard", type=float, required=True)
    parser.add_argument("--hard_margin", type=float, required=True)
    parser.add_argument("--beta_reference", type=float, required=True)
    parser.add_argument("--seed", type=int, required=True)
    parser.add_argument("--gradient_checkpointing", type=int, choices=(0, 1), required=True)
    parser.add_argument("--bootstrap_reps", type=int, required=True)
    return parser.parse_args()


def primitive_score_cache(model, tokenizer, rows, args, adapter, condition="correct"):
    model.set_adapter(adapter)
    counterfactual = (
        joint.counterfactual_texts(rows)
        if condition == "instruction_counterfactual" else {}
    )
    output = {}
    for row in rows:
        value = joint.condition_row(row, condition, counterfactual)
        output[row["instance_id"]] = primitive_scores(
            model, tokenizer, value,
            max_length=args.max_length,
            primitive_batch_size=args.primitive_batch_size,
            require_grad=False,
        ).detach().float().cpu()
    model.set_adapter("default")
    return output


def composed_score_cache(cache):
    return {key: compose_card_scores(value) for key, value in cache.items()}


def axis_indices(row):
    target = benchmark.semantic_target(row)
    return {
        "objective": 0 if target["objective"] == "loss" else 1,
        "constraint": 1 if target["hard_constraint"] else 0,
    }


def loss_terms(scores, row, reference_scores, args):
    import torch
    import torch.nn.functional as functional

    indices = axis_indices(row)
    objective_scores = scores[:2].float()
    constraint_scores = scores[2:].float()
    objective_loss = functional.cross_entropy(
        objective_scores.unsqueeze(0),
        torch.tensor([indices["objective"]], device=scores.device),
    )
    constraint_loss = functional.cross_entropy(
        constraint_scores.unsqueeze(0),
        torch.tensor([indices["constraint"]], device=scores.device),
    )
    objective_wrong = 1 - indices["objective"]
    constraint_wrong = 1 - indices["constraint"]
    objective_hard = functional.softplus(
        args.hard_margin
        - (objective_scores[indices["objective"]] - objective_scores[objective_wrong])
    )
    constraint_hard = functional.softplus(
        args.hard_margin
        - (constraint_scores[indices["constraint"]] - constraint_scores[constraint_wrong])
    )
    hard = 0.5 * (objective_hard + constraint_hard)

    card_scores = compose_card_scores(scores.float())
    outcomes = joint_preflight.card_outcomes(row)
    target = torch.tensor(
        joint_preflight.physics_target(outcomes, args.target_temperature),
        dtype=torch.float32, device=scores.device,
    )
    physics_listwise = -(target * torch.log_softmax(card_scores, dim=0)).sum()

    reference = reference_scores.to(scores.device).float()
    reference_kl_parts = []
    for policy_axis, reference_axis in (
        (objective_scores, reference[:2]),
        (constraint_scores, reference[2:]),
    ):
        log_policy = torch.log_softmax(policy_axis, dim=0)
        probability = torch.softmax(policy_axis, dim=0)
        log_reference = torch.log_softmax(reference_axis, dim=0)
        reference_kl_parts.append(
            (probability * (log_policy - log_reference)).sum()
        )
    reference_kl = 0.5 * sum(reference_kl_parts)
    total = (
        args.lambda_objective * objective_loss
        + args.lambda_constraint * constraint_loss
        + args.lambda_physics * physics_listwise
        + args.lambda_hard * hard
        + args.beta_reference * reference_kl
    )
    if not bool(torch.isfinite(total)):
        raise FloatingPointError(f"non-finite factorized loss: {row['instance_id']}")
    return {
        "total": total,
        "objective_loss": objective_loss,
        "constraint_loss": constraint_loss,
        "physics_listwise": physics_listwise,
        "hard": hard,
        "reference_kl": reference_kl,
    }


def train_replay(model, tokenizer, rows, references, default_lora, reference_lora, args):
    

    import torch

    parameters = [parameter for _, parameter in default_lora]
    optimizer = torch.optim.AdamW(parameters, lr=args.learning_rate, weight_decay=0.0)
    rng = random.Random(args.seed + 2701)
    history, first_gradient = [], None
    optimizer_steps = primitive_backward_passes = 0
    max_replay_score_delta = 0.0
    tolerance = 1e-4
    metric_names = (
        "total", "objective_loss", "constraint_loss", "physics_listwise",
        "hard", "reference_kl",
    )
    for epoch in range(1, args.epochs + 1):
        schedule = list(rows)
        rng.shuffle(schedule)
        optimizer.zero_grad(set_to_none=True)
        epoch_records = []
        for micro, row in enumerate(schedule, start=1):
            scores = primitive_scores(
                model, tokenizer, row,
                max_length=args.max_length,
                primitive_batch_size=args.primitive_batch_size,
                require_grad=False,
            )
            leaf = scores.detach().float().requires_grad_(True)
            terms = loss_terms(leaf, row, references[row["instance_id"]], args)
            coefficients = torch.autograd.grad(terms["total"], leaf)[0].detach()
            epoch_records.append({key: float(terms[key].detach()) for key in metric_names})
            for index, primitive in enumerate(PRIMITIVES):
                replayed = primitive_scores(
                    model, tokenizer, row,
                    max_length=args.max_length,
                    primitive_batch_size=1,
                    require_grad=True,
                    primitives=[primitive],
                )[0].float()
                delta = abs(float(replayed.detach()) - float(scores[index]))
                max_replay_score_delta = max(max_replay_score_delta, delta)
                if delta > tolerance:
                    raise RuntimeError(
                        f"non-deterministic primitive replay row={row['instance_id']} "
                        f"primitive={primitive['primitive_id']} delta={delta}"
                    )
                (replayed * coefficients[index] / args.grad_accum).backward()
                primitive_backward_passes += 1
                del replayed
            if first_gradient is None:
                first_gradient = select.gradient_audit(default_lora, reference_lora)
                if (
                    first_gradient["nonzero_gradient_tensors"] <= 0
                    or not first_gradient["finite"]
                    or first_gradient["reference_gradient_tensors"] != 0
                ):
                    raise RuntimeError(f"first-gradient audit failed: {first_gradient}")
            if micro % args.grad_accum == 0:
                select.optimizer_step(optimizer, parameters, args.max_grad_norm)
                optimizer_steps += 1
            if micro == 1 or micro % 20 == 0 or micro == len(schedule):
                print(json.dumps({
                    "msg": "GridRank factorized primitive-gradient replay",
                    "epoch": epoch, "rows_complete": micro,
                    "rows_total": len(schedule),
                    "primitive_backward_passes": primitive_backward_passes,
                    "max_replay_score_delta": max_replay_score_delta,
                }, ensure_ascii=False), flush=True)
            del scores, leaf, terms, coefficients
        remainder = len(schedule) % args.grad_accum
        if remainder:
            scale = args.grad_accum / remainder
            for parameter in parameters:
                if parameter.grad is not None:
                    parameter.grad.mul_(scale)
            select.optimizer_step(optimizer, parameters, args.max_grad_norm)
            optimizer_steps += 1
        record = {
            "epoch": epoch,
            **{
                key: sum(value[key] for value in epoch_records) / len(epoch_records)
                for key in metric_names
            },
            "optimizer_steps_total": optimizer_steps,
        }
        history.append(record)
        print(json.dumps({"msg": "GridRank factorized epoch", **record}, ensure_ascii=False), flush=True)
    return {
        "objective": (
            "objective-axis CE + constraint-axis CE + composed-card AC-regret "
            "listwise + smooth per-axis margins + frozen-reference KL"
        ),
        "history": history,
        "first_gradient": first_gradient,
        "optimizer_steps": optimizer_steps,
        "gradient_strategy": "exact_factorized_primitive_score_gradient_replay",
        "primitive_backward_passes": primitive_backward_passes,
        "max_replay_score_delta": max_replay_score_delta,
        "replay_tolerance": tolerance,
    }


def axis_summary(rows, primitive_cache):
    values = []
    for row in rows:
        predicted = selected_axes(primitive_cache[row["instance_id"]])
        target = benchmark.semantic_target(row)
        objective_ok = predicted["objective"] == target["objective"]
        constraint_ok = predicted["hard_constraint"] == target["hard_constraint"]
        values.append({
            "network": str(row["network_id"]),
            "pair_type": row["pair_type"],
            "objective_ok": objective_ok,
            "constraint_ok": constraint_ok,
            "joint_ok": objective_ok and constraint_ok,
        })

    def compact(selected):
        n = len(selected)
        if not n:
            return {
                "n": 0, "objective_accuracy": None,
                "constraint_accuracy": None, "joint_axis_accuracy": None,
            }
        return {
            "n": n,
            "objective_accuracy": sum(value["objective_ok"] for value in selected) / n,
            "constraint_accuracy": sum(value["constraint_ok"] for value in selected) / n,
            "joint_axis_accuracy": sum(value["joint_ok"] for value in selected) / n,
        }

    result = compact(values)
    result["by_network"] = {
        network: compact([value for value in values if value["network"] == network])
        for network in ("33", "69")
    }
    result["by_pair_type"] = {
        pair_type: compact([value for value in values if value["pair_type"] == pair_type])
        for pair_type in ("objective", "maintenance_loss", "maintenance_voltage")
    }
    return result


def positive(value):
    return value is not None and value > 0


def nonnegative(value):
    return value is not None and value >= 0


def main():
    import torch
    import grpo_train as training

    args = parse_args()
    output = Path(args.output_dir)
    if output.exists():
        raise FileExistsError(f"refusing to overwrite output: {output}")
    verify_args = SimpleNamespace(**vars(args), output=args.preflight_manifest)
    preflight.verify(verify_args)
    manifest = json.load(open(args.preflight_manifest, encoding="utf-8"))
    if not torch.cuda.is_available():
        raise RuntimeError("GridRank factorized dynamic-policy stage requires CUDA")
    random.seed(args.seed)
    torch.manual_seed(args.seed)
    torch.cuda.manual_seed_all(args.seed)
    train_rows = joint.rows_by_ids(
        args.train_jsonl, manifest["selection"]["train_row_ids"]
    )
    validation_rows = joint.rows_by_ids(
        args.validation_jsonl, manifest["selection"]["validation_row_ids"]
    )
    composition_rows = joint.rows_by_ids(
        args.validation_jsonl, manifest["selection"]["composition_row_ids"]
    )

    model, tokenizer = training.build_model_and_tokenizer(args)
    model.load_adapter(args.sft_adapter_path, adapter_name="sft_control", is_trainable=False)
    model.set_adapter("default")
    default_lora = [
        (name, parameter) for name, parameter in model.named_parameters()
        if "lora_" in name and ".default." in name
    ]
    reference_lora = [
        (name, parameter) for name, parameter in model.named_parameters()
        if "lora_" in name and ".reference." in name
    ]
    sft_lora = [
        (name, parameter) for name, parameter in model.named_parameters()
        if "lora_" in name and ".sft_control." in name
    ]
    if not default_lora or not reference_lora or not sft_lora:
        raise RuntimeError("policy, frozen reference, and SFT control adapters are required")
    for _, parameter in default_lora:
        parameter.requires_grad_(True)
    for _, parameter in [*reference_lora, *sft_lora]:
        parameter.requires_grad_(False)
    equality = select.adapter_initial_equality(default_lora, reference_lora)
    if not equality["same_tensor_set"] or equality["changed_tensors"] != 0:
        raise RuntimeError(f"policy/reference adapter mismatch: {equality}")

    policy_before = select.parameter_copy(default_lora)
    reference_before = select.parameter_copy(reference_lora)
    sft_before = select.parameter_copy(sft_lora)
    reference_train = primitive_score_cache(
        model, tokenizer, train_rows, args, "reference"
    )
    frozen_validation = primitive_score_cache(
        model, tokenizer, validation_rows, args, "reference"
    )
    sft_validation = primitive_score_cache(
        model, tokenizer, validation_rows, args, "sft_control"
    )
    gc.collect()
    torch.cuda.empty_cache()
    training_result = train_replay(
        model, tokenizer, train_rows, reference_train,
        default_lora, reference_lora, args,
    )
    aligned = primitive_score_cache(
        model, tokenizer, validation_rows, args, "default", "correct"
    )
    removed = primitive_score_cache(
        model, tokenizer, validation_rows, args, "default", "instruction_removed"
    )
    counterfactual = primitive_score_cache(
        model, tokenizer, validation_rows, args, "default", "instruction_counterfactual"
    )
    policy_delta = select.parameter_delta(default_lora, policy_before)
    reference_delta = select.parameter_delta(reference_lora, reference_before)
    sft_delta = select.parameter_delta(sft_lora, sft_before)
    score_delta = joint.max_score_delta(frozen_validation, aligned)

    train_all = benchmark.load_rows(args.train_jsonl, "train")
    full_text = benchmark.fit_text_parser(train_all, 20260826)
    withheld_text = benchmark.fit_text_parser(
        [row for row in train_all if row["pair_type"] != WITHHELD_COMPOSITION],
        20260926,
    )
    predictions = {
        "fixed_loss_lindistflow": benchmark.fixed_predictions(validation_rows),
        "frozen_rule_parser_lindistflow": benchmark.rule_predictions(validation_rows),
        "tfidf_logreg_lindistflow": benchmark.predict_text_parser(full_text, validation_rows),
        "tfidf_logreg_withheld_composition": benchmark.predict_text_parser(
            withheld_text, validation_rows
        ),
        "oracle_structured_lindistflow": benchmark.oracle_predictions(validation_rows),
    }
    records = {
        name: joint.records_from_predictions(validation_rows, value, name)
        for name, value in predictions.items()
    }
    composed = {
        "sft_factorized_interface": composed_score_cache(sft_validation),
        "frozen_gridrank_factorized_interface": composed_score_cache(frozen_validation),
        "physics_aligned_factorized_llm": composed_score_cache(aligned),
        "instruction_removed": composed_score_cache(removed),
        "instruction_counterfactual": composed_score_cache(counterfactual),
    }
    records.update({
        name: joint.records_from_scores(
            validation_rows, values,
            name if name in {"instruction_removed", "instruction_counterfactual"} else "correct",
        )
        for name, values in composed.items()
    })
    records["full_ac_oracle"] = joint.full_ac_oracle_records(validation_rows)
    summaries = {name: joint.summarize(value) for name, value in records.items()}
    aligned_records = records["physics_aligned_factorized_llm"]
    seen = lambda values: [
        row for row in values if row["pair_type"] != WITHHELD_COMPOSITION
    ]
    comparisons = {
        "aligned_vs_fixed": joint.paired(
            records["fixed_loss_lindistflow"], aligned_records,
            args.bootstrap_reps, args.seed + 100,
        ),
        "aligned_vs_rule": joint.paired(
            records["frozen_rule_parser_lindistflow"], aligned_records,
            args.bootstrap_reps, args.seed + 200,
        ),
        "aligned_vs_full_tfidf_positive_control": joint.paired(
            records["tfidf_logreg_lindistflow"], aligned_records,
            args.bootstrap_reps, args.seed + 300,
        ),
        "correct_vs_removed": joint.paired(
            records["instruction_removed"], aligned_records,
            args.bootstrap_reps, args.seed + 400,
        ),
        "correct_vs_counterfactual": joint.paired(
            records["instruction_counterfactual"], aligned_records,
            args.bootstrap_reps, args.seed + 500,
        ),
        "composition_aligned_vs_withheld_tfidf": joint.paired(
            joint.subset(records["tfidf_logreg_withheld_composition"], WITHHELD_COMPOSITION),
            joint.subset(aligned_records, WITHHELD_COMPOSITION),
            args.bootstrap_reps, args.seed + 600,
        ),
        "seen_aligned_vs_fixed": joint.paired(
            seen(records["fixed_loss_lindistflow"]), seen(aligned_records),
            args.bootstrap_reps, args.seed + 700,
        ),
        "seen_aligned_vs_full_tfidf": joint.paired(
            seen(records["tfidf_logreg_lindistflow"]), seen(aligned_records),
            args.bootstrap_reps, args.seed + 800,
        ),
    }
    axes = {
        "sft": axis_summary(validation_rows, sft_validation),
        "frozen_gridrank": axis_summary(validation_rows, frozen_validation),
        "physics_aligned": axis_summary(validation_rows, aligned),
        "physics_aligned_composition": axis_summary(composition_rows, aligned),
    }

    history = training_result["history"]
    mechanism = {
        "nonzero_finite_gradient": bool(
            training_result["first_gradient"]
            and training_result["first_gradient"]["nonzero_gradient_tensors"] > 0
            and training_result["first_gradient"]["finite"]
        ),
        "reference_adapter_frozen": reference_delta["changed_tensors"] == 0,
        "sft_adapter_frozen": sft_delta["changed_tensors"] == 0,
        "policy_adapter_changed": policy_delta["changed_tensors"] > 0,
        "primitive_scores_changed": score_delta > 1e-4,
        "training_objective_improved": history[-1]["total"] < history[0]["total"],
    }
    composition = comparisons["composition_aligned_vs_withheld_tfidf"]
    engineering = {
        "aligned_beats_fixed_point": positive(
            comparisons["aligned_vs_fixed"]["improvement_mean"]
        ),
        "seen_aligned_noninferior_to_fixed_point": nonnegative(
            comparisons["seen_aligned_vs_fixed"]["improvement_mean"]
        ),
        "unseen_composition_beats_withheld_tfidf_point": positive(
            composition["improvement_mean"]
        ),
        "composition_nonnegative_both_networks": all(
            nonnegative(composition["by_network"][network]["improvement_mean"])
            for network in ("33", "69")
        ),
        "correct_beats_removed_point": positive(
            comparisons["correct_vs_removed"]["improvement_mean"]
        ),
        "correct_beats_counterfactual_point": positive(
            comparisons["correct_vs_counterfactual"]["improvement_mean"]
        ),
        "composition_objective_accuracy_ge_chance": (
            axes["physics_aligned_composition"]["objective_accuracy"] >= 0.5
        ),
        "composition_constraint_accuracy_ge_chance": (
            axes["physics_aligned_composition"]["constraint_accuracy"] >= 0.5
        ),
    }
    safety = {
        "aligned_feasible_100pct": (
            summaries["physics_aligned_factorized_llm"]["safe_feasible_rate"] == 1.0
        ),
        "aligned_zero_constraint_violation": (
            summaries["physics_aligned_factorized_llm"]["constraint_violation_rate"] == 0.0
        ),
    }
    engineering_pass = all({**mechanism, **engineering, **safety}.values())
    paper = {
        "engineering_gate_pass": engineering_pass,
        "aligned_vs_fixed_ci_lower_positive": (
            comparisons["aligned_vs_fixed"]["ci95"][0] > 0
        ),
        "composition_vs_withheld_tfidf_ci_lower_positive": (
            composition["ci95"][0] > 0
        ),
        "correct_vs_removed_ci_lower_positive": (
            comparisons["correct_vs_removed"]["ci95"][0] > 0
        ),
        "correct_vs_counterfactual_ci_lower_positive": (
            comparisons["correct_vs_counterfactual"]["ci95"][0] > 0
        ),
        "composition_positive_both_networks": all(
            positive(composition["by_network"][network]["improvement_mean"])
            for network in ("33", "69")
        ),
    }

    output.mkdir(parents=True, exist_ok=False)
    saved = bool(training.save_policy_adapter(
        model, output / "diagnostic_adapter", args.epochs
    ))
    adapter_validation = select.validate_saved_adapter(output / "diagnostic_adapter")
    mechanism["diagnostic_adapter_saved"] = saved and adapter_validation["valid"]
    engineering_pass = all({**mechanism, **engineering, **safety}.values())
    paper["engineering_gate_pass"] = engineering_pass
    paper_pass = all(paper.values())
    old_gate = json.load(open(args.joint_gate, encoding="utf-8"))
    joint_card_ablation = {
        "source": str(Path(args.joint_gate).resolve()),
        "engineering_gate_pass": old_gate.get("engineering_gate_pass"),
        "paper_gate_pass": old_gate.get("paper_gate_pass"),
        "aligned_summary": old_gate.get("summaries", {}).get(
            "physics_aligned_dynamic_llm"
        ),
        "composition_vs_withheld_tfidf": old_gate.get("paired", {}).get(
            "composition_aligned_vs_withheld_tfidf"
        ),
    }
    result = {
        "msg": "GridRank factorized physics-certified dynamic-policy gate",
        "architecture": (
            "native LLM independently scores loss/voltage objective and "
            "none/maintenance constraint; additive composition constructs four "
            "semantic policy cards; LinDistFlow ranks actions; cached authoritative "
            "AC outcomes train LoRA; separate AC/no-op gate executes"
        ),
        "withheld_composition": WITHHELD_COMPOSITION,
        "development_reuse_disclosed": True,
        "fresh_final_test_required": True,
        "preflight_sha256": preflight.file_sha256(args.preflight_manifest),
        "schedule": preflight.schedule(args),
        "training": training_result,
        "initial_adapter_equality": equality,
        "parameter_delta": policy_delta,
        "reference_parameter_delta": reference_delta,
        "sft_parameter_delta": sft_delta,
        "validation_primitive_score_max_abs_delta": score_delta,
        "axis_metrics": axes,
        "summaries": summaries,
        "paired": comparisons,
        "joint_card_ablation": joint_card_ablation,
        "mechanism_checks": mechanism,
        "engineering_checks": engineering,
        "safety_checks": safety,
        "paper_checks": paper,
        "engineering_gate_pass": engineering_pass,
        "paper_gate_pass": paper_pass,
        "decision": (
            "authorize_fresh_factorized_dynamic_confirmation"
            if engineering_pass else "stop_factorized_dynamic_route"
        ),
        "interpretation_boundary": (
            "The full TFIDF model is a positive control trained with the withheld "
            "composition labels and is reported, not used as the hidden-composition gate."
        ),
        "diagnostic_adapter": adapter_validation,
    }
    (output / "gridrank_dynamic_factorized_gate.json").write_text(
        json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps(result, ensure_ascii=False))
    if not engineering_pass:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
