"""Check inputs for GridRank select."""

from __future__ import annotations

import argparse
import json
import math
import sys
from pathlib import Path

import preflight_gridrank_feedback as runtime
from audit_gridrank_feedback import CODE_FILES as UPSTREAM_CODE_FILES
from build_gridrank_select import file_sha256, validate_upstream
from gridrank_select_llm import (
    NOOP,
    render_exchange_prompt,
    resolve_preference_token_ids,
    validate_exchange_only_row,
)


HERE = Path(__file__).resolve().parent
SELECT_CODE_FILES = (
    "build_gridrank_select.py",
    "audit_gridrank_select.py",
    "gridrank_select_llm.py",
    "train_gridrank_select.py",
    "verify_gridrank_select.py",
    "preflight_gridrank_select.py",
    "run_gridrank_select.sh",
    "../../docs/GRIDRANK_SELECT_PROTOCOL.md",
)
CODE_FILES = tuple(dict.fromkeys((*UPSTREAM_CODE_FILES, *SELECT_CODE_FILES)))

AUDIT_CHECK_KEYS = {
    "upstream_audit_passed",
    "upstream_summary_hash_locked",
    "upstream_audit_hash_locked",
    "upstream_artifact_hashes_locked",
    "derived_rows_exact",
    "one_loss_row_per_state",
    "unique_load_per_row",
    "both_networks",
    "fixed_nonnoop_candidate_count",
    "noop_absent_from_llm_ranking",
    "noop_anchor_separate",
    "always_noop_policy_impossible",
    "targets_renormalised",
    "accepted_and_unsafe_mix_each_network",
    "train_test_state_disjoint",
    "train_test_load_disjoint",
    "artifact_hashes_match_summary",
    "summary_counts_match",
    "build_code_hash_matches",
}

SCHEDULE_KEYS = (
    "max_length",
    "candidate_batch_size",
    "epochs",
    "topk",
    "learning_rate",
    "grad_accum",
    "max_grad_norm",
    "list_temperature",
    "lambda_bce",
    "lambda_listwise",
    "lambda_hard",
    "hard_margin",
    "beta_reference",
    "seed",
    "gradient_checkpointing",
    "physics_timeout_s",
    "bootstrap_reps",
)


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--upstream_summary", required=True)
    parser.add_argument("--upstream_audit", required=True)
    parser.add_argument("--offline_jsonl", required=True)
    parser.add_argument("--upstream_test_jsonl", required=True)
    parser.add_argument("--train_jsonl", required=True)
    parser.add_argument("--test_jsonl", required=True)
    parser.add_argument("--data_summary", required=True)
    parser.add_argument("--data_audit", required=True)
    parser.add_argument("--resume_adapter_path", required=True)
    parser.add_argument("--base_model", required=True)
    parser.add_argument("--physics_python", required=True)
    parser.add_argument("--physics_timeout_s", type=float, required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--max_length", type=int, required=True)
    parser.add_argument("--candidate_batch_size", type=int, required=True)
    parser.add_argument("--epochs", type=int, required=True)
    parser.add_argument("--topk", type=int, required=True)
    parser.add_argument("--learning_rate", type=float, required=True)
    parser.add_argument("--grad_accum", type=int, required=True)
    parser.add_argument("--max_grad_norm", type=float, required=True)
    parser.add_argument("--list_temperature", type=float, required=True)
    parser.add_argument("--lambda_bce", type=float, required=True)
    parser.add_argument("--lambda_listwise", type=float, required=True)
    parser.add_argument("--lambda_hard", type=float, required=True)
    parser.add_argument("--hard_margin", type=float, required=True)
    parser.add_argument("--beta_reference", type=float, required=True)
    parser.add_argument("--seed", type=int, required=True)
    parser.add_argument("--gradient_checkpointing", type=int, choices=[0, 1], required=True)
    parser.add_argument("--bootstrap_reps", type=int, required=True)
    return parser.parse_args()


def schedule_manifest(args):
    
    return {key: getattr(args, key) for key in SCHEDULE_KEYS}


def _require_exact_keys(mapping, expected, label):
    if not isinstance(mapping, dict) or set(mapping) != set(expected):
        actual = sorted(mapping) if isinstance(mapping, dict) else type(mapping).__name__
        raise ValueError(
            f"{label} keys mismatch: expected={sorted(expected)}, actual={actual}"
        )


def _json(path):
    with open(path, encoding="utf-8") as handle:
        return json.load(handle)


def prompt_length_audit(base_model, partitions, max_length):
    
    if int(max_length) <= 0:
        raise ValueError("max_length must be positive")
    from transformers import AutoTokenizer

    tokenizer = AutoTokenizer.from_pretrained(base_model, local_files_only=True)
    positive_id, negative_id = resolve_preference_token_ids(tokenizer)
    partition_results = {}
    total_rows = total_candidates = truncated_candidates = 0
    global_max = 0
    longest = None
    for partition, raw_path in partitions.items():
        path = Path(raw_path).resolve()
        stats = {
            "path": str(path),
            "rows": 0,
            "candidates": 0,
            "max_tokens": 0,
            "truncated_candidates": 0,
            "noop_candidates": 0,
            "by_network": {},
        }
        with open(path, encoding="utf-8") as handle:
            for line_number, line in enumerate(handle, start=1):
                if not line.strip():
                    continue
                row = json.loads(line)
                validate_exchange_only_row(row, minimum_candidates=3)
                candidates = row["candidates"]
                noop_count = sum(candidate.get("action") == NOOP for candidate in candidates)
                texts = [
                    render_exchange_prompt(tokenizer, row, candidate)
                    for candidate in candidates
                ]
                encoded = tokenizer(
                    texts,
                    add_special_tokens=False,
                    truncation=False,
                    padding=False,
                    return_attention_mask=False,
                    return_token_type_ids=False,
                )
                lengths = [len(token_ids) for token_ids in encoded["input_ids"]]
                if len(lengths) != len(candidates) or any(length <= 0 for length in lengths):
                    raise RuntimeError(
                        f"invalid prompt token counts in {partition} row {line_number}"
                    )
                network = str(row.get("network_id"))
                network_stats = stats["by_network"].setdefault(network, {
                    "rows": 0,
                    "candidates": 0,
                    "max_tokens": 0,
                    "truncated_candidates": 0,
                    "noop_candidates": 0,
                })
                row_max = max(lengths)
                row_truncated = sum(length > max_length for length in lengths)
                stats["rows"] += 1
                stats["candidates"] += len(lengths)
                stats["max_tokens"] = max(stats["max_tokens"], row_max)
                stats["truncated_candidates"] += row_truncated
                stats["noop_candidates"] += noop_count
                network_stats["rows"] += 1
                network_stats["candidates"] += len(lengths)
                network_stats["max_tokens"] = max(network_stats["max_tokens"], row_max)
                network_stats["truncated_candidates"] += row_truncated
                network_stats["noop_candidates"] += noop_count
                total_rows += 1
                total_candidates += len(lengths)
                truncated_candidates += row_truncated
                if row_max > global_max:
                    index = lengths.index(row_max)
                    global_max = row_max
                    longest = {
                        "partition": partition,
                        "instance_id": row.get("instance_id"),
                        "network": network,
                        "candidate_action": candidates[index].get("action"),
                        "tokens": row_max,
                    }
        if stats["rows"] <= 0 or set(stats["by_network"]) != {"33", "69"}:
            raise ValueError(f"invalid prompt-audit coverage: {partition}")
        partition_results[partition] = stats
    noop_candidates = sum(item["noop_candidates"] for item in partition_results.values())
    result = {
        "msg": "GridRank-Select exact exchange-prompt token-length audit",
        "tokenizer_class": type(tokenizer).__name__,
        "chat_template_used": bool(getattr(tokenizer, "chat_template", None)),
        "preference_token_ids": {"YES": positive_id, "NO": negative_id},
        "max_length": int(max_length),
        "rows": total_rows,
        "candidates": total_candidates,
        "max_tokens": global_max,
        "truncated_candidates": truncated_candidates,
        "noop_candidates": noop_candidates,
        "longest_prompt": longest,
        "partitions": partition_results,
    }
    result["prompt_length_pass"] = bool(
        total_candidates > 0
        and global_max <= int(max_length)
        and truncated_candidates == 0
        and noop_candidates == 0
    )
    return result


def _adapter_hash(path):
    root = Path(path)
    required = {
        "adapter_config_json": root / "adapter_config.json",
        "adapter_model_safetensors": root / "adapter_model.safetensors",
    }
    if any(not path.is_file() or path.stat().st_size <= 0 for path in required.values()):
        raise FileNotFoundError("SFT adapter config/weights are missing or empty")
    return {name: file_sha256(path) for name, path in required.items()}


def verify_runtime_lock(
    manifest_path, base_model, physics_python, physics_timeout_s, bootstrap_reps,
):
    if not math.isfinite(float(physics_timeout_s)) or float(physics_timeout_s) <= 0:
        raise ValueError("physics_timeout_s must be finite and positive")
    if int(bootstrap_reps) <= 0:
        raise ValueError("bootstrap_reps must be positive")
    manifest = _json(manifest_path)
    current_training = runtime.training_runtime()
    current_physics = runtime.physics_runtime(physics_python)
    locked_model = manifest.get("base_model_manifest")
    locked_inventory = {
        name: int(value["bytes"]) for name, value in locked_model.items()
    } if isinstance(locked_model, dict) else None
    schedule = manifest.get("training_schedule")
    checks = {
        "preflight_pass": manifest.get("preflight_pass") is True,
        "training_runtime_match": manifest.get("training_runtime") == current_training,
        "physics_runtime_match": manifest.get("physics_runtime") == current_physics,
        "base_model_inventory_match": locked_inventory == runtime.model_inventory(base_model),
        "physics_timeout_match": isinstance(schedule, dict)
            and schedule.get("physics_timeout_s") == float(physics_timeout_s),
        "bootstrap_reps_match": isinstance(schedule, dict)
            and schedule.get("bootstrap_reps") == int(bootstrap_reps),
        "fixed_pilot_schedule": isinstance(schedule, dict)
            and schedule.get("epochs") == 4
            and schedule.get("topk") == 3
            and schedule.get("seed") == 42,
    }
    return {
        "msg": "GridRank-Select locked runtime verification",
        "checks": checks,
        "runtime_pass": all(checks.values()),
        "training_runtime": current_training,
        "physics_runtime": current_physics,
    }


def main():
    args = parse_args()
    if not math.isfinite(args.physics_timeout_s) or args.physics_timeout_s <= 0:
        raise ValueError("physics_timeout_s must be finite and positive")
    if args.bootstrap_reps <= 0:
        raise ValueError("bootstrap_reps must be positive")
    if args.epochs != 4 or args.topk != 3 or args.seed != 42:
        raise ValueError("pilot is locked to epochs=4, topk=3, seed=42")
    output = Path(args.output)
    if output.exists():
        raise FileExistsError(f"refusing to overwrite preflight manifest: {output}")

    upstream_artifacts = {
        "offline_train": args.offline_jsonl,
        "test": args.upstream_test_jsonl,
    }
    upstream_summary, upstream_audit = validate_upstream(
        args.upstream_summary, args.upstream_audit, upstream_artifacts
    )
    summary = _json(args.data_summary)
    audit = _json(args.data_audit)
    _require_exact_keys(audit, {
        "msg", "schema", "summary_sha256", "artifact_sha256", "upstream_sha256",
        "code_sha256", "partition_audits", "checks", "audit_pass",
    }, "GridRank-Select audit")
    _require_exact_keys(audit["artifact_sha256"], {"train", "test"},
                        "GridRank-Select audit artifact_sha256")
    _require_exact_keys(audit["upstream_sha256"], {"summary", "audit", "artifacts"},
                        "GridRank-Select audit upstream_sha256")
    _require_exact_keys(audit["upstream_sha256"]["artifacts"],
                        {"offline_train", "test"},
                        "GridRank-Select audit upstream artifacts")
    _require_exact_keys(audit["code_sha256"],
                        {"build_gridrank_select.py", "audit_gridrank_select.py"},
                        "GridRank-Select audit code_sha256")
    _require_exact_keys(audit["checks"], AUDIT_CHECK_KEYS,
                        "GridRank-Select audit checks")

    artifact_hash = {
        "train": file_sha256(args.train_jsonl),
        "test": file_sha256(args.test_jsonl),
        "summary": file_sha256(args.data_summary),
        "audit": file_sha256(args.data_audit),
    }
    upstream_hash = {
        "summary": file_sha256(args.upstream_summary),
        "audit": file_sha256(args.upstream_audit),
        "artifacts": {
            name: file_sha256(path) for name, path in upstream_artifacts.items()
        },
    }
    missing_code = [name for name in CODE_FILES if not (HERE / name).is_file()]
    code_hash = {
        name: file_sha256(HERE / name) for name in CODE_FILES if (HERE / name).is_file()
    }
    current_audit_code = {
        name: file_sha256(HERE / name)
        for name in ("build_gridrank_select.py", "audit_gridrank_select.py")
    }
    audit_checks_all_true = bool(audit["checks"]) and all(
        value is True for value in audit["checks"].values()
    )
    prompt_audit = prompt_length_audit(
        args.base_model,
        {"train": args.train_jsonl, "test": args.test_jsonl},
        args.max_length,
    )
    adapter_hash = _adapter_hash(args.resume_adapter_path)
    base_manifest = runtime.model_manifest(args.base_model)
    current_training_runtime = runtime.training_runtime()
    current_physics_runtime = runtime.physics_runtime(args.physics_python)
    schedule = schedule_manifest(args)
    checks = {
        "upstream_audit_pass": upstream_audit.get("audit_pass") is True,
        "upstream_coverage_pass": upstream_summary.get("coverage_pass") is True,
        "upstream_hashes_match_current": audit["upstream_sha256"] == upstream_hash,
        "select_audit_pass": audit["audit_pass"] is True,
        "select_audit_checks_all_true": audit_checks_all_true,
        "select_audit_schema": audit["schema"] == "gridrank-select-audit-v1",
        "select_summary_schema": summary.get("schema") == "gridrank-select-summary-v1",
        "select_summary_coverage": summary.get("coverage_pass") is True,
        "select_single_loss_objective": summary.get("objective") == "loss",
        "select_target_temperature_locked": isinstance(
            summary.get("target_temperature"), (int, float)
        ) and not isinstance(summary.get("target_temperature"), bool) and math.isclose(
            float(summary["target_temperature"]),
            0.20,
            rel_tol=0.0,
            abs_tol=1e-12,
        ),
        "select_pool_inherits_upstream": summary.get("fixed_nonnoop_candidate_count")
            == int(upstream_summary["candidate_pool_size"]) - 1,
        "select_audit_summary_hash": audit["summary_sha256"] == artifact_hash["summary"],
        "select_audit_artifact_hashes": audit["artifact_sha256"] == {
            key: artifact_hash[key] for key in ("train", "test")
        },
        "select_audit_current_code": audit["code_sha256"] == current_audit_code,
        "all_code_files_present": not missing_code,
        "candidate_prompts_untruncated": prompt_audit["prompt_length_pass"] is True,
        "noop_absent_from_prompt_candidates": prompt_audit["noop_candidates"] == 0,
        "resume_adapter_present": bool(adapter_hash),
        "fixed_pilot_schedule": schedule["epochs"] == 4
            and schedule["topk"] == 3 and schedule["seed"] == 42,
        "training_runtime_complete": all(
            current_training_runtime["distributions"].get(name) is not None
            for name in runtime.TRAINING_DISTRIBUTIONS
        ),
        "physics_runtime_complete": all(
            current_physics_runtime["distributions"].get(name) is not None
            for name in runtime.PHYSICS_DISTRIBUTIONS
        ),
    }
    result = {
        "msg": "GridRank-Select locked CPU preflight",
        "schema": "gridrank-select-preflight-v1",
        "artifact_sha256": artifact_hash,
        "upstream_sha256": upstream_hash,
        "resume_adapter_sha256": adapter_hash,
        "base_model_manifest": base_manifest,
        "prompt_length_audit": prompt_audit,
        "code_sha256": code_hash,
        "missing_code_files": missing_code,
        "training_schedule": schedule,
        "training_runtime": current_training_runtime,
        "physics_runtime": current_physics_runtime,
        "preflight_python": {
            "executable": str(Path(sys.executable).resolve()),
            "version": sys.version,
        },
        "checks": checks,
        "preflight_pass": all(checks.values()),
    }
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(result, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps(result, ensure_ascii=False))
    if not result["preflight_pass"]:
        raise SystemExit(2)


def runtime_verification_main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--verify_runtime_manifest", required=True)
    parser.add_argument("--base_model", required=True)
    parser.add_argument("--physics_python", required=True)
    parser.add_argument("--physics_timeout_s", type=float, required=True)
    parser.add_argument("--bootstrap_reps", type=int, required=True)
    args = parser.parse_args()
    result = verify_runtime_lock(
        args.verify_runtime_manifest,
        args.base_model,
        args.physics_python,
        args.physics_timeout_s,
        args.bootstrap_reps,
    )
    print(json.dumps(result, ensure_ascii=False))
    if not result["runtime_pass"]:
        raise SystemExit(2)


if __name__ == "__main__":
    if "--verify_runtime_manifest" in sys.argv:
        runtime_verification_main()
    else:
        main()
