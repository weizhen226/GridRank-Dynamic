"""Grpo train utilities."""

import argparse
import importlib
import json
import sys
import time
from collections import deque
from pathlib import Path

import torch
from peft import LoraConfig, PeftModel, get_peft_model, prepare_model_for_kbit_training
from transformers import (
    AutoModelForCausalLM,
    AutoTokenizer,
    BitsAndBytesConfig,
    GenerationConfig,
)

_HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(_HERE))
sys.path.insert(0, str(_HERE.parents[1] / "Dataset-Notebooks" / "utils"))

from dataset_utils import prepare_train_data  

REPO_ROOT = _HERE.parents[1]


def _load_reward_module(network):
    
    module_name = "grpo_reward_69" if str(network) == "69" else "grpo_reward"
    return importlib.import_module(module_name)


def parse_args():
    p = argparse.ArgumentParser(description="Simulator-guided GRPO for grid reconfiguration.")
    p.add_argument("--data_path", type=str, required=True, help="Train CSV (with split/prompt/output).")
    p.add_argument("--base_model", type=str, default=str(REPO_ROOT / "Meta-Llama-3.1-8B-Instruct"))
    p.add_argument("--resume_adapter_path", type=str, default="",
                   help="LoRA adapter to start from (recommended: a balanced_v2 / DPO checkpoint). "
                        "Empty = fresh LoRA (NOT recommended; RL tends to break format from scratch).")
    p.add_argument("--output_dir", type=str, required=True)

    
    p.add_argument("--num_generations", type=int, default=4,
                   help="Group size G (candidates per prompt). MUST be >= 2: GRPO needs intra-group "
                        "reward variance; K=1 gives std=nan and every group is skipped (no learning).")
    p.add_argument("--beta", type=float, default=0.04, help="KL coefficient (anchor to reference).")
    p.add_argument("--learning_rate", type=float, default=1e-6, help="Keep very low: RL easily breaks format.")
    p.add_argument("--grad_accum", type=int, default=4, help="Optimizer step every N prompts.")
    p.add_argument("--max_grad_norm", type=float, default=1.0)

    
    p.add_argument("--temperature", type=float, default=1.0)
    p.add_argument("--top_p", type=float, default=0.95)
    p.add_argument("--max_new_tokens", type=int, default=320)
    p.add_argument("--max_prompt_len", type=int, default=3072)
    p.add_argument("--repetition_penalty", type=float, default=1.1)

    
    p.add_argument("--num_samples", type=int, default=-1, help="Use first N train prompts (-1 = all).")
    p.add_argument("--num_epochs", type=int, default=1)
    p.add_argument("--max_steps", type=int, default=-1, help="Hard cap on prompts processed (-1 = no cap).")
    p.add_argument("--save_every", type=int, default=200, help="Save adapter every N prompts.")
    p.add_argument("--log_every", type=int, default=5)
    p.add_argument("--log_window", type=int, default=20, help="Sliding window (in prompts) for logged averages.")
    p.add_argument("--seed", type=int, default=42)
    p.add_argument("--gradient_checkpointing", type=int, default=1)

    
    p.add_argument("--w_loss", type=float, default=1.0)
    p.add_argument("--w_uv", type=float, default=10.0)
    p.add_argument("--w_ov", type=float, default=10.0)
    p.add_argument("--w_infeasible", type=float, default=100.0)
    p.add_argument("--w_topo", type=float, default=5.0)
    p.add_argument("--floor_reward", type=float, default=None,
                   help="Linear-mode reward floor. Defaults to the selected reward backend's value.")
    p.add_argument("--network", type=str, default="33", choices=["33", "69"],
                   help="Reward/engine: '33' = pandapower case33bw (grpo_reward); '69' = validated "
                        "per-unit BFS, loss-red vs existing, soft voltage (grpo_reward_69).")
    p.add_argument("--reward_mode", type=str, default="gated", choices=["gated", "linear"],
                   help="'gated' = feasibility-gated PO (structure is a HARD gate, cannot be "
                        "traded for loss); 'linear' = legacy weighted-sum sim_score (ablation).")
    args = p.parse_args()
    if args.floor_reward is None:
        args.floor_reward = _load_reward_module(args.network).DEFAULT_FLOOR_REWARD
    return args


def build_model_and_tokenizer(args):
    tok = AutoTokenizer.from_pretrained(args.base_model, local_files_only=True)
    tok.pad_token = tok.eos_token

    bnb = BitsAndBytesConfig(
        load_in_4bit=True,
        bnb_4bit_quant_type="nf4",
        bnb_4bit_compute_dtype=torch.float16,
        bnb_4bit_use_double_quant=True,
    )
    base = AutoModelForCausalLM.from_pretrained(
        args.base_model,
        quantization_config=bnb,
        device_map="auto",
        local_files_only=True,
    )
    base.config.use_cache = False
    base = prepare_model_for_kbit_training(
        base, use_gradient_checkpointing=bool(args.gradient_checkpointing)
    )

    if args.resume_adapter_path:
        
        model = PeftModel.from_pretrained(base, args.resume_adapter_path, is_trainable=True)


        model.load_adapter(args.resume_adapter_path, adapter_name="reference", is_trainable=False)
        model.set_adapter("default")
        model._grpo_has_ref_adapter = True
    else:
        lora = LoraConfig(r=8, lora_alpha=16, lora_dropout=0.05, bias="none", task_type="CAUSAL_LM")
        model = get_peft_model(base, lora)
        
        
        model._grpo_has_ref_adapter = False


    model.enable_input_require_grads()
    if args.gradient_checkpointing:
        
        model.gradient_checkpointing_enable(gradient_checkpointing_kwargs={"use_reentrant": False})


    for m in model.modules():
        if isinstance(m, torch.nn.Dropout):
            m.p = 0.0
    model.train()

    model.print_trainable_parameters()
    return model, tok


def device_of(model):
    return next(model.parameters()).device


def generate_group(model, tok, prompt_text, args):
    
    formatted = f"<|user|>\n{prompt_text}</s>\n<|assistant|>\n"
    enc = tok(formatted, return_tensors="pt", truncation=True, max_length=args.max_prompt_len)
    enc = {k: v.to(device_of(model)) for k, v in enc.items()}
    prompt_len = enc["input_ids"].shape[1]


    model.config.use_cache = True
    if args.gradient_checkpointing:
        try:
            model.gradient_checkpointing_disable()
        except Exception:
            pass

    cfg = GenerationConfig(
        do_sample=True,
        temperature=args.temperature,
        top_p=args.top_p,
        num_return_sequences=args.num_generations,
        max_new_tokens=args.max_new_tokens,
        pad_token_id=tok.eos_token_id,
        eos_token_id=tok.eos_token_id,
        repetition_penalty=args.repetition_penalty,
    )
    with torch.no_grad():
        out = model.generate(**enc, generation_config=cfg)

    
    model.config.use_cache = False
    if args.gradient_checkpointing:
        model.gradient_checkpointing_enable(gradient_checkpointing_kwargs={"use_reentrant": False})
    torch.cuda.empty_cache()

    comp_texts = [tok.decode(out[i, prompt_len:], skip_special_tokens=True) for i in range(out.shape[0])]
    return out, prompt_len, comp_texts


def completion_logprobs(model, seq_ids, prompt_len, eos_id):
    
    comp = seq_ids[0, prompt_len:]
    eos_pos = (comp == eos_id).nonzero(as_tuple=False)
    comp_len = (int(eos_pos[0, 0].item()) + 1) if eos_pos.numel() > 0 else comp.shape[0]
    real_len = prompt_len + comp_len
    seq = seq_ids[:, :real_len]
    attn = torch.ones_like(seq)

    out = model(input_ids=seq, attention_mask=attn)
    logits = out.logits[:, :-1, :]                      
    targets = seq[:, 1:]                                
    
    
    sel = logits.gather(2, targets.unsqueeze(-1)).squeeze(-1).float()[0]   
    lse = torch.logsumexp(logits.float(), dim=-1)[0]                       
    tok_logp = sel - lse
    
    
    comp_logp = tok_logp[prompt_len - 1: real_len - 1]
    return comp_logp


def compute_ref_logprobs(model, seq, prompt_len, eos_id):
    
    with torch.no_grad():
        if getattr(model, "_grpo_has_ref_adapter", False):
            model.set_adapter("reference")
            try:
                rl = completion_logprobs(model, seq, prompt_len, eos_id).detach()
            finally:
                model.set_adapter("default")
        else:
            with model.disable_adapter():
                rl = completion_logprobs(model, seq, prompt_len, eos_id).detach()
    return rl


def save_policy_adapter(model, path, step=None):
    
    path = Path(path)
    try:
        model.set_adapter("default")
    except Exception:
        pass
    model.save_pretrained(str(path), selected_adapters=["default"])
    ok = (path / "adapter_config.json").exists()
    msg = {"msg": "saved" if ok else "WARN_save_incomplete", "path": str(path)}
    if step is not None:
        msg["step"] = step
    if not ok:
        msg["hint"] = "adapter_config.json missing at root (check disk space / PEFT save layout)"
    print(json.dumps(msg, ensure_ascii=False))
    return ok


def main():
    args = parse_args()
    
    
    try:
        sys.stdout.reconfigure(line_buffering=True)
    except Exception:
        pass
    if args.num_generations < 2:
        raise SystemExit(
            "--num_generations must be >= 2: GRPO relies on intra-group reward variance; "
            "with K=1 the group std is nan and every prompt is skipped (no learning signal)."
        )
    torch.manual_seed(args.seed)

    out_dir = Path(args.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    weights = dict(w_loss=args.w_loss, w_uv=args.w_uv, w_ov=args.w_ov,
                   w_infeasible=args.w_infeasible, w_topo=args.w_topo)
    reward_mod = _load_reward_module(args.network)
    print(json.dumps({"msg": "reward backend", "network": args.network,
                      "module": reward_mod.__name__}, ensure_ascii=False))

    model, tok = build_model_and_tokenizer(args)
    eos_id = tok.eos_token_id

    train, _, _ = prepare_train_data(args.data_path)
    prompts = list(train["prompt"])
    if args.num_samples != -1:
        prompts = prompts[: args.num_samples]

    trainable = [p for p in model.parameters() if p.requires_grad]
    optim = torch.optim.AdamW(trainable, lr=args.learning_rate)

    print(json.dumps({
        "msg": "GRPO start",
        "num_prompts": len(prompts),
        "num_generations": args.num_generations,
        "beta": args.beta,
        "learning_rate": args.learning_rate,
        "grad_accum": args.grad_accum,
        "resume_adapter_path": args.resume_adapter_path,
        "weights": weights,
        "floor_reward": args.floor_reward,
        "reward_mode": args.reward_mode,
    }, ensure_ascii=False))

    step = 0                 
    micro = 0                
    hist = deque(maxlen=args.log_window)   
    total_skipped = 0
    optim.zero_grad(set_to_none=True)
    t0 = time.perf_counter()

    for epoch in range(args.num_epochs):
        for prompt in prompts:
            if args.max_steps != -1 and step >= args.max_steps:
                break
            step += 1

            full_ids, prompt_len, comp_texts = generate_group(model, tok, prompt, args)


            scored = [reward_mod.score_completion(prompt, c, weights, args.floor_reward,
                                                  args.reward_mode, return_detail=True)
                      for c in comp_texts]
            rewards = [s[0] for s in scored]
            rewards_t = torch.tensor(rewards, dtype=torch.float32)
            mean_r = rewards_t.mean()
            std_r = rewards_t.std()

            feas_flags = [bool(s[1]["feasible"]) for s in scored]
            feas_reds = [s[1]["loss_reduction_pct"] for s in scored
                         if s[1]["feasible"] and s[1]["loss_reduction_pct"] is not None]
            rec = {
                "group_mean_reward": float(mean_r),
                "feasible_count": sum(feas_flags),
                "feasible_loss_red_sum": float(sum(feas_reds)),
                "total": len(rewards),
                "degenerate": False,
                "kl": 0.0,
                "loss": 0.0,
                "updated": False,
            }


            if torch.isnan(std_r) or float(std_r) < 1e-6:
                rec["degenerate"] = True
                total_skipped += 1
            else:
                advantages = ((rewards_t - mean_r) / (std_r + 1e-8)).tolist()

                group_loss_val = 0.0
                group_kl_val = 0.0
                n_counted = 0
                for i in range(full_ids.shape[0]):
                    seq = full_ids[i: i + 1, :]
                    logp = completion_logprobs(model, seq, prompt_len, eos_id)        
                    if logp.numel() == 0:
                        continue
                    
                    ref_logp = compute_ref_logprobs(model, seq, prompt_len, eos_id)

                    diff = ref_logp - logp
                    kl = torch.exp(diff) - diff - 1.0                              
                    policy = -float(advantages[i]) * logp
                    loss_i = (policy + args.beta * kl).mean()

                    
                    (loss_i / (full_ids.shape[0] * args.grad_accum)).backward()

                    group_loss_val += float(loss_i.detach())
                    group_kl_val += float(kl.mean().detach())
                    n_counted += 1

                if n_counted > 0:
                    rec["loss"] = group_loss_val / n_counted
                    rec["kl"] = group_kl_val / n_counted
                    rec["updated"] = True

                micro += 1
                if micro >= args.grad_accum:
                    torch.nn.utils.clip_grad_norm_(trainable, args.max_grad_norm)
                    optim.step()
                    optim.zero_grad(set_to_none=True)
                    micro = 0


            hist.append(rec)
            if step % args.log_every == 0:
                _log(hist, step, total_skipped, t0)
            if step % args.save_every == 0:
                save_policy_adapter(model, out_dir / f"checkpoint-{step}", step)

    
    if micro > 0:
        torch.nn.utils.clip_grad_norm_(trainable, args.max_grad_norm)
        optim.step()
        optim.zero_grad(set_to_none=True)

    
    save_policy_adapter(model, out_dir)
    print(json.dumps({
        "msg": "GRPO done",
        "prompts_processed": step,
        "final_adapter": str(out_dir),
    }, ensure_ascii=False))


def _log(hist, step, total_skipped, t0):
    n = len(hist)
    if n == 0:
        return
    elapsed = time.perf_counter() - t0
    feas_red_sum = sum(h["feasible_loss_red_sum"] for h in hist)
    feas_cnt = sum(h["feasible_count"] for h in hist)
    tot_cnt = sum(h["total"] for h in hist)
    deg = sum(1 for h in hist if h["degenerate"])
    upd = [h for h in hist if h["updated"]]
    kls = [h["kl"] for h in upd]
    losses = [h["loss"] for h in upd]
    print(json.dumps({
        "step": step,
        "win": n,                                                                   
        
        
        "feasible_loss_red_avg": round(feas_red_sum / feas_cnt, 4) if feas_cnt else None,
        "feasible_rate": round(feas_cnt / tot_cnt, 4) if tot_cnt else None,         
        "degenerate_rate": round(deg / n, 4),                                       
        "avg_kl": round(sum(kls) / len(kls), 5) if kls else None,
        "avg_loss": round(sum(losses) / len(losses), 5) if losses else None,
        "skipped_degenerate_total": total_skipped,
        "sec_per_prompt": round(elapsed / step, 2),
    }, ensure_ascii=False))


if __name__ == "__main__":
    main()


