#!/usr/bin/env bash
set -euo pipefail

CURRENT_STAGE="bootstrap"
on_exit() {
  local rc=$?
  trap - EXIT
  if (( rc != 0 )); then
    printf '{"msg":"GridRank fresh dynamic confirmation runner failure","stage":"%s","confirmation_gate_pass":false,"exit_code":%d}\n' "$CURRENT_STAGE" "$rc"
  fi
  exit "$rc"
}
trap on_exit EXIT

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"
export HF_HUB_OFFLINE=1
export TRANSFORMERS_OFFLINE=1
if [[ ! "${OMP_NUM_THREADS:-}" =~ ^[1-9][0-9]*$ ]]; then export OMP_NUM_THREADS=4; fi
export PYTORCH_CUDA_ALLOC_CONF="${PYTORCH_CUDA_ALLOC_CONF:-max_split_size_mb:64}"

PREFLIGHT_ONLY="${PREFLIGHT_ONLY:-1}"
case "$PREFLIGHT_ONLY" in 0|1) ;; *) echo "PREFLIGHT_ONLY must be 0 or 1" >&2; exit 2;; esac
if [[ "$PREFLIGHT_ONLY" == "1" ]]; then export CUDA_VISIBLE_DEVICES=""; fi

resolve_executable() {
  local requested="$1"
  if [[ "$requested" == */* ]]; then [[ -x "$requested" ]] && printf '%s\n' "$requested"; else command -v -- "$requested"; fi
}
TRAIN_PYTHON_BIN="$(resolve_executable "${TRAIN_PYTHON:-python}")" || exit 2
PHYSICS_PYTHON_BIN="$(resolve_executable "${PHYSICS_PYTHON:-$TRAIN_PYTHON_BIN}")" || exit 2

TAG="${TAG:-gridrank_dynamic_confirmation_v1_20260829}"
[[ "$TAG" =~ ^[A-Za-z0-9][A-Za-z0-9._-]*$ ]] || { echo "invalid TAG" >&2; exit 2; }
PAIR_TAG="${PAIR_TAG:-gridrank_instruction_pairs_v2_20260809}"
FACTOR_TAG="${FACTOR_TAG:-gridrank_dynamic_factorized_v1_20260828}"
RAW33="${RAW33:-structured_action_33_fixed_locked_eval_test.jsonl}"
RAW69="${RAW69:-structured_action_69_s42_locked_eval_test.jsonl}"
TRAIN_JSONL="${TRAIN_JSONL:-${PAIR_TAG}_train.jsonl}"
VALIDATION_JSONL="${VALIDATION_JSONL:-${PAIR_TAG}_validation.jsonl}"
FACTOR_PREFLIGHT="${FACTOR_PREFLIGHT:-${FACTOR_TAG}.preflight.json}"
FACTOR_GATE="${FACTOR_GATE:-output_${FACTOR_TAG}/gridrank_dynamic_factorized_gate.json}"
FACTOR_ADAPTER="${FACTOR_ADAPTER:-output_${FACTOR_TAG}/diagnostic_adapter}"
BASE_MODEL="${BASE_MODEL:-../../Meta-Llama-3.1-8B-Instruct}"

VIEW33="${TAG}_unused_raw_test33_role.jsonl"
VIEW69="${TAG}_unused_raw_test69_role.jsonl"
VIEW33_MANIFEST="${VIEW33%.jsonl}.manifest.json"
VIEW69_MANIFEST="${VIEW69%.jsonl}.manifest.json"
CACHE="${TAG}_physics_cache.jsonl"
PAIRS="${TAG}_pairs.jsonl"
SUMMARY="${TAG}_summary.json"
AUDIT="${TAG}_audit.json"
PREFLIGHT="${TAG}.preflight.json"
OUT="output_${TAG}"
GATE="$OUT/gridrank_dynamic_confirmation_gate.json"

readonly MAX_LENGTH=512
readonly PRIMITIVE_BATCH_SIZE=4
readonly TOPK=1
readonly BOOTSTRAP_REPS=10000
readonly SEED=20260829
readonly GRADIENT_CHECKPOINTING=0
readonly SEEN_PAIRS_PER_NETWORK=12
readonly HIDDEN_PAIRS_PER_NETWORK=24
readonly MAX_SCANNED_STATES_PER_NETWORK=160

for path in "$RAW33" "$RAW69" "$TRAIN_JSONL" "$VALIDATION_JSONL" \
  "$FACTOR_PREFLIGHT" "$FACTOR_GATE" \
  "$FACTOR_ADAPTER/adapter_config.json" "$FACTOR_ADAPTER/adapter_model.safetensors" \
  "$BASE_MODEL/config.json" "$BASE_MODEL/tokenizer_config.json" \
  make_gridrank_dynamic_confirmation_state_view.py build_gridrank_dynamic_confirmation.py \
  audit_gridrank_dynamic_confirmation.py preflight_gridrank_dynamic_confirmation.py \
  eval_gridrank_dynamic_confirmation.py verify_gridrank_dynamic_confirmation.py \
  verify_gridrank_dynamic_confirmation_dependencies.py \
  gridrank_dynamic_factorized_llm.py train_gridrank_dynamic_factorized.py \
  train_gridrank_dynamic_policy.py preflight_gridrank_dynamic_benchmark.py \
  ../../docs/GRIDRANK_DYNAMIC_CONFIRMATION_PROTOCOL.md; do
  test -e "$path" || { echo "missing fresh-confirmation input: $path" >&2; exit 2; }
done

IDENTITY_EXCLUSIONS=("$TRAIN_JSONL" "$VALIDATION_JSONL")
OPTIONAL_IDENTITY_EXCLUSIONS=(
  gridrank_select_confirm_v1_20260725_train.jsonl
)
STATE_ONLY_EXCLUSIONS=(
  gridrank_select_confirm_v1_20260725_test.jsonl
  gridrank_select_gate_v1_20260722_test.jsonl
  gridrank_select_extension_v2_20260726_select_train_lock.jsonl
  gridrank_select_extension_v2_20260726_select_test.jsonl
)
for path in "${OPTIONAL_IDENTITY_EXCLUSIONS[@]}"; do
  [[ ! -f "$path" ]] || IDENTITY_EXCLUSIONS+=("$path")
done
present_state_only=()
for path in "${STATE_ONLY_EXCLUSIONS[@]}"; do
  [[ ! -f "$path" ]] || present_state_only+=("$path")
done
VIEW_IDENTITY_ARGS=()
BUILD_IDENTITY_ARGS=()
for path in "${IDENTITY_EXCLUSIONS[@]}"; do
  VIEW_IDENTITY_ARGS+=(--identity_exclude_jsonl "$path")
  BUILD_IDENTITY_ARGS+=(--exclude_jsonl "$path")
done
VIEW_STATE_ARGS=()
BUILD_STATE_ARGS=()
for path in "${present_state_only[@]}"; do
  VIEW_STATE_ARGS+=(--state_exclude_jsonl "$path")
  BUILD_STATE_ARGS+=(--exclude_state_jsonl "$path")
done

CURRENT_STAGE="dependency_regressions"
echo "=== 1/7 DEPENDENCY-LIGHT FRESH-CONFIRMATION REGRESSIONS ==="
"$TRAIN_PYTHON_BIN" -B verify_gridrank_dynamic_confirmation_dependencies.py

CURRENT_STAGE="fresh_state_views"
echo "=== 2/7 BUILD/VERIFY IDENTITY-DISJOINT RAW-TEST STATE VIEWS ==="
for network in 33 69; do
  if [[ "$network" == "33" ]]; then raw="$RAW33"; view="$VIEW33"; view_manifest="$VIEW33_MANIFEST"; else raw="$RAW69"; view="$VIEW69"; view_manifest="$VIEW69_MANIFEST"; fi
  mode=build
  if [[ -e "$view" || -e "$view_manifest" ]]; then
    [[ -f "$view" && -f "$view_manifest" ]] || { echo "partial state-view outputs for network $network" >&2; exit 2; }
    mode=verify
  fi
  "$TRAIN_PYTHON_BIN" -B make_gridrank_dynamic_confirmation_state_view.py \
    --mode "$mode" --network "$network" --input "$raw" \
    "${VIEW_IDENTITY_ARGS[@]}" "${VIEW_STATE_ARGS[@]}" --min_rows 64 \
    --output_jsonl "$view" --manifest_json "$view_manifest"
done

CURRENT_STAGE="authoritative_pair_build"
echo "=== 3/7 AUTHORITATIVE AC OUTCOMES + STRONG FRESH INSTRUCTION PAIRS ==="
present=0
for path in "$CACHE" "$PAIRS" "$SUMMARY"; do [[ -e "$path" ]] && present=$((present + 1)); done
if (( present == 0 )); then
  "$PHYSICS_PYTHON_BIN" -u build_gridrank_dynamic_confirmation.py \
    --source "33=$VIEW33" --source "69=$VIEW69" \
    "${BUILD_IDENTITY_ARGS[@]}" "${BUILD_STATE_ARGS[@]}" \
    --physics_python "$PHYSICS_PYTHON_BIN" --physics_timeout_s 60 \
    --candidate_pool_size 16 --candidate_seed 20260721 \
    --row_seed "$SEED" --selection_seed "$SEED" \
    --seen_pairs_per_network "$SEEN_PAIRS_PER_NETWORK" \
    --hidden_pairs_per_network "$HIDDEN_PAIRS_PER_NETWORK" \
    --max_scanned_states_per_network "$MAX_SCANNED_STATES_PER_NETWORK" \
    --cache_out "$CACHE" --pairs_out "$PAIRS" --summary_out "$SUMMARY"
elif (( present != 3 )); then
  echo "partial fresh-confirmation data outputs; use a new TAG" >&2
  exit 2
fi

CURRENT_STAGE="cached_data_audit"
echo "=== 4/7 RECOMPUTE CACHED PAIRS, HASHES, AND EXCLUSION BOUNDARY ==="
AUDIT_MODE=build; [[ ! -e "$AUDIT" ]] || AUDIT_MODE=verify
"$TRAIN_PYTHON_BIN" -B audit_gridrank_dynamic_confirmation.py \
  --mode "$AUDIT_MODE" --cache "$CACHE" --pairs "$PAIRS" \
  --summary "$SUMMARY" --audit_out "$AUDIT"

COMMON_PREFLIGHT_ARGS=(
  --fresh_pairs "$PAIRS" --fresh_summary "$SUMMARY" --fresh_audit "$AUDIT"
  --original_train "$TRAIN_JSONL" --original_validation "$VALIDATION_JSONL"
  --factorized_preflight "$FACTOR_PREFLIGHT" --factorized_gate "$FACTOR_GATE"
  --factorized_adapter "$FACTOR_ADAPTER" --base_model "$BASE_MODEL"
  --max_length "$MAX_LENGTH" --primitive_batch_size "$PRIMITIVE_BATCH_SIZE"
  --topk "$TOPK" --bootstrap_reps "$BOOTSTRAP_REPS" --seed "$SEED"
  --gradient_checkpointing "$GRADIENT_CHECKPOINTING"
)

CURRENT_STAGE="locked_cpu_preflight"
echo "=== 5/7 LOCK ONE-TIME FROZEN CONFIRMATION EVALUATION ==="
"$TRAIN_PYTHON_BIN" -B preflight_gridrank_dynamic_confirmation.py \
  "${COMMON_PREFLIGHT_ARGS[@]}" --output "$PREFLIGHT"

if [[ "$PREFLIGHT_ONLY" == "1" ]]; then
  echo "=== GRIDRANK FRESH DYNAMIC CONFIRMATION CPU PREFLIGHT COMPLETE; GPU NOT STARTED ==="
  exit 0
fi
test ! -e "$OUT" || { echo "refusing to overwrite output: $OUT" >&2; exit 2; }

CURRENT_STAGE="cuda_readiness"
echo "=== 6/7 CUDA + BITSANDBYTES NF4 READINESS ==="
"$TRAIN_PYTHON_BIN" -B - <<'PY'
import json
result = {"msg": "GridRank fresh dynamic confirmation CUDA readiness"}
try:
    import bitsandbytes as bnb
    import torch
    from transformers import BitsAndBytesConfig
    checks = {"cuda_available": bool(torch.cuda.is_available()), "visible_device_count": torch.cuda.device_count() > 0}
    device = torch.device("cuda:0") if all(checks.values()) else None
    if device is not None:
        probe = torch.ones(1, device=device)
        checks["cuda_tensor_ok"] = float(probe.item()) == 1.0
        free, total = torch.cuda.mem_get_info(device)
        result.update({"device": torch.cuda.get_device_name(device), "free_memory_bytes": int(free), "total_memory_bytes": int(total)})
        config = BitsAndBytesConfig(load_in_4bit=True, bnb_4bit_quant_type="nf4", bnb_4bit_compute_dtype=torch.float16, bnb_4bit_use_double_quant=True)
        layer = bnb.nn.Linear4bit(64, 64, bias=False, compute_dtype=torch.float16, compress_statistics=True, quant_type="nf4").to(device)
        value = layer(torch.randn(2, 64, device=device, dtype=torch.float16))
        torch.cuda.synchronize(device)
        checks["bitsandbytes_nf4_cuda_kernel_ok"] = bool(value.is_cuda and torch.isfinite(value).all())
        checks["bitsandbytes_config_ok"] = bool(config.load_in_4bit and config.bnb_4bit_quant_type == "nf4")
    else:
        checks.update({"cuda_tensor_ok": False, "bitsandbytes_nf4_cuda_kernel_ok": False, "bitsandbytes_config_ok": False})
except Exception as exc:
    checks = locals().get("checks", {})
    checks["exception_free"] = False
    result["error"] = f"{type(exc).__name__}: {exc}"
result["checks"] = checks
result["readiness_pass"] = bool(checks) and all(checks.values())
print(json.dumps(result, ensure_ascii=False))
raise SystemExit(0 if result["readiness_pass"] else 2)
PY

CURRENT_STAGE="frozen_gpu_evaluation"
echo "=== 7/7 ONE-TIME FROZEN FACTORIZED LLM + TRADITIONAL BASELINES ==="
set +e
"$TRAIN_PYTHON_BIN" -u eval_gridrank_dynamic_confirmation.py \
  --fresh_pairs "$PAIRS" --original_train "$TRAIN_JSONL" \
  --preflight_manifest "$PREFLIGHT" --factorized_adapter "$FACTOR_ADAPTER" \
  --base_model "$BASE_MODEL" --output_dir "$OUT" \
  --max_length "$MAX_LENGTH" --primitive_batch_size "$PRIMITIVE_BATCH_SIZE" \
  --topk "$TOPK" --bootstrap_reps "$BOOTSTRAP_REPS" --seed "$SEED" \
  --gradient_checkpointing "$GRADIENT_CHECKPOINTING"
EVAL_RC=$?
set -e
if [[ ! -f "$GATE" ]]; then exit "$EVAL_RC"; fi
CURRENT_STAGE="result_verification"
"$TRAIN_PYTHON_BIN" -B verify_gridrank_dynamic_confirmation.py --gate "$GATE" --preflight "$PREFLIGHT"
if (( EVAL_RC != 0 )); then exit "$EVAL_RC"; fi
echo "=== GRIDRANK FRESH DYNAMIC CONFIRMATION COMPLETE ==="
