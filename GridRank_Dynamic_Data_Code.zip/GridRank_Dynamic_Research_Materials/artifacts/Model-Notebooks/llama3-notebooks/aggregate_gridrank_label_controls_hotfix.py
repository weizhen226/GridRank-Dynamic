"""Aggregate GridRank label controls hotfix."""

from __future__ import annotations

import argparse
import json
import math
import random
from collections import defaultdict
from pathlib import Path

from gridrank_label_controls import VARIANTS
from preflight_gridrank_label_controls import EXPERIMENT_ID, SCHEMA, file_sha256


AGGREGATE_SCHEMA = "gridrank-label-controls-aggregate-v2"
RECONSTRUCTION = "locked live selected action + locked authoritative test outcomes"
EPS = 1e-12


def _json(path):
    return json.load(open(path, encoding="utf-8"))


def _jsonl(path):
    with open(path, encoding="utf-8") as handle:
        return [json.loads(line) for line in handle if line.strip()]


def mappings(values):
    output = {}
    for value in values:
        key, path = value.split("=", 1)
        if key in output:
            raise ValueError(f"duplicate gate mapping: {key}")
        output[key] = path
    return output


def percentile(values, probability):
    ordered = sorted(values)
    return ordered[int(probability * (len(ordered) - 1))]


def _finite(value):
    return isinstance(value, (int, float)) and not isinstance(value, bool) \
        and math.isfinite(float(value))


def _accepted(candidate):
    return bool(
        candidate.get("feedback_valid")
        and candidate.get("feasible")
        and candidate.get("accepted_by_gate")
        and _finite(candidate.get("safe_utility"))
    )


def _pool_best_value(row):
    candidates = [row["gate_anchor"], *row["candidates"]]
    accepted = [float(item["safe_utility"]) for item in candidates if _accepted(item)]
    if accepted:
        return max(accepted)
    value = row["gate_anchor"].get("safe_utility")
    if not _finite(value):
        raise RuntimeError(f"invalid fallback anchor utility: {row['instance_id']}")
    return float(value)


def reconstruct_state_rows(gate, test_rows):
    

    test_by_id = {row["instance_id"]: row for row in test_rows}
    if len(test_by_id) != len(test_rows):
        raise RuntimeError("duplicate instance_id in locked test corpus")
    live_rows = gate.get("live_topk_gate", {}).get("rows")
    if not isinstance(live_rows, list) or not live_rows:
        raise RuntimeError("gate has no locked live Top-k row decisions")
    if {row.get("instance_id") for row in live_rows} != set(test_by_id):
        raise RuntimeError("gate/test state identities differ")

    output = []
    for live in live_rows:
        instance_id = live["instance_id"]
        row = test_by_id[instance_id]
        if live.get("feedback_valid") is not True \
                or live.get("cache_labels_match") is not True \
                or live.get("matches_cached_gate") is not True:
            raise RuntimeError(f"live/cache certification failed: {instance_id}")
        selected_action = live["selected_action"]
        candidates = [row["gate_anchor"], *row["candidates"]]
        selected = [item for item in candidates if item.get("action") == selected_action]
        if len(selected) != 1:
            raise RuntimeError(
                f"selected action is absent or non-unique in locked test row: {instance_id}"
            )
        selected_value = selected[0].get("safe_utility")
        if not _finite(selected_value) or not _accepted(selected[0]):
            raise RuntimeError(f"selected action is not accepted and finite: {instance_id}")
        safe_regret = max(0.0, _pool_best_value(row) - float(selected_value))
        output.append({
            "instance_id": instance_id,
            "network": str(row["network_id"]),
            "physical_state_sha256": row["physical_state_sha256"],
            "distilled_safe_regret": safe_regret,
            "selected_action": selected_action,
        })

    expected = float(gate["summaries"]["distilled"]["safe_regret_mean"])
    observed = sum(row["distilled_safe_regret"] for row in output) / len(output)
    if not math.isclose(observed, expected, rel_tol=0.0, abs_tol=1e-9):
        raise RuntimeError(
            f"reconstructed safe regret mean differs from gate: {observed} != {expected}"
        )
    return output


def paired(before_rows, after_rows, reps, seed):
    

    before = {row["instance_id"]: row for row in before_rows}
    after = {row["instance_id"]: row for row in after_rows}
    if set(before) != set(after):
        raise RuntimeError("paired label-control state identities differ")
    ordered = sorted(before)
    deltas = [
        float(before[key]["distilled_safe_regret"])
        - float(after[key]["distilled_safe_regret"])
        for key in ordered
    ]
    groups = defaultdict(list)
    for key, delta in zip(ordered, deltas):
        left = before[key]
        right = after[key]
        identity = (left["network"], left["physical_state_sha256"])
        if identity != (right["network"], right["physical_state_sha256"]):
            raise RuntimeError("paired physical-state identity changed")
        groups[identity].append(delta)
    clusters = [sum(values) / len(values) for values in groups.values()]
    rng = random.Random(seed)
    draws = [
        sum(clusters[rng.randrange(len(clusters))] for _ in clusters) / len(clusters)
        for _ in range(reps)
    ]
    return {
        "n_rows": len(deltas),
        "n_state_clusters": len(clusters),
        "safe_regret_improvement_mean": sum(deltas) / len(deltas),
        "state_cluster_improvement_mean": sum(clusters) / len(clusters),
        "state_cluster_bootstrap_ci95": [
            percentile(draws, 0.025), percentile(draws, 0.975)
        ],
        "rows_better": sum(value > EPS for value in deltas),
        "rows_worse": sum(value < -EPS for value in deltas),
        "rows_tied": sum(abs(value) <= EPS for value in deltas),
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--suite_preflight", required=True)
    parser.add_argument("--test_jsonl", required=True)
    parser.add_argument("--gate", action="append", required=True)
    parser.add_argument("--bootstrap_reps", type=int, default=10000)
    parser.add_argument("--bootstrap_seed", type=int, default=20260811)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    if args.bootstrap_reps <= 0:
        raise ValueError("bootstrap_reps must be positive")

    suite = _json(args.suite_preflight)
    if suite.get("schema") != SCHEMA or suite.get("preflight_pass") is not True:
        raise RuntimeError("invalid label-control suite preflight")
    if file_sha256(args.test_jsonl) != suite["artifact_sha256"]["test"]:
        raise RuntimeError("test corpus differs from the locked control input")
    paths = mappings(args.gate)
    if set(paths) != set(VARIANTS):
        raise ValueError("both and only the two label controls are required")

    full = _json(suite["full_control_gate"]["path"])
    controls = {name: _json(path) for name, path in paths.items()}
    test_rows = _jsonl(args.test_jsonl)
    full_rows = reconstruct_state_rows(full, test_rows)
    results = {}
    structural = {}
    for offset, name in enumerate(VARIANTS, start=1):
        gate = controls[name]
        rows = reconstruct_state_rows(gate, test_rows)
        structural[name] = {
            "schema": gate.get("schema") == "gridrank-label-control-gate-v1",
            "variant": gate.get("label_control_variant") == name,
            "suite": gate.get("label_control_suite_sha256")
                == file_sha256(args.suite_preflight),
            "training_complete": gate.get("control_training_complete") is True,
            "same_states": {row["instance_id"] for row in rows}
                == {row["instance_id"] for row in full_rows},
            "reference_frozen": gate.get("reference_parameter_delta", {}).get(
                "changed_tensors"
            ) == 0,
            "final_feasible": gate.get("summaries", {}).get("distilled", {}).get(
                "safe_feasible_rate"
            ) == 1.0,
            "reconstructed_mean_exact": math.isclose(
                sum(row["distilled_safe_regret"] for row in rows) / len(rows),
                float(gate["summaries"]["distilled"]["safe_regret_mean"]),
                rel_tol=0.0, abs_tol=1e-9,
            ),
        }
        full_over_control = paired(
            rows, full_rows, args.bootstrap_reps,
            args.bootstrap_seed + 2000 * offset,
        )
        by_network = {}
        for network in ("33", "69"):
            control_network = [row for row in rows if row["network"] == network]
            full_network = [row for row in full_rows if row["network"] == network]
            by_network[network] = {
                "control_over_frozen_sft": gate["paired"][
                    "distilled_vs_sft_by_network"
                ][network],
                "full_gridrank_over_control": paired(
                    control_network, full_network, args.bootstrap_reps,
                    args.bootstrap_seed + 4000 * offset + int(network),
                ),
            }
        results[name] = {
            "training_supervision_audit": gate["training_supervision_audit"],
            "summary": gate["summaries"]["distilled"],
            "control_over_frozen_sft": gate["paired"]["distilled_vs_sft"],
            "full_gridrank_over_control": full_over_control,
            "by_network": by_network,
        }

    shuffled_ci = results["shuffled_labels"]["full_gridrank_over_control"][
        "state_cluster_bootstrap_ci95"
    ]
    lindistflow_ci = results["lindistflow_labels"]["full_gridrank_over_control"][
        "state_cluster_bootstrap_ci95"
    ]
    checks = {
        "full_control_current": file_sha256(suite["full_control_gate"]["path"])
            == suite["full_control_gate"]["sha256"],
        "locked_test_current": file_sha256(args.test_jsonl)
            == suite["artifact_sha256"]["test"],
        "original_locked_aggregate_code_preserved": file_sha256(
            Path(__file__).with_name("aggregate_gridrank_label_controls.py")
        ) == suite["code_sha256"]["aggregate_gridrank_label_controls.py"],
        "both_controls_structurally_valid": all(
            all(values.values()) for values in structural.values()
        ),
    }
    payload = {
        "schema": AGGREGATE_SCHEMA,
        "experiment_id": EXPERIMENT_ID,
        "audit_pass": all(checks.values()),
        "training_performed": False,
        "model_loaded": False,
        "power_flow_calls": 0,
        "reconstruction": RECONSTRUCTION,
        "full_gridrank_summary": full["summaries"]["distilled"],
        "frozen_sft_summary": full["summaries"]["sft"],
        "controls": results,
        "structural_checks": structural,
        "checks": checks,
        "causal_decision": {
            "full_beats_shuffled_ci_lower_positive": shuffled_ci[0] > 0.0,
            "full_beats_lindistflow_label_ci_lower_positive": lindistflow_ci[0] > 0.0,
            "physics_specificity_gate_pass": shuffled_ci[0] > 0.0
                and lindistflow_ci[0] > 0.0,
            "interpretation": (
                "Full-minus-shuffled isolates valid label-action correspondence beyond "
                "YES/NO format adaptation. Full-minus-LinDistFlow isolates authoritative "
                "AC-feedback value beyond matched approximate-physics supervision."
            ),
        },
        "bootstrap_reps": args.bootstrap_reps,
        "bootstrap_seed": args.bootstrap_seed,
        "suite_preflight": {
            "path": str(Path(args.suite_preflight).resolve()),
            "sha256": file_sha256(args.suite_preflight),
        },
        "test_jsonl": {
            "path": str(Path(args.test_jsonl).resolve()),
            "sha256": file_sha256(args.test_jsonl),
        },
        "control_gates": {
            name: {"path": str(Path(path).resolve()), "sha256": file_sha256(path)}
            for name, path in paths.items()
        },
        "hotfix_code_sha256": file_sha256(__file__),
    }
    Path(args.output).write_text(
        json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    print(json.dumps({
        "msg": "GridRank matched label-controls hotfix aggregate",
        "audit_pass": payload["audit_pass"],
        "causal_decision": payload["causal_decision"],
        "controls": {
            name: {
                "control_over_frozen_sft": value["control_over_frozen_sft"],
                "full_gridrank_over_control": value["full_gridrank_over_control"],
            }
            for name, value in results.items()
        },
    }, ensure_ascii=False))
    if not payload["audit_pass"]:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
