"""Train GridRank dynamic policy."""

from __future__ import annotations

import argparse
import gc
import json
import random
from collections import defaultdict
from pathlib import Path
from types import SimpleNamespace

import preflight_gridrank_dynamic_benchmark as benchmark
import preflight_gridrank_dynamic_policy as preflight
import train_gridrank_select as select
from build_gridrank_instruction_pairs import selected_action, structured_proxy_order
from gridrank_dynamic_llm import (
    CARDS, card_index, card_scores, card_semantics, oracle_card_id,
    selected_card_id,
)


GENERIC_INSTRUCTION = (
    "Choose a safe distribution-grid switching policy for the current operating state."
)


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--train_jsonl", required=True)
    parser.add_argument("--validation_jsonl", required=True)
    parser.add_argument("--pair_summary", required=True)
    parser.add_argument("--benchmark_manifest", required=True)
    parser.add_argument("--preflight_manifest", required=True)
    parser.add_argument("--resume_adapter_path", required=True)
    parser.add_argument("--sft_adapter_path", required=True)
    parser.add_argument("--output_dir", required=True)
    parser.add_argument("--base_model", required=True)
    parser.add_argument("--max_length", type=int, required=True)
    parser.add_argument("--card_batch_size", type=int, required=True)
    parser.add_argument("--epochs", type=int, required=True)
    parser.add_argument("--learning_rate", type=float, required=True)
    parser.add_argument("--grad_accum", type=int, required=True)
    parser.add_argument("--max_grad_norm", type=float, required=True)
    parser.add_argument("--target_temperature", type=float, required=True)
    parser.add_argument("--lambda_semantic", type=float, required=True)
    parser.add_argument("--lambda_physics", type=float, required=True)
    parser.add_argument("--lambda_hard", type=float, required=True)
    parser.add_argument("--hard_margin", type=float, required=True)
    parser.add_argument("--beta_reference", type=float, required=True)
    parser.add_argument("--seed", type=int, required=True)
    parser.add_argument("--gradient_checkpointing", type=int, choices=(0, 1), required=True)
    parser.add_argument("--bootstrap_reps", type=int, required=True)
    return parser.parse_args()


def read_rows(path):
    return [json.loads(line) for line in open(path, encoding="utf-8") if line.strip()]


def rows_by_ids(path, ids):
    values = {row["instance_id"]: row for row in read_rows(path)}
    missing = sorted(set(ids).difference(values))
    if missing:
        raise RuntimeError(f"locked dynamic-policy rows missing: {missing[:5]}")
    return [values[value] for value in ids]


def counterfactual_texts(rows):
    groups = defaultdict(dict)
    for row in rows:
        groups[row["pair_id"]][row["pair_side"]] = row["instruction_text"]
    return {
        row["instance_id"]: groups[row["pair_id"]][
            "right" if row["pair_side"] == "left" else "left"
        ]
        for row in rows
    }


def condition_row(row, condition, counterfactual):
    if condition == "correct":
        return row
    value = dict(row)
    if condition == "instruction_removed":
        value["instruction_text"] = GENERIC_INSTRUCTION
    elif condition == "instruction_counterfactual":
        value["instruction_text"] = counterfactual[row["instance_id"]]
    else:
        raise ValueError(condition)
    return value


def score_cache(model, tokenizer, rows, args, adapter, condition="correct"):
    model.set_adapter(adapter)


    counterfactual = (
        counterfactual_texts(rows)
        if condition == "instruction_counterfactual" else {}
    )
    output = {}
    for row in rows:
        value = condition_row(row, condition, counterfactual)
        output[row["instance_id"]] = card_scores(
            model, tokenizer, value,
            max_length=args.max_length,
            card_batch_size=args.card_batch_size,
            require_grad=False,
        ).detach().float().cpu()
    model.set_adapter("default")
    return output


def loss_terms(scores, row, reference_scores, args):
    import torch
    import torch.nn.functional as functional

    outcomes = preflight.card_outcomes(row)
    target = torch.tensor(
        preflight.physics_target(outcomes, args.target_temperature),
        dtype=torch.float32, device=scores.device,
    )
    log_prob = torch.log_softmax(scores.float(), dim=0)
    physics_listwise = -(target * log_prob).sum()
    semantic_index = card_index(oracle_card_id(row))
    semantic = functional.cross_entropy(
        scores.float().unsqueeze(0),
        torch.tensor([semantic_index], device=scores.device),
    )
    wrong = torch.cat((scores[:semantic_index], scores[semantic_index + 1:]))
    hard = functional.softplus(
        args.hard_margin - (scores[semantic_index] - wrong.max())
    )
    reference_log_prob = torch.log_softmax(
        reference_scores.to(scores.device).float(), dim=0
    )
    probability = torch.softmax(scores.float(), dim=0)
    reference_kl = (probability * (log_prob - reference_log_prob)).sum()
    total = (
        args.lambda_semantic * semantic
        + args.lambda_physics * physics_listwise
        + args.lambda_hard * hard
        + args.beta_reference * reference_kl
    )
    return {
        "total": total,
        "semantic": semantic,
        "physics_listwise": physics_listwise,
        "hard": hard,
        "reference_kl": reference_kl,
    }


def train_replay(model, tokenizer, rows, references, default_lora, reference_lora, args):
    

    import torch

    parameters = [parameter for _, parameter in default_lora]
    optimizer = torch.optim.AdamW(parameters, lr=args.learning_rate, weight_decay=0.0)
    rng = random.Random(args.seed + 1701)
    history, first_gradient = [], None
    optimizer_steps = candidate_backward_passes = 0
    max_replay_score_delta = 0.0
    tolerance = 1e-4
    for epoch in range(1, args.epochs + 1):
        schedule = list(rows)
        rng.shuffle(schedule)
        optimizer.zero_grad(set_to_none=True)
        epoch_records = []
        for micro, row in enumerate(schedule, start=1):
            scores = card_scores(
                model, tokenizer, row,
                max_length=args.max_length,
                card_batch_size=args.card_batch_size,
                require_grad=False,
            )
            leaf = scores.detach().float().requires_grad_(True)
            terms = loss_terms(leaf, row, references[row["instance_id"]], args)
            coefficients = torch.autograd.grad(terms["total"], leaf)[0].detach()
            epoch_records.append({key: float(value.detach()) for key, value in terms.items()})
            for index, card in enumerate(CARDS):
                replayed = card_scores(
                    model, tokenizer, row,
                    max_length=args.max_length,
                    card_batch_size=1,
                    require_grad=True,
                    cards=[card],
                )[0].float()
                delta = abs(float(replayed.detach()) - float(scores[index]))
                max_replay_score_delta = max(max_replay_score_delta, delta)
                if delta > tolerance:
                    raise RuntimeError(
                        f"non-deterministic card replay row={row['instance_id']} "
                        f"card={card['card_id']} delta={delta}"
                    )
                (replayed * coefficients[index] / args.grad_accum).backward()
                candidate_backward_passes += 1
                del replayed
            if first_gradient is None:
                first_gradient = select.gradient_audit(default_lora, reference_lora)
                if (
                    first_gradient["nonzero_gradient_tensors"] <= 0
                    or not first_gradient["finite"]
                    or first_gradient["reference_gradient_tensors"] != 0
                ):
                    raise RuntimeError(f"first-gradient audit failed: {first_gradient}")
            if micro % args.grad_accum == 0:
                select.optimizer_step(optimizer, parameters, args.max_grad_norm)
                optimizer_steps += 1
            if micro == 1 or micro % 20 == 0 or micro == len(schedule):
                print(json.dumps({
                    "msg": "GridRank dynamic-policy score-gradient replay",
                    "epoch": epoch, "rows_complete": micro,
                    "rows_total": len(schedule),
                    "card_backward_passes": candidate_backward_passes,
                    "max_replay_score_delta": max_replay_score_delta,
                }, ensure_ascii=False), flush=True)
            del scores, leaf, terms, coefficients
        remainder = len(schedule) % args.grad_accum
        if remainder:
            scale = args.grad_accum / remainder
            for parameter in parameters:
                if parameter.grad is not None:
                    parameter.grad.mul_(scale)
            select.optimizer_step(optimizer, parameters, args.max_grad_norm)
            optimizer_steps += 1
        record = {
            "epoch": epoch,
            **{
                key: sum(value[key] for value in epoch_records) / len(epoch_records)
                for key in ("total", "semantic", "physics_listwise", "hard", "reference_kl")
            },
            "optimizer_steps_total": optimizer_steps,
        }
        history.append(record)
        print(json.dumps({"msg": "GridRank dynamic-policy epoch", **record}, ensure_ascii=False), flush=True)
    return {
        "objective": (
            "semantic cross-entropy + AC-regret card listwise + smooth hard-card margin "
            "+ frozen-reference KL"
        ),
        "history": history,
        "first_gradient": first_gradient,
        "optimizer_steps": optimizer_steps,
        "gradient_strategy": "exact_card_score_gradient_replay",
        "card_backward_passes": candidate_backward_passes,
        "max_replay_score_delta": max_replay_score_delta,
        "replay_tolerance": tolerance,
    }


def action_from_card(row, card_id):
    semantic = card_semantics(row, card_id, benchmark.extract_edges)
    ranking = structured_proxy_order(
        row, semantic["objective"], semantic["forbidden_edges"]
    )
    return semantic, selected_action(row, ranking, 1)


def records_from_scores(rows, scores, condition):
    output = []
    counterfactual = (
        counterfactual_texts(rows)
        if condition == "instruction_counterfactual" else {}
    )
    for row in rows:
        card_id = selected_card_id(scores[row["instance_id"]])
        score_condition = (
            condition if condition in {"instruction_removed", "instruction_counterfactual"}
            else "correct"
        )
        interpreted_row = condition_row(row, score_condition, counterfactual)
        semantic, action = action_from_card(interpreted_row, card_id)
        regret = benchmark.action_regret(row, action)
        target = benchmark.semantic_target(row)
        output.append({
            "instance_id": row["instance_id"], "pair_id": row["pair_id"],
            "pair_side": row["pair_side"], "pair_type": row["pair_type"],
            "network": str(row["network_id"]), "condition": condition,
            "selected_card": card_id, "target_card": oracle_card_id(row),
            "semantic_correct": card_id == oracle_card_id(row),
            "safe_action": action, "normalised_regret": regret,
            "physics_optimal": regret <= 1e-12,
            "safe_feasible": True,
            "constraint_violation": benchmark.action_touches(
                action, target["forbidden_edges"]
            ),
        })
    return output


def records_from_predictions(rows, predictions, method):
    output = []
    for row in rows:
        semantic = predictions[row["instance_id"]]
        ranking = structured_proxy_order(
            row, semantic["objective"], semantic["forbidden_edges"]
        )
        action = selected_action(row, ranking, 1)
        regret = benchmark.action_regret(row, action)
        target = benchmark.semantic_target(row)
        output.append({
            "instance_id": row["instance_id"], "pair_id": row["pair_id"],
            "pair_side": row["pair_side"], "pair_type": row["pair_type"],
            "network": str(row["network_id"]), "condition": method,
            "selected_card": None, "target_card": oracle_card_id(row),
            "semantic_correct": (
                semantic["objective"] == target["objective"]
                and bool(semantic["hard_constraint"]) == bool(target["hard_constraint"])
                and {tuple(sorted(x)) for x in semantic["forbidden_edges"]}
                == {tuple(sorted(x)) for x in target["forbidden_edges"]}
            ),
            "safe_action": action, "normalised_regret": regret,
            "physics_optimal": regret <= 1e-12, "safe_feasible": True,
            "constraint_violation": benchmark.action_touches(
                action, target["forbidden_edges"]
            ),
        })
    return output


def full_ac_oracle_records(rows):
    output = []
    for row in rows:
        action = row["desired_action"]
        output.append({
            "instance_id": row["instance_id"], "pair_id": row["pair_id"],
            "pair_side": row["pair_side"], "pair_type": row["pair_type"],
            "network": str(row["network_id"]), "condition": "full_ac_oracle",
            "selected_card": None, "target_card": oracle_card_id(row),
            "semantic_correct": True, "safe_action": action,
            "normalised_regret": benchmark.action_regret(row, action),
            "physics_optimal": True, "safe_feasible": True,
            "constraint_violation": False,
        })
    return output


def mean(values):
    return sum(values) / len(values) if values else None


def brief(records):
    return {
        "n": len(records), "pairs": len({row["pair_id"] for row in records}),
        "normalised_regret_mean": mean([row["normalised_regret"] for row in records]),
        "physics_optimal_rate": mean([float(row["physics_optimal"]) for row in records]),
        "semantic_accuracy": mean([float(row["semantic_correct"]) for row in records]),
        "constraint_violation_rate": mean([float(row["constraint_violation"]) for row in records]),
        "safe_feasible_rate": mean([float(row["safe_feasible"]) for row in records]),
    }


def summarize(records):
    groups = defaultdict(list)
    for row in records:
        groups[row["pair_id"]].append(row)
    value = brief(records)
    value["instruction_pair_flip_rate"] = mean([
        float(len({row["safe_action"] for row in rows}) > 1)
        for rows in groups.values()
    ])
    value["by_network"] = {
        network: brief([row for row in records if row["network"] == network])
        for network in ("33", "69")
    }
    value["by_pair_type"] = {
        pair_type: brief([row for row in records if row["pair_type"] == pair_type])
        for pair_type in ("objective", "maintenance_loss", "maintenance_voltage")
    }
    return value


def paired(before, after, reps, seed):
    left = {row["instance_id"]: row for row in before}
    right = {row["instance_id"]: row for row in after}
    if set(left) != set(right):
        raise ValueError("paired IDs differ")
    groups, network = defaultdict(list), {}
    for key in sorted(left):
        pair_id = left[key]["pair_id"]
        groups[pair_id].append(
            float(left[key]["normalised_regret"])
            - float(right[key]["normalised_regret"])
        )
        network[pair_id] = left[key]["network"]

    def calculate(ids, draw_seed):
        values = [mean(groups[value]) for value in ids]
        if not values:
            return {"pair_clusters": 0, "improvement_mean": None, "ci95": [None, None]}
        rng = random.Random(draw_seed)
        draws = sorted(
            mean([values[rng.randrange(len(values))] for _ in values])
            for _ in range(reps)
        )
        return {
            "pair_clusters": len(values), "improvement_mean": mean(values),
            "ci95": [
                draws[int(0.025 * (len(draws) - 1))],
                draws[int(0.975 * (len(draws) - 1))],
            ],
        }
    ids = sorted(groups)
    result = calculate(ids, seed)
    result["rows_better"] = sum(
        left[key]["normalised_regret"] > right[key]["normalised_regret"] + 1e-12
        for key in left
    )
    result["rows_worse"] = sum(
        left[key]["normalised_regret"] + 1e-12 < right[key]["normalised_regret"]
        for key in left
    )
    result["by_network"] = {
        value: calculate([key for key in ids if network[key] == value], seed + int(value))
        for value in ("33", "69")
    }
    return result


def subset(records, pair_type):
    return [row for row in records if row["pair_type"] == pair_type]


def max_score_delta(left, right):
    return max(
        abs(float(a) - float(b))
        for key in left for a, b in zip(left[key], right[key])
    )


def main():
    import torch
    import grpo_train as training

    args = parse_args()
    output = Path(args.output_dir)
    if output.exists():
        raise FileExistsError(f"refusing to overwrite output: {output}")
    verify_args = SimpleNamespace(**vars(args), output=args.preflight_manifest)
    preflight.verify(verify_args)
    manifest = json.load(open(args.preflight_manifest, encoding="utf-8"))
    if not torch.cuda.is_available():
        raise RuntimeError("GridRank dynamic-policy stage requires CUDA")
    random.seed(args.seed)
    torch.manual_seed(args.seed)
    torch.cuda.manual_seed_all(args.seed)
    train_rows = rows_by_ids(args.train_jsonl, manifest["selection"]["train_row_ids"])
    validation_rows = rows_by_ids(
        args.validation_jsonl, manifest["selection"]["validation_row_ids"]
    )
    composition_rows = [
        row for row in validation_rows if row["pair_type"] == "maintenance_voltage"
    ]
    model, tokenizer = training.build_model_and_tokenizer(args)
    model.load_adapter(args.sft_adapter_path, adapter_name="sft_control", is_trainable=False)
    model.set_adapter("default")
    default_lora = [(n, p) for n, p in model.named_parameters() if "lora_" in n and ".default." in n]
    reference_lora = [(n, p) for n, p in model.named_parameters() if "lora_" in n and ".reference." in n]
    sft_lora = [(n, p) for n, p in model.named_parameters() if "lora_" in n and ".sft_control." in n]
    if not default_lora or not reference_lora or not sft_lora:
        raise RuntimeError("policy, frozen reference, and SFT control adapters are required")
    for _, parameter in default_lora:
        parameter.requires_grad_(True)
    for _, parameter in [*reference_lora, *sft_lora]:
        parameter.requires_grad_(False)
    equality = select.adapter_initial_equality(default_lora, reference_lora)
    if not equality["same_tensor_set"] or equality["changed_tensors"] != 0:
        raise RuntimeError(f"policy/reference adapter mismatch: {equality}")
    policy_before = select.parameter_copy(default_lora)
    reference_before = select.parameter_copy(reference_lora)
    sft_before = select.parameter_copy(sft_lora)
    reference_train = score_cache(model, tokenizer, train_rows, args, "reference")
    frozen_validation = score_cache(model, tokenizer, validation_rows, args, "reference")
    sft_validation = score_cache(model, tokenizer, validation_rows, args, "sft_control")
    gc.collect()
    torch.cuda.empty_cache()
    training_result = train_replay(
        model, tokenizer, train_rows, reference_train,
        default_lora, reference_lora, args,
    )
    aligned = score_cache(model, tokenizer, validation_rows, args, "default", "correct")
    removed = score_cache(model, tokenizer, validation_rows, args, "default", "instruction_removed")
    counterfactual = score_cache(
        model, tokenizer, validation_rows, args, "default", "instruction_counterfactual"
    )
    policy_delta = select.parameter_delta(default_lora, policy_before)
    reference_delta = select.parameter_delta(reference_lora, reference_before)
    sft_delta = select.parameter_delta(sft_lora, sft_before)
    score_delta = max_score_delta(frozen_validation, aligned)

    train_all = benchmark.load_rows(args.train_jsonl, "train")
    full_text = benchmark.fit_text_parser(train_all, 20260826)
    withheld_text = benchmark.fit_text_parser(
        [row for row in train_all if row["pair_type"] != "maintenance_voltage"],
        20260926,
    )
    predictions = {
        "fixed_loss_lindistflow": benchmark.fixed_predictions(validation_rows),
        "frozen_rule_parser_lindistflow": benchmark.rule_predictions(validation_rows),
        "tfidf_logreg_lindistflow": benchmark.predict_text_parser(full_text, validation_rows),
        "tfidf_logreg_withheld_composition": benchmark.predict_text_parser(withheld_text, validation_rows),
        "oracle_structured_lindistflow": benchmark.oracle_predictions(validation_rows),
    }
    records = {
        name: records_from_predictions(validation_rows, value, name)
        for name, value in predictions.items()
    }
    records.update({
        "sft_card_interface": records_from_scores(validation_rows, sft_validation, "sft"),
        "frozen_gridrank_card_interface": records_from_scores(validation_rows, frozen_validation, "frozen"),
        "physics_aligned_dynamic_llm": records_from_scores(validation_rows, aligned, "correct"),
        "instruction_removed": records_from_scores(validation_rows, removed, "instruction_removed"),
        "instruction_counterfactual": records_from_scores(validation_rows, counterfactual, "instruction_counterfactual"),
        "full_ac_oracle": full_ac_oracle_records(validation_rows),
    })
    summaries = {name: summarize(value) for name, value in records.items()}
    aligned_records = records["physics_aligned_dynamic_llm"]
    comparisons = {
        "aligned_vs_fixed": paired(records["fixed_loss_lindistflow"], aligned_records, args.bootstrap_reps, args.seed + 100),
        "aligned_vs_rule": paired(records["frozen_rule_parser_lindistflow"], aligned_records, args.bootstrap_reps, args.seed + 200),
        "aligned_vs_full_tfidf": paired(records["tfidf_logreg_lindistflow"], aligned_records, args.bootstrap_reps, args.seed + 300),
        "correct_vs_removed": paired(records["instruction_removed"], aligned_records, args.bootstrap_reps, args.seed + 400),
        "correct_vs_counterfactual": paired(records["instruction_counterfactual"], aligned_records, args.bootstrap_reps, args.seed + 500),
        "composition_aligned_vs_withheld_tfidf": paired(
            subset(records["tfidf_logreg_withheld_composition"], "maintenance_voltage"),
            subset(aligned_records, "maintenance_voltage"),
            args.bootstrap_reps, args.seed + 600,
        ),
    }
    history = training_result["history"]
    mechanism = {
        "nonzero_finite_gradient": bool(
            training_result["first_gradient"]
            and training_result["first_gradient"]["nonzero_gradient_tensors"] > 0
            and training_result["first_gradient"]["finite"]
        ),
        "reference_adapter_frozen": reference_delta["changed_tensors"] == 0,
        "sft_adapter_frozen": sft_delta["changed_tensors"] == 0,
        "policy_adapter_changed": policy_delta["changed_tensors"] > 0,
        "card_scores_changed": score_delta > 1e-4,
        "training_objective_improved": history[-1]["total"] < history[0]["total"],
    }
    comp = comparisons["composition_aligned_vs_withheld_tfidf"]
    engineering = {
        "aligned_beats_fixed_point": comparisons["aligned_vs_fixed"]["improvement_mean"] > 0,
        "aligned_beats_rule_point": comparisons["aligned_vs_rule"]["improvement_mean"] > 0,
        "primary_noninferior_to_full_tfidf_2pp": (
            summaries["physics_aligned_dynamic_llm"]["normalised_regret_mean"]
            <= summaries["tfidf_logreg_lindistflow"]["normalised_regret_mean"] + 0.02
        ),
        "unseen_composition_beats_withheld_tfidf_point": comp["improvement_mean"] > 0,
        "correct_beats_removed_point": comparisons["correct_vs_removed"]["improvement_mean"] > 0,
        "correct_beats_counterfactual_point": comparisons["correct_vs_counterfactual"]["improvement_mean"] > 0,
        "composition_nonnegative_both_networks": all(
            comp["by_network"][network]["improvement_mean"] >= 0 for network in ("33", "69")
        ),
    }
    safety = {
        "aligned_feasible_100pct": summaries["physics_aligned_dynamic_llm"]["safe_feasible_rate"] == 1.0,
        "aligned_zero_constraint_violation": summaries["physics_aligned_dynamic_llm"]["constraint_violation_rate"] == 0.0,
    }
    paper = {
        "engineering_gate_pass": all({**mechanism, **engineering, **safety}.values()),
        "aligned_vs_fixed_ci_lower_positive": comparisons["aligned_vs_fixed"]["ci95"][0] > 0,
        "composition_vs_withheld_tfidf_ci_lower_positive": comp["ci95"][0] > 0,
        "correct_vs_removed_ci_lower_positive": comparisons["correct_vs_removed"]["ci95"][0] > 0,
        "correct_vs_counterfactual_ci_lower_positive": comparisons["correct_vs_counterfactual"]["ci95"][0] > 0,
        "composition_positive_both_networks": all(
            comp["by_network"][network]["improvement_mean"] > 0 for network in ("33", "69")
        ),
    }
    engineering_pass = all({**mechanism, **engineering, **safety}.values())
    paper_pass = all(paper.values())
    output.mkdir(parents=True, exist_ok=False)
    saved = bool(training.save_policy_adapter(model, output / "diagnostic_adapter", args.epochs))
    adapter_validation = select.validate_saved_adapter(output / "diagnostic_adapter")
    mechanism["diagnostic_adapter_saved"] = saved and adapter_validation["valid"]
    engineering_pass = all({**mechanism, **engineering, **safety}.values())
    paper["engineering_gate_pass"] = engineering_pass
    paper_pass = all(paper.values())
    result = {
        "msg": "GridRank physics-certified dynamic semantic-policy gate",
        "architecture": (
            "native LLM selects loss/voltage x maintenance semantic card; "
            "LinDistFlow ranks actions; cached authoritative AC feedback trains LoRA; "
            "separate AC/no-op gate executes"
        ),
        "withheld_composition": "maintenance_voltage",
        "development_reuse_disclosed": True,
        "fresh_final_test_required": True,
        "preflight_sha256": preflight.file_sha256(args.preflight_manifest),
        "schedule": preflight.schedule(args),
        "training": training_result,
        "initial_adapter_equality": equality,
        "parameter_delta": policy_delta,
        "reference_parameter_delta": reference_delta,
        "sft_parameter_delta": sft_delta,
        "validation_score_max_abs_delta": score_delta,
        "summaries": summaries,
        "paired": comparisons,
        "mechanism_checks": mechanism,
        "engineering_checks": engineering,
        "safety_checks": safety,
        "paper_checks": paper,
        "engineering_gate_pass": engineering_pass,
        "paper_gate_pass": paper_pass,
        "decision": (
            "authorize_fresh_dynamic_confirmation" if engineering_pass
            else "stop_dynamic_policy_route"
        ),
        "diagnostic_adapter": adapter_validation,
    }
    (output / "gridrank_dynamic_policy_gate.json").write_text(
        json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps(result, ensure_ascii=False))
    if not engineering_pass:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
