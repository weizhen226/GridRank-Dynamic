"""Gridrank dynamic cross topology utilities."""

from __future__ import annotations

import gridrank_simbench as _base


PREDECLARED_CODES = (
    "1-MV-rural--2-sw",
    "1-MV-semiurb--2-sw",
    "1-MV-urban--2-sw",
)
PRIOR_CODES = (
    "1-MV-rural--0-sw", "1-MV-semiurb--0-sw", "1-MV-urban--0-sw",
    "1-MV-rural--1-sw", "1-MV-semiurb--1-sw", "1-MV-urban--1-sw",
    "1-MV-comm--0-sw", "1-MV-comm--1-sw", "1-MV-comm--2-sw",
)
SUITE_ID = "gridrank-dynamic-simbench-scenario2-unseen-topology-v1"

_base.PREDECLARED_CODES = PREDECLARED_CODES
_base._base_template.cache_clear()
_base.complete_actions.cache_clear()

PANDAPOWER_VERSION = _base.PANDAPOWER_VERSION
SIMBENCH_MAJOR_MINOR = _base.SIMBENCH_MAJOR_MINOR
VMIN = _base.VMIN
VMAX = _base.VMAX
SBASE_MVA = _base.SBASE_MVA
DEADBAND_PCT = _base.DEADBAND_PCT
NOOP = _base.NOOP
ACTION_RE = _base.ACTION_RE

runtime_versions = _base.runtime_versions
available_mv_codes = _base.available_mv_codes
verify_predeclared_codes = _base.verify_predeclared_codes
_check_runtime = _base._check_runtime
base_network = _base.base_network
network_id = _base.network_id
network_inventory = _base.network_inventory
network_fingerprint = _base.network_fingerprint
open_line_indices = _base.open_line_indices
line_edge = _base.line_edge
source_roots = _base.source_roots
line_graph = _base.line_graph
topology_audit = _base.topology_audit
complete_actions = _base.complete_actions
state_network = _base.state_network
state_identity = _base.state_identity
operating_regime = _base.operating_regime
select_action_pool = _base.select_action_pool
candidate_feature_texts = _base.candidate_feature_texts
state_text = _base.state_text
score_state = _base.score_state
proxy_score = _base.proxy_score


def suite_manifest():
    return {
        "suite_id": SUITE_ID,
        "predeclared_codes": list(PREDECLARED_CODES),
        "prior_codes_excluded": list(PRIOR_CODES),
        "dynamic_training_networks": ["IEEE-33", "IEEE-69"],
        "selection_time_boundary": (
            "scenario-2 codes, quotas, candidate budget and language bank are "
            "locked before AC pair qualification and before all model outputs"
        ),
        "role": "sealed dynamic cross-topology zero-shot evaluation only",
        "topology_family_overlap_disclosure": (
            "the exact scenario-2 codes and all dynamic instruction outcomes are "
            "new to the dynamic models; rural/semi-urban/urban graph families "
            "overlap earlier static scenario-shift diagnostics, so this is not "
            "claimed as a pristine never-inspected topology-family holdout"
        ),
        "claim_boundary": (
            "tests zero-shot transfer from IEEE-33/69 dynamic training to exact "
            "unseen SimBench scenario-2 networks of the language-policy plus "
            "topology-normalised physics execution framework; it does not claim "
            "that the LLM internally represents topology or that every SimBench "
            "graph family was previously uninspected"
        ),
    }
