"""Check inputs for GridRank dynamic confirmation replication."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import preflight_gridrank_dynamic_confirmation as original
import preflight_gridrank_dynamic_factorized_replication as factor_preflight
import preflight_gridrank_feedback as runtime


HERE = Path(__file__).resolve().parent
SCHEMA = "gridrank-dynamic-confirmation-seed-replication-preflight-v1"
EXPERIMENT_ID = "gridrank-factorized-dynamic-confirmation-seed-replication-v1"
CODE_FILES = (
    "eval_gridrank_dynamic_confirmation.py",
    "verify_gridrank_dynamic_confirmation.py",
    "preflight_gridrank_dynamic_confirmation_replication.py",
    "eval_gridrank_dynamic_confirmation_replication.py",
    "verify_gridrank_dynamic_confirmation_replication.py",
    "run_gridrank_dynamic_confirmation_replication.sh",
    "../../docs/GRIDRANK_DYNAMIC_MULTISEED_PROTOCOL.md",
)

file_sha256 = original.file_sha256
adapter_hash = original.adapter_hash
schedule = original.schedule


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--fresh_pairs", required=True)
    parser.add_argument("--fresh_summary", required=True)
    parser.add_argument("--fresh_audit", required=True)
    parser.add_argument("--original_train", required=True)
    parser.add_argument("--original_validation", required=True)
    parser.add_argument("--factorized_preflight", required=True)
    parser.add_argument("--factorized_gate", required=True)
    parser.add_argument("--factorized_adapter", required=True)
    parser.add_argument("--base_model", required=True)
    parser.add_argument("--reference_confirmation_preflight", required=False)
    parser.add_argument("--reference_confirmation_gate", required=False)
    parser.add_argument("--model_seed", type=int, required=False)
    parser.add_argument("--output", required=True)
    parser.add_argument("--max_length", type=int, required=True)
    parser.add_argument("--primitive_batch_size", type=int, required=True)
    parser.add_argument("--topk", type=int, required=True)
    parser.add_argument("--bootstrap_reps", type=int, required=True)
    parser.add_argument("--seed", type=int, required=True)
    parser.add_argument("--gradient_checkpointing", type=int, choices=(0, 1), required=True)
    return parser.parse_args()


def code_hashes():
    missing = [name for name in CODE_FILES if not (HERE / name).is_file()]
    if missing:
        raise FileNotFoundError(f"missing confirmation-replication code: {missing}")
    return {name: file_sha256(HERE / name) for name in CODE_FILES}


def _source_artifacts(args):
    return {
        "fresh_pairs": args.fresh_pairs,
        "fresh_summary": args.fresh_summary,
        "fresh_audit": args.fresh_audit,
        "original_train": args.original_train,
        "original_validation": args.original_validation,
    }


def create(args):
    output = Path(args.output)
    if output.exists():
        raise FileExistsError(f"refusing to overwrite confirmation replication preflight: {output}")
    if not args.reference_confirmation_preflight or not args.reference_confirmation_gate:
        raise ValueError("reference seed-42 confirmation preflight and gate are required")
    if args.model_seed not in factor_preflight.SUPPORTED_SEEDS:
        raise ValueError(f"model_seed must be one of {factor_preflight.SUPPORTED_SEEDS}")

    reference = json.load(open(args.reference_confirmation_preflight, encoding="utf-8"))
    reference_gate = json.load(open(args.reference_confirmation_gate, encoding="utf-8"))
    factor_manifest = json.load(open(args.factorized_preflight, encoding="utf-8"))
    factor_gate = json.load(open(args.factorized_gate, encoding="utf-8"))
    sources = _source_artifacts(args)
    reference_artifacts = reference.get("artifacts", {})
    factor_adapter = adapter_hash(args.factorized_adapter)
    current_schedule = schedule(args)

    checks = {
        "reference_confirmation_schema": reference.get("schema") == original.SCHEMA,
        "reference_confirmation_pass": reference.get("preflight_pass") is True,
        "reference_gate_pass": reference_gate.get("confirmation_gate_pass") is True,
        "reference_gate_bound": reference_gate.get("preflight_sha256")
        == file_sha256(args.reference_confirmation_preflight),
        "frozen_confirmation_bytes_reused": all(
            name in reference_artifacts
            and Path(path).is_file()
            and file_sha256(path) == reference_artifacts[name].get("sha256")
            for name, path in sources.items()
        ),
        "evaluation_schedule_matches_seed42": current_schedule == reference.get("schedule"),
        "factorized_replication_preflight_pass": factor_manifest.get("schema")
        == factor_preflight.SCHEMA and factor_manifest.get("preflight_pass") is True,
        "factorized_model_seed_matches": factor_manifest.get("schedule", {}).get("seed")
        == args.model_seed,
        "factorized_gate_bound": factor_gate.get("preflight_sha256")
        == file_sha256(args.factorized_preflight),
        "factorized_adapter_valid": factor_gate.get("diagnostic_adapter", {}).get("valid") is True,
        "factorized_adapter_matches_gate": factor_adapter
        == factor_gate.get("diagnostic_adapter", {}).get("sha256"),
        "base_model_matches_seed42_confirmation": runtime.model_inventory(args.base_model)
        == reference.get("base_model_inventory"),
        "no_fresh_relabel_or_power_flow": True,
    }
    artifacts = {
        **sources,
        "factorized_preflight": args.factorized_preflight,
        "factorized_gate": args.factorized_gate,
    }
    manifest = {
        "msg": "GridRank dynamic confirmation seed-replication preflight",
        "schema": SCHEMA,
        "experiment_id": EXPERIMENT_ID,
        "preflight_pass": all(checks.values()),
        "evaluation_only": True,
        "training_performed": False,
        "model_loaded": False,
        "power_flow_calls": 0,
        "model_seed": args.model_seed,
        "freshness_status": (
            "previously opened byte-locked confirmation reused only for "
            "predeclared random-seed robustness; not an additional fresh test"
        ),
        "reference_seed42_confirmation": {
            "preflight": {
                "path": str(Path(args.reference_confirmation_preflight).resolve()),
                "sha256": file_sha256(args.reference_confirmation_preflight),
            },
            "gate": {
                "path": str(Path(args.reference_confirmation_gate).resolve()),
                "sha256": file_sha256(args.reference_confirmation_gate),
            },
        },
        "artifacts": {
            name: {"path": str(Path(path).resolve()), "sha256": file_sha256(path)}
            for name, path in artifacts.items()
        },
        "factorized_adapter": {
            "path": str(Path(args.factorized_adapter).resolve()),
            "sha256": factor_adapter,
        },
        "base_model": str(Path(args.base_model).resolve()),
        "base_model_inventory": runtime.model_inventory(args.base_model),
        "training_runtime": runtime.training_runtime(),
        "schedule": current_schedule,
        "code_sha256": code_hashes(),
        "checks": checks,
        "failed_checks": [key for key, value in checks.items() if not value],
    }
    output.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(manifest, ensure_ascii=False))
    if not manifest["preflight_pass"]:
        raise SystemExit(2)


def verify(args):
    from gridrank_runtime_compat import runtime_compatibility

    manifest = json.load(open(args.output, encoding="utf-8"))
    artifact_checks = {
        name: Path(item["path"]).is_file() and file_sha256(item["path"]) == item["sha256"]
        for name, item in manifest.get("artifacts", {}).items()
    }
    reference_checks = {
        name: Path(item["path"]).is_file() and file_sha256(item["path"]) == item["sha256"]
        for name, item in manifest.get("reference_seed42_confirmation", {}).items()
    }
    checks = {
        "schema": manifest.get("schema") == SCHEMA,
        "experiment_id": manifest.get("experiment_id") == EXPERIMENT_ID,
        "preflight_pass": manifest.get("preflight_pass") is True,
        "model_seed_supported": manifest.get("model_seed") in factor_preflight.SUPPORTED_SEEDS,
        "schedule_current": manifest.get("schedule") == schedule(args),
        "artifacts_current": bool(artifact_checks) and all(artifact_checks.values()),
        "reference_confirmation_current": bool(reference_checks) and all(reference_checks.values()),
        "adapter_current": adapter_hash(manifest["factorized_adapter"]["path"])
        == manifest["factorized_adapter"]["sha256"],
        "base_model_current": runtime.model_inventory(manifest["base_model"])
        == manifest.get("base_model_inventory"),
        "runtime_compatible": runtime_compatibility(
            manifest.get("training_runtime"), runtime.training_runtime()
        )["compatible"],
        "code_current": manifest.get("code_sha256") == code_hashes(),
    }
    result = {
        "msg": "GridRank confirmation seed-replication runtime verification",
        "checks": checks,
        "verification_pass": all(checks.values()),
    }
    print(json.dumps(result, ensure_ascii=False))
    if not result["verification_pass"]:
        raise SystemExit(2)


def main():
    args = parse_args()
    if Path(args.output).exists():
        verify(args)
    else:
        create(args)


if __name__ == "__main__":
    main()
