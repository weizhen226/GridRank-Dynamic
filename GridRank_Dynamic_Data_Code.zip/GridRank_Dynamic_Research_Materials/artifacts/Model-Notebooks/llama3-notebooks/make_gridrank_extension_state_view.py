"""Make gridrank extension state view utilities."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path

from build_gridrank_feedback import canonical_state_text, physical_state_sha256
from make_no_oracle_state_view import FORBIDDEN, KEEP, _source_rows


SCHEMA = "gridrank-select-extension-state-role-v1"
SOURCE_SPLIT = "test"
EMITTED_ROLE_SPLIT = "validation"


def file_sha256(path):
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _jsonl(path):
    return [json.loads(line) for line in open(path, encoding="utf-8") if line.strip()]


def _exclusions(paths, network):
    states, loads = set(), set()
    artifacts = []
    for raw_path in paths:
        path = Path(raw_path).resolve()
        if not path.is_file():
            raise FileNotFoundError(path)
        rows = _jsonl(path)
        for row in rows:
            if str(row.get("network_id", row.get("network"))) != str(network):
                continue
            state = row.get("physical_state_sha256")
            load = str(row.get("load_id", ""))
            if state:
                states.add(str(state))
            if load:
                loads.add(load if ":" in load else f"{network}:{load}")
        artifacts.append({"path": str(path), "sha256": file_sha256(path)})
    return states, loads, artifacts


def expected_rows(input_path, network, exclusion_paths):
    excluded_states, excluded_loads, artifacts = _exclusions(exclusion_paths, network)
    source = Path(input_path).resolve()
    rows, raw_ids, counters = [], set(), {
        "raw_test_rows": 0, "excluded_state": 0, "excluded_load": 0,
    }
    for row in _source_rows(source):
        if str(row.get("split")) != SOURCE_SPLIT:
            continue
        counters["raw_test_rows"] += 1
        instance_id = str(row.get("instance_id", ""))
        load = str(row.get("load_id", ""))
        if not instance_id or not load or instance_id in raw_ids:
            raise ValueError("raw test identity must be complete and unique")
        raw_ids.add(instance_id)
        prompt = canonical_state_text(str(row.get("prompt", "")), network)
        state = physical_state_sha256(prompt, network)
        if state in excluded_states:
            counters["excluded_state"] += 1
            continue
        if f"{network}:{load}" in excluded_loads:
            counters["excluded_load"] += 1
            continue
        rows.append({
            "instance_id": instance_id,
            "load_id": load,
            "prompt": prompt,
            "split": EMITTED_ROLE_SPLIT,
        })
    counters["emitted_rows"] = len(rows)
    if len(rows) < 64:
        raise RuntimeError(f"network {network}: fewer than 64 unused raw-test rows")
    return rows, counters, excluded_states, excluded_loads, artifacts


def build(args):
    source = Path(args.input).resolve()
    output = Path(args.output_jsonl).resolve()
    manifest_path = Path(args.manifest_json).resolve()
    if not source.is_file() or source == output:
        raise ValueError("extension source must exist and differ from output")
    if output.exists() or manifest_path.exists():
        raise FileExistsError("refusing to overwrite extension view")
    rows, counters, excluded_states, excluded_loads, artifacts = expected_rows(
        source, args.network, args.exclude_jsonl
    )
    output.parent.mkdir(parents=True, exist_ok=True)
    tmp = output.with_name(output.name + ".tmp")
    with open(tmp, "w", encoding="utf-8", newline="\n") as handle:
        for row in rows:
            handle.write(json.dumps(row, ensure_ascii=False, separators=(",", ":")) + "\n")
    os.replace(tmp, output)
    emitted = _jsonl(output)
    if any(set(row) != set(KEEP) or FORBIDDEN.intersection(row) for row in emitted):
        raise RuntimeError("extension view schema/oracle boundary failed")
    result = {
        "msg": "GridRank-Select unused raw-test extension state view",
        "schema": SCHEMA,
        "network": str(args.network),
        "source_path": str(source),
        "source_sha256": file_sha256(source),
        "source_selected_split": SOURCE_SPLIT,
        "emitted_role_split": EMITTED_ROLE_SPLIT,
        "output_path": str(output),
        "output_sha256": file_sha256(output),
        "columns": list(KEEP),
        "source_text_forwarded": False,
        "forbidden_columns_absent": sorted(FORBIDDEN),
        "exclusion_artifacts": artifacts,
        "excluded_state_count": len(excluded_states),
        "excluded_load_count": len(excluded_loads),
        "counters": counters,
    }
    tmp_manifest = manifest_path.with_name(manifest_path.name + ".tmp")
    tmp_manifest.write_text(json.dumps(result, indent=2, ensure_ascii=False), encoding="utf-8")
    os.replace(tmp_manifest, manifest_path)
    return result


def verify(args):
    source = Path(args.input).resolve()
    output = Path(args.output_jsonl).resolve()
    manifest_path = Path(args.manifest_json).resolve()
    manifest = json.load(open(manifest_path, encoding="utf-8"))
    expected, counters, states, loads, artifacts = expected_rows(
        source, args.network, args.exclude_jsonl
    )
    emitted = _jsonl(output)
    expected_bytes = "".join(
        json.dumps(row, ensure_ascii=False, separators=(",", ":")) + "\n" for row in expected
    ).encode("utf-8")
    checks = {
        "schema": manifest.get("schema") == SCHEMA,
        "network": manifest.get("network") == str(args.network),
        "source_path": manifest.get("source_path") == str(source),
        "source_hash": manifest.get("source_sha256") == file_sha256(source),
        "output_path": manifest.get("output_path") == str(output),
        "output_hash": manifest.get("output_sha256") == file_sha256(output),
        "deterministic_bytes": output.read_bytes() == expected_bytes,
        "strict_schema": all(set(row) == set(KEEP) for row in emitted),
        "oracle_boundary": all(not FORBIDDEN.intersection(row) for row in emitted),
        "role_mapping": all(row.get("split") == EMITTED_ROLE_SPLIT for row in emitted),
        "exclusion_artifacts": manifest.get("exclusion_artifacts") == artifacts,
        "exclusion_counts": manifest.get("excluded_state_count") == len(states)
            and manifest.get("excluded_load_count") == len(loads),
        "counters": manifest.get("counters") == counters,
    }
    result = {
        "msg": "GridRank-Select extension view verification",
        "checks": checks,
        "verification_pass": all(checks.values()),
    }
    if not result["verification_pass"]:
        raise RuntimeError(f"extension view verification failed: {checks}")
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", choices=("build", "verify"), required=True)
    parser.add_argument("--network", choices=("33", "69"), required=True)
    parser.add_argument("--input", required=True)
    parser.add_argument("--exclude_jsonl", action="append", required=True)
    parser.add_argument("--output_jsonl", required=True)
    parser.add_argument("--manifest_json", required=True)
    args = parser.parse_args()
    fn = build if args.mode == "build" else verify
    print(json.dumps(fn(args), ensure_ascii=False))


if __name__ == "__main__":
    main()
