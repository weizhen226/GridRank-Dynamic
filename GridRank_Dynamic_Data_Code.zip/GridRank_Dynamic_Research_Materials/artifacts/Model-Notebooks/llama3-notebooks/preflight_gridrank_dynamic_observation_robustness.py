"""Check inputs for GridRank dynamic observation robustness."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import gridrank_dynamic_observation_robustness as robust
import preflight_gridrank_feedback as runtime
from gridrank_runtime_compat import runtime_compatibility


SCHEMA = "gridrank-dynamic-observation-robustness-preflight-v1"
HERE = Path(__file__).resolve().parent
CODE_FILES = (
    "gridrank_dynamic_observation_robustness.py",
    "preflight_gridrank_dynamic_observation_robustness.py",
    "eval_gridrank_dynamic_observation_robustness.py",
    "verify_gridrank_dynamic_observation_robustness.py",
    "verify_gridrank_dynamic_observation_robustness_dependencies.py",
    "run_gridrank_dynamic_observation_robustness.sh",
    "../../docs/GRIDRANK_DYNAMIC_OBSERVATION_ROBUSTNESS_PROTOCOL.md",
)


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--cross_preflight", required=True)
    parser.add_argument("--cross_gate", required=True)
    parser.add_argument("--cross_records", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--bootstrap_reps", type=int, default=10000)
    parser.add_argument("--bootstrap_seed", type=int, default=20260909)
    parser.add_argument("--verify", action="store_true")
    return parser.parse_args()


def artifact(path):
    value = Path(path).resolve()
    if not value.is_file():
        raise FileNotFoundError(value)
    return {
        "path": str(value),
        "sha256": robust.file_sha256(value),
        "size": value.stat().st_size,
    }


def code_hashes():
    missing = [
        name for name in CODE_FILES if not (HERE / name).resolve().is_file()
    ]
    if missing:
        raise FileNotFoundError(f"missing robustness code: {missing}")
    return {
        name: robust.file_sha256((HERE / name).resolve())
        for name in CODE_FILES
    }


def locked_code_current(values):
    return all(
        (HERE / name).resolve().is_file()
        and robust.file_sha256((HERE / name).resolve()) == digest
        for name, digest in values.items()
    )


def schedule(args):
    return {
        "scenario_seed": robust.SCENARIO_SEED,
        "perturbation_seed": robust.PERTURBATION_SEED,
        "pair_type": robust.PRIMARY,
        "seeds": list(robust.SEEDS),
        "load_scales": list(robust.LOAD_SCALES),
        "der_scales": list(robust.DER_SCALES),
        "measurement_noise_sigmas": list(robust.NOISE_SIGMAS),
        "measurement_noise_replicates": list(robust.NOISE_REPLICATES),
        "candidate_count": 32,
        "topk": 1,
        "bootstrap_reps": args.bootstrap_reps,
        "bootstrap_seed": args.bootstrap_seed,
        "noise_distribution": "deterministic clipped Gaussian multiplicative",
        "noise_clip_standard_deviations": 3.0,
        "operating_shift_design": "one-axis-at-a-time",
        "ground_truth_audit": (
            "measurement-noise deployments are audited on the unchanged "
            "sealed clean AC cache"
        ),
    }


def create(args):
    output = Path(args.output)
    if output.exists():
        raise FileExistsError(f"refusing to overwrite preflight: {output}")
    cross = json.load(open(args.cross_preflight, encoding="utf-8"))
    gate = json.load(open(args.cross_gate, encoding="utf-8"))
    records = robust.read_jsonl(args.cross_records)
    pairs_path = cross["artifacts"]["pairs"]["path"]
    rows = robust.read_jsonl(pairs_path)
    primary = [row for row in rows if row["pair_type"] == robust.PRIMARY]
    methods = {row["method"] for row in records}
    requested = {
        f"{robust.LLM_PREFIX}_s{seed}" for seed in robust.SEEDS
    }
    artifacts = {
        "cross_preflight": artifact(args.cross_preflight),
        "cross_gate": artifact(args.cross_gate),
        "cross_records": artifact(args.cross_records),
        "pairs": artifact(pairs_path),
    }
    checks = {
        "cross_preflight_pass": cross.get("preflight_pass") is True,
        "cross_evaluation_pass": gate.get("evaluation_pass") is True,
        "cross_gate_bound_to_preflight": (
            gate.get("preflight_sha256")
            == artifacts["cross_preflight"]["sha256"]
        ),
        "cross_records_bound_to_gate": (
            gate.get("records", {}).get("sha256")
            == artifacts["cross_records"]["sha256"]
        ),
        "primary_rows_96": len(primary) == 96,
        "primary_pairs_48": len({
            row["pair_id"] for row in primary
        }) == 48,
        "primary_states_48": len({
            row["physical_state_sha256"] for row in primary
        }) == 48,
        "candidate_count_32": all(
            len(row["candidates"]) == 32 for row in primary
        ),
        "three_frozen_seed_records": requested.issubset(methods),
        "bootstrap_reps_10000": args.bootstrap_reps == 10000,
        "upstream_code_current": locked_code_current(
            cross["code_sha256"]
        ),
    }
    physics_python = cross["physics_runtime"]["executable"]
    result = {
        "msg": "GridRank sealed dynamic observation robustness preflight",
        "schema": SCHEMA,
        "experiment_id": robust.EXPERIMENT_ID,
        "preflight_pass": all(checks.values()),
        "evaluation_only": True,
        "training_performed": False,
        "model_loaded": False,
        "power_flow_calls": 0,
        "artifacts": artifacts,
        "schedule": schedule(args),
        "physics_runtime": runtime.physics_runtime(physics_python),
        "code_sha256": code_hashes(),
        "upstream_code_sha256": cross["code_sha256"],
        "checks": checks,
        "failed_checks": [
            key for key, value in checks.items() if not value
        ],
    }
    output.write_text(
        json.dumps(result, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    print(json.dumps({
        "msg": result["msg"],
        "preflight_pass": result["preflight_pass"],
        "schedule": result["schedule"],
        "failed_checks": result["failed_checks"],
    }, ensure_ascii=False))
    if not result["preflight_pass"]:
        raise SystemExit(2)
    return result


def verify_manifest(path):
    locked = json.load(open(path, encoding="utf-8"))
    current_physics = runtime.physics_runtime(
        locked["physics_runtime"]["executable"]
    )
    checks = {
        "schema": locked.get("schema") == SCHEMA,
        "experiment_id": locked.get("experiment_id") == robust.EXPERIMENT_ID,
        "preflight_pass": locked.get("preflight_pass") is True,
        "artifacts_current": all(
            robust.file_sha256(value["path"]) == value["sha256"]
            for value in locked["artifacts"].values()
        ),
        "schedule_current": locked.get("schedule") == schedule(
            argparse.Namespace(
                bootstrap_reps=locked["schedule"]["bootstrap_reps"],
                bootstrap_seed=locked["schedule"]["bootstrap_seed"],
            )
        ),
        "physics_runtime_compatible": runtime_compatibility(
            locked["physics_runtime"], current_physics
        )["compatible"],
        "code_current": code_hashes() == locked["code_sha256"],
        "upstream_code_current": locked_code_current(
            locked["upstream_code_sha256"]
        ),
    }
    result = {
        "msg": "GridRank dynamic observation robustness runtime verification",
        "checks": checks,
        "verification_pass": all(checks.values()),
    }
    print(json.dumps(result, ensure_ascii=False))
    if not result["verification_pass"]:
        raise SystemExit(2)
    return locked


def main():
    args = parse_args()
    verify_manifest(args.output) if args.verify else create(args)


if __name__ == "__main__":
    main()

