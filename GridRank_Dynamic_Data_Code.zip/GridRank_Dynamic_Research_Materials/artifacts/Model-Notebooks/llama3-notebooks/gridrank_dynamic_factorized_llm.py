"""Gridrank dynamic factorized llm utilities."""

from __future__ import annotations

from typing import Iterable, Sequence

from gridrank_dynamic_llm import NEGATIVE_TOKEN, POSITIVE_TOKEN, card_ids


PRIMITIVES = (
    {
        "primitive_id": "objective_loss",
        "axis": "objective",
        "value": "loss",
        "description": "The primary objective is active-power loss reduction.",
    },
    {
        "primitive_id": "objective_voltage",
        "axis": "objective",
        "value": "voltage",
        "description": "The primary objective is weakest-bus voltage improvement.",
    },
    {
        "primitive_id": "constraint_none",
        "axis": "constraint",
        "value": "none",
        "description": "No explicitly named unavailable-branch restriction must be enforced.",
    },
    {
        "primitive_id": "constraint_maintenance",
        "axis": "constraint",
        "value": "maintenance",
        "description": "Every explicitly named unavailable branch is a hard switching restriction.",
    },
)


def primitive_ids() -> list[str]:
    return [item["primitive_id"] for item in PRIMITIVES]


def primitive_question(row: dict, primitive: dict) -> str:
    instruction = str(row.get("instruction_text", "")).strip()
    if not instruction:
        raise ValueError("instruction_text is required")
    if primitive.get("primitive_id") not in primitive_ids():
        raise ValueError("invalid factorized primitive")
    axis = "primary operating objective" if primitive["axis"] == "objective" else "temporary branch constraint"
    return (
        "Interpret one aspect of a distribution-grid operator directive.\n\n"
        "Operator directive:\n"
        f"{instruction}\n\n"
        f"Interpretation axis: {axis}.\n"
        "Candidate interpretation:\n"
        f"{primitive['description']}\n\n"
        "Does this candidate interpretation match that aspect of the directive? "
        f"Answer {POSITIVE_TOKEN} or {NEGATIVE_TOKEN}."
    )


def render_primitive_prompt(tokenizer, row: dict, primitive: dict) -> str:
    question = primitive_question(row, primitive)
    if getattr(tokenizer, "chat_template", None):
        return tokenizer.apply_chat_template(
            [{"role": "user", "content": question}],
            tokenize=False,
            add_generation_prompt=True,
        )
    return f"<|user|>\n{question}</s>\n<|assistant|>\n"


def resolve_preference_token_ids(tokenizer) -> tuple[int, int]:
    values = []
    for surface in (POSITIVE_TOKEN, NEGATIVE_TOKEN):
        encoded = tokenizer.encode(surface, add_special_tokens=False)
        if len(encoded) != 1:
            raise RuntimeError(
                f"readout token must be one tokenizer token: {surface!r} -> {encoded}"
            )
        values.append(int(encoded[0]))
    if values[0] == values[1]:
        raise RuntimeError("YES/NO token IDs are identical")
    return values[0], values[1]


def _chunks(values: Sequence, size: int) -> Iterable[Sequence]:
    if size <= 0:
        raise ValueError("primitive_batch_size must be positive")
    for offset in range(0, len(values), size):
        yield values[offset : offset + size]


def primitive_scores(
    model,
    tokenizer,
    row: dict,
    *,
    max_length: int,
    primitive_batch_size: int,
    require_grad: bool,
    primitives: Sequence[dict] = PRIMITIVES,
):
    

    import torch

    requested = [item["primitive_id"] for item in primitives]
    canonical = primitive_ids()
    if (
        not requested
        or len(requested) != len(set(requested))
        or any(value not in canonical for value in requested)
        or requested != sorted(requested, key=canonical.index)
    ):
        raise ValueError("primitive order must be a canonical nonempty subset")
    positive_id, negative_id = resolve_preference_token_ids(tokenizer)
    device = next(model.parameters()).device
    old_truncation = tokenizer.truncation_side
    old_padding = tokenizer.padding_side
    tokenizer.truncation_side = "left"
    tokenizer.padding_side = "right"
    output = []
    try:
        for chunk in _chunks(list(primitives), primitive_batch_size):
            texts = [render_primitive_prompt(tokenizer, row, item) for item in chunk]
            encoded = tokenizer(
                texts, return_tensors="pt", padding=True, truncation=True,
                max_length=max_length, add_special_tokens=False,
            )
            encoded = {key: value.to(device) for key, value in encoded.items()}
            context = torch.enable_grad() if require_grad else torch.no_grad()
            with context:
                kwargs = {"use_cache": False, "return_dict": True}
                if len(chunk) == 1:
                    kwargs["num_logits_to_keep"] = 1
                result = model(**encoded, **kwargs)
                if len(chunk) == 1:
                    logits = result.logits[:, 0].float()
                else:
                    last = encoded["attention_mask"].sum(dim=1).long() - 1
                    batch = torch.arange(last.shape[0], device=device)
                    logits = result.logits[batch, last].float()
                output.append(logits[:, positive_id] - logits[:, negative_id])
    finally:
        tokenizer.truncation_side = old_truncation
        tokenizer.padding_side = old_padding
    scores = torch.cat(output, dim=0)
    if scores.shape != (len(primitives),) or not bool(torch.isfinite(scores).all()):
        raise FloatingPointError("factorized primitive scorer produced invalid scores")
    return scores


def compose_card_scores(scores):
    

    import torch

    if scores.shape != (4,):
        raise ValueError("factorized primitive score shape mismatch")
    values = torch.stack((
        scores[0] + scores[2],  
        scores[1] + scores[2],  
        scores[0] + scores[3],  
        scores[1] + scores[3],  
    ))
    if card_ids() != [
        "loss_unconstrained", "voltage_unconstrained",
        "loss_maintenance", "voltage_maintenance",
    ]:
        raise RuntimeError("dynamic card schema/order changed")
    return values


def selected_axes(scores) -> dict:
    if scores.shape != (4,):
        raise ValueError("factorized primitive score shape mismatch")
    return {
        "objective": "loss" if float(scores[0]) >= float(scores[1]) else "voltage",
        "hard_constraint": bool(float(scores[3]) > float(scores[2])),
    }
