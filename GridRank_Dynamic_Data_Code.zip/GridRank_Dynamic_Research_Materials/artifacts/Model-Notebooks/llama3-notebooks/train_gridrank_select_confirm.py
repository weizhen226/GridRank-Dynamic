"""Train GridRank select confirm."""

from __future__ import annotations

import json
import os
from pathlib import Path

import train_gridrank_select as base
from gridrank_runtime_compat import runtime_compatibility
from preflight_gridrank_select_confirm import CONFIRMATION_ID, SCHEMA as PREFLIGHT_SCHEMA, SEEDS


GATE_SCHEMA = "gridrank-select-confirm-seed-gate-v1"
ORIGINAL_PAIRED = base.paired


def verify_confirmation_preflight(args):
    import preflight_gridrank_feedback as runtime

    manifest = json.load(open(args.preflight_manifest, encoding="utf-8"))
    summary = json.load(open(args.data_summary, encoding="utf-8"))
    audit = json.load(open(args.data_audit, encoding="utf-8"))
    if (
        manifest.get("schema") != PREFLIGHT_SCHEMA
        or manifest.get("preflight_pass") is not True
        or manifest.get("confirmation", {}).get("confirmation_id") != CONFIRMATION_ID
        or args.seed not in SEEDS
        or manifest.get("training_schedule", {}).get("seed") != args.seed
    ):
        raise RuntimeError("invalid GridRank-Select confirmation preflight")
    if audit.get("audit_pass") is not True or summary.get("schema") != "gridrank-select-summary-v1":
        raise RuntimeError("confirmation data summary/audit did not pass")

    expected_artifacts = {
        "train": base.file_sha256(args.train_jsonl),
        "test": base.file_sha256(args.test_jsonl),
        "summary": base.file_sha256(args.data_summary),
        "audit": base.file_sha256(args.data_audit),
    }
    if manifest.get("artifact_sha256") != expected_artifacts:
        raise RuntimeError("confirmation artifact hashes changed")
    if manifest.get("training_schedule") != base.schedule_manifest(args):
        raise RuntimeError("GPU schedule differs from confirmation preflight")

    training_compat = runtime_compatibility(
        manifest.get("training_runtime"), runtime.training_runtime()
    )
    physics_compat = runtime_compatibility(
        manifest.get("physics_runtime"), runtime.physics_runtime(args.physics_python)
    )
    if not training_compat["compatible"] or not physics_compat["compatible"]:
        raise RuntimeError("confirmation user-space runtime changed")

    adapter = Path(args.resume_adapter_path)
    current_adapter = {
        "adapter_config_json": base.file_sha256(adapter / "adapter_config.json"),
        "adapter_model_safetensors": base.file_sha256(adapter / "adapter_model.safetensors"),
    }
    if manifest.get("resume_adapter_sha256") != current_adapter:
        raise RuntimeError("confirmation SFT adapter changed")

    here = Path(__file__).resolve().parent
    code_sha256 = manifest.get("code_sha256")
    if not isinstance(code_sha256, dict) or not code_sha256:
        raise RuntimeError("confirmation preflight omitted source hashes")
    required = {
        "gridrank_select_llm.py", "train_gridrank_select.py",
        "train_gridrank_select_confirm.py", "preflight_gridrank_select_confirm.py",
        "run_gridrank_select_confirm.sh",
    }
    if not required.issubset(code_sha256):
        raise RuntimeError("confirmation preflight omitted critical code")
    for relative, expected in code_sha256.items():
        path = here / relative
        if not path.is_file() or base.file_sha256(path) != expected:
            raise RuntimeError(f"locked confirmation source changed: {relative}")

    base_model = Path(args.base_model)
    locked_model = manifest.get("base_model_manifest")
    if not isinstance(locked_model, dict) or not locked_model:
        raise RuntimeError("confirmation preflight omitted base model")
    for relative, expected in locked_model.items():
        path = base_model / relative
        if (
            not path.is_file()
            or path.stat().st_size != int(expected["bytes"])
            or base.file_sha256(path) != expected["sha256"]
        ):
            raise RuntimeError(f"confirmation base model changed: {relative}")

    test_rows = [
        json.loads(line) for line in open(args.test_jsonl, encoding="utf-8") if line.strip()
    ]
    current_test_states = sorted(row["physical_state_sha256"] for row in test_rows)
    confirmation = manifest["confirmation"]
    split_audit = confirmation.get("split_audit", {})
    if (
        confirmation.get("method_frozen") is not True
        or confirmation.get("test_used_for_tuning") is not False
        or current_test_states != split_audit.get("test_state_sha256s")
    ):
        raise RuntimeError("confirmation split/freeze contract changed")
    return manifest


def paired_with_state_rows(before, after, reps, seed):
    result = ORIGINAL_PAIRED(before, after, reps, seed)
    if [row["instance_id"] for row in before] != [row["instance_id"] for row in after]:
        raise RuntimeError("confirmation paired record order changed")
    result["state_rows"] = [
        {
            "instance_id": old["instance_id"],
            "network": old["network"],
            "load_id": old["load_id"],
            "physical_state_sha256": old["physical_state_sha256"],
            "sft_safe_regret": old["safe_regret"],
            "distilled_safe_regret": new["safe_regret"],
            "safe_regret_improvement": old["safe_regret"] - new["safe_regret"],
            "sft_safe_action": old["safe_action"],
            "distilled_safe_action": new["safe_action"],
            "sft_safe_feasible": old["safe_feasible"],
            "distilled_safe_feasible": new["safe_feasible"],
        }
        for old, new in zip(before, after)
    ]
    return result


def annotate_gate(args):
    output = Path(args.output_dir) / "gridrank_select_gate.json"
    if not output.is_file():
        raise FileNotFoundError("confirmation trainer did not produce gate JSON")
    payload = json.load(open(output, encoding="utf-8"))
    rows = payload.get("paired", {}).get("distilled_vs_sft", {}).get("state_rows")
    if not isinstance(rows, list) or len(rows) != 64:
        raise RuntimeError("confirmation gate lacks 64 row-level paired records")
    payload.update({
        "schema": GATE_SCHEMA,
        "confirmation_id": CONFIRMATION_ID,
        "confirmation_seed": args.seed,
        "confirmation_preflight_sha256": base.file_sha256(args.preflight_manifest),
        "row_level_paired_evidence": True,
        "paper_claim_authorized": False,
        "paper_claim_note": "requires locked three-seed aggregate gate",
    })
    tmp = output.with_name(output.name + ".tmp")
    tmp.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
    os.replace(tmp, output)


def main():
    args = base.parse_args()
    base.verify_preflight = verify_confirmation_preflight
    base.paired = paired_with_state_rows
    exit_code = 0
    try:
        base.main()
    except SystemExit as exc:
        exit_code = int(exc.code or 0)
    annotate_gate(args)
    raise SystemExit(exit_code)


if __name__ == "__main__":
    main()
