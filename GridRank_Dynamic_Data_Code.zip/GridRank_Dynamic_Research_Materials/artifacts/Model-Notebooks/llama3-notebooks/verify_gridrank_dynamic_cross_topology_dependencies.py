
"""Validate GridRank dynamic cross topology dependencies."""

from __future__ import annotations

import ast
import json
from pathlib import Path

import build_gridrank_dynamic_cross_topology as build
import gridrank_dynamic_cross_topology as suite
import preflight_gridrank_dynamic_cross_topology as preflight


HERE = Path(__file__).resolve().parent


def calls(path):
    tree = ast.parse(path.read_text(encoding="utf-8"))
    output = []
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        value = node.func
        if isinstance(value, ast.Name):
            output.append(value.id)
        elif isinstance(value, ast.Attribute):
            output.append(value.attr)
    return output


def main():
    builder = (HERE / "build_gridrank_dynamic_cross_topology.py").read_text(encoding="utf-8")
    evaluator_path = HERE / "eval_gridrank_dynamic_cross_topology.py"
    evaluator_calls = calls(evaluator_path)
    runner = (HERE / "run_gridrank_dynamic_cross_topology.sh").read_text(encoding="utf-8")
    checks = {
        "three_predeclared_scenario2_networks": suite.PREDECLARED_CODES == (
            "1-MV-rural--2-sw", "1-MV-semiurb--2-sw", "1-MV-urban--2-sw",
        ),
        "prior_nine_networks_excluded": not set(suite.PREDECLARED_CODES).intersection(suite.PRIOR_CODES),
        "four_exact_semantic_template_families": set(build.CROSS_TOPOLOGY_TEMPLATES) == {"loss", "voltage", "maintenance_loss", "maintenance_voltage"},
        "builder_has_no_model_loading": all(token not in builder for token in ("AutoModel", "PeftModel", "build_model_and_tokenizer")),
        "builder_uses_authoritative_ac": "difficulty.build_row" in builder,
        "evaluator_has_no_optimizer": "optimizer" not in evaluator_calls and "AdamW" not in evaluator_calls,
        "evaluator_has_no_backward": "backward" not in evaluator_calls,
        "three_llm_seeds": preflight.SEEDS == (42, 123, 2025),
        "preflight_declares_evaluation_only": '"evaluation_only": True' in (HERE / "preflight_gridrank_dynamic_cross_topology.py").read_text(encoding="utf-8"),
        "runner_supports_cpu_preflight": "PREFLIGHT_ONLY" in runner,
        "runner_refuses_overwrite": "refusing to overwrite" in runner,
        "paper_failure_does_not_invalidate_execution": 'if not result["evaluation_pass"]' in evaluator_path.read_text(encoding="utf-8"),
        "claim_boundary_explicit": "does not claim" in suite.suite_manifest()["claim_boundary"],
        "topology_family_overlap_disclosed": "not claimed as a pristine" in suite.suite_manifest()["topology_family_overlap_disclosure"],
    }
    result = {
        "msg": "GridRank dynamic cross-topology dependency-light verification",
        "checks": checks, "verification_pass": all(checks.values()),
        "training_performed": False, "model_loaded": False, "power_flow_calls": 0,
    }
    print(json.dumps(result, ensure_ascii=False))
    if not result["verification_pass"]:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
