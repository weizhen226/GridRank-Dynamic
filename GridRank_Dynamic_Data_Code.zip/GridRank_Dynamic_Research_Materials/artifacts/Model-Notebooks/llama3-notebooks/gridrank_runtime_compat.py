"""Gridrank runtime compat utilities."""

from __future__ import annotations

from typing import Any


def parse_linux_platform(value: Any):
    

    if not isinstance(value, str) or not value:
        return None
    try:
        head, libc = value.rsplit("-with-", 1)
        system_kernel, machine = head.rsplit("-", 1)
        system, kernel = system_kernel.split("-", 1)
    except ValueError:
        return None
    if system != "Linux" or not kernel or not machine or not libc:
        return None
    return {
        "system": system,
        "machine": machine,
        "libc": libc,
        "kernel": kernel,
    }


def runtime_compatibility(locked: Any, current: Any):
    

    locked_dict = locked if isinstance(locked, dict) else {}
    current_dict = current if isinstance(current, dict) else {}
    locked_nonplatform = {
        key: value for key, value in locked_dict.items() if key != "platform"
    }
    current_nonplatform = {
        key: value for key, value in current_dict.items() if key != "platform"
    }
    nonplatform_match = locked_nonplatform == current_nonplatform
    locked_platform = locked_dict.get("platform")
    current_platform = current_dict.get("platform")
    platform_exact = locked_platform == current_platform
    locked_parsed = parse_linux_platform(locked_platform)
    current_parsed = parse_linux_platform(current_platform)

    kernel_release_ignored = False
    if (
        nonplatform_match
        and not platform_exact
        and locked_parsed is not None
        and current_parsed is not None
    ):
        stable_keys = ("system", "machine", "libc")
        kernel_release_ignored = (
            all(locked_parsed[key] == current_parsed[key] for key in stable_keys)
            and locked_parsed["kernel"] != current_parsed["kernel"]
        )

    compatible = nonplatform_match and (platform_exact or kernel_release_ignored)
    if not nonplatform_match:
        reason = "nonplatform_runtime_drift"
    elif platform_exact:
        reason = "exact_runtime_match"
    elif kernel_release_ignored:
        reason = "linux_host_kernel_release_ignored"
    elif locked_parsed is None or current_parsed is None:
        reason = "unparseable_platform_drift"
    else:
        reason = "platform_semantic_drift"

    differing_nonplatform_fields = sorted(
        key
        for key in set(locked_nonplatform) | set(current_nonplatform)
        if locked_nonplatform.get(key) != current_nonplatform.get(key)
    )
    return {
        "exact_match": locked_dict == current_dict,
        "compatible": compatible,
        "reason": reason,
        "nonplatform_fields_match": nonplatform_match,
        "differing_nonplatform_fields": differing_nonplatform_fields,
        "platform_exact_match": platform_exact,
        "host_kernel_release_ignored": kernel_release_ignored,
        "locked_platform": locked_platform,
        "current_platform": current_platform,
        "locked_platform_parsed": locked_parsed,
        "current_platform_parsed": current_parsed,
    }
