"""Evaluate GridRank dynamic joint confirmation replication."""

from __future__ import annotations

import json
import sys
from pathlib import Path

import aggregate_gridrank_dynamic_multiseed as aggregate
import preflight_gridrank_dynamic_joint_confirmation_replication as replication


sys.modules["preflight_gridrank_dynamic_factorization_ablation"] = replication
import eval_gridrank_dynamic_factorization_ablation as locked  


def _argument(name):
    index = sys.argv.index(name)
    return sys.argv[index + 1]


def _seeded_comparison(
    methods, before, after, pair_to_state, state_network, reps, seed,
    pair_type=None,
):
    pair_values, _ = aggregate.pair_effects(
        methods, before, after, pair_type
    )
    state_result = aggregate.bootstrap_state_matrix(
        {_MODEL_SEED: pair_values},
        pair_to_state,
        state_network,
        reps,
        seed,
    )
    before_rows = methods[before]
    after_rows = methods[after]
    if pair_type is not None:
        before_rows = locked.joint.subset(before_rows, pair_type)
        after_rows = locked.joint.subset(after_rows, pair_type)
    return {
        "orientation": f"{before}_regret_minus_{after}_regret",
        "positive_favors": after,
        "pair_cluster_bootstrap": locked.joint.paired(
            before_rows, after_rows, reps, seed + 1
        ),
        "physical_state_statistics": state_result,
    }


def main():
    global _MODEL_SEED
    manifest_path = _argument("--preflight_manifest")
    output_dir = Path(_argument("--output_dir"))
    manifest = json.load(open(manifest_path, encoding="utf-8"))
    _MODEL_SEED = int(manifest["model_seed"])
    locked.comparison = _seeded_comparison
    rc = 0
    try:
        locked.main()
    except SystemExit as exc:
        rc = int(exc.code or 0)
    gate_path = output_dir / "gridrank_dynamic_factorization_ablation_gate.json"
    if gate_path.is_file():
        gate = json.load(open(gate_path, encoding="utf-8"))
        gate["model_seed"] = _MODEL_SEED
        gate["replication_evaluation_integrity_pass"] = all(
            gate.get("integrity_checks", {}).values()
        ) and all(gate.get("safety_checks", {}).values())
        gate["replication_factorization_effect_pass"] = all(
            gate.get("mechanism_checks", {}).values()
        ) and all(gate.get("efficacy_checks", {}).values())
        gate["replication_interpretation"] = (
            "A per-seed efficacy miss is retained for the final three-seed "
            "aggregate and does not invalidate a structurally audited control."
        )
        gate_path.write_text(
            json.dumps(gate, ensure_ascii=False, indent=2), encoding="utf-8"
        )
    raise SystemExit(rc)


if __name__ == "__main__":
    main()
