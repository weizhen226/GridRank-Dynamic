"""Gridrank dynamic supplement utilities."""

from __future__ import annotations

import hashlib
import json
import math
import random
from collections import defaultdict
from pathlib import Path

import preflight_gridrank_dynamic_benchmark as benchmark
from build_gridrank_instruction_pairs import (
    NOOP,
    action_edges,
    selected_action,
    structured_proxy_order,
)
from gridrank_dynamic_llm import CARDS, card_index


SCHEMA = "gridrank-dynamic-supplement-cached-v1"
SEEDS = (42, 123, 2025)
PRIMARY = "maintenance_voltage"
LLM_PREFIX = "physics_aligned_factorized_llm"
TFIDF = "factorized_tfidf_withheld"
REGIMES = ("load_only", "moderate_der", "high_der")


def file_sha256(path):
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def read_jsonl(path):
    return [
        json.loads(line)
        for line in open(path, encoding="utf-8")
        if line.strip()
    ]


def mean(values):
    values = list(values)
    return sum(values) / len(values) if values else None


def quantile(values):
    ordered = sorted(float(value) for value in values)
    if not ordered:
        return [None, None]
    return [
        ordered[int(0.025 * (len(ordered) - 1))],
        ordered[int(0.975 * (len(ordered) - 1))],
    ]


def operating_regime(row):
    
    if row.get("operating_regime") in REGIMES:
        return row["operating_regime"]
    return REGIMES[state_index(row) % len(REGIMES)]


def state_index(row):
    
    if row.get("state_index") is not None:
        return int(row["state_index"])
    return int(str(row["load_id"]).rsplit(":", 1)[-1])


def predicted_semantics(row, record):
    card_id = record.get("selected_card")
    if not card_id:
        raise ValueError(f"record lacks selected_card: {record.get('instance_id')}")
    card = CARDS[card_index(card_id)]
    constrained = bool(card["hard_constraint"])
    return {
        "objective": str(card["objective"]),
        "hard_constraint": constrained,
        "forbidden_edges": (
            benchmark.extract_edges(row["instruction_text"]) if constrained else []
        ),
    }


def candidate(row, action):
    return next(item for item in row["candidates"] if item["action"] == action)


def candidate_raw_utility(item, objective, anchor_min):
    if not bool(item.get("feedback_valid")) or not bool(item.get("feasible")):
        return None
    reduction = item.get("reduction_pct")
    minimum = item.get("candidate_min_vm_pu")
    if reduction is None or minimum is None or anchor_min is None:
        return None
    if item["action"] == NOOP:
        return 0.0
    if objective == "loss":
        return float(reduction)
    if objective == "voltage":
        return (
            100.0 * (float(minimum) - float(anchor_min))
            if float(reduction) >= -0.5
            else None
        )
    raise ValueError(objective)


def objective_deadband(objective):
    return 0.05 if objective == "loss" else 0.01


def direct_action_status(row, action, objective, forbidden_edges):
    item = candidate(row, action)
    anchor_min = row["gate_anchor"].get("anchor_min_vm_pu")
    raw = candidate_raw_utility(item, objective, anchor_min)
    touches = benchmark.action_touches(action, forbidden_edges)
    reason = str(item.get("reason") or "")
    feedback_valid = bool(item.get("feedback_valid"))
    feasible = bool(item.get("feasible"))
    nonconverged = (not feasible) and (
        reason.startswith("power_flow:") or reason == "nonconverged"
    )
    voltage_violation = (not feasible) and reason == "voltage"
    topology_violation = (not feasible) and reason == "non_radial"
    objective_guard = (
        objective == "voltage"
        and item.get("reduction_pct") is not None
        and float(item["reduction_pct"]) < -0.5
    )
    deadband_failure = (
        feedback_valid
        and feasible
        and not touches
        and not objective_guard
        and (raw is None or float(raw) <= objective_deadband(objective))
    )
    accepted = (
        feedback_valid
        and feasible
        and not touches
        and not objective_guard
        and raw is not None
        and float(raw) > objective_deadband(objective)
    )
    return {
        "feedback_valid": feedback_valid,
        "feasible": feasible,
        "nonconverged": nonconverged,
        "voltage_violation": voltage_violation,
        "topology_violation": topology_violation,
        "maintenance_violation": touches,
        "objective_guard_violation": objective_guard,
        "deadband_failure": deadband_failure,
        "accepted": accepted,
        "unsafe": (
            (not feedback_valid) or (not feasible) or touches or objective_guard
        ),
        "unsafe_or_nonbeneficial": not accepted,
        "reason": reason,
        "raw_utility": raw,
    }


def canonical_order(row, forbidden_edges):
    forbidden = {
        tuple(sorted((int(edge[0]), int(edge[1]))))
        for edge in forbidden_edges
    }
    return sorted(
        item["action"]
        for item in row["candidates"]
        if not forbidden.intersection(action_edges(item["action"]))
    )


def masked_proxy_order(row, objective, forbidden_edges):
    
    eligible = set(canonical_order(row, forbidden_edges))
    return [
        action
        for action in structured_proxy_order(row, objective, forbidden_edges)
        if action in eligible
    ]


def exact_random_top1(row, eligible_actions):
    regrets, optimal, noops = [], [], []
    for action in eligible_actions:
        deployed = selected_action(row, [action], 1)
        regret = benchmark.action_regret(row, deployed)
        regrets.append(float(regret))
        optimal.append(float(regret <= 1e-12))
        noops.append(float(deployed == NOOP))
    return {
        "normalised_regret": mean(regrets),
        "physics_optimal": mean(optimal),
        "no_op": mean(noops),
        "eligible_actions": len(eligible_actions),
    }


def record_index(records):
    result = defaultdict(dict)
    for record in records:
        method = record["method"]
        instance = record["instance_id"]
        if instance in result[method]:
            raise ValueError(f"duplicate record: {method}:{instance}")
        result[method][instance] = record
    return result


def _rate(rows, key):
    return mean(float(row[key]) for row in rows)


def safety_summary(rows):
    keys = (
        "pre_gate_feedback_invalid",
        "pre_gate_nonconverged",
        "pre_gate_voltage_violation",
        "pre_gate_topology_violation",
        "pre_gate_maintenance_violation",
        "pre_gate_objective_guard_violation",
        "pre_gate_deadband_failure",
        "pre_gate_unsafe",
        "pre_gate_unsafe_or_nonbeneficial",
        "gate_rejected_top1",
        "gate_rescue",
        "deployed_no_op",
        "deployed_feasible",
        "deployed_constraint_violation",
        "mask_changes_top1",
        "mask_prevents_forbidden_top1",
        "mask_off_gate_deployed_no_op",
        "mask_off_direct_constraint_violation",
        "mask_off_direct_unsafe",
    )
    return {
        "n": len(rows),
        **{f"{key}_rate": _rate(rows, key) for key in keys},
        "normalised_regret_mean": mean(
            row["normal_regret"] for row in rows
        ),
        "mask_off_gate_regret_mean": mean(
            row["mask_off_gate_regret"] for row in rows
        ),
    }


def analyse_safety(pair_rows, records):
    rows_by_id = {row["instance_id"]: row for row in pair_rows}
    indexed = record_index(records)
    per_seed, pooled = {}, []
    for seed in SEEDS:
        method = f"{LLM_PREFIX}_s{seed}"
        if method not in indexed:
            raise KeyError(method)
        values = []
        for instance_id, record in sorted(indexed[method].items()):
            row = rows_by_id[instance_id]
            semantic = predicted_semantics(row, record)
            target = benchmark.semantic_target(row)
            ranking = masked_proxy_order(
                row, semantic["objective"], semantic["forbidden_edges"]
            )
            unmasked = masked_proxy_order(row, semantic["objective"], [])
            top1 = ranking[0]
            unmasked_top1 = unmasked[0]
            status = direct_action_status(
                row, top1, target["objective"], target["forbidden_edges"]
            )
            unmasked_status = direct_action_status(
                row, unmasked_top1, target["objective"],
                target["forbidden_edges"],
            )
            mask_off_deployed = selected_action(row, unmasked, 1)
            final = record["safe_action"]
            value = {
                "seed": seed,
                "instance_id": instance_id,
                "network": str(row["network_id"]),
                "regime": operating_regime(row),
                "pair_type": row["pair_type"],
                "pre_gate_feedback_invalid": not status["feedback_valid"],
                "pre_gate_nonconverged": status["nonconverged"],
                "pre_gate_voltage_violation": status["voltage_violation"],
                "pre_gate_topology_violation": status["topology_violation"],
                "pre_gate_maintenance_violation": status["maintenance_violation"],
                "pre_gate_objective_guard_violation": status[
                    "objective_guard_violation"
                ],
                "pre_gate_deadband_failure": status["deadband_failure"],
                "pre_gate_unsafe": status["unsafe"],
                "pre_gate_unsafe_or_nonbeneficial": status[
                    "unsafe_or_nonbeneficial"
                ],
                "gate_rejected_top1": final != top1,
                "gate_rescue": status["unsafe"] and final == NOOP,
                "deployed_no_op": final == NOOP,
                "deployed_feasible": bool(record["safe_feasible"]),
                "deployed_constraint_violation": bool(
                    record["constraint_violation"]
                ),
                "mask_changes_top1": top1 != unmasked_top1,
                "mask_prevents_forbidden_top1": (
                    unmasked_status["maintenance_violation"]
                    and not status["maintenance_violation"]
                ),
                "mask_off_gate_deployed_no_op": mask_off_deployed == NOOP,
                "mask_off_direct_constraint_violation": unmasked_status[
                    "maintenance_violation"
                ],
                "mask_off_direct_unsafe": unmasked_status["unsafe"],
                "normal_regret": float(record["normalised_regret"]),
                "mask_off_gate_regret": float(
                    benchmark.action_regret(row, mask_off_deployed)
                ),
            }
            values.append(value)
            pooled.append(value)
        per_seed[str(seed)] = {
            "all": safety_summary(values),
            "maintenance_rows": safety_summary([
                value for value in values
                if value["pair_type"].startswith("maintenance_")
            ]),
        }
    return {
        "definition": (
            "pre-gate is the LinDistFlow Top-1 exchange; deployed is the "
            "cached AC/no-op result. Mask-off direct is a non-deployed "
            "counterfactual and is never authorized for execution."
        ),
        "per_seed": per_seed,
        "pooled_three_seed": {
            "all": safety_summary(pooled),
            "maintenance_rows": safety_summary([
                value for value in pooled
                if value["pair_type"].startswith("maintenance_")
            ]),
            "by_network": {
                network: safety_summary([
                    value for value in pooled
                    if value["network"] == network
                ])
                for network in sorted({
                    value["network"] for value in pooled
                })
            },
        },
        "rows": pooled,
    }


def ranker_summary(rows):
    return {
        "n": len(rows),
        "normalised_regret_mean": mean(
            row["normalised_regret"] for row in rows
        ),
        "physics_optimal_rate": mean(
            float(row["physics_optimal"]) for row in rows
        ),
        "no_op_rate": mean(float(row["no_op"]) for row in rows),
    }


def _two_way_improvement(rows, control, reps, seed):
    by_seed_state = defaultdict(list)
    network = {}
    for row in rows:
        key = (int(row["seed"]), row["physical_state_sha256"])
        by_seed_state[key].append(
            float(row[control]["normalised_regret"])
            - float(row["lindistflow"]["normalised_regret"])
        )
        network[row["physical_state_sha256"]] = row["network"]
    matrix = {
        key: mean(values) for key, values in by_seed_state.items()
    }
    states = sorted({state for _, state in matrix})
    seeds = sorted({value for value, _ in matrix})
    if seeds != list(SEEDS):
        raise ValueError("ranker seed set mismatch")
    state_mean = {
        state: mean(matrix[(value, state)] for value in seeds)
        for state in states
    }
    rng = random.Random(seed)
    state_draws = [
        mean(state_mean[states[rng.randrange(len(states))]] for _ in states)
        for _ in range(reps)
    ]
    rng2 = random.Random(seed + 1)
    two_way = []
    for _ in range(reps):
        sampled_seeds = [
            seeds[rng2.randrange(len(seeds))] for _ in seeds
        ]
        sampled_states = [
            states[rng2.randrange(len(states))] for _ in states
        ]
        two_way.append(mean(
            matrix[(value, state)]
            for value in sampled_seeds
            for state in sampled_states
        ))
    return {
        "control_minus_lindistflow_improvement_mean": mean(state_mean.values()),
        "per_seed_improvement_mean": {
            str(value): mean(
                matrix[(value, state)] for state in states
            )
            for value in seeds
        },
        "physical_state_clusters": len(states),
        "physical_state_cluster_ci95": quantile(state_draws),
        "two_way_seed_state_ci95": quantile(two_way),
        "by_network": {
            name: {
                "states": len(selected),
                "improvement_mean": mean(state_mean[state] for state in selected),
            }
            for name in sorted(set(network.values()))
            for selected in [[
                state for state in states if network[state] == name
            ]]
        },
    }


def analyse_rankers(pair_rows, records, bootstrap_reps, bootstrap_seed):
    rows_by_id = {row["instance_id"]: row for row in pair_rows}
    indexed = record_index(records)
    output_rows = []
    for seed in SEEDS:
        method = f"{LLM_PREFIX}_s{seed}"
        for instance_id, record in sorted(indexed[method].items()):
            row = rows_by_id[instance_id]
            semantic = predicted_semantics(row, record)
            ldf_order = masked_proxy_order(
                row, semantic["objective"], semantic["forbidden_edges"]
            )
            fixed_order = canonical_order(row, semantic["forbidden_edges"])
            if not ldf_order or not fixed_order:
                raise RuntimeError(f"empty ranking: {instance_id}")
            ldf_action = selected_action(row, ldf_order, 1)
            fixed_action = selected_action(row, fixed_order, 1)
            if ldf_action != record["safe_action"]:
                raise RuntimeError(
                    f"cached LinDistFlow action mismatch: {method}:{instance_id}"
                )
            random_result = exact_random_top1(row, fixed_order)
            output_rows.append({
                "seed": seed,
                "instance_id": instance_id,
                "physical_state_sha256": row["physical_state_sha256"],
                "network": str(row["network_id"]),
                "regime": operating_regime(row),
                "pair_type": row["pair_type"],
                "lindistflow": {
                    "normalised_regret": float(
                        benchmark.action_regret(row, ldf_action)
                    ),
                    "physics_optimal": (
                        benchmark.action_regret(row, ldf_action) <= 1e-12
                    ),
                    "no_op": ldf_action == NOOP,
                },
                "fixed_canonical": {
                    "normalised_regret": float(
                        benchmark.action_regret(row, fixed_action)
                    ),
                    "physics_optimal": (
                        benchmark.action_regret(row, fixed_action) <= 1e-12
                    ),
                    "no_op": fixed_action == NOOP,
                },
                "uniform_random_top1_exact": random_result,
            })

    def summaries(rows):
        return {
            method: ranker_summary([
                {
                    "normalised_regret": row[method]["normalised_regret"],
                    "physics_optimal": row[method]["physics_optimal"],
                    "no_op": row[method]["no_op"],
                }
                for row in rows
            ])
            for method in (
                "lindistflow", "fixed_canonical",
                "uniform_random_top1_exact",
            )
        }

    primary = [
        row for row in output_rows if row["pair_type"] == PRIMARY
    ]
    return {
        "definition": (
            "All rankers use the same predicted policy card, maintenance "
            "filter, one non-noop query and independent no-op anchor. "
            "Uniform random Top-1 is evaluated exactly over every eligible "
            "candidate rather than by Monte Carlo."
        ),
        "all": summaries(output_rows),
        "primary_withheld_composition": summaries(primary),
        "paired_all": {
            control: _two_way_improvement(
                output_rows, control, bootstrap_reps,
                bootstrap_seed + index * 1000,
            )
            for index, control in enumerate(
                ("fixed_canonical", "uniform_random_top1_exact"), start=1
            )
        },
        "paired_primary": {
            control: _two_way_improvement(
                primary, control, bootstrap_reps,
                bootstrap_seed + 10000 + index * 1000,
            )
            for index, control in enumerate(
                ("fixed_canonical", "uniform_random_top1_exact"), start=1
            )
        },
        "rows": output_rows,
    }


def _brief_existing(records):
    return {
        "n": len(records),
        "physical_states": len({
            row["physical_state_sha256"] for row in records
        }),
        "normalised_regret_mean": mean(
            float(row["normalised_regret"]) for row in records
        ),
        "physics_optimal_rate": mean(
            float(row["physics_optimal"]) for row in records
        ),
        "safe_feasible_rate": mean(
            float(row["safe_feasible"]) for row in records
        ),
        "constraint_violation_rate": mean(
            float(row["constraint_violation"]) for row in records
        ),
        "no_op_rate": mean(
            float(row["safe_action"] == NOOP) for row in records
        ),
    }


def analyse_regimes(pair_rows, records, bootstrap_reps, bootstrap_seed):
    source = {row["instance_id"]: row for row in pair_rows}
    enriched = []
    for record in records:
        if record["instance_id"] not in source:
            continue
        value = dict(record)
        row = source[record["instance_id"]]
        value["physical_state_sha256"] = row["physical_state_sha256"]
        value["operating_regime"] = operating_regime(row)
        enriched.append(value)
    methods = [
        "fixed_loss_lindistflow",
        "frozen_rule_parser_lindistflow",
        TFIDF,
        "oracle_structured_lindistflow",
        "full_ac_oracle",
        *[f"{LLM_PREFIX}_s{seed}" for seed in SEEDS],
    ]
    available = {row["method"] for row in enriched}
    missing = [method for method in methods if method not in available]
    if missing:
        raise KeyError(f"missing regime methods: {missing}")

    result = {}
    llm_methods = {
        f"{LLM_PREFIX}_s{seed}" for seed in SEEDS
    }

    def method_block(selected):
        values = {
            method: _brief_existing([
                row for row in selected if row["method"] == method
            ])
            for method in methods
        }
        values["physics_aligned_factorized_llm_three_seed"] = (
            _brief_existing([
                row for row in selected if row["method"] in llm_methods
            ])
        )
        return values

    for regime in REGIMES:
        selected = [
            row for row in enriched
            if row["operating_regime"] == regime
        ]
        result[regime] = {
            "all_pair_types": method_block(selected),
            "primary_withheld_composition": method_block([
                row for row in selected if row["pair_type"] == PRIMARY
            ]),
        }

    unique_states = {
        row["physical_state_sha256"]: row["operating_regime"]
        for row in enriched
    }
    regime_counts = {
        regime: sum(value == regime for value in unique_states.values())
        for regime in REGIMES
    }
    return {
        "definition": (
            "Operating regimes were fixed by state_index mod 3 before model "
            "evaluation: load_only, moderate_der and high_der."
        ),
        "unique_physical_states": len(unique_states),
        "unique_state_regime_mix": regime_counts,
        "by_regime": result,
        "note": (
            "This is a stratified recomputation of the sealed cross-topology "
            "records, not a newly selected test set."
        ),
    }


def cached_analysis(pair_rows, records, *, bootstrap_reps, bootstrap_seed):
    safety = analyse_safety(pair_rows, records)
    rankers = analyse_rankers(
        pair_rows, records, bootstrap_reps, bootstrap_seed
    )
    regimes = analyse_regimes(
        pair_rows, records, bootstrap_reps, bootstrap_seed
    )
    checks = {
        "rows_192": len(pair_rows) == 192,
        "three_llm_seeds": all(
            any(
                row["method"] == f"{LLM_PREFIX}_s{seed}"
                for row in records
            )
            for seed in SEEDS
        ),
        "three_regimes_present": all(
            regimes["unique_state_regime_mix"][value] > 0
            for value in REGIMES
        ),
        "cached_lindistflow_exact": True,
        "final_feasible_all_llm": (
            safety["pooled_three_seed"]["all"][
                "deployed_feasible_rate"
            ] == 1.0
        ),
        "final_constraint_safe_all_llm": (
            safety["pooled_three_seed"]["all"][
                "deployed_constraint_violation_rate"
            ] == 0.0
        ),
    }
    return {
        "msg": "GridRank dynamic cached safety/ranking/regime supplement",
        "schema": SCHEMA,
        "cached_only": True,
        "training_performed": False,
        "model_loaded": False,
        "power_flow_calls": 0,
        "safety_and_maintenance_mask": safety,
        "matched_ranking_controls": rankers,
        "simbench_operating_regimes": regimes,
        "checks": checks,
        "analysis_pass": all(checks.values()),
        "failed_checks": [
            key for key, value in checks.items() if not value
        ],
    }
