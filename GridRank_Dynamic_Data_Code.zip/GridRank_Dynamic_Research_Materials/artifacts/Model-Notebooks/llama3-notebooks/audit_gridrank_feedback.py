"""Audit GridRank feedback."""

from __future__ import annotations

import argparse
import hashlib
import json
import math
from collections import Counter, defaultdict
from pathlib import Path

import grpo_reward_limited as reward
from build_gridrank_feedback import (
    BUILD_CODE_FILES,
    INSTRUCTIONS,
    NOOP,
    _state_rows_by_load,
    base_state,
    file_sha256,
    label_candidates,
    read_state_only,
)


HERE = Path(__file__).resolve().parent
CODE_FILES = tuple(dict.fromkeys((*BUILD_CODE_FILES,
    "make_no_oracle_state_view.py",
    "audit_gridrank_feedback.py",
    "gridrank_llm.py",
    "train_gridrank_feedback.py",
    "preflight_gridrank_feedback.py",
    "verify_gridrank_feedback.py",
    "run_gridrank_feedback.sh",
    "grpo_train.py",
    "../../Dataset-Notebooks/utils/dataset_utils.py",
    "../../docs/GRIDRANK_FEEDBACK_PROTOCOL.md",
)))


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--train_source", action="append", required=True)
    parser.add_argument("--validation_source", action="append", required=True)
    parser.add_argument("--offline_jsonl", required=True)
    parser.add_argument("--online_jsonl", required=True)
    parser.add_argument("--test_jsonl", required=True)
    parser.add_argument("--summary_json", required=True)
    parser.add_argument("--physics_python", required=True)
    parser.add_argument("--physics_timeout_s", type=float, default=60.0)
    parser.add_argument("--replay_states_per_network", type=int, default=1)
    parser.add_argument("--output", required=True)
    return parser.parse_args()


def load_jsonl(path):
    rows = [json.loads(line) for line in open(path, encoding="utf-8") if line.strip()]
    if not rows:
        raise ValueError(f"empty JSONL: {path}")
    return rows


def parse_sources(specs, split):
    output = {}
    for spec in specs:
        network, path = spec.split("=", 1)
        rows = read_state_only(path, split)
        output[network] = {
            "path": path,
            "ordered": rows,
            "rows": {str(row["instance_id"]): row for row in rows},
        }
    if set(output) != {"33", "69"}:
        raise ValueError("expected 33 and 69 sources")
    return output


def close(a, b, tolerance=1e-8):
    if a is None or b is None:
        return a is b
    return math.isclose(float(a), float(b), rel_tol=tolerance, abs_tol=tolerance)


def candidate_physics_equal(left, right):
    keys = (
        "feedback_revealed", "feedback_valid", "feasible", "reason", "reduction_pct",
        "anchor_loss_kw", "candidate_loss_kw", "anchor_min_vm_pu",
        "candidate_min_vm_pu", "candidate_max_vm_pu",
    )
    for key in keys:
        if key not in left or key not in right:
            return False
        if isinstance(left[key], (float, int)) or isinstance(right[key], (float, int)):
            if not close(left[key], right[key]):
                return False
        elif left[key] != right[key]:
            return False
    return True


def group_audit(rows, expected_partition, source_map, summary):
    instance_ids = [str(row.get("instance_id")) for row in rows]
    if len(instance_ids) != len(set(instance_ids)):
        raise ValueError(f"duplicate instance_id in {expected_partition}")
    groups = defaultdict(list)
    for row in rows:
        if row.get("partition") != expected_partition:
            raise ValueError(f"wrong partition in {row.get('instance_id')}")
        groups[(str(row["network_id"]), row["physical_state_sha256"])].append(row)
    counters = Counter()
    for (network, state_sha), directives in groups.items():
        expected_instructions = INSTRUCTIONS[
            "test" if expected_partition == "test" else "train"
        ]
        if len(directives) != len(expected_instructions):
            raise ValueError(f"wrong directive count: {network}:{state_sha}")
        if {row["instruction_id"] for row in directives} != set(INSTRUCTIONS[
            "test" if expected_partition == "test" else "train"
        ]):
            raise ValueError(f"incomplete instruction group: {network}:{state_sha}")
        representative = directives[0]
        source_split = "validation" if expected_partition == "test" else "train"
        raw = source_map[source_split][network]["rows"].get(representative["source_instance_id"])
        if raw is None:
            raise ValueError(f"generated state absent from strict source: {representative['instance_id']}")
        rebuilt = base_state(
            raw, network, int(summary["candidate_pool_size"]), int(summary["candidate_seed"])
        )
        scalar_keys = (
            "source_instance_id", "load_id", "network_id", "state_text",
            "physical_state_sha256", "full_candidate_count", "candidate_pool_sha256",
        )
        for row in directives:
            if any(row[key] != rebuilt[key] for key in scalar_keys):
                raise RuntimeError(f"topology/state provenance mismatch: {row['instance_id']}")
            expected_style = "test" if expected_partition == "test" else "train"
            expected_source_split = "validation" if expected_partition == "test" else "train"
            expected_instance = (
                f"{expected_partition}:{network}:{row['source_instance_id']}:"
                f"{row['instruction_id']}"
            )
            if (
                row.get("instruction_style") != expected_style
                or row.get("source_split") != expected_source_split
                or row.get("instance_id") != expected_instance
            ):
                raise RuntimeError(f"row identity/style mismatch: {row['instance_id']}")
            if row["instruction_text"] != INSTRUCTIONS[expected_style][row["instruction_id"]]:
                raise RuntimeError(f"instruction text/style mismatch: {row['instance_id']}")
        expected_actions = [item["action"] for item in rebuilt["candidates"]]
        for row in directives:
            if [item["action"] for item in row["candidates"]] != expected_actions:
                raise RuntimeError(f"candidate membership changed by directive: {row['instance_id']}")
            if [item["candidate_feature_text"] for item in row["candidates"]] != [
                item["candidate_feature_text"] for item in rebuilt["candidates"]
            ]:
                raise RuntimeError(f"candidate feature mismatch: {row['instance_id']}")

        if expected_partition == "online_stream":
            forbidden = {
                "desired_index", "desired_action", "instruction_utility", "safe_utility",
                "accepted_by_gate", "normalised_regret", "physics_rank", "target_prob",
                "optimal_indices", "optimal_actions", "is_physics_optimal",
                "fallback_candidate", "reduction_pct", "feasible", "feedback_valid",
                "reason", "anchor_loss_kw", "candidate_loss_kw", "anchor_min_vm_pu",
                "candidate_min_vm_pu", "candidate_max_vm_pu",
            }
            for row in directives:
                if forbidden.intersection(row):
                    raise RuntimeError(f"online row leaked top-level label: {row['instance_id']}")
                if any(forbidden.intersection(candidate) for candidate in row["candidates"]):
                    raise RuntimeError(f"online candidate leaked physics/target: {row['instance_id']}")
                if any(
                    set(candidate) != {"action", "candidate_feature_text", "feedback_revealed"}
                    or candidate.get("feedback_revealed") is not False
                    for candidate in row["candidates"]
                ):
                    raise RuntimeError(f"online candidate schema is not sealed: {row['instance_id']}")
                if row["feedback_status"] != "unrevealed-online-stream":
                    raise RuntimeError("online feedback status is not sealed")
            counters["unrevealed_states"] += 1
            continue

        reference_candidates = directives[0]["candidates"]
        if not all(candidate.get("feedback_revealed") for candidate in reference_candidates):
            raise RuntimeError("scored partition contains unrevealed candidate")
        for row in directives[1:]:
            if not all(candidate_physics_equal(a, b) for a, b in zip(
                reference_candidates, row["candidates"]
            )):
                raise RuntimeError("physical outcome changed across directives")
        for row in directives:
            desired, relabelled = label_candidates(
                row["instruction_id"], reference_candidates, float(summary["target_temperature"])
            )
            if desired != int(row["desired_index"]) or row["desired_action"] != relabelled[desired]["action"]:
                raise RuntimeError(f"desired action mismatch: {row['instance_id']}")
            optimal = [
                index for index, candidate in enumerate(relabelled)
                if candidate["is_physics_optimal"]
            ]
            if row.get("optimal_indices") != optimal or row.get("optimal_actions") != [
                relabelled[index]["action"] for index in optimal
            ]:
                raise RuntimeError(f"optimal-set mismatch: {row['instance_id']}")
            for stored, rebuilt_candidate in zip(row["candidates"], relabelled):
                for key in (
                    "instruction_utility", "safe_utility", "accepted_by_gate",
                    "is_physics_optimal", "fallback_candidate", "normalised_regret",
                    "physics_rank", "target_prob",
                ):
                    if isinstance(stored[key], (float, int)) or isinstance(rebuilt_candidate[key], (float, int)):
                        if not close(stored[key], rebuilt_candidate[key]):
                            raise RuntimeError(f"derived target mismatch {key}: {row['instance_id']}")
                    elif stored[key] != rebuilt_candidate[key]:
                        raise RuntimeError(f"derived target mismatch {key}: {row['instance_id']}")
            if not close(sum(item["target_prob"] for item in row["candidates"]), 1.0):
                raise RuntimeError(f"target probabilities do not sum to one: {row['instance_id']}")
            counters[f"desired_{'noop' if row['desired_action'] == NOOP else 'exchange'}"] += 1
        counters["scored_states"] += 1
    return groups, dict(counters)


def physics_replay(groups, count_per_network, physics_python, timeout):
    records = []
    if count_per_network <= 0:
        return records
    for network in ("33", "69"):
        keys = sorted(key for key in groups if key[0] == network)[:count_per_network]
        for key in keys:
            row = groups[key][0]
            actions = [candidate["action"] for candidate in row["candidates"]]
            replayed = reward.score_completions(
                row["state_text"], actions, return_detail=True, action_mode="delta",
                physics_backend="pandapower-subprocess", physics_python=physics_python,
                physics_timeout_s=timeout,
            )
            if len(replayed) != len(actions):
                raise RuntimeError("physics replay outcome count mismatch")
            mismatches = []
            for stored, (reduction, feasible, detail) in zip(row["candidates"], replayed):
                checks = {
                    "feedback_valid": bool(detail.get("feedback_valid")) == bool(stored["feedback_valid"]),
                    "feasible": bool(feasible) == bool(stored["feasible"]),
                    "reason": detail.get("reason") == stored["reason"],
                    "reduction_pct": close(reduction, stored["reduction_pct"], 1e-6),
                    "anchor_loss_kw": close(detail.get("anchor_loss_kw"), stored["anchor_loss_kw"], 1e-6),
                    "anchor_min_vm_pu": close(detail.get("anchor_min_vm_pu"), stored["anchor_min_vm_pu"], 1e-6),
                    "candidate_loss_kw": close(detail.get("candidate_loss_kw"), stored["candidate_loss_kw"], 1e-6),
                    "candidate_min_vm_pu": close(detail.get("min_vm_pu"), stored["candidate_min_vm_pu"], 1e-6),
                    "candidate_max_vm_pu": close(detail.get("max_vm_pu"), stored["candidate_max_vm_pu"], 1e-6),
                }
                if not all(checks.values()):
                    mismatches.append({"action": stored["action"], "checks": checks})
            records.append({
                "network": network,
                "physical_state_sha256": row["physical_state_sha256"],
                "candidate_count": len(actions),
                "anchor_power_flows": 1,
                "candidate_power_flows": len(actions),
                "mismatches": mismatches,
                "pass": not mismatches,
            })
    return records


def online_anchor_replay(groups, physics_python, timeout):
    records = []
    for key in sorted(groups):
        row = groups[key][0]
        replayed = reward.score_completions(
            row["state_text"], [NOOP], return_detail=True, action_mode="delta",
            physics_backend="pandapower-subprocess", physics_python=physics_python,
            physics_timeout_s=timeout,
        )
        if len(replayed) != 1:
            raise RuntimeError("online anchor replay outcome count mismatch")
        reduction, feasible, detail = replayed[0]
        passed = bool(detail.get("feedback_valid")) and bool(feasible)
        records.append({
            "network": key[0],
            "physical_state_sha256": key[1],
            "feedback_valid": bool(detail.get("feedback_valid")),
            "feasible": bool(feasible),
            "anchor_loss_kw": detail.get("anchor_loss_kw"),
            "anchor_min_vm_pu": detail.get("anchor_min_vm_pu"),
            "pass": passed,
        })
    return records


def selection_trace_replay(summary, source_map, physics_python, timeout):
    records = []
    for partition, networks in summary["selection_trace"].items():
        source_split = "validation" if partition == "test" else "train"
        for network, items in networks.items():
            for item in items:
                raw = source_map[source_split][network]["rows"].get(
                    str(item["source_instance_id"])
                )
                if raw is None:
                    raise RuntimeError("selection trace references an absent source row")
                base = base_state(
                    raw, network, int(summary["candidate_pool_size"]),
                    int(summary["candidate_seed"]),
                )
                replayed = reward.score_completions(
                    base["state_text"], [NOOP], return_detail=True, action_mode="delta",
                    physics_backend="pandapower-subprocess", physics_python=physics_python,
                    physics_timeout_s=timeout,
                )
                if len(replayed) != 1:
                    raise RuntimeError("selection anchor replay outcome count mismatch")
                _, feasible, detail = replayed[0]
                operational = bool(detail.get("feedback_valid")) and bool(feasible)
                expected = bool(item["included"])
                records.append({
                    "partition": partition,
                    "network": network,
                    "source_instance_id": str(item["source_instance_id"]),
                    "expected_included": expected,
                    "feedback_valid": bool(detail.get("feedback_valid")),
                    "feasible": bool(feasible),
                    "pass": operational == expected,
                })
    return records


def partition_summary_matches(name, rows, groups, summary):
    expected = summary["partitions"][name]
    candidate_counts = [len(row["candidates"]) for row in rows]
    actual = {
        "rows": len(rows),
        "base_states": len(groups),
        "loads": len({row["load_id"] for row in rows}),
        "network_mix": dict(Counter(row["network_id"] for row in rows)),
        "instruction_mix": dict(Counter(row["instruction_id"] for row in rows)),
        "candidate_count_min": min(candidate_counts),
        "candidate_count_max": max(candidate_counts),
    }
    return all(actual[key] == expected.get(key) for key in actual) and close(
        sum(row["full_candidate_count"] for row in rows) / len(rows),
        expected.get("full_candidate_count_mean"),
    )


def selected_loads_match(artifacts, summary):
    for partition, (_, rows) in artifacts.items():
        for network in ("33", "69"):
            actual = sorted({
                row["load_id"].split(":", 1)[1]
                for row in rows if str(row["network_id"]) == network
            })
            expected = sorted(str(value) for value in summary["selected_load_ids"][partition][network])
            if actual != expected:
                return False
    return True


def selection_trace_matches(source_map, artifacts, summary):
    trace = summary.get("selection_trace")
    if not isinstance(trace, dict):
        return False
    row_seed = int(summary["row_seed"])
    for network in ("33", "69"):
        train_order = _state_rows_by_load(
            source_map["train"][network]["ordered"], network, row_seed
        )
        offline_trace = trace.get("offline_train", {}).get(network, [])
        online_trace = trace.get("online_stream", {}).get(network, [])
        combined = [*offline_trace, *online_trace]
        expected_ids = [str(row["instance_id"]) for row in train_order[:len(combined)]]
        if [str(item.get("source_instance_id")) for item in combined] != expected_ids:
            return False
        validation_order = _state_rows_by_load(
            source_map["validation"][network]["ordered"], network, row_seed + 4242
        )
        test_trace = trace.get("test", {}).get(network, [])
        if [str(item.get("source_instance_id")) for item in test_trace] != [
            str(row["instance_id"]) for row in validation_order[:len(test_trace)]
        ]:
            return False
        for partition, values in (
            ("offline_train", offline_trace),
            ("online_stream", online_trace),
            ("test", test_trace),
        ):
            selected_ids = {
                row["source_instance_id"] for row in artifacts[partition][1]
                if str(row["network_id"]) == network
            }
            included_ids = {
                str(item.get("source_instance_id")) for item in values
                if item.get("included") is True
            }
            if selected_ids != included_ids:
                return False
            if any(
                item.get("reason") not in {"operational_anchor", "infeasible_anchor"}
                or not isinstance(item.get("candidate_evaluations"), int)
                or int(item["candidate_evaluations"]) <= 0
                for item in values
            ):
                return False
    return True


def main():
    args = parse_args()
    if args.replay_states_per_network <= 0:
        raise SystemExit("replay_states_per_network must be positive")
    summary = json.load(open(args.summary_json, encoding="utf-8"))
    if summary.get("schema") != "gridrank-feedback-v1":
        raise ValueError("unexpected GridRank summary schema")
    source_map = {
        "train": parse_sources(args.train_source, "train"),
        "validation": parse_sources(args.validation_source, "validation"),
    }
    artifacts = {
        "offline_train": (args.offline_jsonl, load_jsonl(args.offline_jsonl)),
        "online_stream": (args.online_jsonl, load_jsonl(args.online_jsonl)),
        "test": (args.test_jsonl, load_jsonl(args.test_jsonl)),
    }
    groups, partition_audits = {}, {}
    for name, (_, rows) in artifacts.items():
        groups[name], partition_audits[name] = group_audit(rows, name, source_map, summary)

    state_sets = {name: {key[1] for key in values} for name, values in groups.items()}
    state_disjoint = all(
        not state_sets[a].intersection(state_sets[b])
        for offset, a in enumerate(state_sets)
        for b in list(state_sets)[offset + 1:]
    )
    load_sets = {
        name: {row["load_id"] for row in rows}
        for name, (_, rows) in artifacts.items()
    }
    loads_disjoint = all(
        not load_sets[a].intersection(load_sets[b])
        for offset, a in enumerate(load_sets)
        for b in list(load_sets)[offset + 1:]
    )
    artifact_hashes_match = all(
        file_sha256(path) == summary["artifacts"][name]["sha256"]
        for name, (path, _) in artifacts.items()
    )
    summary_counts_match = all(
        partition_summary_matches(name, rows, groups[name], summary)
        for name, (_, rows) in artifacts.items()
    )
    code_sha256 = {
        name: file_sha256(HERE / name) for name in CODE_FILES if (HERE / name).exists()
    }
    missing_code_files = [name for name in CODE_FILES if not (HERE / name).exists()]
    build_code_matches = summary.get("build_code_sha256") == {
        name: file_sha256(HERE / name) for name in BUILD_CODE_FILES
        if (HERE / name).exists()
    }
    source_hashes_match = all(
        summary.get("sources", {}).get(split, {}).get(network, {}).get("sha256")
        == file_sha256(value["path"])
        for split, sources in source_map.items()
        for network, value in sources.items()
    )
    selected_match = selected_loads_match(artifacts, summary)
    trace_match = selection_trace_matches(source_map, artifacts, summary)
    trace_values = [
        item
        for partition in summary.get("selection_trace", {}).values()
        for network_rows in partition.values()
        for item in network_rows
    ]
    expected_pf = {
        "anchor_power_flows": len(trace_values),
        "candidate_power_flows": sum(int(item["candidate_evaluations"]) for item in trace_values),
    }
    expected_pf["backend_power_flows"] = (
        expected_pf["anchor_power_flows"] + expected_pf["candidate_power_flows"]
    )
    power_flow_counts_match = all(
        int(summary.get("power_flow_calls", {}).get(key, -1)) == value
        for key, value in expected_pf.items()
    )
    replay = []
    for partition in ("offline_train", "test"):
        replay.extend(physics_replay(
            groups[partition], args.replay_states_per_network,
            args.physics_python, args.physics_timeout_s,
        ))
    selection_replay = selection_trace_replay(
        summary, source_map, args.physics_python, args.physics_timeout_s
    )
    expected_replay_count = 2 * 2 * args.replay_states_per_network
    labelled_noop_operational = all(
        next(candidate for candidate in directives[0]["candidates"] if candidate["action"] == NOOP).get("feasible")
        for partition in ("offline_train", "test")
        for directives in groups[partition].values()
    )
    checks = {
        "strict_source_schema": True,
        "topology_membership_rebuilt": True,
        "derived_targets_recomputed": True,
        "online_feedback_sealed": partition_audits["online_stream"].get("unrevealed_states", 0)
            == len(groups["online_stream"]),
        "state_partitions_disjoint": state_disjoint,
        "load_partitions_disjoint": loads_disjoint,
        "artifact_hashes_match_summary": artifact_hashes_match,
        "summary_counts_match": summary_counts_match,
        "source_hashes_match_summary": source_hashes_match,
        "selected_load_ids_match": selected_match,
        "deterministic_selection_trace_matches": trace_match,
        "power_flow_call_counts_match_trace": power_flow_counts_match,
        "build_code_matches_summary": build_code_matches,
        "both_target_types_in_offline": all(
            partition_audits["offline_train"].get(f"desired_{kind}", 0) > 0
            for kind in ("noop", "exchange")
        ),
        "both_target_types_in_test": all(
            partition_audits["test"].get(f"desired_{kind}", 0) > 0
            for kind in ("noop", "exchange")
        ),
        "locked_code_files_present": not missing_code_files,
        "labelled_noop_operational": labelled_noop_operational,
        "pandapower_replay_count_exact": len(replay) == expected_replay_count,
        "pandapower_replay_exact": len(replay) == expected_replay_count
            and all(record["pass"] for record in replay),
        "selection_anchor_replay_exact": len(selection_replay) == len(trace_values)
            and all(record["pass"] for record in selection_replay),
    }
    result = {
        "msg": "GridRank strict data/provenance audit",
        "summary_sha256": file_sha256(args.summary_json),
        "artifact_sha256": {name: file_sha256(path) for name, (path, _) in artifacts.items()},
        "source_sha256": {
            split: {network: file_sha256(value["path"]) for network, value in sources.items()}
            for split, sources in source_map.items()
        },
        "code_sha256": code_sha256,
        "missing_code_files": missing_code_files,
        "partition_audits": partition_audits,
        "physics_replay": replay,
        "selection_anchor_replay": selection_replay,
        "checks": checks,
        "audit_pass": all(checks.values()),
    }
    Path(args.output).parent.mkdir(parents=True, exist_ok=True)
    Path(args.output).write_text(json.dumps(result, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps(result, ensure_ascii=False))
    if not result["audit_pass"]:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
