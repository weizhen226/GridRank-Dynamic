"""Validate GridRank dynamic factorization multiseed dependencies."""

from __future__ import annotations

import ast
import json
from pathlib import Path


HERE = Path(__file__).resolve().parent


def main():
    tree = ast.parse(
        (HERE / "aggregate_gridrank_dynamic_factorization_multiseed.py").read_text(
            encoding="utf-8"
        )
    )
    imports = {
        alias.name
        for node in ast.walk(tree)
        if isinstance(node, ast.Import)
        for alias in node.names
    }
    calls = [
        node.func.attr
        for node in ast.walk(tree)
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute)
    ]
    source = (
        HERE / "aggregate_gridrank_dynamic_factorization_multiseed.py"
    ).read_text(encoding="utf-8")
    checks = {
        "three_seeds_exact": "SEEDS = (42, 123, 2025)" in source,
        "paired_orientation_joint_minus_factorized": (
            'statistics.pair_effects(\n            methods, JOINT, FACTORIZED'
            in source
        ),
        "physical_state_bootstrap_present": "bootstrap_state_matrix" in source,
        "two_way_gate_present": (
            "primary_two_way_seed_state_ci_lower_positive" in source
        ),
        "hierarchical_gate_present": "primary_hierarchical_ci_lower_positive"
        in source,
        "no_model_library_import": not imports.intersection(
            {"torch", "transformers", "peft", "bitsandbytes"}
        ),
        "no_fit_backward_or_power_flow": not any(
            name in calls
            for name in (
                "fit",
                "backward",
                "step",
                "runpp",
                "run_power_flow",
                "evaluate_action",
            )
        ),
    }
    result = {
        "msg": "GridRank factorization multiseed dependency verification",
        "checks": checks,
        "verification_pass": all(checks.values()),
        "training_performed": False,
        "model_loaded": False,
        "power_flow_calls": 0,
    }
    print(json.dumps(result, ensure_ascii=False))
    if not result["verification_pass"]:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
