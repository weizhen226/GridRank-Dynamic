"""Build gridalign instruction feedback."""

import argparse
import hashlib
import json
import random
from collections import Counter
from pathlib import Path

import grpo_reward_limited as reward
from limited_protocol import DEADBAND_PCT


NOOP = "Action: none"


INSTRUCTIONS = {
    "train": {
        "loss": "Prioritize the largest feasible reduction in active power loss; retain the current topology when no candidate improves it.",
        "voltage": "Prioritize raising the minimum bus voltage, while rejecting infeasible actions and actions that increase loss by more than 0.5 percent.",
        "balanced": "Balance active-loss reduction and minimum-voltage improvement; prefer a candidate that improves their combined operating score.",
        "conservative": "Use a conservative policy: reconfigure only when feasible loss reduction is at least 2 percent and minimum voltage is not degraded.",
    },
    "test": {
        "loss": "Choose the feasible exchange that cuts resistive losses the most; otherwise leave every switch as it is.",
        "voltage": "Favor the admissible exchange with the strongest improvement of the weakest bus voltage, without accepting over 0.5 percent extra loss.",
        "balanced": "Trade off feeder losses against the low-voltage margin, selecting the action with the best combined benefit.",
        "conservative": "Avoid unnecessary switching: act only for at least a 2 percent loss saving with no reduction of the minimum voltage.",
    },
}


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", action="append", required=True, help="NETWORK=JSONL")
    parser.add_argument("--split", choices=["train", "validation"], required=True)
    parser.add_argument("--instruction_style", choices=["train", "test"], required=True)
    parser.add_argument("--rows_per_network", type=int, default=24)
    parser.add_argument("--max_scanned_rows_per_network", type=int, default=32)
    parser.add_argument("--candidate_pool_size", type=int, default=8)
    parser.add_argument("--candidate_seed", type=int, default=20260715)
    parser.add_argument("--row_seed", type=int, default=42)
    parser.add_argument("--physics_backend", choices=["pandapower-subprocess"], default="pandapower-subprocess")
    parser.add_argument("--physics_python", required=True)
    parser.add_argument("--physics_timeout_s", type=float, default=60.0)
    parser.add_argument("--out_jsonl", required=True)
    parser.add_argument("--out_summary", required=True)
    return parser.parse_args()


def state_only_prompt(prompt, directive):
    marker = "Power Distribution Network:"
    offset = prompt.find(marker)
    if offset < 0:
        raise ValueError("prompt is missing physical-state marker")
    return (
        "You are selecting one distribution-network branch exchange.\n"
        f"Operator directive: {directive}\n"
        "Candidate actions will be evaluated under the following physical state.\n\n"
        + prompt[offset:]
    )


def action_pool(network, instance_id, actions, size, seed):
    unique = [NOOP, *sorted(set(action for action in actions if action != NOOP))]
    if len(unique) <= size:
        return unique
    prefix = f"{seed}|{network}|{instance_id}|"
    ranked = sorted(
        unique[1:],
        key=lambda action: hashlib.sha256((prefix + action).encode("utf-8")).digest(),
    )
    return [NOOP, *ranked[:size - 1]]


def sanitize_feedback(action, scored):
    reduction, feasible, detail = scored
    return {
        "action": action,
        "feasible": bool(feasible),
        "feedback_valid": bool(detail.get("feedback_valid")),
        "reason": detail.get("reason"),
        "reduction_pct": float(reduction) if reduction is not None else None,
        "anchor_loss_kw": detail.get("anchor_loss_kw"),
        "candidate_loss_kw": detail.get("candidate_loss_kw"),
        "anchor_min_vm_pu": detail.get("anchor_min_vm_pu"),
        "candidate_min_vm_pu": detail.get("min_vm_pu"),
        "candidate_max_vm_pu": detail.get("max_vm_pu"),
    }


def utility(kind, candidate, anchor_min):
    if not candidate["feedback_valid"] or not candidate["feasible"]:
        return None
    reduction = candidate["reduction_pct"]
    minimum = candidate["candidate_min_vm_pu"]
    if reduction is None or minimum is None or anchor_min is None:
        return None
    voltage_delta = float(minimum) - float(anchor_min)
    if candidate["action"] == NOOP:
        return 0.0
    if kind == "loss":
        return float(reduction)
    if kind == "voltage":
        return 100.0 * voltage_delta if float(reduction) >= -0.5 else None
    if kind == "balanced":
        return float(reduction) + 500.0 * voltage_delta
    if kind == "conservative":
        if float(reduction) < 2.0 or voltage_delta < -1e-4:
            return None
        return float(reduction)
    raise ValueError(kind)


def label_for_instruction(kind, candidates):
    noop_index = next(index for index, item in enumerate(candidates) if item["action"] == NOOP)
    anchor_min = candidates[noop_index]["anchor_min_vm_pu"]
    values = [utility(kind, item, anchor_min) for item in candidates]
    noop_utility = values[noop_index]
    if noop_utility is None:
        raise RuntimeError("no-op physics feedback is invalid")
    best_index = noop_index
    best_value = float(noop_utility)
    for index, value in enumerate(values):
        if value is not None and float(value) > best_value:
            best_index, best_value = index, float(value)
    thresholds = {"loss": DEADBAND_PCT, "voltage": 0.01, "balanced": 0.05, "conservative": 0.0}
    if best_value <= float(noop_utility) + thresholds[kind]:
        best_index = noop_index
    output = []
    for index, candidate in enumerate(candidates):
        item = dict(candidate)
        item["instruction_utility"] = values[index]
        item["target_prob"] = float(index == best_index)
        output.append(item)
    return best_index, output


def row_digest(rows):
    payload = "\n".join(
        f'{row["network_id"]}:{row["base_instance_id"]}:{row["instruction_id"]}:'
        f'{row["desired_action"]}' for row in rows
    )
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def main():
    args = parse_args()
    if args.candidate_pool_size < 2 or args.rows_per_network <= 0:
        raise SystemExit("candidate_pool_size >= 2 and rows_per_network > 0 are required")
    output = []
    counters = Counter()
    for source_offset, spec in enumerate(args.source):
        network, path = spec.split("=", 1)
        raw_rows = [json.loads(line) for line in open(path, encoding="utf-8") if line.strip()]
        if not raw_rows or any(row.get("split") != args.split for row in raw_rows):
            raise ValueError(f"{path} must contain only split={args.split}")
        rng = random.Random(args.row_seed + 101 * source_offset)
        rng.shuffle(raw_rows)
        retained_states = 0
        for raw in raw_rows[:args.max_scanned_rows_per_network]:
            counters[f"network_{network}_scanned"] += 1
            
            actions = action_pool(
                network, raw["instance_id"],
                [item["action"] for item in raw.get("candidates", [])],
                args.candidate_pool_size, args.candidate_seed,
            )
            scored = reward.score_completions(
                raw["prompt"], actions, return_detail=True, action_mode="delta",
                physics_backend=args.physics_backend,
                physics_python=args.physics_python,
                physics_timeout_s=args.physics_timeout_s,
            )
            candidates = [sanitize_feedback(action, item) for action, item in zip(actions, scored)]
            counters["simulator_calls"] += len(actions)
            if not all(item["feedback_valid"] for item in candidates):
                counters["invalid_feedback_states"] += 1
                continue
            labelled = {}
            desired_actions = {}
            for kind in INSTRUCTIONS[args.instruction_style]:
                desired_index, items = label_for_instruction(kind, candidates)
                labelled[kind] = items
                desired_actions[kind] = actions[desired_index]
            if len(set(desired_actions.values())) < 2:
                counters["non_counterfactual_states"] += 1
                continue
            for kind, directive in INSTRUCTIONS[args.instruction_style].items():
                items = labelled[kind]
                desired_index = next(
                    index for index, item in enumerate(items) if item["target_prob"] == 1.0
                )
                output.append({
                    "instance_id": f'{network}:{raw["instance_id"]}:{kind}',
                    "base_instance_id": raw["instance_id"],
                    "load_id": f'{network}:{raw.get("load_id")}',
                    "network_id": str(network),
                    "split": args.split,
                    "instruction_id": kind,
                    "instruction_style": args.instruction_style,
                    "instruction_text": directive,
                    "prompt": state_only_prompt(raw["prompt"], directive),
                    "candidates": items,
                    "desired_index": desired_index,
                    "desired_action": items[desired_index]["action"],
                    "candidate_pool_sha256": hashlib.sha256(
                        "\n".join(actions).encode("utf-8")
                    ).hexdigest(),
                })
            retained_states += 1
            counters[f"network_{network}_states"] += 1
            if retained_states >= args.rows_per_network:
                break
        if retained_states < args.rows_per_network:
            counters[f"network_{network}_underfilled"] = args.rows_per_network - retained_states

    Path(args.out_jsonl).parent.mkdir(parents=True, exist_ok=True)
    with open(args.out_jsonl, "w", encoding="utf-8") as handle:
        for row in output:
            handle.write(json.dumps(row, ensure_ascii=False) + "\n")
    summary = {
        "msg": "GridAlign instruction-conditioned live-feedback data",
        "split": args.split,
        "instruction_style": args.instruction_style,
        "rows": len(output),
        "base_states": len(output) // len(INSTRUCTIONS[args.instruction_style]),
        "requested_states_per_network": args.rows_per_network,
        "networks": sorted({row["network_id"] for row in output}),
        "instruction_mix": dict(Counter(row["instruction_id"] for row in output)),
        "desired_action_mix": dict(Counter(
            "noop" if row["desired_action"] == NOOP else "exchange" for row in output
        )),
        "counters": dict(counters),
        "data_sha256": row_digest(output),
        "candidate_membership": "no-op + deterministic action hash; source physics labels ignored",
        "physics_backend": args.physics_backend,
    }
    summary["coverage_pass"] = not any(
        key.endswith("_underfilled") and value > 0
        for key, value in counters.items()
    )
    with open(args.out_summary, "w", encoding="utf-8") as handle:
        json.dump(summary, handle, indent=2, ensure_ascii=False)
    print(json.dumps(summary, ensure_ascii=False))


if __name__ == "__main__":
    main()
