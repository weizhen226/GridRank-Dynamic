"""Validate GridRank label controls hotfix."""

from __future__ import annotations

import argparse
import json

from aggregate_gridrank_label_controls_hotfix import (
    AGGREGATE_SCHEMA,
    RECONSTRUCTION,
    paired,
)
from gridrank_label_controls import VARIANTS
from preflight_gridrank_label_controls import EXPERIMENT_ID, file_sha256


def dependency_regression():
    before = [
        {"instance_id": "a", "network": "33", "physical_state_sha256": "1",
         "distilled_safe_regret": 2.0},
        {"instance_id": "b", "network": "69", "physical_state_sha256": "2",
         "distilled_safe_regret": 1.0},
    ]
    after = [
        {"instance_id": "a", "network": "33", "physical_state_sha256": "1",
         "distilled_safe_regret": 1.0},
        {"instance_id": "b", "network": "69", "physical_state_sha256": "2",
         "distilled_safe_regret": 1.0},
    ]
    result = paired(before, after, 200, 7)
    checks = {
        "orientation_before_minus_after": result["safe_regret_improvement_mean"] == 0.5,
        "state_clusters": result["n_state_clusters"] == 2,
        "counts": result["rows_better"] == 1 and result["rows_tied"] == 1,
    }
    payload = {
        "msg": "GridRank label-control hotfix dependency regression",
        "checks": checks,
        "verification_pass": all(checks.values()),
    }
    print(json.dumps(payload, ensure_ascii=False))
    if not payload["verification_pass"]:
        raise SystemExit(2)


def verify_result(path, suite_path):
    result = json.load(open(path, encoding="utf-8"))
    checks = {
        "schema": result.get("schema") == AGGREGATE_SCHEMA,
        "experiment_id": result.get("experiment_id") == EXPERIMENT_ID,
        "audit_pass": result.get("audit_pass") is True,
        "variants": set(result.get("controls", {})) == set(VARIANTS),
        "causal_decision": isinstance(result.get("causal_decision"), dict),
        "cached_only": result.get("training_performed") is False
            and result.get("model_loaded") is False
            and result.get("power_flow_calls") == 0,
        "reconstruction": result.get("reconstruction") == RECONSTRUCTION,
        "suite_identity": result.get("suite_preflight", {}).get("sha256")
            == file_sha256(suite_path),
    }
    payload = {
        "msg": "GridRank label-control hotfix aggregate verification",
        "checks": checks,
        "verification_pass": all(checks.values()),
        "causal_decision": result.get("causal_decision"),
    }
    print(json.dumps(payload, ensure_ascii=False))
    if not payload["verification_pass"]:
        raise SystemExit(2)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--aggregate")
    parser.add_argument("--suite_preflight")
    args = parser.parse_args()
    if args.aggregate:
        if not args.suite_preflight:
            raise SystemExit("aggregate verification requires suite preflight")
        verify_result(args.aggregate, args.suite_preflight)
    else:
        dependency_regression()


if __name__ == "__main__":
    main()
