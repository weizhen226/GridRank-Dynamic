"""Gridrank dynamic observation robustness utilities."""

from __future__ import annotations

import copy
import hashlib
import json
import math
import random
from collections import defaultdict
from pathlib import Path

import preflight_gridrank_dynamic_benchmark as benchmark
from build_gridrank_instruction_pairs import (
    NOOP,
    selected_action,
    structured_proxy_order,
)
from build_gridrank_instruct_identifiability import label_instruction
from gridrank_dynamic_llm import CARDS, card_index


SCHEMA = "gridrank-dynamic-observation-robustness-v1"
EXPERIMENT_ID = "gridrank-dynamic-sealed-operating-and-observation-robustness-v1"
PRIMARY = "maintenance_voltage"
SEEDS = (42, 123, 2025)
LLM_PREFIX = "physics_aligned_factorized_llm"
SCENARIO_SEED = 20260907
PERTURBATION_SEED = 20260909
LOAD_SCALES = (0.85, 1.0, 1.15)
DER_SCALES = (0.80, 1.0, 1.20)
NOISE_SIGMAS = (0.01, 0.03, 0.05)
NOISE_REPLICATES = (0, 1, 2)
REGIMES = ("load_only", "moderate_der", "high_der")
LOAD_BINS = ("low", "medium", "high")


def file_sha256(path):
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def read_jsonl(path):
    return [
        json.loads(line)
        for line in open(path, encoding="utf-8")
        if line.strip()
    ]


def write_jsonl_exclusive(path, rows):
    with open(path, "x", encoding="utf-8", newline="\n") as handle:
        for row in rows:
            handle.write(
                json.dumps(row, ensure_ascii=False, sort_keys=True) + "\n"
            )


def mean(values):
    values = list(values)
    return sum(values) / len(values) if values else None


def quantile(values):
    ordered = sorted(float(value) for value in values)
    if not ordered:
        return [None, None]
    return [
        ordered[int(0.025 * (len(ordered) - 1))],
        ordered[int(0.975 * (len(ordered) - 1))],
    ]


def state_index(row):
    
    if row.get("state_index") is not None:
        return int(row["state_index"])
    try:
        return int(str(row["load_id"]).rsplit(":", 1)[-1])
    except (KeyError, TypeError, ValueError) as exc:
        raise ValueError(
            f"state index unavailable for {row.get('instance_id')}"
        ) from exc


def _hash_unit(*parts):
    digest = hashlib.sha256("|".join(map(str, parts)).encode()).digest()
    return (int.from_bytes(digest[:8], "big") + 0.5) / float(2**64)


def hash_normal(*parts):
    
    first = max(_hash_unit(*parts, "u1"), 1e-15)
    second = _hash_unit(*parts, "u2")
    return math.sqrt(-2.0 * math.log(first)) * math.cos(
        2.0 * math.pi * second
    )


def operating_conditions():
    
    return (
        {"id": "clean", "load_scale": 1.0, "der_scale": 1.0},
        {"id": "load_085", "load_scale": 0.85, "der_scale": 1.0},
        {"id": "load_115", "load_scale": 1.15, "der_scale": 1.0},
        {"id": "der_080", "load_scale": 1.0, "der_scale": 0.80},
        {"id": "der_120", "load_scale": 1.0, "der_scale": 1.20},
    )


def noise_conditions():
    return tuple(
        {
            "id": f"noise_s{int(round(100 * sigma)):02d}_r{replicate}",
            "sigma": float(sigma),
            "replicate": int(replicate),
        }
        for sigma in NOISE_SIGMAS
        for replicate in NOISE_REPLICATES
    )


def scale_operating_net(net, load_scale, der_scale):
    value = copy.deepcopy(net)
    if len(value.load):
        value.load.loc[:, "scaling"] = (
            value.load.scaling.astype(float) * float(load_scale)
        ).clip(lower=0.0)
    for table_name in ("sgen", "gen", "storage"):
        table = getattr(value, table_name)
        if len(table):
            table.loc[:, "scaling"] = (
                table.scaling.astype(float) * float(der_scale)
            ).clip(lower=0.0)
    return value


def noisy_observation(net, sigma, replicate, state_sha, seed=PERTURBATION_SEED):
    
    value = copy.deepcopy(net)
    for table_name in ("load", "sgen", "gen", "storage"):
        table = getattr(value, table_name)
        if not len(table):
            continue
        for index, row in table.iterrows():
            factor = 1.0 + float(sigma) * hash_normal(
                seed, state_sha, replicate, table_name, int(index)
            )
            
            
            factor = min(1.0 + 3.0 * sigma, max(1.0 - 3.0 * sigma, factor))
            base = float(row.get("scaling", 1.0))
            table.at[index, "scaling"] = max(0.0, base * factor)
    return value


def aggregate_power(net, table_name):
    table = getattr(net, table_name)
    if not len(table):
        return 0.0
    return sum(
        float(row.get("p_mw", 0.0)) * float(row.get("scaling", 1.0))
        for _, row in table.iterrows()
        if bool(row.get("in_service", True))
    )


def state_operating_metadata(grid, code, net, state_index):
    base = grid.base_network(code)
    base_load = max(aggregate_power(base, "load"), 1e-12)
    load = aggregate_power(net, "load")
    der = sum(
        aggregate_power(net, name) for name in ("sgen", "gen", "storage")
    )
    return {
        "network": grid.network_id(code),
        "simbench_code": code,
        "n_bus": int(len(net.bus)),
        "state_index": int(state_index),
        "operating_regime": grid.operating_regime(state_index),
        "load_mw": float(load),
        "base_load_mw": float(base_load),
        "normalised_load_level": float(load / base_load),
        "der_mw": float(der),
        "der_active": bool(der > 1e-12),
    }


def assign_load_bins(metadata):
    
    grouped = defaultdict(list)
    for state_sha, value in metadata.items():
        grouped[value["network"]].append(
            (float(value["normalised_load_level"]), state_sha)
        )
    output = {}
    for network, values in grouped.items():
        ordered = sorted(values)
        count = len(ordered)
        for rank, (_, state_sha) in enumerate(ordered):
            index = min(2, (3 * rank) // max(1, count))
            output[state_sha] = LOAD_BINS[index]
    return output


def record_index(records):
    result = defaultdict(dict)
    for record in records:
        method = str(record["method"])
        instance = str(record["instance_id"])
        if instance in result[method]:
            raise ValueError(f"duplicate record: {method}:{instance}")
        result[method][instance] = record
    return result


def frozen_semantics(row, record):
    card_id = record.get("selected_card")
    if not card_id:
        raise ValueError(f"missing selected_card: {record.get('instance_id')}")
    card = CARDS[card_index(card_id)]
    constrained = bool(card["hard_constraint"])
    return {
        "objective": str(card["objective"]),
        "hard_constraint": constrained,
        "forbidden_edges": (
            benchmark.extract_edges(row["instruction_text"])
            if constrained else []
        ),
    }


def semantic_family(semantic):
    prefix = "maintenance_" if semantic["hard_constraint"] else ""
    return prefix + str(semantic["objective"])


def feature_row(source_row, features):
    value = dict(source_row)
    value["candidates"] = [
        {
            "action": item["action"],
            "candidate_feature_text": features[item["action"]],
        }
        for item in source_row["candidates"]
    ]
    return value


def proxy_order(source_row, features, semantic):
    return structured_proxy_order(
        feature_row(source_row, features),
        semantic["objective"],
        semantic["forbidden_edges"],
    )


def _live_candidate(action, item, anchor, feature_text):
    return {
        **dict(item),
        "action": action,
        "candidate_feature_text": feature_text,
        "anchor_loss_kw": anchor.get("loss_kw"),
        "anchor_min_vm_pu": anchor.get("min_vm_pu"),
        "anchor_max_vm_pu": anchor.get("max_vm_pu"),
        "candidate_loss_kw": item.get("loss_kw"),
        "candidate_min_vm_pu": item.get("min_vm_pu"),
        "candidate_max_vm_pu": item.get("max_vm_pu"),
    }


def run_live_actions(grid, code, net, actions, features):
    
    base = grid._base
    anchor = base._run_power_flow(
        code,
        copy.deepcopy(net),
        base.open_line_indices(code, net),
    )
    outcomes = {}
    if anchor.get("feedback_valid") and anchor.get("loss_kw") is not None:
        for action in actions:
            item = base._run_power_flow(
                code,
                copy.deepcopy(net),
                base.action_open_lines(code, action),
            )
            reduction = None
            if item.get("feedback_valid") and item.get("loss_kw") is not None:
                reduction = 100.0 * (
                    float(anchor["loss_kw"]) - float(item["loss_kw"])
                ) / max(abs(float(anchor["loss_kw"])), 1e-12)
            item = dict(item)
            item["reduction_pct"] = reduction
            outcomes[action] = _live_candidate(
                action, item, anchor, features[action]
            )
    return anchor, outcomes


def live_state(source_row, anchor, outcomes, features):
    candidates = [
        outcomes[item["action"]] for item in source_row["candidates"]
    ]
    noop_item = {
        **dict(anchor),
        "action": NOOP,
        "reduction_pct": 0.0,
    }
    noop = _live_candidate(NOOP, noop_item, anchor, features[NOOP])
    return {
        "network_id": str(source_row["network_id"]),
        "load_id": str(source_row["load_id"]),
        "physical_state_sha256": source_row["physical_state_sha256"],
        "state_text": source_row["state_text"],
        "candidates": [*candidates, noop],
    }


def labelled_state(state, semantic):
    return label_instruction(
        state,
        semantic_family(semantic),
        "validation",
        tuple(
            tuple(sorted((int(edge[0]), int(edge[1]))))
            for edge in semantic["forbidden_edges"]
        ),
        0.20,
    )


def deploy_full_pool(source_row, features, state, semantic, gate_semantic=None):
    
    ranking = proxy_order(source_row, features, semantic)
    labelled = labelled_state(state, gate_semantic or semantic)
    return selected_action(labelled, ranking, 1), ranking[0]


def observed_gate_action(
    source_row, ranking, anchor, outcomes, semantic, gate_semantic=None
):
    
    gate = gate_semantic or semantic
    top1 = ranking[0]
    item = outcomes.get(top1)
    if (
        item is None
        or not bool(anchor.get("feedback_valid"))
        or not bool(anchor.get("feasible"))
        or not bool(item.get("feedback_valid"))
        or not bool(item.get("feasible"))
        or benchmark.action_touches(top1, gate["forbidden_edges"])
    ):
        return NOOP, top1, "physical_or_constraint_reject"
    reduction = item.get("reduction_pct")
    minimum = item.get("candidate_min_vm_pu")
    anchor_min = anchor.get("min_vm_pu")
    utility = None
    if reduction is not None and minimum is not None and anchor_min is not None:
        if gate["objective"] == "loss":
            utility = float(reduction)
        elif float(reduction) >= -0.5:
            utility = 100.0 * (float(minimum) - float(anchor_min))
    deadband = 0.05 if gate["objective"] == "loss" else 0.01
    if utility is None or utility <= deadband:
        return NOOP, top1, "objective_or_deadband_reject"
    return top1, top1, "accepted"


def clean_action_status(row, action):
    target = benchmark.semantic_target(row)
    item = (
        row["gate_anchor"]
        if action == NOOP
        else next(x for x in row["candidates"] if x["action"] == action)
    )
    return {
        "normalised_regret": float(benchmark.action_regret(row, action)),
        "physics_optimal": benchmark.action_regret(row, action) <= 1e-12,
        "true_feasible": bool(item.get("feedback_valid"))
        and bool(item.get("feasible")),
        "true_constraint_violation": benchmark.action_touches(
            action, target["forbidden_edges"]
        ),
        "no_op": action == NOOP,
    }


def condition_summary(rows):
    if not rows:
        return {
            "n": 0,
            "physical_states": 0,
            "normalised_regret_mean": None,
            "regret_degradation_mean": None,
            "physics_optimal_rate": None,
            "action_flip_rate": None,
            "true_feasible_rate": None,
            "true_constraint_violation_rate": None,
            "no_op_rate": None,
            "observed_anchor_feasible_rate": None,
            "observed_gate_rejection_rate": None,
        }
    return {
        "n": len(rows),
        "physical_states": len({
            row["physical_state_sha256"] for row in rows
        }),
        "normalised_regret_mean": mean(
            float(row["normalised_regret"]) for row in rows
        ),
        "regret_degradation_mean": mean(
            float(row["regret_degradation"]) for row in rows
        ),
        "physics_optimal_rate": mean(
            float(row["physics_optimal"]) for row in rows
        ),
        "action_flip_rate": mean(
            float(row["action_flip"]) for row in rows
        ),
        "true_feasible_rate": mean(
            float(row["true_feasible"]) for row in rows
        ),
        "true_constraint_violation_rate": mean(
            float(row["true_constraint_violation"]) for row in rows
        ),
        "no_op_rate": mean(float(row["no_op"]) for row in rows),
        "observed_anchor_feasible_rate": mean(
            float(row["observed_anchor_feasible"]) for row in rows
        ),
        "observed_gate_rejection_rate": mean(
            float(row["observed_gate_rejected"]) for row in rows
        ),
    }


def state_cluster_ci(rows, reps, seed):
    grouped = defaultdict(list)
    for row in rows:
        grouped[row["physical_state_sha256"]].append(
            float(row["regret_degradation"])
        )
    states = sorted(grouped)
    values = {state: mean(grouped[state]) for state in states}
    rng = random.Random(seed)
    draws = [
        mean(values[states[rng.randrange(len(states))]] for _ in states)
        for _ in range(reps)
    ] if states else []
    return {
        "physical_state_clusters": len(states),
        "regret_degradation_mean": mean(values.values()),
        "physical_state_cluster_ci95": quantile(draws),
    }


def grouped_summary(rows, key):
    return {
        str(value): condition_summary([
            row for row in rows if row[key] == value
        ])
        for value in sorted({row[key] for row in rows})
    }


def summarize(records, bootstrap_reps, bootstrap_seed):
    operating = [
        row for row in records if row["experiment_axis"] == "operating_shift"
    ]
    noise = [
        row for row in records if row["experiment_axis"] == "measurement_noise"
    ]
    operating_ids = [item["id"] for item in operating_conditions()]
    operating_blocks = {}
    for index, condition in enumerate(operating_ids):
        selected = [row for row in operating if row["condition"] == condition]
        operating_blocks[condition] = {
            **condition_summary(selected),
            "paired_degradation": state_cluster_ci(
                selected, bootstrap_reps, bootstrap_seed + index * 1000
            ),
            "by_network": grouped_summary(selected, "network"),
            "by_regime": grouped_summary(selected, "operating_regime"),
            "by_seed": grouped_summary(selected, "seed"),
        }
    noise_blocks = {}
    for index, sigma in enumerate(NOISE_SIGMAS):
        selected = [
            row for row in noise
            if math.isclose(float(row["noise_sigma"]), sigma)
        ]
        noise_blocks[f"{sigma:.2f}"] = {
            **condition_summary(selected),
            "paired_degradation": state_cluster_ci(
                selected, bootstrap_reps,
                bootstrap_seed + 10000 + index * 1000,
            ),
            "by_network": grouped_summary(selected, "network"),
            "by_regime": grouped_summary(selected, "operating_regime"),
            "by_load_bin": grouped_summary(selected, "load_bin"),
            "by_seed": grouped_summary(selected, "seed"),
        }
    clean = [row for row in operating if row["condition"] == "clean"]
    result = {
        "operating_shifts": operating_blocks,
        "measurement_noise": noise_blocks,
        "clean_by_load_bin": grouped_summary(clean, "load_bin"),
        "clean_by_network_size": grouped_summary(clean, "network_size"),
        "clean_by_der_regime": grouped_summary(clean, "operating_regime"),
    }
    low_noise = [
        row for row in noise if float(row["noise_sigma"]) <= 0.03 + 1e-12
    ]
    result["scientific_checks"] = {
        "operating_shift_true_feasible_rate_1": all(
            row["true_feasible"] for row in operating
        ),
        "operating_shift_constraint_violation_rate_0": not any(
            row["true_constraint_violation"] for row in operating
        ),
        "measurement_true_feasible_rate_ge_99pct": (
            mean(float(row["true_feasible"]) for row in noise) >= 0.99
        ),
        "measurement_constraint_violation_rate_0": not any(
            row["true_constraint_violation"] for row in noise
        ),
        "low_noise_mean_regret_degradation_le_0p05": (
            mean(float(row["regret_degradation"]) for row in low_noise)
            <= 0.05
        ),
        "all_three_networks_present": len({
            row["network"] for row in records
        }) == 3,
        "all_three_regimes_present": {
            row["operating_regime"] for row in records
        } == set(REGIMES),
        "all_three_load_bins_present": {
            row["load_bin"] for row in records
        } == set(LOAD_BINS),
    }
    result["robustness_gate_pass"] = all(
        result["scientific_checks"].values()
    )
    return result
