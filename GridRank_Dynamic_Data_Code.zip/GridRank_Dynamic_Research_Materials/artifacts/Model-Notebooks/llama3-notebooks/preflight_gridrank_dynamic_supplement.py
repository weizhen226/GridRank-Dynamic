"""Check inputs for GridRank dynamic supplement."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import gridrank_dynamic_supplement as supplement
import preflight_gridrank_feedback as runtime
from gridrank_runtime_compat import runtime_compatibility


SCHEMA = "gridrank-dynamic-supplement-preflight-v1"
EXPERIMENT_ID = "gridrank-dynamic-safety-ranking-regime-efficiency-v1"
HERE = Path(__file__).resolve().parent
CODE_FILES = (
    "gridrank_dynamic_supplement.py",
    "preflight_gridrank_dynamic_supplement.py",
    "eval_gridrank_dynamic_supplement_cached.py",
    "benchmark_gridrank_dynamic_supplement.py",
    "aggregate_gridrank_dynamic_supplement.py",
    "verify_gridrank_dynamic_supplement.py",
    "verify_gridrank_dynamic_supplement_dependencies.py",
    "run_gridrank_dynamic_supplement.sh",
    "../../docs/GRIDRANK_DYNAMIC_SUPPLEMENT_PROTOCOL.md",
)


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--cross_preflight", required=True)
    parser.add_argument("--cross_gate", required=True)
    parser.add_argument("--cross_records", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--benchmark_rows", type=int, default=32)
    parser.add_argument("--warmup_rows", type=int, default=1)
    parser.add_argument("--latency_seed", type=int, default=42)
    parser.add_argument("--bootstrap_reps", type=int, default=10000)
    parser.add_argument("--bootstrap_seed", type=int, default=20260908)
    parser.add_argument("--verify", action="store_true")
    return parser.parse_args()


def artifact(path):
    value = Path(path).resolve()
    if not value.is_file():
        raise FileNotFoundError(value)
    return {
        "path": str(value),
        "sha256": supplement.file_sha256(value),
        "size": value.stat().st_size,
    }


def code_hashes():
    missing = [
        name for name in CODE_FILES if not (HERE / name).resolve().is_file()
    ]
    if missing:
        raise FileNotFoundError(f"missing supplement code: {missing}")
    return {
        name: supplement.file_sha256((HERE / name).resolve())
        for name in CODE_FILES
    }


def locked_code_current(values):
    return all(
        (HERE / name).resolve().is_file()
        and supplement.file_sha256((HERE / name).resolve()) == digest
        for name, digest in values.items()
    )


def directory_current(manifest):
    root = Path(manifest["path"])
    if not root.is_dir():
        return False
    current = {}
    for item in sorted(value for value in root.rglob("*") if value.is_file()):
        relative = item.relative_to(root).as_posix()
        record = {"size": item.stat().st_size}
        expected = manifest["files"].get(relative, {})
        if "sha256" in expected:
            record["sha256"] = supplement.file_sha256(item)
        current[relative] = record
    return current == manifest["files"]


def schedule(args):
    return {
        "benchmark_rows": args.benchmark_rows,
        "warmup_rows": args.warmup_rows,
        "latency_seed": args.latency_seed,
        "bootstrap_reps": args.bootstrap_reps,
        "bootstrap_seed": args.bootstrap_seed,
        "llm_max_length": 1024,
        "primitive_batch_size": 4,
        "scenario_seed": 20260907,
        "candidate_count": 32,
        "topk": 1,
    }


def create(args):
    output = Path(args.output)
    if output.exists():
        raise FileExistsError(f"refusing to overwrite preflight: {output}")
    cross = json.load(open(args.cross_preflight, encoding="utf-8"))
    gate = json.load(open(args.cross_gate, encoding="utf-8"))
    records = supplement.read_jsonl(args.cross_records)
    rows = supplement.read_jsonl(cross["artifacts"]["pairs"]["path"])
    selected_methods = {row["method"] for row in records}
    requested = {
        "fixed_loss_lindistflow",
        "frozen_rule_parser_lindistflow",
        supplement.TFIDF,
        "oracle_structured_lindistflow",
        "full_ac_oracle",
        *{
            f"{supplement.LLM_PREFIX}_s{seed}"
            for seed in supplement.SEEDS
        },
    }
    artifacts = {
        "cross_preflight": artifact(args.cross_preflight),
        "cross_gate": artifact(args.cross_gate),
        "cross_records": artifact(args.cross_records),
        **{
            key: artifact(value["path"])
            for key, value in cross["artifacts"].items()
        },
    }
    checks = {
        "cross_preflight_pass": cross.get("preflight_pass") is True,
        "cross_evaluation_pass": gate.get("evaluation_pass") is True,
        "cross_gate_bound_to_preflight": (
            gate.get("preflight_sha256")
            == artifacts["cross_preflight"]["sha256"]
        ),
        "cross_records_bound_to_gate": (
            gate.get("records", {}).get("sha256")
            == artifacts["cross_records"]["sha256"]
        ),
        "rows_192": len(rows) == 192,
        "records_nonempty": bool(records),
        "requested_methods_present": requested.issubset(selected_methods),
        "candidate_count_32": all(
            len(row["candidates"]) == 32 for row in rows
        ),
        "benchmark_rows_in_range": 8 <= args.benchmark_rows <= 96,
        "warmup_rows_positive": args.warmup_rows >= 1,
        "latency_seed_42": args.latency_seed == 42,
        "bootstrap_reps_10000": args.bootstrap_reps == 10000,
        "cross_code_current": locked_code_current(cross["code_sha256"]),
    }
    result = {
        "msg": "GridRank dynamic supplement locked preflight",
        "schema": SCHEMA,
        "experiment_id": EXPERIMENT_ID,
        "preflight_pass": all(checks.values()),
        "training_performed": False,
        "cached_analysis_performed": False,
        "live_latency_performed": False,
        "artifacts": artifacts,
        "llm_adapter": cross["llm_adapters"][str(args.latency_seed)],
        "base_model": cross["base_model"],
        "training_runtime": runtime.training_runtime(),
        "physics_runtime": runtime.physics_runtime(
            cross["physics_runtime"]["executable"]
        ),
        "schedule": schedule(args),
        "code_sha256": code_hashes(),
        "upstream_code_sha256": cross["code_sha256"],
        "checks": checks,
        "failed_checks": [
            key for key, value in checks.items() if not value
        ],
    }
    output.write_text(
        json.dumps(result, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    print(json.dumps({
        "msg": result["msg"],
        "preflight_pass": result["preflight_pass"],
        "schedule": result["schedule"],
        "failed_checks": result["failed_checks"],
    }, ensure_ascii=False))
    if not result["preflight_pass"]:
        raise SystemExit(2)
    return result


def verify_manifest(path):
    locked = json.load(open(path, encoding="utf-8"))
    current_training = runtime.training_runtime()
    current_physics = runtime.physics_runtime(
        locked["physics_runtime"]["executable"]
    )
    checks = {
        "schema": locked.get("schema") == SCHEMA,
        "experiment_id": locked.get("experiment_id") == EXPERIMENT_ID,
        "preflight_pass": locked.get("preflight_pass") is True,
        "artifacts_current": all(
            supplement.file_sha256(value["path"]) == value["sha256"]
            for value in locked["artifacts"].values()
        ),
        "llm_adapter_current": directory_current(locked["llm_adapter"]),
        "base_model_current": directory_current(locked["base_model"]),
        "training_runtime_compatible": runtime_compatibility(
            locked["training_runtime"], current_training
        )["compatible"],
        "physics_runtime_compatible": runtime_compatibility(
            locked["physics_runtime"], current_physics
        )["compatible"],
        "code_current": code_hashes() == locked["code_sha256"],
        "upstream_code_current": locked_code_current(
            locked["upstream_code_sha256"]
        ),
    }
    result = {
        "msg": "GridRank dynamic supplement runtime verification",
        "checks": checks,
        "verification_pass": all(checks.values()),
    }
    print(json.dumps(result, ensure_ascii=False))
    if not result["verification_pass"]:
        raise SystemExit(2)
    return locked


def main():
    args = parse_args()
    verify_manifest(args.output) if args.verify else create(args)


if __name__ == "__main__":
    main()
