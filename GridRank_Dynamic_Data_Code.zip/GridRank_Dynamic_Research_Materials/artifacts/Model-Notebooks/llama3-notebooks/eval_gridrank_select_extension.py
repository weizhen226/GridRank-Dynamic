"""Evaluate GridRank select extension."""

from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
from types import SimpleNamespace

from aggregate_gridrank_select_confirm import (
    SEEDS,
    _bootstrap,
    _two_way_bootstrap,
    random_top3_baseline,
)
from build_gridrank_select import file_sha256
import preflight_gridrank_select_extension as preflight
import train_gridrank_select as base


SCHEMA = "gridrank-select-extension-gate-v1"


def _json(path):
    with open(path, encoding="utf-8") as handle:
        return json.load(handle)


def _specs(values, label):
    output = {}
    for spec in values:
        seed, raw = spec.split("=", 1)
        seed = int(seed)
        if seed in output:
            raise ValueError(f"duplicate {label}: {seed}")
        path = Path(raw).resolve()
        if not path.exists():
            raise FileNotFoundError(path)
        output[seed] = path
    if set(output) != set(SEEDS):
        raise ValueError(f"{label} requires seeds {SEEDS}")
    return output


def _adapter_hash(path):
    root = Path(path)
    return {
        "adapter_config_json": file_sha256(root / "adapter_config.json"),
        "adapter_model_safetensors": file_sha256(root / "adapter_model.safetensors"),
    }


def _evaluate_adapter(model, tokenizer, rows, args, adapter):
    import torch

    records = []
    with torch.inference_mode():
        for row in rows:
            scores = base.score_row(
                model, tokenizer, row, args, False, adapter=adapter
            ).detach().float().cpu()
            records.append(base.record_from_scores(row, scores, args.topk))
    return records


def _state_evidence(before, after):
    if [row["instance_id"] for row in before] != [row["instance_id"] for row in after]:
        raise RuntimeError("extension paired order changed")
    return [
        {
            "instance_id": old["instance_id"],
            "network": old["network"],
            "load_id": old["load_id"],
            "physical_state_sha256": old["physical_state_sha256"],
            "sft_safe_regret": old["safe_regret"],
            "distilled_safe_regret": new["safe_regret"],
            "safe_regret_improvement": old["safe_regret"] - new["safe_regret"],
            "sft_safe_action": old["safe_action"],
            "distilled_safe_action": new["safe_action"],
            "sft_safe_feasible": old["safe_feasible"],
            "distilled_safe_feasible": new["safe_feasible"],
        }
        for old, new in zip(before, after)
    ]


def _random_map(rows):
    return {
        row["physical_state_sha256"]: float(row["expected_safe_regret"])
        for row in random_top3_baseline(rows)
    }


def _analysis(matrix, sft_map, noop_map, random_map, metadata, feasible, reps, seed):
    states = sorted(metadata)
    if set(sft_map) != set(states) or set(noop_map) != set(states) \
            or set(random_map) != set(states):
        raise ValueError("analysis baseline state set mismatch")
    if any(set(matrix[item]) != set(states) for item in SEEDS):
        raise ValueError("analysis seed state set mismatch")
    per_seed = []
    for item in SEEDS:
        values = [matrix[item][state] for state in states]
        per_seed.append({
            "seed": item,
            "mean_improvement": sum(values) / len(values),
            "ci95": _bootstrap(values, reps, seed + item),
            "states_better": sum(value > 1e-12 for value in values),
            "states_worse": sum(value < -1e-12 for value in values),
            "states_tied": sum(abs(value) <= 1e-12 for value in values),
            "safe_feasible_rate": feasible[item],
        })
    state_means = {
        state: sum(matrix[item][state] for item in SEEDS) / len(SEEDS)
        for state in states
    }
    pooled = sum(state_means.values()) / len(state_means)
    state_ci = _bootstrap(list(state_means.values()), reps, seed)
    two_way = _two_way_bootstrap(matrix, reps, seed + 1)
    by_network = {}
    for offset, network in enumerate(("33", "69")):
        selected = [state for state in states if metadata[state]["network"] == network]
        values = [state_means[state] for state in selected]
        by_network[network] = {
            "n_states": len(values),
            "pooled_mean_improvement": sum(values) / len(values),
            "state_bootstrap_ci95": _bootstrap(values, reps, seed + 10 + offset),
            "positive_states": sum(value > 1e-12 for value in values),
            "negative_states": sum(value < -1e-12 for value in values),
        }
    sft_mean = sum(sft_map.values()) / len(states)
    distilled_mean = sft_mean - pooled
    noop_mean = sum(noop_map.values()) / len(states)
    random_mean = sum(random_map.values()) / len(states)
    baselines = {
        "sft_safe_regret_mean": sft_mean,
        "distilled_three_seed_safe_regret_mean": distilled_mean,
        "always_noop_safe_regret_mean": noop_mean,
        "random_top3_plus_anchor_expected_safe_regret_mean": random_mean,
        "random_top3_exact_subsets_per_state": 455,
        "delivered_reduction_pct": {
            "sft": noop_mean - sft_mean,
            "distilled": noop_mean - distilled_mean,
            "random_top3": noop_mean - random_mean,
        },
    }
    checks = {
        "at_least_2_of_3_positive_seeds": sum(
            row["mean_improvement"] > 0.0 for row in per_seed
        ) >= 2,
        "pooled_state_ci_lower_gt_zero": state_ci[0] > 0.0,
        "two_way_seed_state_ci_lower_gt_zero": two_way[0] > 0.0,
        "both_networks_positive": all(
            row["pooled_mean_improvement"] > 0.0 for row in by_network.values()
        ),
        "distilled_beats_random_equal_budget": distilled_mean < random_mean,
        "distilled_beats_always_noop": distilled_mean < noop_mean,
        "all_seed_feasibility_100pct": all(feasible[item] == 1.0 for item in SEEDS),
    }
    return {
        "n_states": len(states),
        "per_seed": per_seed,
        "positive_seed_count": sum(row["mean_improvement"] > 0.0 for row in per_seed),
        "pooled_state_mean_improvement": pooled,
        "pooled_state_bootstrap_ci95": state_ci,
        "two_way_seed_state_bootstrap_ci95": two_way,
        "by_network": by_network,
        "baselines": baselines,
        "checks": checks,
        "gate_pass": all(checks.values()),
    }


def _prior_evidence(gate_paths):
    matrix, sft_map, metadata, feasible = {}, None, {}, {}
    for seed in SEEDS:
        gate = _json(gate_paths[seed])
        rows = gate["paired"]["distilled_vs_sft"]["state_rows"]
        current_sft = {row["physical_state_sha256"]: float(row["sft_safe_regret"])
                       for row in rows}
        if sft_map is None:
            sft_map = current_sft
        elif current_sft != sft_map:
            raise RuntimeError("original SFT evidence is not seed invariant")
        matrix[seed] = {
            row["physical_state_sha256"]: float(row["safe_regret_improvement"])
            for row in rows
        }
        feasible[seed] = float(gate["summaries"]["distilled"]["safe_feasible_rate"])
        for row in rows:
            metadata.setdefault(row["physical_state_sha256"], {
                "network": str(row["network"]), "load_id": row["load_id"],
                "instance_id": row["instance_id"],
            })
    return matrix, sft_map, metadata, feasible


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--test_jsonl", required=True)
    parser.add_argument("--original_test_jsonl", required=True)
    parser.add_argument("--original_gate", action="append", required=True)
    parser.add_argument("--seed_adapter", action="append", required=True)
    parser.add_argument("--preflight_manifest", required=True)
    parser.add_argument("--sft_adapter", required=True)
    parser.add_argument("--base_model", required=True)
    parser.add_argument("--physics_python", required=True)
    parser.add_argument("--physics_timeout_s", type=float, default=60.0)
    parser.add_argument("--max_length", type=int, default=1024)
    parser.add_argument("--candidate_batch_size", type=int, default=4)
    parser.add_argument("--topk", type=int, default=3)
    parser.add_argument("--bootstrap_reps", type=int, default=10000)
    parser.add_argument("--bootstrap_seed", type=int, default=20260726)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    output = Path(args.output)
    if output.exists():
        raise FileExistsError(f"refusing to overwrite {output}")
    if args.topk != 3 or args.bootstrap_reps != 10000 or args.bootstrap_seed != 20260726:
        raise ValueError("extension evaluation schedule drift")
    gate_paths = _specs(args.original_gate, "original_gate")
    adapter_paths = _specs(args.seed_adapter, "seed_adapter")
    verify_args = SimpleNamespace(
        output=args.preflight_manifest, base_model=args.base_model,
        physics_python=args.physics_python, bootstrap_reps=args.bootstrap_reps,
    )
    preflight.verify(verify_args)
    manifest = _json(args.preflight_manifest)
    if file_sha256(args.test_jsonl) != manifest["artifacts"]["select_test"]["sha256"]:
        raise RuntimeError("extension test artifact differs from preflight")
    if file_sha256(args.original_test_jsonl) \
            != manifest["artifacts"]["original_test"]["sha256"]:
        raise RuntimeError("original test artifact differs from preflight")
    if Path(args.sft_adapter).resolve() != Path(manifest["sft_adapter"]["path"]):
        raise RuntimeError("SFT adapter path differs from preflight")
    for seed in SEEDS:
        locked_adapter = manifest["frozen_adapters"][str(seed)]
        locked_gate = manifest["original_gates"][str(seed)]
        if Path(adapter_paths[seed]).resolve() != Path(locked_adapter["path"]):
            raise RuntimeError(f"seed {seed} adapter path differs from preflight")
        if Path(gate_paths[seed]).resolve() != Path(locked_gate["path"]):
            raise RuntimeError(f"seed {seed} gate path differs from preflight")
    import torch
    import grpo_train as training

    if not torch.cuda.is_available():
        raise RuntimeError("extension LLM evaluation requires CUDA")

    extension_rows = base.load_rows(args.test_jsonl, "test", args.topk)
    original_rows = base.load_rows(args.original_test_jsonl, "test", args.topk)
    if len(extension_rows) != 64 or len(original_rows) != 64:
        raise RuntimeError("extension/original state count mismatch")
    if {row["physical_state_sha256"] for row in extension_rows}.intersection(
        {row["physical_state_sha256"] for row in original_rows}
    ):
        raise RuntimeError("extension overlaps original confirmation")

    before_hashes = {seed: _adapter_hash(path) for seed, path in adapter_paths.items()}
    model_args = SimpleNamespace(
        base_model=args.base_model, resume_adapter_path=args.sft_adapter,
        gradient_checkpointing=0,
    )
    model, tokenizer = training.build_model_and_tokenizer(model_args)
    tokenizer.pad_token = tokenizer.eos_token
    model.config.pad_token_id = tokenizer.pad_token_id
    for seed in SEEDS:
        model.load_adapter(
            str(adapter_paths[seed]), adapter_name=f"seed_{seed}", is_trainable=False
        )
    for parameter in model.parameters():
        parameter.requires_grad_(False)
    model.eval()

    sft_records = _evaluate_adapter(model, tokenizer, extension_rows, args, "default")
    seed_records, live = {}, {}
    for seed in SEEDS:
        records = _evaluate_adapter(model, tokenizer, extension_rows, args, f"seed_{seed}")
        seed_records[seed] = records
        live[seed] = base.live_topk_replay(extension_rows, records, args)
    gradients_materialized = sum(
        parameter.grad is not None for parameter in model.parameters()
    )
    after_hashes = {seed: _adapter_hash(path) for seed, path in adapter_paths.items()}

    extension_matrix, extension_metadata, extension_feasible = {}, {}, {}
    extension_sft = {
        row["physical_state_sha256"]: float(row["safe_regret"]) for row in sft_records
    }
    extension_noop = {
        row["physical_state_sha256"]: float(row["always_noop_safe_regret"])
        for row in sft_records
    }
    evidence = {}
    for seed in SEEDS:
        rows = _state_evidence(sft_records, seed_records[seed])
        evidence[str(seed)] = rows
        extension_matrix[seed] = {
            row["physical_state_sha256"]: float(row["safe_regret_improvement"])
            for row in rows
        }
        extension_feasible[seed] = base.summarise(seed_records[seed])["safe_feasible_rate"]
        for row in rows:
            extension_metadata.setdefault(row["physical_state_sha256"], {
                "network": str(row["network"]), "load_id": row["load_id"],
                "instance_id": row["instance_id"],
            })
    extension = _analysis(
        extension_matrix, extension_sft, extension_noop, _random_map(extension_rows),
        extension_metadata, extension_feasible, args.bootstrap_reps, args.bootstrap_seed,
    )

    prior_matrix, prior_sft, prior_metadata, prior_feasible = _prior_evidence(gate_paths)
    prior_noop = {
        row["physical_state_sha256"]: float(row["always_noop_safe_regret"])
        for row in [
            base.record_from_scores(
                source, [0.0] * len(source["candidates"]), args.topk
            )
            for source in original_rows
        ]
    }
    combined_matrix = {
        seed: {**prior_matrix[seed], **extension_matrix[seed]} for seed in SEEDS
    }
    combined_sft = {**prior_sft, **extension_sft}
    combined_noop = {**prior_noop, **extension_noop}
    combined_random = {**_random_map(original_rows), **_random_map(extension_rows)}
    combined_metadata = {**prior_metadata, **extension_metadata}
    combined_feasible = {
        seed: (
            prior_feasible[seed] * len(prior_metadata)
            + extension_feasible[seed] * len(extension_metadata)
        ) / len(combined_metadata)
        for seed in SEEDS
    }
    combined = _analysis(
        combined_matrix, combined_sft, combined_noop, combined_random,
        combined_metadata, combined_feasible, args.bootstrap_reps, args.bootstrap_seed + 100,
    )

    live_checks = {
        str(seed): {
            "valid_rate_100pct": live[seed]["summary"]["valid_rate"] == 1.0,
            "cache_match_100pct": live[seed]["summary"]["cache_labels_match_rate"] == 1.0,
            "safe_action_match_100pct": live[seed]["summary"]["matches_cached_gate_rate"] == 1.0,
            "selected_feasible_100pct": live[seed]["summary"]["selected_feasible_rate"] == 1.0,
            "noop_never_ranked": live[seed]["summary"]["noop_ranked_rows"] == 0,
        }
        for seed in SEEDS
    }
    mechanism_checks = {
        "evaluation_only_no_optimizer_or_backward": True,
        "no_gradients_materialized": gradients_materialized == 0,
        "adapter_files_unchanged": before_hashes == after_hashes,
        "three_distinct_adapter_weights": len({
            value["adapter_model_safetensors"] for value in after_hashes.values()
        }) == 3,
        "all_live_checks": all(
            all(values.values()) for values in live_checks.values()
        ),
    }
    replication_pass = extension["gate_pass"] and all(mechanism_checks.values())
    result = {
        "msg": "GridRank-Select frozen-adapter unused-test extension gate",
        "schema": SCHEMA,
        "extension_id": preflight.EXTENSION_ID,
        "training_performed": False,
        "parameter_updates": 0,
        "preflight_sha256": file_sha256(args.preflight_manifest),
        "adapter_sha256_before": before_hashes,
        "adapter_sha256_after": after_hashes,
        "extension_only_primary": extension,
        "combined_128_state_secondary": combined,
        "extension_state_evidence": evidence,
        "live_replay": {str(seed): live[seed] for seed in SEEDS},
        "live_checks": live_checks,
        "mechanism_checks": mechanism_checks,
        "extension_replication_gate_pass": replication_pass,
        "scoped_replication_claim_authorized": replication_pass,
        "claim_scope": (
            "three frozen physics-distilled LLM adapters improve equal-budget safe "
            "regret over frozen SFT on 64 unused 33/69-bus test states"
        ),
    }
    output.parent.mkdir(parents=True, exist_ok=True)
    tmp = output.with_name(output.name + ".tmp")
    tmp.write_text(json.dumps(result, indent=2, ensure_ascii=False), encoding="utf-8")
    os.replace(tmp, output)
    print(json.dumps({
        "msg": result["msg"],
        "schema": result["schema"],
        "training_performed": False,
        "parameter_updates": 0,
        "extension_only_primary": extension,
        "combined_128_state_secondary": combined,
        "mechanism_checks": mechanism_checks,
        "extension_replication_gate_pass": replication_pass,
        "scoped_replication_claim_authorized": replication_pass,
        "full_gate_path": str(output.resolve()),
    }, ensure_ascii=False))
    if not replication_pass:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
