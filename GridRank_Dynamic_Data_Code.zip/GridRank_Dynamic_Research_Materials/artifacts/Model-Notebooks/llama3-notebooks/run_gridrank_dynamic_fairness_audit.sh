#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

TAG="${TAG:-gridrank_dynamic_fairness_audit_v1_20260901}"
REFERENCE_TAG="${REFERENCE_TAG:-gridrank_dynamic_confirmation_v1_20260829_hotfix1}"
PAIR_TAG="${PAIR_TAG:-gridrank_instruction_pairs_v2_20260809}"
TFIDF_OUT="${TFIDF_OUT:-${TAG}_factorized_tfidf.json}"
STATE_OUT="${STATE_OUT:-${TAG}_state_clusters.json}"

ORIGINAL_TRAIN="${ORIGINAL_TRAIN:-${PAIR_TAG}_train.jsonl}"
FRESH_PAIRS="${FRESH_PAIRS:-${REFERENCE_TAG}_pairs.jsonl}"
FRESH_SUMMARY="${FRESH_SUMMARY:-${REFERENCE_TAG}_summary.json}"
CONFIRM_GATE="${CONFIRM_GATE:-output_${REFERENCE_TAG}/gridrank_dynamic_confirmation_gate.json}"
CONFIRM_RECORDS="${CONFIRM_RECORDS:-output_${REFERENCE_TAG}/gridrank_dynamic_confirmation_records.jsonl}"

for path in "$ORIGINAL_TRAIN" "$FRESH_PAIRS" "$FRESH_SUMMARY" \
  "$CONFIRM_GATE" "$CONFIRM_RECORDS"; do
  test -f "$path" || { echo "missing fairness-audit input: $path" >&2; exit 2; }
done
test ! -e "$TFIDF_OUT" || { echo "refusing to overwrite: $TFIDF_OUT" >&2; exit 2; }
test ! -e "$STATE_OUT" || { echo "refusing to overwrite: $STATE_OUT" >&2; exit 2; }

echo "=== 1/3 REPLAY AND AUDIT FACTORIZED TF-IDF BASELINE ==="
python -B audit_gridrank_dynamic_factorized_tfidf.py \
  --original_train "$ORIGINAL_TRAIN" \
  --fresh_pairs "$FRESH_PAIRS" \
  --confirmation_records "$CONFIRM_RECORDS" \
  --output "$TFIDF_OUT"

echo "=== 2/3 PHYSICAL-STATE AND NESTED STATE/PAIR BOOTSTRAP ==="
python -B analyze_gridrank_dynamic_state_clusters.py \
  --fresh_summary "$FRESH_SUMMARY" \
  --confirmation_gate "$CONFIRM_GATE" \
  --confirmation_records "$CONFIRM_RECORDS" \
  --factorized_tfidf_audit "$TFIDF_OUT" \
  --bootstrap_reps 10000 --bootstrap_seed 20260901 \
  --output "$STATE_OUT"

echo "=== 3/3 VERIFY EXACT CACHED RECOMPUTATION ==="
python -B verify_gridrank_dynamic_state_clusters.py --result "$STATE_OUT"
echo "=== GRIDRANK DYNAMIC FAIRNESS/STATISTICAL AUDIT COMPLETE ==="
