"""Aggregate GridRank dynamic supplement."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import gridrank_dynamic_supplement as supplement
import preflight_gridrank_dynamic_supplement as preflight


SCHEMA = "gridrank-dynamic-supplement-gate-v1"


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--preflight_manifest", required=True)
    parser.add_argument("--cached_result", required=True)
    parser.add_argument("--latency_result", required=True)
    parser.add_argument("--output", required=True)
    return parser.parse_args()


def artifact(path):
    value = Path(path).resolve()
    return {
        "path": str(value),
        "sha256": supplement.file_sha256(value),
        "size": value.stat().st_size,
    }


def without_rows(value):
    if isinstance(value, dict):
        return {
            key: without_rows(item)
            for key, item in value.items()
            if key != "rows"
        }
    if isinstance(value, list):
        return [without_rows(item) for item in value]
    return value


def main():
    args = parse_args()
    output = Path(args.output)
    if output.exists():
        raise FileExistsError(f"refusing to overwrite supplement gate: {output}")
    locked = preflight.verify_manifest(args.preflight_manifest)
    cached = json.load(open(args.cached_result, encoding="utf-8"))
    latency = json.load(open(args.latency_result, encoding="utf-8"))
    schedule = locked["schedule"]
    safety = cached["safety_and_maintenance_mask"]["pooled_three_seed"]
    ranking = cached["matched_ranking_controls"]
    regimes = cached["simbench_operating_regimes"]
    method_summaries = latency["method_summaries"]

    checks = {
        "cached_schema": (
            cached.get("schema") == supplement.SCHEMA
            and cached.get("analysis_pass") is True
        ),
        "latency_schema": (
            latency.get("schema")
            == "gridrank-dynamic-supplement-latency-v1"
            and latency.get("benchmark_pass") is True
        ),
        "bound_to_preflight": (
            latency.get("preflight_sha256")
            == supplement.file_sha256(args.preflight_manifest)
        ),
        "no_frozen_model_retraining": (
            cached.get("training_performed") is False
            and latency.get("frozen_model_training_performed") is False
            and latency.get("sealed_test_rows_used_for_fit") is False
        ),
        "cached_no_power_flow": cached.get("power_flow_calls") == 0,
        "final_feasibility_100pct": (
            safety["all"]["deployed_feasible_rate"] == 1.0
        ),
        "final_constraint_violation_zero": (
            safety["all"]["deployed_constraint_violation_rate"] == 0.0
        ),
        "safety_gate_decomposition_present": (
            "pre_gate_unsafe_rate" in safety["all"]
            and "gate_rejected_top1_rate" in safety["all"]
            and "deployed_no_op_rate" in safety["all"]
        ),
        "maintenance_counterfactual_present": (
            "mask_prevents_forbidden_top1_rate" in safety["maintenance_rows"]
            and "mask_off_direct_constraint_violation_rate"
            in safety["maintenance_rows"]
        ),
        "equal_budget_rankers_present": (
            set(ranking["all"])
            == {
                "lindistflow",
                "fixed_canonical",
                "uniform_random_top1_exact",
            }
        ),
        "three_regimes_present": (
            set(regimes["by_regime"]) == set(supplement.REGIMES)
            and sum(regimes["unique_state_regime_mix"].values())
            == regimes["unique_physical_states"]
        ),
        "latency_rows_exact": (
            latency["benchmark_rows"] == schedule["benchmark_rows"]
        ),
        "four_efficiency_interfaces": set(method_summaries) == {
            "physics_aligned_factorized_llm_s42",
            "factorized_tfidf_withheld",
            "frozen_rule_parser_lindistflow",
            "fixed_loss_lindistflow",
        },
        "live_cache_replay_exact": all(
            value["live_cache_match_rate"] == 1.0
            for value in method_summaries.values()
        ),
        "exact_live_call_accounting": (
            latency["power_flow_calls"]["measurement"][
                "backend_power_flows"
            ]
            == 2 * schedule["benchmark_rows"] * len(method_summaries)
        ),
    }
    result = {
        "msg": "GridRank dynamic safety/ranking/regime/efficiency supplement",
        "schema": SCHEMA,
        "experiment_id": preflight.EXPERIMENT_ID,
        "preflight_sha256": supplement.file_sha256(args.preflight_manifest),
        "artifacts": {
            "preflight": artifact(args.preflight_manifest),
            "cached": artifact(args.cached_result),
            "latency": artifact(args.latency_result),
        },
        "frozen_model_training_performed": False,
        "baseline_tfidf_fit_performed": True,
        "sealed_test_rows_used_for_fit": False,
        "supplement_evidence_ready": all(checks.values()),
        "safety_and_maintenance_mask": without_rows(
            cached["safety_and_maintenance_mask"]
        ),
        "matched_ranking_controls": without_rows(
            cached["matched_ranking_controls"]
        ),
        "simbench_operating_regimes": regimes,
        "efficiency": {
            "cold_start_excluded_from_steady_state": latency[
                "cold_start_excluded_from_steady_state"
            ],
            "model_cold_load_ms": latency["model_cold_load_ms"],
            "tfidf_train_only_fit_ms": latency["tfidf_train_only_fit_ms"],
            "gpu_memory": latency["gpu_memory"],
            "benchmark_mix": latency["benchmark_mix"],
            "method_summaries": method_summaries,
            "power_flow_calls": latency["power_flow_calls"],
        },
        "interpretation_boundary": (
            "Gate-off and mask-off-direct values are offline diagnostics only. "
            "No infeasible or maintenance-prohibited action is authorized for "
            "execution. Latency is hardware-specific and reports steady-state "
            "P50/P95 separately from model cold start."
        ),
        "checks": checks,
        "failed_checks": [
            key for key, value in checks.items() if not value
        ],
    }
    output.write_text(
        json.dumps(result, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    print(json.dumps({
        "msg": result["msg"],
        "supplement_evidence_ready": result["supplement_evidence_ready"],
        "safety_all": result["safety_and_maintenance_mask"][
            "pooled_three_seed"
        ]["all"],
        "ranking_primary": result["matched_ranking_controls"][
            "primary_withheld_composition"
        ],
        "regime_mix": result["simbench_operating_regimes"][
            "unique_state_regime_mix"
        ],
        "efficiency": result["efficiency"],
        "failed_checks": result["failed_checks"],
    }, ensure_ascii=False))
    if not result["supplement_evidence_ready"]:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
