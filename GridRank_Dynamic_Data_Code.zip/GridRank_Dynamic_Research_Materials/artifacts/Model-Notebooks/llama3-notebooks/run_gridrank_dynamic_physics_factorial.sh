#!/usr/bin/env bash
set -euo pipefail

CURRENT_STAGE="bootstrap"
on_exit() {
  local rc=$?
  trap - EXIT
  if (( rc != 0 )); then
    printf '{"msg":"GridRank dynamic physics-factorial failure","stage":"%s","exit_code":%d}\n' \
      "$CURRENT_STAGE" "$rc"
  fi
  exit "$rc"
}
trap on_exit EXIT

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"
export HF_HUB_OFFLINE=1
export TRANSFORMERS_OFFLINE=1
if [[ ! "${OMP_NUM_THREADS:-}" =~ ^[1-9][0-9]*$ ]]; then export OMP_NUM_THREADS=4; fi
export PYTORCH_CUDA_ALLOC_CONF="${PYTORCH_CUDA_ALLOC_CONF:-max_split_size_mb:64}"

PREFLIGHT_ONLY="${PREFLIGHT_ONLY:-1}"
case "$PREFLIGHT_ONLY" in 0|1) ;; *) echo "PREFLIGHT_ONLY must be 0 or 1" >&2; exit 2;; esac
if [[ "$PREFLIGHT_ONLY" == "1" ]]; then export CUDA_VISIBLE_DEVICES=""; fi

resolve_executable() {
  local requested="$1"
  if [[ "$requested" == */* ]]; then
    [[ -x "$requested" ]] && printf '%s\n' "$requested"
  else
    command -v -- "$requested"
  fi
}
TRAIN_PYTHON_BIN="$(resolve_executable "${TRAIN_PYTHON:-python}")" || exit 2

TAG="${TAG:-gridrank_dynamic_physics_factorial_v1_20260905}"
[[ "$TAG" =~ ^[A-Za-z0-9][A-Za-z0-9._-]*$ ]] || { echo "invalid TAG" >&2; exit 2; }
MODEL_PREFIX="${MODEL_PREFIX:-gridrank_dynamic_sftinit_factorized_v1_20260905}"
CONFIRM_PREFIX="${CONFIRM_PREFIX:-gridrank_dynamic_sftinit_confirmation_v1_20260905}"
PAIR_TAG="${PAIR_TAG:-gridrank_instruction_pairs_v2_20260809}"
BENCHMARK_TAG="${BENCHMARK_TAG:-gridrank_dynamic_benchmark_v1_20260826_hotfix1}"
JOINT_TAG="${JOINT_TAG:-gridrank_dynamic_policy_v1_20260827_hotfix2}"
FROZEN_CONFIRM_TAG="${FROZEN_CONFIRM_TAG:-gridrank_dynamic_confirmation_v1_20260829_hotfix1}"
GRID_NOPHYS_MODEL_PREFIX="${GRID_NOPHYS_MODEL_PREFIX:-gridrank_dynamic_no_physics_v1_20260902}"
GRID_NOPHYS_CONFIRM_PREFIX="${GRID_NOPHYS_CONFIRM_PREFIX:-gridrank_dynamic_no_physics_confirmation_v1_20260902}"

TRAIN_JSONL="${TRAIN_JSONL:-${PAIR_TAG}_train.jsonl}"
VALIDATION_JSONL="${VALIDATION_JSONL:-${PAIR_TAG}_validation.jsonl}"
PAIR_SUMMARY="${PAIR_SUMMARY:-${PAIR_TAG}_summary.json}"
BENCHMARK_MANIFEST="${BENCHMARK_MANIFEST:-${BENCHMARK_TAG}.preflight.json}"
JOINT_PREFLIGHT="${JOINT_PREFLIGHT:-${JOINT_TAG}.preflight.json}"
JOINT_GATE="${JOINT_GATE:-output_${JOINT_TAG}/gridrank_dynamic_policy_gate.json}"
SFT_ADAPTER="${SFT_ADAPTER:-output_gridintent_gate_33_69_v2_20260717/sft_only}"
BASE_MODEL="${BASE_MODEL:-../../Meta-Llama-3.1-8B-Instruct}"

FRESH_PAIRS="${FRESH_PAIRS:-${FROZEN_CONFIRM_TAG}_pairs.jsonl}"
FRESH_SUMMARY="${FRESH_SUMMARY:-${FROZEN_CONFIRM_TAG}_summary.json}"
FRESH_AUDIT="${FRESH_AUDIT:-${FROZEN_CONFIRM_TAG}_audit.json}"
REFERENCE_CONFIRM_PREFLIGHT="${REFERENCE_CONFIRM_PREFLIGHT:-${FROZEN_CONFIRM_TAG}.preflight.json}"
REFERENCE_CONFIRM_GATE="${REFERENCE_CONFIRM_GATE:-output_${FROZEN_CONFIRM_TAG}/gridrank_dynamic_confirmation_gate.json}"
AGGREGATE="${AGGREGATE:-${TAG}_aggregate.json}"

readonly MAX_LENGTH=512
readonly TRAIN_PRIMITIVE_BATCH_SIZE=1
readonly EPOCHS=4
readonly LEARNING_RATE=5e-6
readonly GRAD_ACCUM=4
readonly MAX_GRAD_NORM=1.0
readonly TARGET_TEMPERATURE=0.10
readonly LAMBDA_OBJECTIVE=0.5
readonly LAMBDA_CONSTRAINT=0.5
readonly LAMBDA_HARD=0.5
readonly HARD_MARGIN=0.5
readonly BETA_REFERENCE=0.01
readonly TRAIN_GRADIENT_CHECKPOINTING=1
readonly EVAL_PRIMITIVE_BATCH_SIZE=4
readonly TOPK=1
readonly EVAL_GRADIENT_CHECKPOINTING=0
readonly BOOTSTRAP_REPS=10000
readonly EVALUATION_SEED=20260829
readonly AGGREGATE_SEED=20260905

full_factor_tag() {
  case "$1" in
    42) printf '%s\n' "gridrank_dynamic_factorized_v1_20260828" ;;
    123|2025) printf '%s\n' "gridrank_dynamic_factorized_replication_v1_s${1}_20260830" ;;
    *) return 2 ;;
  esac
}

full_confirm_tag() {
  case "$1" in
    42) printf '%s\n' "$FROZEN_CONFIRM_TAG" ;;
    123|2025) printf '%s\n' "gridrank_dynamic_confirmation_replication_v1_s${1}_20260831" ;;
    *) return 2 ;;
  esac
}

sft_model_tag() {
  printf '%s\n' "${MODEL_PREFIX}_p${1}_s${2}"
}

sft_confirm_tag() {
  printf '%s\n' "${CONFIRM_PREFIX}_p${1}_s${2}"
}

for path in \
  "$TRAIN_JSONL" "$VALIDATION_JSONL" "$PAIR_SUMMARY" "$BENCHMARK_MANIFEST" \
  "$JOINT_PREFLIGHT" "$JOINT_GATE" "$FRESH_PAIRS" "$FRESH_SUMMARY" "$FRESH_AUDIT" \
  "$REFERENCE_CONFIRM_PREFLIGHT" "$REFERENCE_CONFIRM_GATE" \
  "$SFT_ADAPTER/adapter_config.json" "$SFT_ADAPTER/adapter_model.safetensors" \
  "$BASE_MODEL/config.json" "$BASE_MODEL/tokenizer_config.json" \
  preflight_gridrank_dynamic_physics_factorial.py \
  train_gridrank_dynamic_physics_factorial.py \
  verify_gridrank_dynamic_physics_factorial_model.py \
  preflight_gridrank_dynamic_physics_factorial_confirmation.py \
  eval_gridrank_dynamic_physics_factorial_confirmation.py \
  verify_gridrank_dynamic_physics_factorial_confirmation.py \
  aggregate_gridrank_dynamic_physics_factorial.py \
  verify_gridrank_dynamic_physics_factorial.py \
  verify_gridrank_dynamic_physics_factorial_dependencies.py \
  ../../docs/GRIDRANK_DYNAMIC_PHYSICS_FACTORIAL_PROTOCOL.md; do
  test -e "$path" || { echo "missing dynamic physics-factorial input: $path" >&2; exit 2; }
done

CURRENT_STAGE="dependency_regressions"
echo "=== 1/6 DEPENDENCY-LIGHT PHYSICS-SOURCE FACTORIAL CONTRACT ==="
"$TRAIN_PYTHON_BIN" -B verify_gridrank_dynamic_physics_factorial_dependencies.py

CURRENT_STAGE="prior_cell_inventory"
echo "=== 2/6 VERIFY TWO FROZEN GRIDRANK-INITIALIZED CELLS ==="
for seed in 42 123 2025; do
  full_factor="$(full_factor_tag "$seed")"
  full_confirm="$(full_confirm_tag "$seed")"
  for path in \
    "${full_factor}.preflight.json" \
    "output_${full_factor}/gridrank_dynamic_factorized_gate.json" \
    "${full_confirm}.preflight.json" \
    "output_${full_confirm}/gridrank_dynamic_confirmation_gate.json" \
    "output_${full_confirm}/gridrank_dynamic_confirmation_records.jsonl" \
    "${GRID_NOPHYS_MODEL_PREFIX}_s${seed}.preflight.json" \
    "output_${GRID_NOPHYS_MODEL_PREFIX}_s${seed}/gridrank_dynamic_factorized_gate.json" \
    "${GRID_NOPHYS_CONFIRM_PREFIX}_s${seed}.preflight.json" \
    "output_${GRID_NOPHYS_CONFIRM_PREFIX}_s${seed}/gridrank_dynamic_confirmation_gate.json" \
    "output_${GRID_NOPHYS_CONFIRM_PREFIX}_s${seed}/gridrank_dynamic_confirmation_records.jsonl"; do
    test -e "$path" || { echo "missing frozen factorial cell input: $path" >&2; exit 2; }
  done
done

for physics in 1 0; do
  for seed in 42 123 2025; do
    CURRENT_STAGE="sft_cell_preflight_p${physics}_seed_${seed}"
    full_factor="$(full_factor_tag "$seed")"
    model_tag="$(sft_model_tag "$physics" "$seed")"
    model_preflight="${model_tag}.preflight.json"
    LAMBDA_PHYSICS="${physics}.0"
    TRAIN_ARGS=(
      --train_jsonl "$TRAIN_JSONL"
      --validation_jsonl "$VALIDATION_JSONL"
      --pair_summary "$PAIR_SUMMARY"
      --benchmark_manifest "$BENCHMARK_MANIFEST"
      --joint_preflight "$JOINT_PREFLIGHT"
      --joint_gate "$JOINT_GATE"
      --resume_adapter_path "$SFT_ADAPTER"
      --sft_adapter_path "$SFT_ADAPTER"
      --base_model "$BASE_MODEL"
      --max_length "$MAX_LENGTH"
      --primitive_batch_size "$TRAIN_PRIMITIVE_BATCH_SIZE"
      --epochs "$EPOCHS"
      --learning_rate "$LEARNING_RATE"
      --grad_accum "$GRAD_ACCUM"
      --max_grad_norm "$MAX_GRAD_NORM"
      --target_temperature "$TARGET_TEMPERATURE"
      --lambda_objective "$LAMBDA_OBJECTIVE"
      --lambda_constraint "$LAMBDA_CONSTRAINT"
      --lambda_physics "$LAMBDA_PHYSICS"
      --lambda_hard "$LAMBDA_HARD"
      --hard_margin "$HARD_MARGIN"
      --beta_reference "$BETA_REFERENCE"
      --seed "$seed"
      --gradient_checkpointing "$TRAIN_GRADIENT_CHECKPOINTING"
      --bootstrap_reps "$BOOTSTRAP_REPS"
    )
    echo "=== 3/6 LOCK FROZEN-SFT CELL P=$physics SEED=$seed ==="
    "$TRAIN_PYTHON_BIN" -B preflight_gridrank_dynamic_physics_factorial.py \
      "${TRAIN_ARGS[@]}" \
      --reference_gridrank_preflight "${full_factor}.preflight.json" \
      --reference_gridrank_gate "output_${full_factor}/gridrank_dynamic_factorized_gate.json" \
      --output "$model_preflight"
  done
done

if [[ "$PREFLIGHT_ONLY" == "1" ]]; then
  echo "=== GRIDRANK DYNAMIC PHYSICS FACTORIAL CPU PREFLIGHT COMPLETE; GPU NOT STARTED ==="
  exit 0
fi

CURRENT_STAGE="cuda_readiness"
echo "=== 4/6 CUDA + BITSANDBYTES NF4 READINESS ==="
"$TRAIN_PYTHON_BIN" -B - <<'PY'
import json
try:
    import bitsandbytes as bnb
    import torch
    from transformers import BitsAndBytesConfig
    checks = {"cuda_available": torch.cuda.is_available(), "visible_device_count": torch.cuda.device_count() > 0}
    device = torch.device("cuda:0") if all(checks.values()) else None
    if device is not None:
        probe = torch.ones(1, device=device)
        checks["cuda_tensor_ok"] = float(probe.item()) == 1.0
        free, total = torch.cuda.mem_get_info(device)
        layer = bnb.nn.Linear4bit(64, 64, bias=False, compute_dtype=torch.float16, compress_statistics=True, quant_type="nf4").to(device)
        value = layer(torch.randn(2, 64, device=device, dtype=torch.float16))
        torch.cuda.synchronize(device)
        checks["nf4_kernel_ok"] = bool(value.is_cuda and torch.isfinite(value).all())
        config = BitsAndBytesConfig(load_in_4bit=True, bnb_4bit_quant_type="nf4", bnb_4bit_compute_dtype=torch.float16, bnb_4bit_use_double_quant=True)
        checks["nf4_config_ok"] = bool(config.load_in_4bit and config.bnb_4bit_quant_type == "nf4")
        metadata = {"device": torch.cuda.get_device_name(device), "free_memory_bytes": int(free), "total_memory_bytes": int(total)}
    else:
        checks.update({"cuda_tensor_ok": False, "nf4_kernel_ok": False, "nf4_config_ok": False})
        metadata = {}
except Exception as exc:
    checks = locals().get("checks", {})
    checks["exception_free"] = False
    metadata = {"error": f"{type(exc).__name__}: {exc}"}
result = {"msg": "GridRank dynamic physics-factorial CUDA readiness", **metadata, "checks": checks, "readiness_pass": bool(checks) and all(checks.values())}
print(json.dumps(result, ensure_ascii=False))
raise SystemExit(0 if result["readiness_pass"] else 2)
PY

for physics in 1 0; do
  for seed in 42 123 2025; do
    LAMBDA_PHYSICS="${physics}.0"
    model_tag="$(sft_model_tag "$physics" "$seed")"
    model_preflight="${model_tag}.preflight.json"
    model_out="output_${model_tag}"
    model_gate="${model_out}/gridrank_dynamic_factorized_gate.json"
    model_adapter="${model_out}/diagnostic_adapter"
    TRAIN_ARGS=(
      --train_jsonl "$TRAIN_JSONL" --validation_jsonl "$VALIDATION_JSONL"
      --pair_summary "$PAIR_SUMMARY" --benchmark_manifest "$BENCHMARK_MANIFEST"
      --joint_preflight "$JOINT_PREFLIGHT" --joint_gate "$JOINT_GATE"
      --resume_adapter_path "$SFT_ADAPTER" --sft_adapter_path "$SFT_ADAPTER"
      --base_model "$BASE_MODEL" --max_length "$MAX_LENGTH"
      --primitive_batch_size "$TRAIN_PRIMITIVE_BATCH_SIZE" --epochs "$EPOCHS"
      --learning_rate "$LEARNING_RATE" --grad_accum "$GRAD_ACCUM"
      --max_grad_norm "$MAX_GRAD_NORM" --target_temperature "$TARGET_TEMPERATURE"
      --lambda_objective "$LAMBDA_OBJECTIVE" --lambda_constraint "$LAMBDA_CONSTRAINT"
      --lambda_physics "$LAMBDA_PHYSICS" --lambda_hard "$LAMBDA_HARD"
      --hard_margin "$HARD_MARGIN" --beta_reference "$BETA_REFERENCE"
      --seed "$seed" --gradient_checkpointing "$TRAIN_GRADIENT_CHECKPOINTING"
      --bootstrap_reps "$BOOTSTRAP_REPS"
    )
    CURRENT_STAGE="train_sft_cell_p${physics}_seed_${seed}"
    echo "=== 5/6 TRAIN/EVALUATE FROZEN-SFT CELL P=$physics SEED=$seed ==="
    if [[ -e "$model_out" ]]; then
      test -f "$model_gate" || { echo "incomplete existing output: $model_out" >&2; exit 2; }
      test -f "$model_adapter/adapter_model.safetensors" || { echo "missing adapter: $model_out" >&2; exit 2; }
    else
      "$TRAIN_PYTHON_BIN" -u train_gridrank_dynamic_physics_factorial.py \
        "${TRAIN_ARGS[@]}" --preflight_manifest "$model_preflight" --output_dir "$model_out"
    fi
    "$TRAIN_PYTHON_BIN" -B verify_gridrank_dynamic_physics_factorial_model.py \
      --gate "$model_gate" --preflight "$model_preflight"

    confirm_tag="$(sft_confirm_tag "$physics" "$seed")"
    confirm_preflight="${confirm_tag}.preflight.json"
    confirm_out="output_${confirm_tag}"
    confirm_gate="${confirm_out}/gridrank_dynamic_confirmation_gate.json"
    confirm_records="${confirm_out}/gridrank_dynamic_confirmation_records.jsonl"
    CONFIRM_ARGS=(
      --fresh_pairs "$FRESH_PAIRS" --fresh_summary "$FRESH_SUMMARY"
      --fresh_audit "$FRESH_AUDIT" --original_train "$TRAIN_JSONL"
      --original_validation "$VALIDATION_JSONL"
      --factorized_preflight "$model_preflight" --factorized_gate "$model_gate"
      --factorized_adapter "$model_adapter" --base_model "$BASE_MODEL"
      --max_length "$MAX_LENGTH" --primitive_batch_size "$EVAL_PRIMITIVE_BATCH_SIZE"
      --topk "$TOPK" --bootstrap_reps "$BOOTSTRAP_REPS"
      --seed "$EVALUATION_SEED" --gradient_checkpointing "$EVAL_GRADIENT_CHECKPOINTING"
    )
    "$TRAIN_PYTHON_BIN" -B preflight_gridrank_dynamic_physics_factorial_confirmation.py \
      "${CONFIRM_ARGS[@]}" \
      --reference_confirmation_preflight "$REFERENCE_CONFIRM_PREFLIGHT" \
      --reference_confirmation_gate "$REFERENCE_CONFIRM_GATE" \
      --model_seed "$seed" --output "$confirm_preflight"
    if [[ -e "$confirm_out" ]]; then
      test -f "$confirm_gate" || { echo "incomplete confirmation: $confirm_out" >&2; exit 2; }
      test -f "$confirm_records" || { echo "missing records: $confirm_out" >&2; exit 2; }
    else
      "$TRAIN_PYTHON_BIN" -u eval_gridrank_dynamic_physics_factorial_confirmation.py \
        --fresh_pairs "$FRESH_PAIRS" --original_train "$TRAIN_JSONL" \
        --preflight_manifest "$confirm_preflight" --factorized_adapter "$model_adapter" \
        --base_model "$BASE_MODEL" --output_dir "$confirm_out" \
        --max_length "$MAX_LENGTH" --primitive_batch_size "$EVAL_PRIMITIVE_BATCH_SIZE" \
        --topk "$TOPK" --bootstrap_reps "$BOOTSTRAP_REPS" --seed "$EVALUATION_SEED" \
        --gradient_checkpointing "$EVAL_GRADIENT_CHECKPOINTING"
    fi
    "$TRAIN_PYTHON_BIN" -B verify_gridrank_dynamic_physics_factorial_confirmation.py \
      --gate "$confirm_gate" --preflight "$confirm_preflight"
  done
done

CURRENT_STAGE="aggregate"
echo "=== 6/6 AGGREGATE FOUR CELLS ACROSS THREE SEEDS ==="
if [[ -e "$AGGREGATE" ]]; then
  "$TRAIN_PYTHON_BIN" -B verify_gridrank_dynamic_physics_factorial.py --result "$AGGREGATE"
  echo "=== GRIDRANK DYNAMIC PHYSICS FACTORIAL ALREADY COMPLETE AND VERIFIED ==="
  exit 0
fi

AGG_ARGS=()
for seed in 42 123 2025; do
  full_factor="$(full_factor_tag "$seed")"
  full_confirm="$(full_confirm_tag "$seed")"
  grid0_model="${GRID_NOPHYS_MODEL_PREFIX}_s${seed}"
  grid0_confirm="${GRID_NOPHYS_CONFIRM_PREFIX}_s${seed}"
  sft1_model="$(sft_model_tag 1 "$seed")"
  sft1_confirm="$(sft_confirm_tag 1 "$seed")"
  sft0_model="$(sft_model_tag 0 "$seed")"
  sft0_confirm="$(sft_confirm_tag 0 "$seed")"
  for spec in \
    "gridrank_p1:$full_factor:$full_confirm" \
    "gridrank_p0:$grid0_model:$grid0_confirm" \
    "sft_p1:$sft1_model:$sft1_confirm" \
    "sft_p0:$sft0_model:$sft0_confirm"; do
    IFS=: read -r cell model confirm <<< "$spec"
    AGG_ARGS+=(
      --gate "$cell:$seed=output_${confirm}/gridrank_dynamic_confirmation_gate.json"
      --records "$cell:$seed=output_${confirm}/gridrank_dynamic_confirmation_records.jsonl"
      --factor_preflight "$cell:$seed=${model}.preflight.json"
      --confirmation_preflight "$cell:$seed=${confirm}.preflight.json"
    )
  done
done
"$TRAIN_PYTHON_BIN" -B aggregate_gridrank_dynamic_physics_factorial.py \
  "${AGG_ARGS[@]}" --fresh_summary "$FRESH_SUMMARY" \
  --bootstrap_reps "$BOOTSTRAP_REPS" --bootstrap_seed "$AGGREGATE_SEED" \
  --output "$AGGREGATE"
"$TRAIN_PYTHON_BIN" -B verify_gridrank_dynamic_physics_factorial.py --result "$AGGREGATE"
echo "=== GRIDRANK DYNAMIC PHYSICS FACTORIAL COMPLETE ==="
