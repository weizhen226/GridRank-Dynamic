"""Validate GridRank dynamic factorized replication."""

from __future__ import annotations

import sys

import preflight_gridrank_dynamic_factorized_replication as replication_preflight


sys.modules["preflight_gridrank_dynamic_factorized"] = replication_preflight

import verify_gridrank_dynamic_factorized as locked_verifier  


if __name__ == "__main__":
    locked_verifier.main()
