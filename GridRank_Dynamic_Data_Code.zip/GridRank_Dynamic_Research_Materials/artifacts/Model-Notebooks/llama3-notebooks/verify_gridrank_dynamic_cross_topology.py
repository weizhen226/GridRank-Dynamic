
"""Validate GridRank dynamic cross topology."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from types import SimpleNamespace

import preflight_gridrank_dynamic_cross_topology as preflight


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--gate", required=True)
    parser.add_argument("--preflight", required=True)
    return parser.parse_args()


def main():
    args = parse_args()
    gate = json.load(open(args.gate, encoding="utf-8"))
    locked = json.load(open(args.preflight, encoding="utf-8"))
    preflight.verify(SimpleNamespace(
        output=args.preflight, verify=True, **locked["schedule"]
    ))
    records = gate.get("records", {})
    generalisation_expected = bool(gate.get("evaluation_pass")) and all(gate.get("generalisation_checks", {}).values())
    decision_expected = (
        "authorize_framework_cross_topology_claim" if generalisation_expected else
        "report_bounded_cross_topology_result_without_generalisation_claim"
    )
    checks = {
        "schema": gate.get("schema") == "gridrank-dynamic-cross-topology-gate-v1",
        "experiment_id": gate.get("experiment_id") == preflight.EXPERIMENT_ID,
        "preflight_pass": locked.get("preflight_pass") is True,
        "preflight_hash": gate.get("preflight_sha256") == preflight.file_sha256(args.preflight),
        "evaluation_only": gate.get("evaluation_only") is True,
        "training_not_performed": gate.get("training_performed") is False,
        "sealed_outcomes_not_fit": gate.get("sealed_outcomes_used_for_fit") is False,
        "three_seeds": gate.get("seeds") == [42, 123, 2025],
        "records_current": Path(records.get("path", "")).is_file() and preflight.file_sha256(records["path"]) == records.get("sha256"),
        "integrity_pass": gate.get("evaluation_pass") is True and all(gate.get("integrity_checks", {}).values()),
        "generalisation_gate_consistent": gate.get("generalisation_gate_pass") is generalisation_expected,
        "decision_consistent": gate.get("decision") == decision_expected,
        "interpretation_boundary_present": bool(gate.get("interpretation_boundary")),
        "frozen_inputs_reverified_after_inference": True,
    }
    result = {
        "msg": "GridRank dynamic cross-topology result verification",
        "checks": checks, "verification_pass": all(checks.values()),
        "evaluation_pass": gate.get("evaluation_pass"),
        "failed_generalisation": gate.get("failed_generalisation"),
        "decision": gate.get("decision"),
    }
    print(json.dumps(result, ensure_ascii=False))
    if not result["verification_pass"]:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
