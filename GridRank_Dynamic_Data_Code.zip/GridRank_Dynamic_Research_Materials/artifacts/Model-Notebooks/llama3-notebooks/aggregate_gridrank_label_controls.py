"""Aggregate GridRank label controls."""

from __future__ import annotations

import argparse
import json
import random
from pathlib import Path

from gridrank_label_controls import VARIANTS
from preflight_gridrank_label_controls import EXPERIMENT_ID, SCHEMA, file_sha256


AGGREGATE_SCHEMA = "gridrank-label-controls-aggregate-v1"
EPS = 1e-12


def _json(path):
    return json.load(open(path, encoding="utf-8"))


def mappings(values):
    output = {}
    for value in values:
        key, path = value.split("=", 1)
        output[key] = path
    return output


def percentile(values, probability):
    ordered = sorted(values)
    return ordered[int(probability * (len(ordered) - 1))]


def paired(left_rows, right_rows, left_field, right_field, reps, seed):
    left = {row["instance_id"]: row for row in left_rows}
    right = {row["instance_id"]: row for row in right_rows}
    if set(left) != set(right):
        raise RuntimeError("paired label-control state identities differ")
    values = [
        float(left[key][left_field]) - float(right[key][right_field])
        for key in sorted(left)
    ]
    rng = random.Random(seed)
    draws = [
        sum(rng.choice(values) for _ in values) / len(values)
        for _ in range(reps)
    ]
    return {
        "n_states": len(values),
        "safe_regret_improvement_mean": sum(values) / len(values),
        "state_bootstrap_ci95": [percentile(draws, 0.025), percentile(draws, 0.975)],
        "left_better_states": sum(value > EPS for value in values),
        "left_worse_states": sum(value < -EPS for value in values),
        "tied_states": sum(abs(value) <= EPS for value in values),
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--suite_preflight", required=True)
    parser.add_argument("--gate", action="append", required=True)
    parser.add_argument("--bootstrap_reps", type=int, default=10000)
    parser.add_argument("--bootstrap_seed", type=int, default=20260811)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    suite = _json(args.suite_preflight)
    if suite.get("schema") != SCHEMA or suite.get("preflight_pass") is not True:
        raise RuntimeError("invalid label-control suite preflight")
    paths = mappings(args.gate)
    if set(paths) != set(VARIANTS):
        raise ValueError("both and only the two label controls are required")
    full = _json(suite["full_control_gate"]["path"])
    controls = {name: _json(path) for name, path in paths.items()}
    full_rows = full["paired"]["distilled_vs_sft"]["state_rows"]
    results = {}
    structural = {}
    for offset, name in enumerate(VARIANTS, start=1):
        gate = controls[name]
        rows = gate["paired"]["distilled_vs_sft"]["state_rows"]
        structural[name] = {
            "schema": gate.get("schema") == "gridrank-label-control-gate-v1",
            "variant": gate.get("label_control_variant") == name,
            "suite": gate.get("label_control_suite_sha256") == file_sha256(args.suite_preflight),
            "training_complete": gate.get("control_training_complete") is True,
            "same_states": {row["instance_id"] for row in rows}
                == {row["instance_id"] for row in full_rows},
            "reference_frozen": gate.get("reference_parameter_delta", {}).get("changed_tensors") == 0,
            "final_feasible": gate.get("summaries", {}).get("distilled", {}).get("safe_feasible_rate") == 1.0,
        }
        control_over_sft = paired(
            rows, rows, "sft_safe_regret", "distilled_safe_regret",
            args.bootstrap_reps, args.bootstrap_seed + 1000 * offset,
        )
        full_over_control = paired(
            rows, full_rows, "distilled_safe_regret", "distilled_safe_regret",
            args.bootstrap_reps, args.bootstrap_seed + 2000 * offset,
        )
        by_network = {}
        for network in ("33", "69"):
            control_network = [row for row in rows if str(row["network"]) == network]
            full_network = [row for row in full_rows if str(row["network"]) == network]
            by_network[network] = {
                "control_over_sft": paired(
                    control_network, control_network,
                    "sft_safe_regret", "distilled_safe_regret",
                    args.bootstrap_reps, args.bootstrap_seed + 3000 * offset + int(network),
                ),
                "full_over_control": paired(
                    control_network, full_network,
                    "distilled_safe_regret", "distilled_safe_regret",
                    args.bootstrap_reps, args.bootstrap_seed + 4000 * offset + int(network),
                ),
            }
        results[name] = {
            "training_supervision_audit": gate["training_supervision_audit"],
            "summary": gate["summaries"]["distilled"],
            "control_over_frozen_sft": control_over_sft,
            "full_gridrank_over_control": full_over_control,
            "by_network": by_network,
        }
    shuffled_ci = results["shuffled_labels"]["full_gridrank_over_control"]["state_bootstrap_ci95"]
    lindistflow_ci = results["lindistflow_labels"]["full_gridrank_over_control"]["state_bootstrap_ci95"]
    checks = {
        "full_control_current": file_sha256(suite["full_control_gate"]["path"])
            == suite["full_control_gate"]["sha256"],
        "both_controls_structurally_valid": all(
            all(values.values()) for values in structural.values()
        ),
    }
    payload = {
        "schema": AGGREGATE_SCHEMA,
        "experiment_id": EXPERIMENT_ID,
        "audit_pass": all(checks.values()),
        "full_gridrank_summary": full["summaries"]["distilled"],
        "frozen_sft_summary": full["summaries"]["sft"],
        "controls": results,
        "structural_checks": structural,
        "checks": checks,
        "causal_decision": {
            "full_beats_shuffled_ci_lower_positive": shuffled_ci[0] > 0.0,
            "full_beats_lindistflow_label_ci_lower_positive": lindistflow_ci[0] > 0.0,
            "physics_specificity_gate_pass": shuffled_ci[0] > 0.0 and lindistflow_ci[0] > 0.0,
            "interpretation": (
                "Full-minus-shuffled isolates valid label-action correspondence beyond YES/NO "
                "format adaptation. Full-minus-LinDistFlow isolates authoritative AC-feedback "
                "value beyond matched approximate-physics supervision."
            ),
        },
        "bootstrap_reps": args.bootstrap_reps,
        "bootstrap_seed": args.bootstrap_seed,
        "suite_preflight": {
            "path": str(Path(args.suite_preflight).resolve()),
            "sha256": file_sha256(args.suite_preflight),
        },
        "control_gates": {
            name: {"path": str(Path(path).resolve()), "sha256": file_sha256(path)}
            for name, path in paths.items()
        },
    }
    Path(args.output).write_text(
        json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    print(json.dumps({
        "msg": "GridRank matched label-controls aggregate",
        "audit_pass": payload["audit_pass"],
        "causal_decision": payload["causal_decision"],
        "controls": {
            name: {
                "control_over_frozen_sft": value["control_over_frozen_sft"],
                "full_gridrank_over_control": value["full_gridrank_over_control"],
            }
            for name, value in results.items()
        },
    }, ensure_ascii=False))
    if not payload["audit_pass"]:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
