"""Physics graph policy utilities."""

import math

import action_extract
import grpo_reward_limited as reward
from structured_action_head import action_features

NODE_FEATURE_DIM = 9
EDGE_FEATURE_DIM = 2
ACTION_FEATURE_DIM = 10
NOOP = "Action: none"
NODE_FEATURE_GROUPS = {
    "local_load": (0, 1),
    "downstream": (2, 3),
    "depth": (4,),
    "voltage_drop": (5,),
    "source": (6,),
    "switch_markers": (7, 8),
}


def _edge(edge):
    return tuple(sorted(int(value) for value in edge))


def _scales(engine):
    rs = sorted(abs(float(r)) for _, _, r, _ in engine.ALL_BRANCHES if r)
    xs = sorted(abs(float(x)) for _, _, _, x in engine.ALL_BRANCHES if x)
    return rs[len(rs) // 2], xs[len(xs) // 2]


def candidate_open_set(existing_open, action):
    existing = {_edge(item) for item in existing_open}
    if action == NOOP:
        return existing, None, None
    parsed = action_extract.extract_delta(action)
    if parsed is None or parsed == "none":
        raise ValueError(f"invalid structured action: {action!r}")
    close_edge, open_edge = (_edge(parsed[0]), _edge(parsed[1]))
    if close_edge not in existing or open_edge in existing:
        raise ValueError(f"action inconsistent with existing topology: {action}")
    return (existing - {close_edge}) | {open_edge}, close_edge, open_edge


def graph_for_action(prompt, action, drop_node_features=()):
    
    engine = reward.engine_from_prompt(prompt)
    existing = reward.parse_existing_open(prompt)
    load = reward.parse_load(prompt)
    if engine is None or existing is None or load is None:
        raise ValueError("prompt is missing network, existing topology, or load")
    open_set, close_edge, open_edge = candidate_open_set(existing, action)
    active = []
    impedance = {}
    for a, b, resistance, reactance in engine.ALL_BRANCHES:
        key = engine._key(a, b)
        impedance[key] = (float(resistance), float(reactance))
        if key not in open_set:
            active.append(key)
    if len(active) != engine.N_BUS - 1:
        raise ValueError(f"candidate is not a tree by edge count: {action}")

    adjacency = {bus: [] for bus in range(1, engine.N_BUS + 1)}
    for a, b in active:
        adjacency[a].append(b)
        adjacency[b].append(a)
    parent = {1: 0}
    depth = {1: 0}
    order = [1]
    for bus in order:
        for neighbor in adjacency[bus]:
            if neighbor in parent:
                continue
            parent[neighbor] = bus
            depth[neighbor] = depth[bus] + 1
            order.append(neighbor)
    if len(order) != engine.N_BUS:
        raise ValueError(f"candidate is disconnected: {action}")

    load_values = list(load[:engine.N_BUS]) + [0j] * max(0, engine.N_BUS - len(load))
    downstream = {bus: load_values[bus - 1] for bus in range(1, engine.N_BUS + 1)}
    for bus in reversed(order[1:]):
        downstream[parent[bus]] += downstream[bus]
    total_p = max(sum(max(0.0, value.real) for value in load_values), 1e-8)
    total_q = max(sum(max(0.0, value.imag) for value in load_values), 1e-8)
    positive_p = [value.real for value in load_values if value.real > 0]
    positive_q = [value.imag for value in load_values if value.imag > 0]
    p_scale = sum(positive_p) / max(1, len(positive_p))
    q_scale = sum(positive_q) / max(1, len(positive_q))
    approximate_drop = {1: 0.0}
    zbase = float(getattr(engine, "ZBASE", 1.0))
    for bus in order[1:]:
        edge = engine._key(bus, parent[bus])
        resistance, reactance = impedance[edge]
        flow = downstream[bus]
        local_drop = (resistance * flow.real + reactance * flow.imag) / max(zbase, 1e-8)
        approximate_drop[bus] = approximate_drop[parent[bus]] + local_drop

    close_nodes = set(close_edge or ())
    open_nodes = set(open_edge or ())
    node_features = []
    for bus in range(1, engine.N_BUS + 1):
        value = load_values[bus - 1]
        aggregate = downstream[bus]
        node_features.append([
            value.real / max(p_scale, 1e-8),
            value.imag / max(q_scale, 1e-8),
            aggregate.real / total_p,
            aggregate.imag / total_q,
            depth[bus] / max(1.0, float(engine.N_BUS - 1)),
            approximate_drop[bus],
            float(bus == 1),
            float(bus in close_nodes),
            float(bus in open_nodes),
        ])
    unknown_groups = sorted(set(drop_node_features) - set(NODE_FEATURE_GROUPS))
    if unknown_groups:
        raise ValueError(f"unknown node feature groups: {unknown_groups}")
    dropped_indices = {
        index
        for group in drop_node_features
        for index in NODE_FEATURE_GROUPS[group]
    }
    if dropped_indices:
        for features in node_features:
            for index in dropped_indices:
                features[index] = 0.0

    resistance_scale, reactance_scale = _scales(engine)
    edge_index = []
    edge_features = []
    for a, b in active:
        resistance, reactance = impedance[(a, b)]
        feature = [resistance / resistance_scale, reactance / reactance_scale]
        edge_index.extend([[a - 1, b - 1], [b - 1, a - 1]])
        edge_features.extend([feature, feature])
    candidate_features = (
        [0.0] * ACTION_FEATURE_DIM
        if action == NOOP else action_features(engine, close_edge, open_edge)
    )
    return {
        "node_features": node_features,
        "edge_index": edge_index,
        "edge_features": edge_features,
        "action_features": candidate_features,
    }


def target_distribution(row, target_mode="soft_regret"):
    
    if target_mode not in {"soft_regret", "hard_optimal"}:
        raise ValueError(f"unknown target mode: {target_mode}")
    candidates = [dict(item) for item in row["candidates"]]
    best_reduction = float(row["best_reduction_pct"])
    if bool(row["true_noop"]):
        noop = {"action": NOOP, "feasible": True, "reduction_pct": 0.0,
                "target_prob": 1.0, "regret_pct": 0.0}
        for item in candidates:
            item["target_prob"] = 0.0
        return [noop] + candidates

    scale = max(0.02, 0.10 * max(best_reduction, 0.05))
    output = [{"action": NOOP, "feasible": True, "reduction_pct": 0.0,
               "regret_pct": best_reduction}]
    output.extend(candidates)
    weights = []
    for item in output:
        reduction = item.get("reduction_pct")
        if item.get("feasible") and reduction is not None:
            regret = max(0.0, best_reduction - float(reduction))
            item["regret_pct"] = regret
            weights.append(math.exp(-regret / scale))
        else:
            item["regret_pct"] = None
            weights.append(0.0)
    total = sum(weights)
    for item, weight in zip(output, weights):
        item["target_prob"] = weight / total
    if target_mode == "hard_optimal":
        chosen = row["chosen"]
        if chosen == NOOP or not any(item["action"] == chosen for item in output):
            raise ValueError(f"canonical action absent for hard target: {chosen}")
        for item in output:
            item["target_prob"] = float(item["action"] == chosen)
    return output


def inference_candidates(row):
    
    return [{"action": NOOP}] + [dict(item) for item in row["candidates"]]


def collate_graphs(graphs, device):
    import torch

    nodes, edges, edge_features, graph_ids, action_features = [], [], [], [], []
    offset = 0
    for graph_id, graph in enumerate(graphs):
        nodes.extend(graph["node_features"])
        graph_ids.extend([graph_id] * len(graph["node_features"]))
        edges.extend([[a + offset, b + offset] for a, b in graph["edge_index"]])
        edge_features.extend(graph["edge_features"])
        action_features.append(graph["action_features"])
        offset += len(graph["node_features"])
    return {
        "nodes": torch.tensor(nodes, dtype=torch.float32, device=device),
        "edge_index": torch.tensor(edges, dtype=torch.long, device=device).t().contiguous(),
        "edge_features": torch.tensor(edge_features, dtype=torch.float32, device=device),
        "graph_ids": torch.tensor(graph_ids, dtype=torch.long, device=device),
        "action_features": torch.tensor(action_features, dtype=torch.float32, device=device),
        "n_graphs": len(graphs),
    }


def build_model(hidden_dim=128, layers=6):
    import torch

    class MessageLayer(torch.nn.Module):
        def __init__(self):
            super().__init__()
            self.message = torch.nn.Sequential(
                torch.nn.Linear(hidden_dim + EDGE_FEATURE_DIM, hidden_dim),
                torch.nn.GELU(),
                torch.nn.Linear(hidden_dim, hidden_dim),
            )
            self.update = torch.nn.Sequential(
                torch.nn.Linear(hidden_dim * 2, hidden_dim),
                torch.nn.GELU(),
                torch.nn.Linear(hidden_dim, hidden_dim),
            )
            self.norm = torch.nn.LayerNorm(hidden_dim)

        def forward(self, hidden, edge_index, edge_features):
            source, target = edge_index[0], edge_index[1]
            messages = self.message(torch.cat([hidden[source], edge_features], dim=-1))
            aggregate = torch.zeros_like(hidden)
            aggregate.index_add_(0, target, messages)
            degree = torch.zeros(hidden.shape[0], 1, device=hidden.device, dtype=hidden.dtype)
            degree.index_add_(0, target, torch.ones(messages.shape[0], 1, device=hidden.device))
            aggregate = aggregate / degree.clamp_min(1.0)
            return self.norm(hidden + self.update(torch.cat([hidden, aggregate], dim=-1)))

    class PhysicsGraphPolicy(torch.nn.Module):
        def __init__(self):
            super().__init__()
            self.node_projection = torch.nn.Sequential(
                torch.nn.Linear(NODE_FEATURE_DIM, hidden_dim), torch.nn.GELU()
            )
            self.layers = torch.nn.ModuleList([MessageLayer() for _ in range(layers)])
            self.action_projection = torch.nn.Sequential(
                torch.nn.Linear(ACTION_FEATURE_DIM, hidden_dim), torch.nn.GELU(),
                torch.nn.Linear(hidden_dim, hidden_dim),
            )
            self.policy = torch.nn.Sequential(
                torch.nn.Linear(hidden_dim * 4, hidden_dim), torch.nn.GELU(),
                torch.nn.Linear(hidden_dim, 1),
            )
            self.feasibility = torch.nn.Sequential(
                torch.nn.Linear(hidden_dim * 4, hidden_dim // 2), torch.nn.GELU(),
                torch.nn.Linear(hidden_dim // 2, 1),
            )

        def encode(self, batch):
            hidden = self.node_projection(batch["nodes"])
            for layer in self.layers:
                hidden = layer(hidden, batch["edge_index"], batch["edge_features"])
            count = batch["n_graphs"]
            pooled_mean = torch.zeros(count, hidden_dim, device=hidden.device)
            pooled_mean.index_add_(0, batch["graph_ids"], hidden)
            sizes = torch.bincount(batch["graph_ids"], minlength=count).unsqueeze(1)
            pooled_mean = pooled_mean / sizes.clamp_min(1)
            pooled_max = torch.stack([
                hidden[batch["graph_ids"] == graph_id].max(dim=0).values
                for graph_id in range(count)
            ])
            roots = torch.stack([
                hidden[(batch["graph_ids"] == graph_id).nonzero(as_tuple=False)[0, 0]]
                for graph_id in range(count)
            ])
            action = self.action_projection(batch["action_features"])
            return torch.cat([pooled_mean, pooled_max, roots, action], dim=-1)

        def forward(self, batch):
            representation = self.encode(batch)
            return self.policy(representation).squeeze(-1), self.feasibility(representation).squeeze(-1)

    return PhysicsGraphPolicy()


