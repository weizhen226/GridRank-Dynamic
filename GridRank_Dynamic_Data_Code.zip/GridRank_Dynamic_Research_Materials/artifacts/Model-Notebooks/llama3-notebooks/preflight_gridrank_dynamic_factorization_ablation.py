"""Check inputs for GridRank dynamic factorization ablation."""

from __future__ import annotations

import argparse
import hashlib
import json
from collections import Counter
from pathlib import Path

import preflight_gridrank_feedback as runtime
import preflight_gridrank_dynamic_policy as joint_preflight_module
from gridrank_dynamic_llm import CARDS, render_card_prompt
from gridrank_runtime_compat import runtime_compatibility


HERE = Path(__file__).resolve().parent
SCHEMA = "gridrank-dynamic-factorization-ablation-preflight-v1"
EXPERIMENT_ID = "gridrank-dynamic-factorized-vs-joint-card-seed42-v1"
PRIMARY_PAIR_TYPE = "maintenance_voltage"
CODE_FILES = (
    "preflight_gridrank_dynamic_factorization_ablation.py",
    "eval_gridrank_dynamic_factorization_ablation.py",
    "verify_gridrank_dynamic_factorization_ablation.py",
    "verify_gridrank_dynamic_factorization_ablation_dependencies.py",
    "run_gridrank_dynamic_factorization_ablation.sh",
    "gridrank_dynamic_llm.py",
    "gridrank_dynamic_factorized_llm.py",
    "train_gridrank_dynamic_policy.py",
    "train_gridrank_dynamic_factorized.py",
    "aggregate_gridrank_dynamic_multiseed.py",
    "../../docs/GRIDRANK_DYNAMIC_FACTORIZATION_ABLATION_PROTOCOL.md",
)


def file_sha256(path):
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def adapter_hash(path):
    root = Path(path)
    return {
        "adapter_config_json": file_sha256(root / "adapter_config.json"),
        "adapter_model_safetensors": file_sha256(root / "adapter_model.safetensors"),
    }


def code_hashes():
    missing = [name for name in CODE_FILES if not (HERE / name).is_file()]
    if missing:
        raise FileNotFoundError(f"missing factorization-ablation code: {missing}")
    return {name: file_sha256(HERE / name) for name in CODE_FILES}


def rows(path):
    return [
        json.loads(line) for line in open(path, encoding="utf-8") if line.strip()
    ]


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--fresh_pairs", required=True)
    parser.add_argument("--fresh_summary", required=True)
    parser.add_argument("--fresh_audit", required=True)
    parser.add_argument("--joint_preflight", required=True)
    parser.add_argument("--joint_gate", required=True)
    parser.add_argument("--joint_adapter", required=True)
    parser.add_argument("--factorized_preflight", required=True)
    parser.add_argument("--factorized_gate", required=True)
    parser.add_argument("--factorized_adapter", required=True)
    parser.add_argument("--factorized_confirmation_preflight", required=True)
    parser.add_argument("--factorized_confirmation_gate", required=True)
    parser.add_argument("--factorized_confirmation_records", required=True)
    parser.add_argument("--base_model", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--max_length", type=int, required=True)
    parser.add_argument("--card_batch_size", type=int, required=True)
    parser.add_argument("--topk", type=int, required=True)
    parser.add_argument("--bootstrap_reps", type=int, required=True)
    parser.add_argument("--seed", type=int, required=True)
    parser.add_argument(
        "--gradient_checkpointing", type=int, choices=(0, 1), required=True
    )
    return parser.parse_args()


def schedule(args):
    return {
        "max_length": args.max_length,
        "card_batch_size": args.card_batch_size,
        "topk": args.topk,
        "bootstrap_reps": args.bootstrap_reps,
        "seed": args.seed,
        "gradient_checkpointing": args.gradient_checkpointing,
    }


def prompt_audit(values, base_model, max_length):
    from transformers import AutoTokenizer

    tokenizer = AutoTokenizer.from_pretrained(base_model, local_files_only=True)
    maximum = truncated = prompts = 0
    for row in values:
        for card in CARDS:
            text = render_card_prompt(tokenizer, row, card)
            length = len(tokenizer(text, add_special_tokens=False)["input_ids"])
            maximum = max(maximum, length)
            truncated += int(length > max_length)
            prompts += 1
    return {
        "prompts": prompts,
        "cards_per_row": len(CARDS),
        "max_tokens": maximum,
        "truncated_prompts": truncated,
        "prompt_length_pass": truncated == 0,
    }


def matched_training_contract(joint_preflight, factorized_preflight):
    joint_schedule = joint_preflight.get("schedule", {})
    factor_schedule = factorized_preflight.get("schedule", {})
    scalar_matches = {
        "max_length": joint_schedule.get("max_length")
        == factor_schedule.get("max_length"),
        "epochs": joint_schedule.get("epochs") == factor_schedule.get("epochs"),
        "learning_rate": joint_schedule.get("learning_rate")
        == factor_schedule.get("learning_rate"),
        "grad_accum": joint_schedule.get("grad_accum")
        == factor_schedule.get("grad_accum"),
        "max_grad_norm": joint_schedule.get("max_grad_norm")
        == factor_schedule.get("max_grad_norm"),
        "target_temperature": joint_schedule.get("target_temperature")
        == factor_schedule.get("target_temperature"),
        "lambda_physics": joint_schedule.get("lambda_physics")
        == factor_schedule.get("lambda_physics"),
        "lambda_hard": joint_schedule.get("lambda_hard")
        == factor_schedule.get("lambda_hard"),
        "hard_margin": joint_schedule.get("hard_margin")
        == factor_schedule.get("hard_margin"),
        "beta_reference": joint_schedule.get("beta_reference")
        == factor_schedule.get("beta_reference"),
        "seed": joint_schedule.get("seed") == factor_schedule.get("seed") == 42,
        "gradient_checkpointing": joint_schedule.get("gradient_checkpointing")
        == factor_schedule.get("gradient_checkpointing"),
        "bootstrap_reps": joint_schedule.get("bootstrap_reps")
        == factor_schedule.get("bootstrap_reps"),
    }
    semantic_budget_match = (
        joint_schedule.get("lambda_semantic")
        == factor_schedule.get("lambda_objective", 0)
        + factor_schedule.get("lambda_constraint", 0)
    )
    joint_rows = joint_preflight.get("selection", {}).get("train_row_ids", [])
    factor_rows = factorized_preflight.get("selection", {}).get(
        "train_row_ids", []
    )
    joint_gridrank = joint_preflight.get("adapters", {}).get("gridrank", {})
    factor_gridrank = factorized_preflight.get("adapters", {}).get("gridrank", {})
    joint_sft = joint_preflight.get("adapters", {}).get("sft", {})
    factor_sft = factorized_preflight.get("adapters", {}).get("sft", {})
    return {
        "same_training_row_ids": joint_rows == factor_rows and len(joint_rows) == 114,
        "same_initial_gridrank_adapter": joint_gridrank.get("sha256")
        == factor_gridrank.get("sha256"),
        "same_sft_control_adapter": joint_sft.get("sha256")
        == factor_sft.get("sha256"),
        "same_base_model_inventory": joint_preflight.get("base_model_inventory")
        == factorized_preflight.get("base_model_inventory"),
        "same_scalar_training_schedule": all(scalar_matches.values()),
        "same_total_semantic_loss_weight": semantic_budget_match,
        "same_four_score_calls_per_row": True,
        "schedule_field_matches": scalar_matches,
    }


def create(args):
    output = Path(args.output)
    if output.exists():
        raise FileExistsError(f"refusing to overwrite preflight: {output}")
    fresh = rows(args.fresh_pairs)
    fresh_summary = json.load(open(args.fresh_summary, encoding="utf-8"))
    fresh_audit = json.load(open(args.fresh_audit, encoding="utf-8"))
    joint_preflight = json.load(open(args.joint_preflight, encoding="utf-8"))
    joint_gate = json.load(open(args.joint_gate, encoding="utf-8"))
    factor_preflight = json.load(open(args.factorized_preflight, encoding="utf-8"))
    factor_gate = json.load(open(args.factorized_gate, encoding="utf-8"))
    confirmation_preflight = json.load(
        open(args.factorized_confirmation_preflight, encoding="utf-8")
    )
    confirmation_gate = json.load(
        open(args.factorized_confirmation_gate, encoding="utf-8")
    )
    factor_records = rows(args.factorized_confirmation_records)
    methods = {row.get("method") for row in factor_records}
    pair_mix = Counter((str(row["network_id"]), row["pair_type"]) for row in fresh)
    prompt = prompt_audit(fresh, args.base_model, args.max_length)
    matched = matched_training_contract(joint_preflight, factor_preflight)
    compatibility = runtime_compatibility(
        joint_preflight.get("training_runtime"), runtime.training_runtime()
    )
    expected_joint_adapter = joint_gate.get("diagnostic_adapter", {}).get("sha256")
    expected_factor_adapter = factor_gate.get("diagnostic_adapter", {}).get("sha256")
    confirmation_artifacts = confirmation_preflight.get("artifacts", {})
    checks = {
        "fresh_build_coverage_pass": fresh_summary.get("coverage_pass") is True,
        "fresh_audit_pass": fresh_audit.get("audit_pass") is True,
        "fresh_pairs_bound_to_summary": fresh_summary.get("artifacts", {})
        .get("pairs", {})
        .get("sha256")
        == file_sha256(args.fresh_pairs),
        "fresh_bytes_match_factorized_confirmation": confirmation_artifacts.get(
            "fresh_pairs", {}
        ).get("sha256")
        == file_sha256(args.fresh_pairs),
        "joint_preflight_pass": joint_preflight.get("preflight_pass") is True,
        "factorized_preflight_pass": factor_preflight.get("preflight_pass") is True,
        "joint_gate_bound_to_preflight": joint_gate.get("preflight_sha256")
        == file_sha256(args.joint_preflight),
        "factorized_gate_bound_to_preflight": factor_gate.get("preflight_sha256")
        == file_sha256(args.factorized_preflight),
        "joint_adapter_current": adapter_hash(args.joint_adapter)
        == expected_joint_adapter,
        "factorized_adapter_current": adapter_hash(args.factorized_adapter)
        == expected_factor_adapter,
        "factorized_confirmation_pass": confirmation_gate.get(
            "confirmation_gate_pass"
        )
        is True,
        "factorized_confirmation_bound_to_preflight": confirmation_gate.get(
            "preflight_sha256"
        )
        == file_sha256(args.factorized_confirmation_preflight),
        "factorized_confirmation_records_current": confirmation_gate.get(
            "records", {}
        ).get("sha256")
        == file_sha256(args.factorized_confirmation_records),
        "factorized_confirmation_method_present":
            "physics_aligned_factorized_llm" in methods,
        "training_contract_matched": all(
            value
            for key, value in matched.items()
            if key != "schedule_field_matches"
        ) and all(matched["schedule_field_matches"].values()),
        "fresh_rows_192": len(fresh) == 192,
        "fresh_pair_clusters_96": len({row["pair_id"] for row in fresh}) == 96,
        "fresh_physical_states_66": len(
            {row["physical_state_sha256"] for row in fresh}
        )
        == 66,
        "primary_rows_96": sum(
            row["pair_type"] == PRIMARY_PAIR_TYPE for row in fresh
        )
        == 96,
        "primary_48_rows_each_network": all(
            pair_mix[(network, PRIMARY_PAIR_TYPE)] == 48
            for network in ("33", "69")
        ),
        "prompt_length": prompt["prompt_length_pass"],
        "topk_one": args.topk == 1,
        "bootstrap_10000_or_more": args.bootstrap_reps >= 10000,
        "fixed_evaluation_seed": args.seed == 20260903,
        "runtime_compatible": compatibility["compatible"],
    }
    artifacts = {
        "fresh_pairs": args.fresh_pairs,
        "fresh_summary": args.fresh_summary,
        "fresh_audit": args.fresh_audit,
        "joint_preflight": args.joint_preflight,
        "joint_gate": args.joint_gate,
        "factorized_preflight": args.factorized_preflight,
        "factorized_gate": args.factorized_gate,
        "factorized_confirmation_preflight": args.factorized_confirmation_preflight,
        "factorized_confirmation_gate": args.factorized_confirmation_gate,
        "factorized_confirmation_records": args.factorized_confirmation_records,
    }
    manifest = {
        "msg": "GridRank matched factorization-ablation preflight",
        "schema": SCHEMA,
        "experiment_id": EXPERIMENT_ID,
        "preflight_pass": all(checks.values()),
        "evaluation_only": True,
        "training_performed": False,
        "model_loaded": False,
        "power_flow_calls": 0,
        "confirmation_reuse_disclosed": True,
        "freshness_boundary": (
            "The 192-row confirmation set was already opened for the factorized "
            "main result. This is a post-confirmation matched ablation, not a new "
            "independent confirmatory test."
        ),
        "primary_hypothesis": (
            "On unseen maintenance+voltage compositions, factorized GridRank has "
            "lower normalized regret than the matched joint four-card GridRank."
        ),
        "artifacts": {
            name: {"path": str(Path(path).resolve()), "sha256": file_sha256(path)}
            for name, path in artifacts.items()
        },
        "adapters": {
            "joint_card": {
                "path": str(Path(args.joint_adapter).resolve()),
                "sha256": adapter_hash(args.joint_adapter),
            },
            "factorized": {
                "path": str(Path(args.factorized_adapter).resolve()),
                "sha256": adapter_hash(args.factorized_adapter),
            },
        },
        "base_model": str(Path(args.base_model).resolve()),
        "base_model_inventory": runtime.model_inventory(args.base_model),
        "locked_training_runtime": joint_preflight.get("training_runtime"),
        "runtime_compatibility": compatibility,
        "matched_training_contract": matched,
        "schedule": schedule(args),
        "fresh_partition": {
            "rows": len(fresh),
            "pair_clusters": len({row["pair_id"] for row in fresh}),
            "physical_states": len(
                {row["physical_state_sha256"] for row in fresh}
            ),
            "primary_rows": sum(
                row["pair_type"] == PRIMARY_PAIR_TYPE for row in fresh
            ),
        },
        "prompt_audit": prompt,
        "code_sha256": code_hashes(),
        "checks": checks,
        "failed_checks": [key for key, value in checks.items() if not value],
    }
    output.write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps(manifest, ensure_ascii=False))
    if not manifest["preflight_pass"]:
        raise SystemExit(2)


def verify(args):
    manifest = json.load(open(args.output, encoding="utf-8"))
    checks = {
        "schema": manifest.get("schema") == SCHEMA,
        "experiment_id": manifest.get("experiment_id") == EXPERIMENT_ID,
        "preflight_pass": manifest.get("preflight_pass") is True,
        "artifacts_current": all(
            Path(item["path"]).is_file()
            and file_sha256(item["path"]) == item["sha256"]
            for item in manifest.get("artifacts", {}).values()
        ),
        "adapters_current": all(
            adapter_hash(item["path"]) == item["sha256"]
            for item in manifest.get("adapters", {}).values()
        ),
        "base_model_current": runtime.model_inventory(manifest["base_model"])
        == manifest["base_model_inventory"],
        "runtime_compatible": runtime_compatibility(
            manifest.get("locked_training_runtime"), runtime.training_runtime()
        )["compatible"],
        "schedule_current": manifest.get("schedule") == schedule(args),
        "code_current": manifest.get("code_sha256") == code_hashes(),
    }
    result = {
        "msg": "GridRank factorization-ablation runtime verification",
        "checks": checks,
        "verification_pass": all(checks.values()),
    }
    print(json.dumps(result, ensure_ascii=False))
    if not result["verification_pass"]:
        raise SystemExit(2)


def main():
    args = parse_args()
    if Path(args.output).exists():
        verify(args)
    else:
        create(args)


if __name__ == "__main__":
    main()
