"""Evaluate GridRank label controls extension."""

from __future__ import annotations

import argparse
import json
import os
import random
from collections import defaultdict
from pathlib import Path
from types import SimpleNamespace

from aggregate_gridrank_label_controls_hotfix import reconstruct_state_rows
from build_gridrank_select import file_sha256
from preflight_gridrank_label_controls_extension import METHODS, verify
import train_gridrank_select as base


SCHEMA = "gridrank-label-controls-extension-gate-v1"
EPS = 1e-12


def _json(path):
    return json.load(open(path, encoding="utf-8"))


def _mapping(values, expected, label):
    output = {}
    for value in values:
        name, raw = value.split("=", 1)
        output[name] = Path(raw).resolve()
    if set(output) != set(expected):
        raise ValueError(f"{label} requires exactly {tuple(expected)}")
    return output


def _adapter_hash(path):
    root = Path(path)
    return {
        "adapter_config_json": file_sha256(root / "adapter_config.json"),
        "adapter_model_safetensors": file_sha256(root / "adapter_model.safetensors"),
    }


def _evaluate(model, tokenizer, rows, args, adapter):
    import torch

    output = []
    with torch.inference_mode():
        for row in rows:
            scores = base.score_row(
                model, tokenizer, row, args, False, adapter=adapter
            ).detach().float().cpu()
            output.append(base.record_from_scores(row, scores, args.topk))
    return output


def _state_rows(records):
    return [{
        "instance_id": row["instance_id"],
        "network": str(row["network"]),
        "physical_state_sha256": row["physical_state_sha256"],
        "safe_regret": float(row["safe_regret"]),
        "safe_action": row["safe_action"],
        "safe_feasible": bool(row["safe_feasible"]),
    } for row in records]


def _normalise_reconstructed(rows):
    return [{
        "instance_id": row["instance_id"],
        "network": str(row["network"]),
        "physical_state_sha256": row["physical_state_sha256"],
        "safe_regret": float(row["distilled_safe_regret"]),
        "safe_action": row["selected_action"],
        "safe_feasible": True,
    } for row in rows]


def _sft_original_rows(full_gate):
    rows = full_gate["paired"]["distilled_vs_sft"]["state_rows"]
    return [{
        "instance_id": row["instance_id"],
        "network": str(row["network"]),
        "physical_state_sha256": row["physical_state_sha256"],
        "safe_regret": float(row["sft_safe_regret"]),
        "safe_action": row["sft_safe_action"],
        "safe_feasible": bool(row["sft_safe_feasible"]),
    } for row in rows]


def _percentile(values, probability):
    ordered = sorted(values)
    return ordered[int(probability * (len(ordered) - 1))]


def _paired(before_rows, after_rows, reps, seed):
    before = {row["instance_id"]: row for row in before_rows}
    after = {row["instance_id"]: row for row in after_rows}
    if set(before) != set(after):
        raise RuntimeError("paired extension state identities differ")
    keys = sorted(before)
    deltas, groups = [], defaultdict(list)
    for key in keys:
        old, new = before[key], after[key]
        identity = (old["network"], old["physical_state_sha256"])
        if identity != (new["network"], new["physical_state_sha256"]):
            raise RuntimeError("paired extension physical state changed")
        delta = float(old["safe_regret"]) - float(new["safe_regret"])
        deltas.append(delta)
        groups[identity].append(delta)
    clusters = [sum(values) / len(values) for values in groups.values()]
    rng = random.Random(seed)
    draws = [
        sum(clusters[rng.randrange(len(clusters))] for _ in clusters) / len(clusters)
        for _ in range(reps)
    ]
    return {
        "n_rows": len(deltas),
        "n_state_clusters": len(clusters),
        "safe_regret_improvement_mean": sum(deltas) / len(deltas),
        "state_cluster_bootstrap_ci95": [
            _percentile(draws, 0.025), _percentile(draws, 0.975)
        ],
        "rows_better": sum(value > EPS for value in deltas),
        "rows_worse": sum(value < -EPS for value in deltas),
        "rows_tied": sum(abs(value) <= EPS for value in deltas),
    }


def _comparison(before_rows, after_rows, reps, seed):
    result = _paired(before_rows, after_rows, reps, seed)
    result["by_network"] = {}
    for offset, network in enumerate(("33", "69")):
        before = [row for row in before_rows if row["network"] == network]
        after = [row for row in after_rows if row["network"] == network]
        result["by_network"][network] = _paired(
            before, after, reps, seed + 100 + offset
        )
    return result


def _summary(rows):
    return {
        "n": len(rows),
        "safe_regret_mean": sum(row["safe_regret"] for row in rows) / len(rows),
        "safe_feasible_rate": sum(row["safe_feasible"] for row in rows) / len(rows),
    }


def _analysis(method_rows, reps, seed):
    full = method_rows["full_gridrank"]
    shuffled = method_rows["shuffled_labels"]
    lindistflow = method_rows["lindistflow_labels"]
    sft = method_rows["frozen_sft"]
    return {
        "n_states": len(full),
        "summaries": {name: _summary(rows) for name, rows in method_rows.items()},
        "comparisons": {
            "full_gridrank_vs_shuffled_labels": _comparison(
                shuffled, full, reps, seed + 1
            ),
            "full_gridrank_vs_lindistflow_labels": _comparison(
                lindistflow, full, reps, seed + 2
            ),
            "full_gridrank_vs_frozen_sft": _comparison(sft, full, reps, seed + 3),
            "shuffled_labels_vs_frozen_sft": _comparison(
                sft, shuffled, reps, seed + 4
            ),
            "lindistflow_labels_vs_frozen_sft": _comparison(
                sft, lindistflow, reps, seed + 5
            ),
        },
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--extension_test", required=True)
    parser.add_argument("--original_test", required=True)
    parser.add_argument("--method_gate", action="append", required=True)
    parser.add_argument("--method_adapter", action="append", required=True)
    parser.add_argument("--preflight_manifest", required=True)
    parser.add_argument("--sft_adapter", required=True)
    parser.add_argument("--base_model", required=True)
    parser.add_argument("--physics_python", required=True)
    parser.add_argument("--physics_timeout_s", type=float, default=60.0)
    parser.add_argument("--max_length", type=int, default=1024)
    parser.add_argument("--candidate_batch_size", type=int, default=4)
    parser.add_argument("--topk", type=int, default=3)
    parser.add_argument("--bootstrap_reps", type=int, default=10000)
    parser.add_argument("--bootstrap_seed", type=int, default=20260812)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    if args.topk != 3 or args.bootstrap_reps != 10000 \
            or args.bootstrap_seed != 20260812:
        raise ValueError("label-control extension schedule drift")
    output = Path(args.output)
    if output.exists():
        raise FileExistsError(f"refusing to overwrite {output}")
    gates = _mapping(args.method_gate, METHODS, "method_gate")
    adapters = _mapping(args.method_adapter, METHODS, "method_adapter")
    manifest = verify(
        args.preflight_manifest, args.base_model,
        args.physics_python, args.bootstrap_reps,
    )
    if file_sha256(args.extension_test) \
            != manifest["artifacts"]["extension_test"]["sha256"]:
        raise RuntimeError("extension test changed after preflight")
    if file_sha256(args.original_test) \
            != manifest["artifacts"]["original_test"]["sha256"]:
        raise RuntimeError("original test changed after preflight")
    for name in METHODS:
        if str(gates[name]) != manifest["method_gates"][name]["path"]:
            raise RuntimeError(f"wrong locked gate: {name}")
        if str(adapters[name]) != manifest["method_adapters"][name]["path"]:
            raise RuntimeError(f"wrong locked adapter: {name}")

    import torch
    import grpo_train as training

    if not torch.cuda.is_available():
        raise RuntimeError("label-control extension evaluation requires CUDA")
    extension_rows = base.load_rows(args.extension_test, "test", args.topk)
    original_rows = base.load_rows(args.original_test, "test", args.topk)
    if len(extension_rows) != 64 or len(original_rows) != 64:
        raise RuntimeError("locked 64+64 state contract changed")

    before_hashes = {name: _adapter_hash(path) for name, path in adapters.items()}
    model_args = SimpleNamespace(
        base_model=args.base_model,
        resume_adapter_path=args.sft_adapter,
        gradient_checkpointing=0,
    )
    model, tokenizer = training.build_model_and_tokenizer(model_args)
    tokenizer.pad_token = tokenizer.eos_token
    model.config.pad_token_id = tokenizer.pad_token_id
    for name in METHODS:
        model.load_adapter(str(adapters[name]), adapter_name=name, is_trainable=False)
    for parameter in model.parameters():
        parameter.requires_grad_(False)
    model.eval()

    score_args = SimpleNamespace(
        max_length=args.max_length,
        candidate_batch_size=args.candidate_batch_size,
        topk=args.topk,
        physics_python=args.physics_python,
        physics_timeout_s=args.physics_timeout_s,
    )
    extension_records = {
        "frozen_sft": _evaluate(
            model, tokenizer, extension_rows, score_args, "default"
        )
    }
    live = {}
    for name in METHODS:
        extension_records[name] = _evaluate(
            model, tokenizer, extension_rows, score_args, name
        )
        live[name] = base.live_topk_replay(
            extension_rows, extension_records[name], score_args
        )

    gradients_materialized = sum(
        parameter.grad is not None for parameter in model.parameters()
    )
    after_hashes = {name: _adapter_hash(path) for name, path in adapters.items()}
    gate_payloads = {name: _json(path) for name, path in gates.items()}
    original_method_rows = {
        name: _normalise_reconstructed(
            reconstruct_state_rows(gate_payloads[name], original_rows)
        ) for name in METHODS
    }
    original_method_rows["frozen_sft"] = _sft_original_rows(
        gate_payloads["full_gridrank"]
    )
    extension_method_rows = {
        name: _state_rows(records) for name, records in extension_records.items()
    }
    combined_method_rows = {
        name: [*original_method_rows[name], *extension_method_rows[name]]
        for name in ("frozen_sft", *METHODS)
    }
    extension_analysis = _analysis(
        extension_method_rows, args.bootstrap_reps, args.bootstrap_seed
    )
    combined_analysis = _analysis(
        combined_method_rows, args.bootstrap_reps, args.bootstrap_seed + 1000
    )

    live_checks = {
        name: {
            "valid_rate_100pct": live[name]["summary"]["valid_rate"] == 1.0,
            "cache_match_100pct": live[name]["summary"]["cache_labels_match_rate"] == 1.0,
            "safe_action_match_100pct": live[name]["summary"][
                "matches_cached_gate_rate"
            ] == 1.0,
            "selected_feasible_100pct": live[name]["summary"][
                "selected_feasible_rate"
            ] == 1.0,
            "noop_never_ranked": live[name]["summary"]["noop_ranked_rows"] == 0,
        } for name in METHODS
    }
    mechanism_checks = {
        "evaluation_only_no_parameter_updates": True,
        "no_gradients_materialized": gradients_materialized == 0,
        "adapter_files_unchanged": before_hashes == after_hashes,
        "three_frozen_methods_evaluated": set(extension_records)
            == {"frozen_sft", *METHODS},
        "extension_64_and_combined_128": extension_analysis["n_states"] == 64
            and combined_analysis["n_states"] == 128,
        "all_live_checks": all(
            all(values.values()) for values in live_checks.values()
        ),
    }
    combined_shuffled = combined_analysis["comparisons"][
        "full_gridrank_vs_shuffled_labels"
    ]
    combined_lindistflow = combined_analysis["comparisons"][
        "full_gridrank_vs_lindistflow_labels"
    ]
    causal_decision = {
        "full_beats_shuffled_combined_ci_lower_positive":
            combined_shuffled["state_cluster_bootstrap_ci95"][0] > 0.0,
        "full_beats_lindistflow_combined_ci_lower_positive":
            combined_lindistflow["state_cluster_bootstrap_ci95"][0] > 0.0,
        "valid_physics_labels_beyond_format_supported":
            combined_shuffled["state_cluster_bootstrap_ci95"][0] > 0.0,
        "authoritative_ac_beyond_lindistflow_supported":
            combined_lindistflow["state_cluster_bootstrap_ci95"][0] > 0.0,
    }
    result = {
        "msg": "GridRank matched label-controls frozen-adapter extension gate",
        "schema": SCHEMA,
        "experiment_id": manifest["experiment_id"],
        "training_performed": False,
        "parameter_updates": 0,
        "model_forward_only": True,
        "preflight_sha256": file_sha256(args.preflight_manifest),
        "adapter_sha256_before": before_hashes,
        "adapter_sha256_after": after_hashes,
        "extension_64_state_primary": extension_analysis,
        "combined_128_state_primary": combined_analysis,
        "extension_state_evidence": {
            name: extension_method_rows[name]
            for name in ("frozen_sft", *METHODS)
        },
        "live_replay": live,
        "live_checks": live_checks,
        "mechanism_checks": mechanism_checks,
        "evaluation_gate_pass": all(mechanism_checks.values()),
        "causal_decision": causal_decision,
    }
    output.parent.mkdir(parents=True, exist_ok=True)
    tmp = output.with_name(output.name + ".tmp")
    tmp.write_text(json.dumps(result, indent=2, ensure_ascii=False), encoding="utf-8")
    os.replace(tmp, output)
    print(json.dumps({
        "msg": result["msg"],
        "training_performed": False,
        "parameter_updates": 0,
        "extension_64_state_primary": extension_analysis,
        "combined_128_state_primary": combined_analysis,
        "mechanism_checks": mechanism_checks,
        "evaluation_gate_pass": result["evaluation_gate_pass"],
        "causal_decision": causal_decision,
        "full_gate_path": str(output.resolve()),
    }, ensure_ascii=False))
    if not result["evaluation_gate_pass"]:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
