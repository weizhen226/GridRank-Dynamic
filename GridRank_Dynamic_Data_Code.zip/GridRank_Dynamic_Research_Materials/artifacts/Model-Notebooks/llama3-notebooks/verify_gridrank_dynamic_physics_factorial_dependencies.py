"""Validate GridRank dynamic physics factorial dependencies."""

from __future__ import annotations

import ast
import json
from pathlib import Path

import aggregate_gridrank_dynamic_physics_factorial as factorial


HERE = Path(__file__).resolve().parent


def direct_imports(path):
    tree = ast.parse(path.read_text(encoding="utf-8"))
    imports = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            imports.update(alias.name.split(".")[0] for alias in node.names)
        elif isinstance(node, ast.ImportFrom) and node.module:
            imports.add(node.module.split(".")[0])
    return imports


def synthetic_effect_orientations_pass():
    
    regrets = {
        "gridrank_p1": 0.1,
        "gridrank_p0": 0.2,
        "sft_p1": 0.3,
        "sft_p0": 0.5,
    }
    loaded = {cell: {} for cell in factorial.CELLS}
    for cell, regret in regrets.items():
        for seed in factorial.SEEDS:
            loaded[cell][seed] = {
                "records": {
                    factorial.ALIGNED: [
                        {
                            "instance_id": f"toy:{side}",
                            "pair_id": "toy-pair",
                            "pair_type": factorial.PRIMARY_PAIR_TYPE,
                            "normalised_regret": regret,
                        }
                        for side in ("left", "right")
                    ]
                }
            }
    effects = factorial._effect_matrices(loaded, factorial.PRIMARY_PAIR_TYPE)
    expected = {
        "prealignment_at_p1": 0.2,
        "prealignment_at_p0": 0.3,
        "static_prealignment_main": 0.25,
        "dynamic_loss_with_gridrank": 0.1,
        "dynamic_loss_with_sft": 0.2,
        "dynamic_loss_main": 0.15,
        "interaction_dynamic_loss_sft_minus_gridrank": 0.1,
        "tested_pipeline_full_vs_minimal": 0.4,
    }
    return all(
        abs(effects[name][seed]["toy-pair"] - target) < 1e-12
        for name, target in expected.items()
        for seed in factorial.SEEDS
    )


def main():
    runner = (HERE / "run_gridrank_dynamic_physics_factorial.sh").read_text(
        encoding="utf-8"
    )
    preflight = (HERE / "preflight_gridrank_dynamic_physics_factorial.py").read_text(
        encoding="utf-8"
    )
    trainer = (HERE / "train_gridrank_dynamic_physics_factorial.py").read_text(
        encoding="utf-8"
    )
    aggregate_path = HERE / "aggregate_gridrank_dynamic_physics_factorial.py"
    aggregate_text = aggregate_path.read_text(encoding="utf-8")
    imports = direct_imports(aggregate_path)
    checks = {
        "two_initializations_declared": all(
            token in aggregate_text for token in ("gridrank_p1", "sft_p1")
        ),
        "two_physics_levels_declared": all(
            token in aggregate_text for token in ("gridrank_p0", "sft_p0")
        ),
        "three_predeclared_seeds": "for seed in 42 123 2025" in runner,
        "only_missing_sft_cells_trained": (
            '--resume_adapter_path "$SFT_ADAPTER"' in runner
            and "for physics in 1 0" in runner
        ),
        "locked_factorized_trainer_delegated": (
            "import train_gridrank_dynamic_factorized as locked_trainer" in trainer
        ),
        "initial_adapter_must_equal_sft": "initial_adapter_is_frozen_sft" in preflight,
        "initialization_must_differ_gridrank": (
            "sft_initialization_differs_from_gridrank" in preflight
        ),
        "main_effects_present": all(
            token in aggregate_text
            for token in (
                "static_prealignment_main",
                "dynamic_loss_main",
                "interaction_dynamic_loss_sft_minus_gridrank",
                "tested_pipeline_full_vs_minimal",
            )
        ),
        "aggregate_has_no_model_libraries": not bool(
            imports & {"torch", "transformers", "peft", "bitsandbytes"}
        ),
        "aggregate_has_no_powerflow_libraries": not bool(
            imports & {"pandapower", "simbench"}
        ),
        "post_confirmation_boundary_explicit": "not a fresh test" in runner
        or "post-confirmation" in aggregate_text,
        "minimal_cell_not_called_physics_free": "not an all-physics versus zero-physics"
        in aggregate_text,
        "synthetic_effect_orientations": synthetic_effect_orientations_pass(),
    }
    result = {
        "msg": "GridRank dynamic physics-source factorial dependency verification",
        "checks": checks,
        "verification_pass": all(checks.values()),
        "training_performed": False,
        "model_loaded": False,
        "power_flow_calls": 0,
    }
    print(json.dumps(result, ensure_ascii=False))
    if not result["verification_pass"]:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
