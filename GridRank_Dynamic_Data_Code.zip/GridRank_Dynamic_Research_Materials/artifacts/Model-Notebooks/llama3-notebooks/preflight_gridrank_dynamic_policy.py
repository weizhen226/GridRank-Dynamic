"""Check inputs for GridRank dynamic policy."""

from __future__ import annotations

import argparse
import hashlib
import json
import math
from collections import Counter
from pathlib import Path

import preflight_gridrank_feedback as runtime
import preflight_gridrank_dynamic_benchmark as benchmark
from build_gridrank_instruction_pairs import selected_action, structured_proxy_order
from gridrank_dynamic_llm import (
    CARDS, card_ids, card_semantics, oracle_card_id, render_card_prompt,
)


HERE = Path(__file__).resolve().parent
SCHEMA = "gridrank-dynamic-policy-preflight-v1"
EXPERIMENT_ID = "gridrank-physics-certified-dynamic-policy-v1"
WITHHELD_PAIR_TYPE = "maintenance_voltage"
CODE_FILES = (
    "build_gridrank_instruction_pairs.py",
    "preflight_gridrank_dynamic_benchmark.py",
    "gridrank_dynamic_llm.py",
    "preflight_gridrank_dynamic_policy.py",
    "train_gridrank_dynamic_policy.py",
    "verify_gridrank_dynamic_policy.py",
    "verify_gridrank_dynamic_policy_dependencies.py",
    "run_gridrank_dynamic_policy.sh",
    "grpo_train.py",
    "../../docs/GRIDRANK_DYNAMIC_POLICY_PROTOCOL.md",
)


def file_sha256(path):
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def adapter_hash(path):
    root = Path(path)
    return {
        "adapter_config_json": file_sha256(root / "adapter_config.json"),
        "adapter_model_safetensors": file_sha256(root / "adapter_model.safetensors"),
    }


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--train_jsonl", required=True)
    parser.add_argument("--validation_jsonl", required=True)
    parser.add_argument("--pair_summary", required=True)
    parser.add_argument("--benchmark_manifest", required=True)
    parser.add_argument("--resume_adapter_path", required=True)
    parser.add_argument("--sft_adapter_path", required=True)
    parser.add_argument("--base_model", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--max_length", type=int, required=True)
    parser.add_argument("--card_batch_size", type=int, required=True)
    parser.add_argument("--epochs", type=int, required=True)
    parser.add_argument("--learning_rate", type=float, required=True)
    parser.add_argument("--grad_accum", type=int, required=True)
    parser.add_argument("--max_grad_norm", type=float, required=True)
    parser.add_argument("--target_temperature", type=float, required=True)
    parser.add_argument("--lambda_semantic", type=float, required=True)
    parser.add_argument("--lambda_physics", type=float, required=True)
    parser.add_argument("--lambda_hard", type=float, required=True)
    parser.add_argument("--hard_margin", type=float, required=True)
    parser.add_argument("--beta_reference", type=float, required=True)
    parser.add_argument("--seed", type=int, required=True)
    parser.add_argument("--gradient_checkpointing", type=int, choices=(0, 1), required=True)
    parser.add_argument("--bootstrap_reps", type=int, required=True)
    return parser.parse_args()


def schedule(args):
    keys = (
        "max_length", "card_batch_size", "epochs", "learning_rate",
        "grad_accum", "max_grad_norm", "target_temperature",
        "lambda_semantic", "lambda_physics", "lambda_hard",
        "hard_margin", "beta_reference", "seed",
        "gradient_checkpointing", "bootstrap_reps",
    )
    return {key: getattr(args, key) for key in keys}


def action_regret(row, action):
    return benchmark.action_regret(row, action)


def card_outcomes(row):
    values = []
    for card in CARDS:
        semantic = card_semantics(row, card["card_id"], benchmark.extract_edges)
        ranking = structured_proxy_order(
            row, semantic["objective"], semantic["forbidden_edges"]
        )
        action = selected_action(row, ranking, 1)
        values.append({
            "card_id": card["card_id"],
            "action": action,
            "normalised_regret": action_regret(row, action),
        })
    return values


def physics_target(outcomes, temperature):
    import math

    values = [-float(item["normalised_regret"]) / temperature for item in outcomes]
    maximum = max(values)
    weights = [math.exp(value - maximum) for value in values]
    total = sum(weights)
    return [value / total for value in weights]


def training_selection(rows):
    selected, rejected = [], Counter()
    for row in rows:
        if row["pair_type"] == WITHHELD_PAIR_TYPE:
            rejected["withheld_composition"] += 1
            continue
        outcomes = card_outcomes(row)
        oracle = oracle_card_id(row)
        oracle_value = next(
            item["normalised_regret"] for item in outcomes if item["card_id"] == oracle
        )
        best = min(item["normalised_regret"] for item in outcomes)
        if oracle_value > best + 1e-6:
            rejected["structured_card_not_physics_optimal"] += 1
            continue
        selected.append(row)
    return selected, dict(rejected)


def code_hashes():
    missing = [name for name in CODE_FILES if not (HERE / name).is_file()]
    if missing:
        raise FileNotFoundError(f"missing dynamic-policy code: {missing}")
    return {name: file_sha256(HERE / name) for name in CODE_FILES}


def prompt_audit(rows, base_model, max_length):
    from transformers import AutoTokenizer

    tokenizer = AutoTokenizer.from_pretrained(base_model, local_files_only=True)
    maximum, count, truncated = 0, 0, 0
    for row in rows:
        for card in CARDS:
            text = render_card_prompt(tokenizer, row, card)
            length = len(tokenizer(text, add_special_tokens=False)["input_ids"])
            maximum = max(maximum, length)
            count += 1
            truncated += int(length > max_length)
    return {
        "prompts": count, "max_tokens": maximum,
        "truncated_prompts": truncated,
        "prompt_length_pass": truncated == 0,
    }


def create(args):
    output = Path(args.output)
    if output.exists():
        raise FileExistsError(f"refusing to overwrite preflight: {output}")
    train_all = benchmark.load_rows(args.train_jsonl, "train")
    validation_all = benchmark.load_rows(args.validation_jsonl, "validation")
    validation = sorted(
        [row for row in validation_all if int(row["paraphrase_index"]) == 0],
        key=lambda row: row["instance_id"],
    )
    composition = [row for row in validation if row["pair_type"] == WITHHELD_PAIR_TYPE]
    selected, rejected = training_selection(train_all)
    selected_ids = [row["instance_id"] for row in selected]
    prompt = prompt_audit(selected + validation, args.base_model, args.max_length)
    dynamic_manifest = json.load(open(args.benchmark_manifest, encoding="utf-8"))


    benchmark_requires_fresh_final = bool(
        dynamic_manifest.get("fresh_final_test_required_after_model_selection") is True
        or dynamic_manifest.get("fresh_final_test_required") is True
    )
    pair_summary = json.load(open(args.pair_summary, encoding="utf-8"))
    selected_mix = Counter((str(row["network_id"]), row["pair_type"]) for row in selected)
    validation_ids = [row["instance_id"] for row in validation]
    composition_ids = [row["instance_id"] for row in composition]
    checks = {
        "dynamic_benchmark_pass": dynamic_manifest.get("preflight_pass") is True,
        "dynamic_benchmark_authorized": dynamic_manifest.get("decision") == "authorize_dynamic_llm_seed42_preflight",
        "pair_gate_pass": pair_summary.get("coverage_pass") is True,
        "benchmark_artifacts_match": all(
            dynamic_manifest.get("artifacts", {}).get(name, {}).get("sha256") == file_sha256(path)
            for name, path in (
                ("train", args.train_jsonl),
                ("validation", args.validation_jsonl),
                ("pair_summary", args.pair_summary),
            )
        ),
        "composition_absent_from_training": all(
            row["pair_type"] != WITHHELD_PAIR_TYPE for row in selected
        ),
        "physics_certified_training_rows_ge_80": len(selected) >= 80,
        "both_seen_pair_types_both_networks": all(
            selected_mix[(network, pair_type)] > 0
            for network in ("33", "69")
            for pair_type in ("objective", "maintenance_loss")
        ),
        "validation_rows_96": len(validation) == 96,
        "composition_rows_32": len(composition) == 32,
        "four_semantic_cards": len(card_ids()) == 4,
        "top1_interface": dynamic_manifest.get("topk") == 1,
        "frozen_seed_42": args.seed == 42,
        "positive_schedule": all(
            isinstance(value, (int, float)) and value > 0
            for value in schedule(args).values()
        ),
        "prompt_length": prompt["prompt_length_pass"],
        "fresh_final_test_required": benchmark_requires_fresh_final,
    }
    manifest = {
        "msg": "GridRank physics-certified dynamic semantic-policy preflight",
        "schema": SCHEMA,
        "experiment_id": EXPERIMENT_ID,
        "preflight_pass": all(checks.values()),
        "training_performed": False,
        "model_loaded": False,
        "power_flow_calls": 0,
        "development_reuse_disclosed": True,
        "fresh_final_test_required": True,
        "upstream_fresh_final_test_field": (
            "fresh_final_test_required_after_model_selection"
            if dynamic_manifest.get("fresh_final_test_required_after_model_selection") is True
            else "fresh_final_test_required"
        ),
        "artifacts": {
            "train": {"path": str(Path(args.train_jsonl).resolve()), "sha256": file_sha256(args.train_jsonl)},
            "validation": {"path": str(Path(args.validation_jsonl).resolve()), "sha256": file_sha256(args.validation_jsonl)},
            "pair_summary": {"path": str(Path(args.pair_summary).resolve()), "sha256": file_sha256(args.pair_summary)},
            "dynamic_benchmark": {"path": str(Path(args.benchmark_manifest).resolve()), "sha256": file_sha256(args.benchmark_manifest)},
        },
        "adapters": {
            "gridrank": {"path": str(Path(args.resume_adapter_path).resolve()), "sha256": adapter_hash(args.resume_adapter_path)},
            "sft": {"path": str(Path(args.sft_adapter_path).resolve()), "sha256": adapter_hash(args.sft_adapter_path)},
        },
        "base_model": str(Path(args.base_model).resolve()),
        "base_model_inventory": runtime.model_inventory(args.base_model),
        "training_runtime": runtime.training_runtime(),
        "schedule": schedule(args),
        "selection": {
            "rule": (
                "exclude maintenance_voltage; retain only rows whose structured semantic card "
                "is AC-regret-optimal among four cards; no validation outcome used"
            ),
            "all_train_rows": len(train_all),
            "selected_train_rows": len(selected),
            "rejected": rejected,
            "selected_mix": {f"{a}:{b}": value for (a, b), value in sorted(selected_mix.items())},
            "train_row_ids": selected_ids,
            "validation_row_ids": validation_ids,
            "composition_row_ids": composition_ids,
        },
        "prompt_audit": prompt,
        "code_sha256": code_hashes(),
        "checks": checks,
        "failed_checks": [key for key, value in checks.items() if not value],
    }
    output.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(manifest, ensure_ascii=False))
    if not manifest["preflight_pass"]:
        raise SystemExit(2)


def verify(args):
    from gridrank_runtime_compat import runtime_compatibility

    manifest = json.load(open(args.output, encoding="utf-8"))
    artifact_checks = {
        name: Path(item["path"]).is_file() and file_sha256(item["path"]) == item["sha256"]
        for name, item in manifest.get("artifacts", {}).items()
    }
    adapter_checks = {
        name: adapter_hash(item["path"]) == item["sha256"]
        for name, item in manifest.get("adapters", {}).items()
    }
    checks = {
        "schema": manifest.get("schema") == SCHEMA,
        "experiment_id": manifest.get("experiment_id") == EXPERIMENT_ID,
        "preflight_pass": manifest.get("preflight_pass") is True,
        "artifacts_current": bool(artifact_checks) and all(artifact_checks.values()),
        "adapters_current": bool(adapter_checks) and all(adapter_checks.values()),
        "base_model_current": manifest.get("base_model_inventory") == runtime.model_inventory(manifest.get("base_model")),
        "runtime_compatible": runtime_compatibility(
            manifest.get("training_runtime"), runtime.training_runtime()
        )["compatible"],
        "schedule_current": manifest.get("schedule") == schedule(args),
        "code_current": manifest.get("code_sha256") == code_hashes(),
    }
    result = {
        "msg": "GridRank dynamic-policy runtime verification",
        "checks": checks, "verification_pass": all(checks.values()),
    }
    print(json.dumps(result, ensure_ascii=False))
    if not result["verification_pass"]:
        raise SystemExit(2)


def main():
    args = parse_args()
    if Path(args.output).exists():
        verify(args)
    else:
        create(args)


if __name__ == "__main__":
    main()
