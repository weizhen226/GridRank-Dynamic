"""Train GridRank dynamic physics ablation."""

from __future__ import annotations

import sys
from pathlib import Path

import preflight_gridrank_dynamic_physics_ablation as ablation_preflight


sys.modules["preflight_gridrank_dynamic_factorized"] = ablation_preflight

import train_gridrank_dynamic_factorized as locked_trainer  


def _argument(name):
    index = sys.argv.index(name)
    return sys.argv[index + 1]


if __name__ == "__main__":
    try:
        locked_trainer.main()
    except SystemExit as exc:


        output = Path(_argument("--output_dir"))
        complete = (
            (output / "gridrank_dynamic_factorized_gate.json").is_file()
            and (output / "diagnostic_adapter" / "adapter_config.json").is_file()
            and (output / "diagnostic_adapter" / "adapter_model.safetensors").is_file()
        )
        if exc.code == 2 and complete:
            print(
                '{"msg":"no-physics ablation model artifact complete",'
                '"original_efficacy_exit_accepted":true}'
            )
        else:
            raise
