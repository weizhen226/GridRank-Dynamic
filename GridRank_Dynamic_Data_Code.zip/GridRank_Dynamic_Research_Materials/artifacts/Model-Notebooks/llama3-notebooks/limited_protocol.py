"""Limited protocol utilities."""

DEADBAND_PCT = 0.05   


def bucket(hr):
    
    return ("none" if hr <= DEADBAND_PCT else "low" if hr < 2.0
            else "mid" if hr < 10.0 else "high")
