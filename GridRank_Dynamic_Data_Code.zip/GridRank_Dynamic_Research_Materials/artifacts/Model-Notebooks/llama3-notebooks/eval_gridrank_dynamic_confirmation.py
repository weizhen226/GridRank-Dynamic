"""Evaluate GridRank dynamic confirmation."""

from __future__ import annotations

import argparse
import gc
import json
import random
from collections import defaultdict
from pathlib import Path
from types import SimpleNamespace

import preflight_gridrank_dynamic_benchmark as benchmark
import preflight_gridrank_dynamic_confirmation as preflight
import train_gridrank_dynamic_factorized as factorized
import train_gridrank_dynamic_policy as joint


PRIMARY_PAIR_TYPE = "maintenance_voltage"


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--fresh_pairs", required=True)
    parser.add_argument("--original_train", required=True)
    parser.add_argument("--preflight_manifest", required=True)
    parser.add_argument("--factorized_adapter", required=True)
    parser.add_argument("--base_model", required=True)
    parser.add_argument("--output_dir", required=True)
    parser.add_argument("--max_length", type=int, required=True)
    parser.add_argument("--primitive_batch_size", type=int, required=True)
    parser.add_argument("--topk", type=int, required=True)
    parser.add_argument("--bootstrap_reps", type=int, required=True)
    parser.add_argument("--seed", type=int, required=True)
    parser.add_argument("--gradient_checkpointing", type=int, choices=(0, 1), required=True)
    return parser.parse_args()


def read_rows(path):
    return [json.loads(line) for line in open(path, encoding="utf-8") if line.strip()]


def write_records(path, records):
    with open(path, "x", encoding="utf-8", newline="\n") as handle:
        for method in sorted(records):
            for row in records[method]:
                handle.write(json.dumps({"method": method, **row}, ensure_ascii=False, sort_keys=True) + "\n")


def positive(value):
    return value is not None and value > 0


def main():
    import torch
    import grpo_train as training

    args = parse_args()
    output = Path(args.output_dir)
    if output.exists():
        raise FileExistsError(f"refusing to overwrite fresh confirmation output: {output}")
    preflight_args = SimpleNamespace(**vars(args), output=args.preflight_manifest)


    manifest = json.load(open(args.preflight_manifest, encoding="utf-8"))
    locked = {name: value["path"] for name, value in manifest["artifacts"].items()}
    for key, value in {
        "fresh_summary": locked["fresh_summary"],
        "fresh_audit": locked["fresh_audit"],
        "original_validation": locked["original_validation"],
        "factorized_preflight": locked["factorized_preflight"],
        "factorized_gate": locked["factorized_gate"],
    }.items():
        setattr(preflight_args, key, value)
    preflight_args.fresh_pairs = locked["fresh_pairs"]
    preflight_args.original_train = locked["original_train"]
    preflight.verify(preflight_args)
    if not torch.cuda.is_available():
        raise RuntimeError("fresh factorized confirmation requires CUDA")
    random.seed(args.seed)
    torch.manual_seed(args.seed)
    torch.cuda.manual_seed_all(args.seed)

    fresh_rows = read_rows(args.fresh_pairs)
    original_train = read_rows(args.original_train)
    model_args = SimpleNamespace(
        base_model=args.base_model,
        resume_adapter_path=args.factorized_adapter,
        output_dir=args.output_dir,
        gradient_checkpointing=args.gradient_checkpointing,
    )
    model, tokenizer = training.build_model_and_tokenizer(model_args)
    for parameter in model.parameters():
        parameter.requires_grad_(False)
    model.eval()
    model.config.use_cache = False

    aligned = factorized.primitive_score_cache(
        model, tokenizer, fresh_rows, args, "default", "correct"
    )
    removed = factorized.primitive_score_cache(
        model, tokenizer, fresh_rows, args, "default", "instruction_removed"
    )
    counterfactual = factorized.primitive_score_cache(
        model, tokenizer, fresh_rows, args, "default", "instruction_counterfactual"
    )
    gc.collect()
    torch.cuda.empty_cache()

    full_text = benchmark.fit_text_parser(original_train, 20260826)
    withheld_rows = [
        row for row in original_train if row["pair_type"] != PRIMARY_PAIR_TYPE
    ]
    withheld_text = benchmark.fit_text_parser(withheld_rows, 20260926)
    predictions = {
        "fixed_loss_lindistflow": benchmark.fixed_predictions(fresh_rows),
        "frozen_rule_parser_lindistflow": benchmark.rule_predictions(fresh_rows),
        "tfidf_logreg_lindistflow_positive_control": benchmark.predict_text_parser(
            full_text, fresh_rows
        ),
        "tfidf_logreg_withheld_composition": benchmark.predict_text_parser(
            withheld_text, fresh_rows
        ),
        "oracle_structured_lindistflow": benchmark.oracle_predictions(fresh_rows),
    }
    records = {
        name: joint.records_from_predictions(fresh_rows, values, name)
        for name, values in predictions.items()
    }
    composed = {
        "physics_aligned_factorized_llm": factorized.composed_score_cache(aligned),
        "instruction_removed": factorized.composed_score_cache(removed),
        "instruction_counterfactual": factorized.composed_score_cache(counterfactual),
    }
    records.update({
        name: joint.records_from_scores(
            fresh_rows,
            values,
            name if name in {"instruction_removed", "instruction_counterfactual"} else "correct",
        )
        for name, values in composed.items()
    })
    records["full_ac_oracle"] = joint.full_ac_oracle_records(fresh_rows)
    summaries = {name: joint.summarize(values) for name, values in records.items()}
    aligned_records = records["physics_aligned_factorized_llm"]
    hidden = lambda values: joint.subset(values, PRIMARY_PAIR_TYPE)
    paired = {
        "aligned_vs_fixed": joint.paired(
            records["fixed_loss_lindistflow"], aligned_records,
            args.bootstrap_reps, args.seed + 100,
        ),
        "aligned_vs_rule": joint.paired(
            records["frozen_rule_parser_lindistflow"], aligned_records,
            args.bootstrap_reps, args.seed + 200,
        ),
        "aligned_vs_full_tfidf_positive_control": joint.paired(
            records["tfidf_logreg_lindistflow_positive_control"], aligned_records,
            args.bootstrap_reps, args.seed + 300,
        ),
        "correct_vs_removed": joint.paired(
            records["instruction_removed"], aligned_records,
            args.bootstrap_reps, args.seed + 400,
        ),
        "correct_vs_counterfactual": joint.paired(
            records["instruction_counterfactual"], aligned_records,
            args.bootstrap_reps, args.seed + 500,
        ),
        "fresh_composition_aligned_vs_withheld_tfidf": joint.paired(
            hidden(records["tfidf_logreg_withheld_composition"]),
            hidden(aligned_records),
            args.bootstrap_reps, args.seed + 600,
        ),
        "fresh_composition_aligned_vs_fixed": joint.paired(
            hidden(records["fixed_loss_lindistflow"]),
            hidden(aligned_records),
            args.bootstrap_reps, args.seed + 700,
        ),
    }
    axes = {
        "physics_aligned": factorized.axis_summary(fresh_rows, aligned),
        "physics_aligned_composition": factorized.axis_summary(
            [row for row in fresh_rows if row["pair_type"] == PRIMARY_PAIR_TYPE],
            {key: value for key, value in aligned.items() if any(
                row["instance_id"] == key and row["pair_type"] == PRIMARY_PAIR_TYPE
                for row in fresh_rows
            )},
        ),
    }
    primary = paired["fresh_composition_aligned_vs_withheld_tfidf"]
    checks = {
        "evaluation_only_no_training": True,
        "fresh_outcomes_not_used_for_fit": full_text["fit_rows"] == len(original_train)
            and withheld_text["fit_rows"] == len(withheld_rows),
        "primary_ci_lower_positive": primary["ci95"][0] > 0,
        "primary_positive_both_networks": all(
            positive(primary["by_network"][network]["improvement_mean"])
            for network in ("33", "69")
        ),
        "correct_vs_removed_ci_lower_positive": paired["correct_vs_removed"]["ci95"][0] > 0,
        "correct_vs_counterfactual_ci_lower_positive": paired["correct_vs_counterfactual"]["ci95"][0] > 0,
        "aligned_feasible_100pct": summaries["physics_aligned_factorized_llm"]["safe_feasible_rate"] == 1.0,
        "aligned_zero_constraint_violation": summaries["physics_aligned_factorized_llm"]["constraint_violation_rate"] == 0.0,
        "adapter_unchanged_on_disk": (
            preflight.adapter_hash(args.factorized_adapter)
            == manifest["factorized_adapter"]["sha256"]
        ),
    }
    output.mkdir(parents=True, exist_ok=False)
    records_path = output / "gridrank_dynamic_confirmation_records.jsonl"
    write_records(records_path, records)
    result = {
        "msg": "GridRank frozen factorized fresh dynamic confirmation gate",
        "schema": "gridrank-dynamic-fresh-confirmation-gate-v1",
        "experiment_id": preflight.EXPERIMENT_ID,
        "preflight_sha256": preflight.file_sha256(args.preflight_manifest),
        "evaluation_only": True,
        "training_performed": False,
        "fresh_outcomes_used_for_fit": False,
        "primary_pair_type": PRIMARY_PAIR_TYPE,
        "summaries": summaries,
        "paired": paired,
        "axis_metrics": axes,
        "causal_score_max_abs_delta": {
            "correct_vs_removed": joint.max_score_delta(removed, aligned),
            "correct_vs_counterfactual": joint.max_score_delta(counterfactual, aligned),
        },
        "checks": checks,
        "confirmation_gate_pass": all(checks.values()),
        "failed_checks": [key for key, value in checks.items() if not value],
        "records": {
            "path": str(records_path.resolve()),
            "sha256": preflight.file_sha256(records_path),
            "methods": sorted(records),
            "rows": sum(len(values) for values in records.values()),
        },
        "interpretation_boundary": (
            "The full TFIDF parser saw maintenance_voltage labels and is a positive "
            "control. The primary traditional comparator was fit on the same original "
            "language bank after withholding that composition and never used fresh labels."
        ),
        "decision": (
            "authorize_dynamic_adaptation_paper_claim"
            if all(checks.values())
            else "retain_development_result_without_confirmatory_claim"
        ),
    }
    gate_path = output / "gridrank_dynamic_confirmation_gate.json"
    gate_path.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(result, ensure_ascii=False))
    if not result["confirmation_gate_pass"]:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
