"""Validate GridRank dynamic state clusters."""

from __future__ import annotations

import argparse
import json
import subprocess
import sys
import tempfile
from pathlib import Path

import analyze_gridrank_dynamic_state_clusters as analysis


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--result", required=True)
    args = parser.parse_args()
    locked = json.load(open(args.result, encoding="utf-8"))
    with tempfile.TemporaryDirectory() as directory:
        rebuilt = Path(directory) / "rebuilt.json"
        command = [
            sys.executable, "-B", analysis.__file__,
            "--fresh_summary", locked["inputs"]["fresh_summary"]["path"],
            "--confirmation_gate", locked["inputs"]["confirmation_gate"]["path"],
            "--confirmation_records", locked["inputs"]["confirmation_records"]["path"],
            "--factorized_tfidf_audit", locked["inputs"]["factorized_tfidf_audit"]["path"],
            "--bootstrap_reps", str(locked["bootstrap_reps"]),
            "--bootstrap_seed", str(locked["bootstrap_seed"]),
            "--output", str(rebuilt),
        ]
        subprocess.run(command, check=True, stdout=subprocess.DEVNULL)
        current = json.load(open(rebuilt, encoding="utf-8"))
    checks = {
        "schema": locked.get("schema") == analysis.SCHEMA,
        "exact_recomputation": locked == current,
        "audit_consistent": locked.get("audit_pass")
            == all(locked.get("integrity_checks", {}).values()),
        "sensitivity_consistent": locked.get("state_cluster_sensitivity_pass")
            == all(locked.get("sensitivity_checks", {}).values()),
    }
    result = {
        "msg": "GridRank dynamic state-cluster result verification",
        "checks": checks,
        "verification_pass": all(checks.values()),
        "audit_pass": locked.get("audit_pass"),
        "state_cluster_sensitivity_pass": locked.get(
            "state_cluster_sensitivity_pass"
        ),
        "failed_sensitivity": locked.get("failed_sensitivity"),
    }
    print(json.dumps(result, ensure_ascii=False))
    if not result["verification_pass"]:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
