"""Action extract utilities."""

import re


_OPEN_RE = re.compile(r"(Existing\s+)?Open Lines=\[(.*?)\]", re.S)
_PAIR_RE = re.compile(r"\(\s*(\d+)\s*,\s*(\d+)\s*\)")


def _pairs(s):
    return [(int(a), int(b)) for a, b in _PAIR_RE.findall(s)]


def last_action_match(text):
    
    found = None
    for m in _OPEN_RE.finditer(str(text)):
        if m.group(1):                      
            continue
        p = _pairs(m.group(2))
        if p:
            found = (m, p)
    return found if found else (None, None)


def extract_action(text):
    
    _, p = last_action_match(text)
    return p


def action_char_span(text):
    
    m, _ = last_action_match(text)
    if not m:
        return None, None
    
    
    cs = m.start() + m.group(0).find("Open Lines=")
    return cs, m.end()


def action_span(decode, ids):
    
    ids = list(ids)
    cs, ce = action_char_span(decode(ids))
    if cs is None:
        return None, None
    start = end = None
    for k in range(1, len(ids) + 1):
        length = len(decode(ids[:k]))
        if start is None and length > cs:
            start = k - 1
        if length >= ce:
            end = k
            break
    if start is None or end is None:
        return None, None
    return start, end


_DELTA_REPL_RE = re.compile(
    r"Action:\s*Replace\s*\(\s*(\d+)\s*,\s*(\d+)\s*\)\s*with\s*\(\s*(\d+)\s*,\s*(\d+)\s*\)", re.I)
_DELTA_NONE_RE = re.compile(r"Action:\s*none", re.I)


def _last_delta_match(text):
    
    t = str(text)
    cands = []
    for m in _DELTA_REPL_RE.finditer(t):
        cands.append((m.start(), m.end(),
                      ((int(m.group(1)), int(m.group(2))), (int(m.group(3)), int(m.group(4))))))
    for m in _DELTA_NONE_RE.finditer(t):
        cands.append((m.start(), m.end(), "none"))
    if not cands:
        return None
    cands.sort(key=lambda c: c[0])
    return cands[-1]


def extract_delta(text):
    
    c = _last_delta_match(text)
    return c[2] if c else None


def delta_char_span(text):
    
    c = _last_delta_match(text)
    return (c[0], c[1]) if c else (None, None)


def delta_span(decode, ids):
    
    ids = list(ids)
    cs, ce = delta_char_span(decode(ids))
    if cs is None:
        return None, None
    start = end = None
    for k in range(1, len(ids) + 1):
        length = len(decode(ids[:k]))
        if start is None and length > cs:
            start = k - 1
        if length >= ce:
            end = k
            break
    if start is None or end is None:
        return None, None
    return start, end


if __name__ == "__main__":
    from tokenizers import Tokenizer
    tk = Tokenizer.from_file("../../Meta-Llama-3.1-8B-Instruct/tokenizer.json")
    dec = lambda ids: tk.decode(ids, skip_special_tokens=False)

    PRED = [(11, 43), (12, 13), (14, 15), (55, 56), (61, 62)]
    EX = [(11, 43), (13, 21), (14, 15), (55, 56), (61, 62)]
    pj = lambda ps: "[" + ", ".join(f"({a}, {b})" for a, b in ps) + "]"
    cases = [
        ("single prediction", f"Output: Open Lines={pj(PRED)}", PRED),
        ("echo existing THEN predict",
         f"Output: Open Lines={pj(EX)} then better: Output: Open Lines={pj(PRED)}", PRED),
        ("explicit 'Existing ' echo + predict",
         f"Existing Open Lines={pj(EX)}. Output: Open Lines={pj(PRED)}", PRED),
        ("prediction + free text", f"Output: Open Lines={pj(PRED)} because radial & low loss.", PRED),
        ("no action", "totally broken output", None),
    ]
    allok = True
    for name, comp, expected in cases:
        got = extract_action(comp)
        s, e = action_span(dec, tk.encode(comp).ids)
        span_pairs = extract_action(dec(tk.encode(comp).ids[s:e])) if s is not None else None
        ok = (got == expected) and (span_pairs == expected)
        allok = allok and ok
        print(f"[{name}] extract==prediction:{got==expected}  mask-span==prediction:{span_pairs==expected}  -> {ok}")
    print("\nALL CASES PASS (extract & mask both == intended PREDICTION):", allok)
