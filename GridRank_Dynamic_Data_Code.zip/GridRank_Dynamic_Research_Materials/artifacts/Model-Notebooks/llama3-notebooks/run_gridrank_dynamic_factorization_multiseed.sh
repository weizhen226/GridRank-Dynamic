#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"
if [[ ! "${OMP_NUM_THREADS:-}" =~ ^[1-9][0-9]*$ ]]; then export OMP_NUM_THREADS=4; fi
TRAIN_PYTHON_BIN="${TRAIN_PYTHON:-python}"
TAG="${TAG:-gridrank_dynamic_factorization_multiseed_v1_20260904}"
FRESH_TAG="${FRESH_TAG:-gridrank_dynamic_confirmation_v1_20260829_hotfix1}"
RESULT="${RESULT:-${TAG}_aggregate.json}"

for path in \
  "${FRESH_TAG}_summary.json" \
  "${FRESH_TAG}.preflight.json" \
  output_${FRESH_TAG}/gridrank_dynamic_confirmation_gate.json \
  output_${FRESH_TAG}/gridrank_dynamic_confirmation_records.jsonl \
  output_gridrank_dynamic_factorization_ablation_v1_20260903/gridrank_dynamic_factorization_ablation_gate.json \
  output_gridrank_dynamic_factorization_ablation_v1_20260903/gridrank_dynamic_factorization_ablation_records.jsonl \
  gridrank_dynamic_factorization_ablation_v1_20260903.preflight.json \
  gridrank_dynamic_confirmation_replication_v1_s123_20260831.preflight.json \
  output_gridrank_dynamic_confirmation_replication_v1_s123_20260831/gridrank_dynamic_confirmation_gate.json \
  output_gridrank_dynamic_confirmation_replication_v1_s123_20260831/gridrank_dynamic_confirmation_records.jsonl \
  output_gridrank_dynamic_confirmation_replication_v1_s2025_20260831/gridrank_dynamic_confirmation_gate.json \
  output_gridrank_dynamic_confirmation_replication_v1_s2025_20260831/gridrank_dynamic_confirmation_records.jsonl \
  gridrank_dynamic_confirmation_replication_v1_s2025_20260831.preflight.json \
  gridrank_dynamic_joint_confirmation_v1_s123_20260904.preflight.json \
  output_gridrank_dynamic_joint_confirmation_v1_s123_20260904/gridrank_dynamic_factorization_ablation_gate.json \
  output_gridrank_dynamic_joint_confirmation_v1_s123_20260904/gridrank_dynamic_factorization_ablation_records.jsonl \
  gridrank_dynamic_joint_confirmation_v1_s2025_20260904.preflight.json \
  output_gridrank_dynamic_joint_confirmation_v1_s2025_20260904/gridrank_dynamic_factorization_ablation_gate.json \
  output_gridrank_dynamic_joint_confirmation_v1_s2025_20260904/gridrank_dynamic_factorization_ablation_records.jsonl; do
  test -e "$path" || { echo "missing factorization multiseed input: $path" >&2; exit 2; }
done
test ! -e "$RESULT" || { echo "refusing to overwrite aggregate: $RESULT" >&2; exit 2; }

echo "=== 1/3 DEPENDENCY-LIGHT THREE-SEED FACTORIZATION REGRESSIONS ==="
"$TRAIN_PYTHON_BIN" -B verify_gridrank_dynamic_factorization_multiseed_dependencies.py

echo "=== 2/3 AGGREGATE SEED X PHYSICAL-STATE X PAIR STATISTICS ==="
"$TRAIN_PYTHON_BIN" -B aggregate_gridrank_dynamic_factorization_multiseed.py \
  --factor_preflight "42=${FRESH_TAG}.preflight.json" \
  --factor_preflight "123=gridrank_dynamic_confirmation_replication_v1_s123_20260831.preflight.json" \
  --factor_preflight "2025=gridrank_dynamic_confirmation_replication_v1_s2025_20260831.preflight.json" \
  --factor_gate "42=output_${FRESH_TAG}/gridrank_dynamic_confirmation_gate.json" \
  --factor_gate "123=output_gridrank_dynamic_confirmation_replication_v1_s123_20260831/gridrank_dynamic_confirmation_gate.json" \
  --factor_gate "2025=output_gridrank_dynamic_confirmation_replication_v1_s2025_20260831/gridrank_dynamic_confirmation_gate.json" \
  --factor_records "42=output_${FRESH_TAG}/gridrank_dynamic_confirmation_records.jsonl" \
  --factor_records "123=output_gridrank_dynamic_confirmation_replication_v1_s123_20260831/gridrank_dynamic_confirmation_records.jsonl" \
  --factor_records "2025=output_gridrank_dynamic_confirmation_replication_v1_s2025_20260831/gridrank_dynamic_confirmation_records.jsonl" \
  --joint_preflight "42=gridrank_dynamic_factorization_ablation_v1_20260903.preflight.json" \
  --joint_preflight "123=gridrank_dynamic_joint_confirmation_v1_s123_20260904.preflight.json" \
  --joint_preflight "2025=gridrank_dynamic_joint_confirmation_v1_s2025_20260904.preflight.json" \
  --joint_gate "42=output_gridrank_dynamic_factorization_ablation_v1_20260903/gridrank_dynamic_factorization_ablation_gate.json" \
  --joint_gate "123=output_gridrank_dynamic_joint_confirmation_v1_s123_20260904/gridrank_dynamic_factorization_ablation_gate.json" \
  --joint_gate "2025=output_gridrank_dynamic_joint_confirmation_v1_s2025_20260904/gridrank_dynamic_factorization_ablation_gate.json" \
  --joint_records "42=output_gridrank_dynamic_factorization_ablation_v1_20260903/gridrank_dynamic_factorization_ablation_records.jsonl" \
  --joint_records "123=output_gridrank_dynamic_joint_confirmation_v1_s123_20260904/gridrank_dynamic_factorization_ablation_records.jsonl" \
  --joint_records "2025=output_gridrank_dynamic_joint_confirmation_v1_s2025_20260904/gridrank_dynamic_factorization_ablation_records.jsonl" \
  --fresh_summary "${FRESH_TAG}_summary.json" \
  --bootstrap_reps 10000 --bootstrap_seed 20260904 --output "$RESULT"

echo "=== 3/3 VERIFY EXACT CACHED RECOMPUTATION ==="
"$TRAIN_PYTHON_BIN" -B verify_gridrank_dynamic_factorization_multiseed.py \
  --result "$RESULT"
echo "=== GRIDRANK DYNAMIC FACTORIZATION THREE-SEED AGGREGATE COMPLETE ==="
