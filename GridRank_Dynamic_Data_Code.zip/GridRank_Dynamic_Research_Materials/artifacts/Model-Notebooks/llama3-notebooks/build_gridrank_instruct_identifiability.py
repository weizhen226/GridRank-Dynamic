"""Build GridRank instruct identifiability."""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import re
from collections import Counter, defaultdict
from pathlib import Path


NOOP = "Action: none"
ACTION_RE = re.compile(
    r"^Action:\s*Replace\s*\((\d+)\s*,\s*(\d+)\)\s*"
    r"with\s*\((\d+)\s*,\s*(\d+)\)\s*$"
)
TRAIN_FAMILIES = ("loss", "voltage", "maintenance_loss")
VALIDATION_FAMILIES = (*TRAIN_FAMILIES, "maintenance_voltage")
TARGET_TEMPERATURE = 0.20
LOSS_DEADBAND_PCT = 0.05
VOLTAGE_DEADBAND_PU = 1e-4

TRAIN_TEMPLATES = {
    "loss": (
        "Minimize active-power loss. Propose only a feasible exchange with a "
        "positive loss reduction; otherwise retain the current topology."
    ),
    "voltage": (
        "Prioritize increasing the minimum bus voltage. Reject infeasible "
        "exchanges and any exchange that increases active-power loss by more "
        "than 0.5 percent."
    ),
    "maintenance_loss": (
        "Minimize active-power loss, but do not operate either maintenance-"
        "restricted branch {edges}. Retain the current topology if no allowed "
        "exchange has a positive benefit."
    ),
    "maintenance_voltage": (
        "Improve the weakest bus voltage while respecting the temporary "
        "maintenance prohibition on branches {edges}; tolerate at most 0.5 "
        "percent additional active-power loss."
    ),
}

VALIDATION_TEMPLATES = {
    "loss": (
        "Choose the admissible branch exchange that cuts feeder losses the "
        "most, and leave all switches unchanged when no exchange helps."
    ),
    "voltage": (
        "Give first priority to the lowest per-unit bus voltage, subject to "
        "feasibility and a maximum loss increase of 0.5 percent."
    ),
    "maintenance_loss": (
        "A temporary outage order forbids touching branches {edges}. Among "
        "the remaining admissible exchanges, prefer the greatest loss saving."
    ),
    "maintenance_voltage": (
        "Under the temporary branch restrictions {edges}, select the safe "
        "exchange that best raises the minimum voltage without adding more "
        "than 0.5 percent loss."
    ),
}

RAW_CANDIDATE_FIELDS = (
    "action",
    "candidate_feature_text",
    "feedback_valid",
    "feasible",
    "reason",
    "reduction_pct",
    "anchor_loss_kw",
    "candidate_loss_kw",
    "anchor_min_vm_pu",
    "candidate_min_vm_pu",
    "candidate_max_vm_pu",
)

SCRIPT_DIR = Path(__file__).resolve().parent
CODE_FILES = {
    "build_gridrank_instruct_identifiability.py": SCRIPT_DIR
    / "build_gridrank_instruct_identifiability.py",
    "verify_gridrank_instruct_identifiability.py": SCRIPT_DIR
    / "verify_gridrank_instruct_identifiability.py",
    "run_gridrank_instruct_identifiability.sh": SCRIPT_DIR
    / "run_gridrank_instruct_identifiability.sh",
    "../../docs/GRIDRANK_INSTRUCT_IDENTIFIABILITY_PROTOCOL.md": SCRIPT_DIR
    / "../../docs/GRIDRANK_INSTRUCT_IDENTIFIABILITY_PROTOCOL.md",
}


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--train_cache", required=True)
    parser.add_argument("--validation_cache", required=True, nargs="+")
    parser.add_argument("--train_out", required=True)
    parser.add_argument("--validation_out", required=True)
    parser.add_argument("--summary_out", required=True)
    parser.add_argument("--maintenance_seed", type=int, default=20260804)
    parser.add_argument("--forbidden_edge_count", type=int, default=2)
    parser.add_argument("--target_temperature", type=float, default=TARGET_TEMPERATURE)
    parser.add_argument("--min_states_per_network", type=int, default=32)
    parser.add_argument("--validation_states_per_network", type=int, default=32)
    parser.add_argument("--validation_selection_seed", type=int, default=20260805)
    parser.add_argument("--min_separation_rate", type=float, default=0.20)
    parser.add_argument("--min_objective_flip_rate", type=float, default=0.10)
    parser.add_argument("--min_maintenance_flip_rate", type=float, default=0.10)
    parser.add_argument("--min_fixed_loss_regret", type=float, default=0.05)
    return parser.parse_args()


def file_sha256(path):
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def code_inventory():
    hashes = {
        name: file_sha256(path)
        for name, path in CODE_FILES.items()
        if path.is_file()
    }
    missing = [name for name, path in CODE_FILES.items() if not path.is_file()]
    return hashes, missing


def _finite(value):
    try:
        output = float(value)
    except (TypeError, ValueError):
        return None
    return output if math.isfinite(output) else None


def canonical_edge(a, b):
    a, b = int(a), int(b)
    return (a, b) if a <= b else (b, a)


def action_edges(action):
    if action == NOOP:
        return ()
    match = ACTION_RE.fullmatch(str(action))
    if match is None:
        raise ValueError(f"invalid exchange action: {action!r}")
    a, b, c, d = map(int, match.groups())
    return (canonical_edge(a, b), canonical_edge(c, d))


def edge_text(edges):
    return " and ".join(f"({a}, {b})" for a, b in edges)


def select_forbidden_edges(candidates, state_sha, count, seed):
    if count <= 0:
        raise ValueError("forbidden_edge_count must be positive")
    edges = sorted({edge for item in candidates for edge in action_edges(item["action"])})
    if len(edges) < count:
        raise ValueError(f"candidate pool exposes only {len(edges)} unique branches")
    ranked = sorted(
        edges,
        key=lambda edge: hashlib.sha256(
            f"{seed}|{state_sha}|{edge[0]}|{edge[1]}".encode("utf-8")
        ).digest(),
    )
    return tuple(ranked[:count])


def _canonical_candidate(item):
    missing = [key for key in RAW_CANDIDATE_FIELDS if key not in item]
    if missing:
        raise ValueError(f"candidate missing cached physics fields: {missing}")
    output = {key: item.get(key) for key in RAW_CANDIDATE_FIELDS}
    action_edges(output["action"])
    return output


def load_cached_states(path):
    rows = [json.loads(line) for line in open(path, encoding="utf-8") if line.strip()]
    if not rows:
        raise ValueError(f"empty cache: {path}")
    grouped = defaultdict(list)
    for row in rows:
        required = {
            "network_id", "load_id", "state_text", "physical_state_sha256", "candidates"
        }
        missing = required.difference(row)
        if missing:
            raise ValueError(f"cached row missing fields: {sorted(missing)}")
        grouped[str(row["physical_state_sha256"])].append(row)

    states = []
    for state_sha, variants in sorted(grouped.items()):
        first = variants[0]
        network = str(first["network_id"])
        load_id = str(first["load_id"])
        state_text = str(first["state_text"])
        candidates = [_canonical_candidate(item) for item in first["candidates"]]
        actions = [item["action"] for item in candidates]
        if len(actions) != len(set(actions)) or actions.count(NOOP) != 1:
            raise ValueError(f"state {state_sha} must contain one no-op and unique actions")
        if len(candidates) != 16:
            raise ValueError(f"state {state_sha} must contain no-op plus 15 exchanges")
        fingerprint = json.dumps(candidates, sort_keys=True, separators=(",", ":"))
        for row in variants[1:]:
            if (
                str(row["network_id"]) != network
                or str(row["load_id"]) != load_id
                or str(row["state_text"]) != state_text
            ):
                raise ValueError(f"state metadata differs across cached directives: {state_sha}")
            other = [_canonical_candidate(item) for item in row["candidates"]]
            if json.dumps(other, sort_keys=True, separators=(",", ":")) != fingerprint:
                raise ValueError(f"cached physics differs across directives: {state_sha}")
        states.append({
            "network_id": network,
            "load_id": load_id,
            "state_text": state_text,
            "physical_state_sha256": state_sha,
            "source_cached_rows": len(variants),
            "candidates": candidates,
        })
    return states


def merge_cached_states(paths):
    
    merged = {}
    duplicate_states = 0
    for path in paths:
        for state in load_cached_states(path):
            key = (state["network_id"], state["physical_state_sha256"])
            if key not in merged:
                merged[key] = state
                continue
            duplicate_states += 1
            current = merged[key]
            comparable = ("load_id", "state_text", "candidates")
            if any(current[field] != state[field] for field in comparable):
                raise ValueError(f"duplicate cached state differs across pools: {key}")
    return list(merged.values()), duplicate_states


def select_disjoint_validation(pool, train_states, per_network, seed):
    
    if per_network <= 0:
        raise ValueError("validation_states_per_network must be positive")
    train_state_ids = {
        (item["network_id"], item["physical_state_sha256"])
        for item in train_states
    }
    train_load_ids = {
        (item["network_id"], item["load_id"])
        for item in train_states
    }
    counters = Counter()
    eligible = []
    for state in pool:
        state_key = (state["network_id"], state["physical_state_sha256"])
        load_key = (state["network_id"], state["load_id"])
        if state_key in train_state_ids:
            counters[f"network_{state['network_id']}_excluded_state"] += 1
            continue
        if load_key in train_load_ids:
            counters[f"network_{state['network_id']}_excluded_load"] += 1
            continue
        eligible.append(state)

    selected = []
    eligible_by_network = {}
    for network in ("33", "69"):
        subset = [item for item in eligible if item["network_id"] == network]
        eligible_by_network[network] = len(subset)
        ranked = sorted(
            subset,
            key=lambda item: hashlib.sha256(
                (
                    f"{seed}|{network}|{item['load_id']}|"
                    f"{item['physical_state_sha256']}"
                ).encode("utf-8")
            ).digest(),
        )
        if len(ranked) < per_network:
            raise ValueError(
                f"network {network} has only {len(ranked)} disjoint validation "
                f"states; need {per_network}"
            )
        selected.extend(ranked[:per_network])
    trace = {
        "selection_rule": (
            "exclude train network+state and network+load identities, then rank "
            "by frozen SHA-256 of seed/network/load/state; no outcomes used"
        ),
        "selection_seed": seed,
        "requested_states_per_network": per_network,
        "pool_unique_states": len(pool),
        "eligible_states_by_network": eligible_by_network,
        "exclusion_counts": dict(counters),
        "selected_state_sha256s": {
            network: sorted(
                item["physical_state_sha256"]
                for item in selected if item["network_id"] == network
            )
            for network in ("33", "69")
        },
        "selected_load_ids": {
            network: sorted(
                item["load_id"]
                for item in selected if item["network_id"] == network
            )
            for network in ("33", "69")
        },
    }
    return selected, trace


def _raw_utility(base_family, candidate, anchor_min):
    if not bool(candidate.get("feedback_valid")) or not bool(candidate.get("feasible")):
        return None
    reduction = _finite(candidate.get("reduction_pct"))
    minimum = _finite(candidate.get("candidate_min_vm_pu"))
    anchor_min = _finite(anchor_min)
    if reduction is None or minimum is None or anchor_min is None:
        return None
    if candidate["action"] == NOOP:
        return 0.0
    if base_family == "loss":
        return reduction
    if base_family == "voltage":
        return 100.0 * (minimum - anchor_min) if reduction >= -0.5 else None
    raise ValueError(base_family)


def _accepted(base_family, value, action):
    if action == NOOP:
        return value is not None
    if value is None:
        return False
    if base_family == "loss":
        return float(value) > LOSS_DEADBAND_PCT
    return float(value) > 100.0 * VOLTAGE_DEADBAND_PU


def _normalised_regrets(values, desired):
    finite = [float(value) for value in values if value is not None]
    if not finite or values[desired] is None:
        return [0.0 if index == desired else 1.0 for index in range(len(values))]
    best = float(values[desired])
    spread = max(finite) - min(finite) if len(finite) > 1 else abs(best)
    floor = min([0.0, *finite]) - max(1e-6, spread)
    scale = max(1e-6, best - floor)
    return [
        1.0 if value is None else min(1.0, max(0.0, (best - float(value)) / scale))
        for value in values
    ]


def label_instruction(state, family, style, forbidden_edges, temperature):
    maintenance = family.startswith("maintenance_")
    base_family = "voltage" if family.endswith("voltage") else "loss"
    templates = TRAIN_TEMPLATES if style == "train" else VALIDATION_TEMPLATES
    instruction = templates[family].format(edges=edge_text(forbidden_edges))
    source = state["candidates"]
    noop = next(index for index, item in enumerate(source) if item["action"] == NOOP)
    anchor_min = source[noop]["anchor_min_vm_pu"]
    raw_values, safe_values = [], []
    forbidden = set(forbidden_edges)
    for candidate in source:
        value = _raw_utility(base_family, candidate, anchor_min)
        touches_forbidden = bool(forbidden.intersection(action_edges(candidate["action"])))
        if maintenance and candidate["action"] != NOOP and touches_forbidden:
            value = None
        raw_values.append(value)
        safe_values.append(
            float(value) if _accepted(base_family, value, candidate["action"]) else None
        )
    safe_values[noop] = 0.0
    best = max(float(value) for value in safe_values if value is not None)
    optimal = {
        index for index, value in enumerate(safe_values)
        if value is not None and math.isclose(float(value), best, rel_tol=1e-12, abs_tol=1e-12)
    }
    desired = noop if noop in optimal else min(optimal, key=lambda index: source[index]["action"])
    regrets = _normalised_regrets(safe_values, desired)

    exchange_indices = [index for index in range(len(source)) if index != noop]
    weights = [
        0.0 if safe_values[index] is None else math.exp(-regrets[index] / temperature)
        for index in exchange_indices
    ]
    total = sum(weights)
    probabilities = [0.0 if total == 0.0 else value / total for value in weights]
    candidates = []
    for probability, index in zip(probabilities, exchange_indices):
        item = dict(source[index])
        item.update({
            "instruction_utility": raw_values[index],
            "safe_utility": safe_values[index],
            "accepted_by_gate": safe_values[index] is not None,
            "touches_forbidden_edge": bool(forbidden.intersection(action_edges(item["action"]))),
            "is_physics_optimal": index in optimal,
            "normalised_regret": regrets[index],
            "target_prob": probability,
        })
        candidates.append(item)
    anchor = dict(source[noop])
    anchor.update({
        "instruction_utility": 0.0,
        "safe_utility": 0.0,
        "accepted_by_gate": True,
        "touches_forbidden_edge": False,
        "is_physics_optimal": noop in optimal,
        "normalised_regret": regrets[noop],
    })
    return {
        "instance_id": f"gridrank-instruct:{style}:{state['network_id']}:{state['physical_state_sha256']}:{family}",
        "partition": "train" if style == "train" else "validation",
        "network_id": state["network_id"],
        "load_id": state["load_id"],
        "physical_state_sha256": state["physical_state_sha256"],
        "state_text": state["state_text"],
        "instruction_id": family,
        "instruction_style": style,
        "instruction_text": instruction,
        "base_objective": base_family,
        "maintenance_constraint": maintenance,
        "forbidden_edges": [list(edge) for edge in forbidden_edges] if maintenance else [],
        "gate_anchor": anchor,
        "desired_action": source[desired]["action"],
        "desired_is_noop": desired == noop,
        "candidate_count": len(candidates),
        "candidates": candidates,
    }


def build_rows(states, style, seed, forbidden_count, temperature):
    families = TRAIN_FAMILIES if style == "train" else VALIDATION_FAMILIES
    rows = []
    for state in states:
        forbidden = select_forbidden_edges(
            state["candidates"], state["physical_state_sha256"], forbidden_count, seed
        )
        for family in families:
            rows.append(label_instruction(state, family, style, forbidden, temperature))
    return rows


def _row_safe_map(row):
    result = {NOOP: 0.0}
    for item in row["candidates"]:
        if item["safe_utility"] is not None:
            result[item["action"]] = float(item["safe_utility"])
    return result


def _regret_for_action(row, action):
    safe = _row_safe_map(row)
    best = max(safe.values())
    if action not in safe:
        return 1.0
    values = list(safe.values())
    spread = max(values) - min(values) if len(values) > 1 else abs(best)
    floor = min([0.0, *values]) - max(1e-6, spread)
    return min(1.0, max(0.0, (best - safe[action]) / max(1e-6, best - floor)))


def summarise(rows):
    groups = defaultdict(dict)
    for row in rows:
        groups[row["physical_state_sha256"]][row["instruction_id"]] = row
    state_records = []
    for state_sha, values in sorted(groups.items()):
        loss = values["loss"]["desired_action"]
        voltage = values["voltage"]["desired_action"]
        maintenance_loss = values["maintenance_loss"]["desired_action"]
        maintenance_voltage = values.get("maintenance_voltage")
        desired_actions = {row["desired_action"] for row in values.values()}
        fixed_loss_regrets = [_regret_for_action(row, loss) for row in values.values()]
        state_records.append({
            "physical_state_sha256": state_sha,
            "network": values["loss"]["network_id"],
            "load_id": values["loss"]["load_id"],
            "separating": len(desired_actions) >= 2,
            "objective_flip": loss != voltage,
            "maintenance_flip": loss != maintenance_loss,
            "composition_flip": bool(
                maintenance_voltage
                and maintenance_voltage["desired_action"] != maintenance_loss
            ),
            "fixed_loss_regret": sum(fixed_loss_regrets) / len(fixed_loss_regrets),
            "desired_action_count": len(desired_actions),
        })

    def ratio(key, subset):
        return 0.0 if not subset else sum(bool(item[key]) for item in subset) / len(subset)

    def mean(key, subset):
        return 0.0 if not subset else sum(float(item[key]) for item in subset) / len(subset)

    by_network = {}
    for network in sorted({item["network"] for item in state_records}):
        subset = [item for item in state_records if item["network"] == network]
        by_network[network] = {
            "states": len(subset),
            "instruction_separating_rate": ratio("separating", subset),
            "objective_flip_rate": ratio("objective_flip", subset),
            "maintenance_flip_rate": ratio("maintenance_flip", subset),
            "composition_flip_rate": ratio("composition_flip", subset),
            "fixed_loss_normalised_regret_mean": mean("fixed_loss_regret", subset),
        }
    desired_mix = Counter(row["desired_action"] for row in rows)
    family_noop = Counter(
        row["instruction_id"] for row in rows if row["desired_is_noop"]
    )
    return {
        "rows": len(rows),
        "states": len(state_records),
        "network_mix": dict(Counter(item["network"] for item in state_records)),
        "instruction_mix": dict(Counter(row["instruction_id"] for row in rows)),
        "instruction_separating_states": sum(item["separating"] for item in state_records),
        "instruction_separating_rate": ratio("separating", state_records),
        "objective_flip_states": sum(item["objective_flip"] for item in state_records),
        "objective_flip_rate": ratio("objective_flip", state_records),
        "maintenance_flip_states": sum(item["maintenance_flip"] for item in state_records),
        "maintenance_flip_rate": ratio("maintenance_flip", state_records),
        "composition_flip_states": sum(item["composition_flip"] for item in state_records),
        "composition_flip_rate": ratio("composition_flip", state_records),
        "fixed_loss_normalised_regret_mean": mean("fixed_loss_regret", state_records),
        "desired_noop_by_instruction": dict(family_noop),
        "unique_desired_actions": len(desired_mix),
        "by_network": by_network,
    }


def write_jsonl(path, rows):
    with open(path, "x", encoding="utf-8", newline="\n") as handle:
        for row in rows:
            handle.write(json.dumps(row, ensure_ascii=False, sort_keys=True) + "\n")


def main():
    args = parse_args()
    if not (0.0 < args.target_temperature <= 10.0):
        raise SystemExit("target_temperature must be in (0, 10]")
    if args.min_states_per_network <= 0:
        raise SystemExit("min_states_per_network must be positive")
    output_paths = [Path(args.train_out), Path(args.validation_out), Path(args.summary_out)]
    if any(path.exists() for path in output_paths):
        raise FileExistsError(f"refusing to overwrite an output: {output_paths}")

    train_states = load_cached_states(args.train_cache)
    validation_pool, duplicate_pool_states = merge_cached_states(args.validation_cache)
    validation_states, validation_selection = select_disjoint_validation(
        validation_pool,
        train_states,
        args.validation_states_per_network,
        args.validation_selection_seed,
    )
    validation_selection["duplicate_pool_states"] = duplicate_pool_states
    train_rows = build_rows(
        train_states, "train", args.maintenance_seed,
        args.forbidden_edge_count, args.target_temperature,
    )
    validation_rows = build_rows(
        validation_states, "validation", args.maintenance_seed,
        args.forbidden_edge_count, args.target_temperature,
    )
    train_summary = summarise(train_rows)
    validation_summary = summarise(validation_rows)

    train_state_ids = {
        (item["network_id"], item["physical_state_sha256"])
        for item in train_states
    }
    validation_state_ids = {
        (item["network_id"], item["physical_state_sha256"])
        for item in validation_states
    }
    train_loads = {(item["network_id"], item["load_id"]) for item in train_states}
    validation_loads = {
        (item["network_id"], item["load_id"])
        for item in validation_states
    }
    expected_train_mix = {family: len(train_states) for family in TRAIN_FAMILIES}
    expected_validation_mix = {
        family: len(validation_states) for family in VALIDATION_FAMILIES
    }
    code_sha256, missing_code_files = code_inventory()
    checks = {
        "train_validation_state_disjoint": not train_state_ids.intersection(validation_state_ids),
        "train_validation_load_disjoint": not train_loads.intersection(validation_loads),
        "train_network_coverage": all(
            train_summary["network_mix"].get(network, 0) >= args.min_states_per_network
            for network in ("33", "69")
        ),
        "validation_network_coverage": all(
            validation_summary["network_mix"].get(network, 0) >= args.min_states_per_network
            for network in ("33", "69")
        ),
        "train_instruction_mix_exact": train_summary["instruction_mix"] == expected_train_mix,
        "validation_instruction_mix_exact": (
            validation_summary["instruction_mix"] == expected_validation_mix
        ),
        "train_instruction_separation": (
            train_summary["instruction_separating_rate"] >= args.min_separation_rate
        ),
        "validation_instruction_separation": (
            validation_summary["instruction_separating_rate"] >= args.min_separation_rate
        ),
        "train_objective_flip": (
            train_summary["objective_flip_rate"] >= args.min_objective_flip_rate
        ),
        "validation_objective_flip": (
            validation_summary["objective_flip_rate"] >= args.min_objective_flip_rate
        ),
        "train_maintenance_flip": (
            train_summary["maintenance_flip_rate"] >= args.min_maintenance_flip_rate
        ),
        "validation_maintenance_flip": (
            validation_summary["maintenance_flip_rate"] >= args.min_maintenance_flip_rate
        ),
        "train_fixed_loss_regret_material": (
            train_summary["fixed_loss_normalised_regret_mean"] >= args.min_fixed_loss_regret
        ),
        "validation_fixed_loss_regret_material": (
            validation_summary["fixed_loss_normalised_regret_mean"] >= args.min_fixed_loss_regret
        ),
        "both_networks_have_separation": all(
            train_summary["by_network"][network]["instruction_separating_rate"] >= 0.10
            and validation_summary["by_network"][network]["instruction_separating_rate"] >= 0.10
            for network in ("33", "69")
        ),
        "all_rows_exchange_only_ranker": all(
            row["candidate_count"] == 15
            and len(row["candidates"]) == 15
            and all(item["action"] != NOOP for item in row["candidates"])
            and row["gate_anchor"]["action"] == NOOP
            for row in [*train_rows, *validation_rows]
        ),
        "all_anchors_operational": all(
            row["gate_anchor"]["feedback_valid"]
            and row["gate_anchor"]["feasible"]
            for row in [*train_rows, *validation_rows]
        ),
        "locked_code_files_present": not missing_code_files,
    }

    write_jsonl(args.train_out, train_rows)
    write_jsonl(args.validation_out, validation_rows)
    summary = {
        "msg": "GridRank-Instruct cached-physics identifiability gate",
        "schema": "gridrank-instruct-identifiability-v1",
        "cached_only": True,
        "training_performed": False,
        "model_loaded": False,
        "power_flow_calls": 0,
        "instruction_design": {
            "train_families": list(TRAIN_FAMILIES),
            "validation_families": list(VALIDATION_FAMILIES),
            "unseen_composition": "maintenance_voltage is absent from training families",
            "maintenance_selection": "fixed SHA-256 over state hash and topology-only action edges",
            "maintenance_seed": args.maintenance_seed,
            "forbidden_edge_count": args.forbidden_edge_count,
            "target_temperature": args.target_temperature,
        },
        "thresholds": {
            "min_states_per_network": args.min_states_per_network,
            "min_separation_rate": args.min_separation_rate,
            "min_objective_flip_rate": args.min_objective_flip_rate,
            "min_maintenance_flip_rate": args.min_maintenance_flip_rate,
            "min_fixed_loss_regret": args.min_fixed_loss_regret,
        },
        "sources": {
            "train": {"path": str(Path(args.train_cache).resolve()), "sha256": file_sha256(args.train_cache)},
            "validation_pool": [
                {"path": str(Path(path).resolve()), "sha256": file_sha256(path)}
                for path in args.validation_cache
            ],
        },
        "artifacts": {
            "train": {"path": str(Path(args.train_out).resolve()), "sha256": file_sha256(args.train_out)},
            "validation": {"path": str(Path(args.validation_out).resolve()), "sha256": file_sha256(args.validation_out)},
        },
        "code_sha256": code_sha256,
        "missing_code_files": missing_code_files,
        "validation_selection": validation_selection,
        "partitions": {"train": train_summary, "validation": validation_summary},
        "checks": checks,
        "coverage_pass": all(checks.values()),
    }
    with open(args.summary_out, "x", encoding="utf-8", newline="\n") as handle:
        json.dump(summary, handle, ensure_ascii=False, indent=2, sort_keys=True)
        handle.write("\n")
    print(json.dumps(summary, ensure_ascii=False))


if __name__ == "__main__":
    main()
