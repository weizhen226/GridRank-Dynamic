"""Validate GridRank dynamic benchmark."""

from __future__ import annotations

import argparse
import ast
import json
from pathlib import Path

import preflight_gridrank_dynamic_benchmark as dynamic


HERE = Path(__file__).resolve().parent


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--manifest")
    return parser.parse_args()


def imports(path):
    tree = ast.parse(Path(path).read_text(encoding="utf-8"))
    output = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            output.update(alias.name.split(".")[0] for alias in node.names)
        elif isinstance(node, ast.ImportFrom) and node.module:
            output.add(node.module.split(".")[0])
    return output


def static_checks():
    preflight = HERE / "preflight_gridrank_dynamic_benchmark.py"
    runner = HERE / "run_gridrank_dynamic_benchmark.sh"
    protocol = HERE / "../../docs/GRIDRANK_DYNAMIC_BENCHMARK_PROTOCOL.md"
    source = preflight.read_text(encoding="utf-8")
    runner_text = runner.read_text(encoding="utf-8")
    protocol_text = protocol.read_text(encoding="utf-8")
    top_imports = imports(preflight)
    checks = {
        "no_llm_or_training_imports": not {
            "torch", "transformers", "peft", "bitsandbytes"
        }.intersection(top_imports),
        "no_power_flow_imports": not {
            "pandapower", "simbench", "subprocess_physics_backend"
        }.intersection(top_imports),
        "sklearn_lazily_imported": (
            "from sklearn.feature_extraction.text import TfidfVectorizer" in source
            and "def fit_text_parser" in source
        ),
        "three_interface_levels": all(
            token in source for token in (
                "fixed_loss_lindistflow",
                "frozen_rule_parser_lindistflow",
                "tfidf_logreg_lindistflow",
                "oracle_structured_lindistflow",
            )
        ),
        "unseen_paraphrase_track": "unseen_paraphrase_primary" in source,
        "unseen_composition_track": "tfidf_logreg_withheld_composition" in source,
        "composition_withheld_from_fit": (
            'row["pair_type"] != COMPOSITION_PAIR_TYPE' in source
        ),
        "development_reuse_disclosed": (
            "development_reuse_disclosed" in source
            and "fresh_final_test_required" in source
            and "development" in protocol_text.lower()
        ),
        "runner_hides_cuda": 'export CUDA_VISIBLE_DEVICES=""' in runner_text,
        "runner_has_no_gpu_stage": "CUDA readiness" not in runner_text,
        "protocol_requires_equal_information": "equal-information" in protocol_text,
    }
    logic = {
        "edge_extraction": dynamic.extract_edges(
            "Do not operate (7, 8) or (12, 13)."
        ) == [[7, 8], [12, 13]],
        "touch_detection": dynamic.action_touches(
            "Action: Replace (7, 8) with (8, 9)", [[7, 8]]
        ),
        "noop_never_touches": not dynamic.action_touches(
            "Action: none", [[7, 8]]
        ),
    }
    checks.update(logic)
    result = {
        "msg": "GridRank dynamic benchmark dependency-light verification",
        "checks": checks,
        "verification_pass": all(checks.values()),
        "imports": sorted(top_imports),
        "llm_training_performed": False,
        "model_loaded": False,
        "power_flow_calls": 0,
    }
    print(json.dumps(result, ensure_ascii=False))
    if not result["verification_pass"]:
        raise SystemExit(2)


def verify_manifest(path):
    manifest = json.load(open(path, encoding="utf-8"))
    artifact_checks = {
        name: Path(item["path"]).is_file()
        and dynamic.file_sha256(item["path"]) == item["sha256"]
        for name, item in manifest.get("artifacts", {}).items()
    }
    checks = {
        "schema": manifest.get("schema") == dynamic.SCHEMA,
        "experiment_id": manifest.get("experiment_id") == dynamic.EXPERIMENT_ID,
        "preflight_pass": manifest.get("preflight_pass") is True,
        "llm_not_trained": manifest.get("llm_training_performed") is False,
        "llm_not_loaded": manifest.get("llm_loaded") is False,
        "no_power_flow": manifest.get("power_flow_calls") == 0,
        "traditional_baseline_fit": manifest.get("traditional_baseline_fit") is True,
        "artifacts_current": bool(artifact_checks) and all(artifact_checks.values()),
        "code_current": manifest.get("code_sha256") == dynamic.code_hashes(),
        "development_reuse_disclosed": manifest.get("development_reuse_disclosed") is True,
        "fresh_final_test_required": manifest.get("fresh_final_test_required_after_model_selection") is True,
        "both_tracks_present": {
            "unseen_paraphrase_primary", "unseen_paraphrase_replication",
            "unseen_composition",
        }.issubset(manifest.get("suites", {})),
    }
    result = {
        "msg": "GridRank dynamic benchmark result verification",
        "checks": checks,
        "verification_pass": all(checks.values()),
        "decision": manifest.get("decision"),
        "failed_checks": manifest.get("failed_checks", []),
    }
    print(json.dumps(result, ensure_ascii=False))
    if not result["verification_pass"]:
        raise SystemExit(2)


def main():
    args = parse_args()
    if args.manifest:
        verify_manifest(args.manifest)
    else:
        static_checks()


if __name__ == "__main__":
    main()
