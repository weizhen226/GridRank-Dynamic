#!/usr/bin/env bash
set -euo pipefail

resolve_executable () {
  local requested="$1"
  if [[ "$requested" == */* ]]; then
    test -x "$requested" && printf '%s\n' "$requested"
  else
    command -v -- "$requested"
  fi
}
TRAIN_PYTHON_BIN="$(resolve_executable "${TRAIN_PYTHON:-python}")" || {
  echo "TRAIN_PYTHON is not executable" >&2; exit 2;
}

TAG="${TAG:-gridrank_label_controls_v1_20260811}"
SOURCE_TAG="${SOURCE_TAG:-gridrank_select_confirm_v1_20260725}"
SUITE_PREFLIGHT="${SUITE_PREFLIGHT:-${TAG}.preflight.json}"
TEST_JSONL="${TEST_JSONL:-${SOURCE_TAG}_test.jsonl}"
SHUFFLED_GATE="${SHUFFLED_GATE:-output_${TAG}_shuffled_labels/gridrank_select_gate.json}"
LINDISTFLOW_GATE="${LINDISTFLOW_GATE:-output_${TAG}_lindistflow_labels/gridrank_select_gate.json}"
OUTPUT="${OUTPUT:-${TAG}_aggregate_hotfix.json}"

for path in "$SUITE_PREFLIGHT" "$TEST_JSONL" "$SHUFFLED_GATE" "$LINDISTFLOW_GATE"; do
  test -f "$path" || { echo "missing hotfix input: $path" >&2; exit 2; }
done
test ! -e "$OUTPUT" || { echo "refusing to overwrite hotfix aggregate: $OUTPUT" >&2; exit 2; }

echo "=== 1/3 DEPENDENCY-LIGHT HOTFIX REGRESSION ==="
"$TRAIN_PYTHON_BIN" -B verify_gridrank_label_controls_hotfix.py

echo "=== 2/3 RECONSTRUCT LOCKED STATE REGRETS AND AGGREGATE ==="
"$TRAIN_PYTHON_BIN" -B aggregate_gridrank_label_controls_hotfix.py \
  --suite_preflight "$SUITE_PREFLIGHT" --test_jsonl "$TEST_JSONL" \
  --gate "shuffled_labels=$SHUFFLED_GATE" \
  --gate "lindistflow_labels=$LINDISTFLOW_GATE" \
  --bootstrap_reps 10000 --bootstrap_seed 20260811 --output "$OUTPUT"

echo "=== 3/3 VERIFY HOTFIX DECISION ARTIFACT ==="
"$TRAIN_PYTHON_BIN" -B verify_gridrank_label_controls_hotfix.py \
  --aggregate "$OUTPUT" --suite_preflight "$SUITE_PREFLIGHT"
echo "=== GRIDRANK LABEL-CONTROL AGGREGATION HOTFIX COMPLETE ==="
