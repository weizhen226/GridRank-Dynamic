"""Check inputs for GridRank select extension."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import preflight_gridrank_feedback as runtime
from build_gridrank_select import file_sha256
from gridrank_runtime_compat import runtime_compatibility
from make_gridrank_extension_state_view import SCHEMA as VIEW_SCHEMA


HERE = Path(__file__).resolve().parent
SCHEMA = "gridrank-select-extension-preflight-v1"
EXTENSION_ID = "gridrank-select-frozen-adapter-unused-test-extension-v1"
SEEDS = (42, 123, 2025)
EXTENSION_ROWS_PER_NETWORK = 32
EXTENSION_CODE_FILES = (
    "gridrank_runtime_compat.py",
    "make_gridrank_extension_state_view.py",
    "preflight_gridrank_select_extension.py",
    "eval_gridrank_select_extension.py",
    "verify_gridrank_select_extension.py",
    "run_gridrank_select_extension.sh",
    "../../docs/GRIDRANK_SELECT_EXTENSION_PROTOCOL.md",
)


def _json(path):
    with open(path, encoding="utf-8") as handle:
        return json.load(handle)


def _rows(path):
    return [json.loads(line) for line in open(path, encoding="utf-8") if line.strip()]


def _specs(values, label, expect=SEEDS):
    output = {}
    for spec in values:
        key, raw = spec.split("=", 1)
        key = int(key) if all(isinstance(item, int) for item in expect) else key
        if key in output:
            raise ValueError(f"duplicate {label}: {key}")
        path = Path(raw).resolve()
        if not path.is_file() and not path.is_dir():
            raise FileNotFoundError(path)
        output[key] = path
    if set(output) != set(expect):
        raise ValueError(f"{label} requires {tuple(expect)}")
    return output


def _record(path):
    path = Path(path).resolve()
    return {"path": str(path), "sha256": file_sha256(path)}


def _adapter_record(path):
    root = Path(path).resolve()
    return {
        "path": str(root),
        "adapter_config_json": file_sha256(root / "adapter_config.json"),
        "adapter_model_safetensors": file_sha256(root / "adapter_model.safetensors"),
    }


def _current_code_hashes(locked):
    output = {}
    for name in locked:
        path = HERE / name
        if not path.is_file():
            raise FileNotFoundError(f"missing locked extension code: {name}")
        output[name] = file_sha256(path)
    return output


def _split_audit(extension_test, prior_paths):
    extension = _rows(extension_test)
    prior = [row for path in prior_paths for row in _rows(path)]
    ext_states = {row["physical_state_sha256"] for row in extension}
    ext_loads = {row["load_id"] for row in extension}
    prior_states = {row["physical_state_sha256"] for row in prior}
    prior_loads = {row["load_id"] for row in prior}
    by_network = {
        network: sum(str(row["network_id"]) == network for row in extension)
        for network in ("33", "69")
    }
    checks = {
        "extension_rows_64": len(extension) == 2 * EXTENSION_ROWS_PER_NETWORK,
        "balanced_networks": all(
            by_network[network] == EXTENSION_ROWS_PER_NETWORK for network in ("33", "69")
        ),
        "one_row_per_state": len(ext_states) == len(extension),
        "extension_state_disjoint_prior": not ext_states.intersection(prior_states),
        "extension_load_disjoint_prior": not ext_loads.intersection(prior_loads),
    }
    return {
        "extension_rows": len(extension),
        "by_network": by_network,
        "prior_rows_scanned": len(prior),
        "extension_state_sha256s": sorted(ext_states),
        "checks": checks,
    }, checks


def create(args):
    output = Path(args.output)
    if output.exists():
        raise FileExistsError(f"refusing to overwrite {output}")
    gates = _specs(args.original_gate, "original_gate")
    adapters = _specs(args.seed_adapter, "seed_adapter")
    views = _specs(args.test_view, "test_view", expect=("33", "69"))
    view_manifests = _specs(
        args.test_view_manifest, "test_view_manifest", expect=("33", "69")
    )
    gate_payloads = {seed: _json(path) for seed, path in gates.items()}
    aggregate = _json(args.original_aggregate)
    upstream = _json(args.upstream_summary)
    upstream_audit = _json(args.upstream_audit)
    data_summary = _json(args.data_summary)
    data_audit = _json(args.data_audit)

    primary = aggregate.get("primary_checks", {})
    sole_original_failure = (
        primary.get("two_way_seed_state_ci_lower_gt_zero") is False
        and all(value for key, value in primary.items()
                if key != "two_way_seed_state_ci_lower_gt_zero")
    )
    adapter_records = {str(seed): _adapter_record(path) for seed, path in adapters.items()}
    adapter_hashes = {
        record["adapter_model_safetensors"] for record in adapter_records.values()
    }
    gate_checks = {}
    for seed in SEEDS:
        gate = gate_payloads[seed]
        gate_checks[f"gate_{seed}_identity"] = (
            gate.get("schema") == "gridrank-select-confirm-seed-gate-v1"
            and gate.get("confirmation_seed") == seed
            and gate.get("engineering_gate_pass") is True
        )
        gate_checks[f"adapter_{seed}_matches_gate"] = (
            adapter_records[str(seed)]["adapter_model_safetensors"]
            == gate.get("diagnostic_adapter", {}).get("sha256", {}).get(
                "adapter_model_safetensors"
            )
        )

    validation_sources = upstream.get("sources", {}).get("validation", {})
    view_records, view_checks = {}, {}
    for network in ("33", "69"):
        manifest = _json(view_manifests[network])
        view_records[network] = {
            "raw": _record(manifest["source_path"]),
            "view": _record(views[network]),
            "manifest": _record(view_manifests[network]),
        }
        view_checks[f"view_{network}_locked"] = (
            manifest.get("schema") == VIEW_SCHEMA
            and manifest.get("network") == network
            and manifest.get("source_sha256") == file_sha256(manifest["source_path"])
            and manifest.get("output_sha256") == file_sha256(views[network])
            and manifest.get("source_text_forwarded") is False
            and validation_sources.get(network, {}).get("sha256")
                == file_sha256(views[network])
        )

    split_audit, split_checks = _split_audit(
        args.test_jsonl,
        [args.original_train_jsonl, args.original_test_jsonl, args.pilot_test_jsonl],
    )
    current_training = runtime.training_runtime()
    current_physics = runtime.physics_runtime(args.physics_python)
    original_runtime = gate_payloads[42]["locked_manifest"]
    original_model_inventory = {
        name: int(record["bytes"])
        for name, record in original_runtime.get("base_model_manifest", {}).items()
    }
    training_compat = runtime_compatibility(
        original_runtime.get("training_runtime"), current_training
    )
    physics_compat = runtime_compatibility(
        original_runtime.get("physics_runtime"), current_physics
    )

    code_hashes = dict(original_runtime.get("code_sha256", {}))
    for name in EXTENSION_CODE_FILES:
        path = HERE / name
        if not path.is_file():
            raise FileNotFoundError(f"missing extension code: {name}")
        code_hashes[name] = file_sha256(path)

    artifacts = {
        "upstream_summary": _record(args.upstream_summary),
        "upstream_audit": _record(args.upstream_audit),
        "select_train": _record(args.train_jsonl),
        "select_test": _record(args.test_jsonl),
        "select_summary": _record(args.data_summary),
        "select_audit": _record(args.data_audit),
        "original_train": _record(args.original_train_jsonl),
        "original_test": _record(args.original_test_jsonl),
        "pilot_test": _record(args.pilot_test_jsonl),
        "original_aggregate": _record(args.original_aggregate),
    }
    checks = {
        "original_aggregate_preserved_failure": aggregate.get("confirmation_gate_pass") is False,
        "original_aggregate_only_two_way_failed": sole_original_failure,
        "three_distinct_frozen_adapters": len(adapter_hashes) == 3,
        "upstream_feedback_schema": upstream.get("schema") == "gridrank-feedback-v1",
        "upstream_feedback_audit_pass": upstream_audit.get("audit_pass") is True,
        "candidate_pool_frozen": upstream.get("candidate_pool_size") == 16
            and upstream.get("candidate_seed") == 20260721
            and upstream.get("row_seed") == 20260726,
        "select_data_audit_pass": data_audit.get("audit_pass") is True,
        "select_objective_loss": data_summary.get("objective") == "loss",
        "evaluation_only": True,
        "training_runtime_compatible": training_compat["compatible"],
        "physics_runtime_compatible": physics_compat["compatible"],
        "base_model_inventory": runtime.model_inventory(args.base_model)
            == original_model_inventory,
        **gate_checks,
        **view_checks,
        **{f"split_{key}": value for key, value in split_checks.items()},
    }
    result = {
        "msg": "GridRank-Select frozen-adapter unused-test extension preflight",
        "schema": SCHEMA,
        "extension_id": EXTENSION_ID,
        "preflight_pass": all(checks.values()),
        "evaluation_only": True,
        "training_performed": False,
        "seeds": list(SEEDS),
        "extension_rows_per_network": EXTENSION_ROWS_PER_NETWORK,
        "topk": 3,
        "bootstrap_reps": args.bootstrap_reps,
        "bootstrap_seed": 20260726,
        "artifacts": artifacts,
        "views": view_records,
        "original_gates": {str(seed): _record(path) for seed, path in gates.items()},
        "frozen_adapters": adapter_records,
        "sft_adapter": _adapter_record(args.sft_adapter),
        "base_model": str(Path(args.base_model).resolve()),
        "base_model_manifest": runtime.model_inventory(args.base_model),
        "training_runtime": current_training,
        "physics_runtime": current_physics,
        "runtime_compatibility": {"training": training_compat, "physics": physics_compat},
        "split_audit": split_audit,
        "code_sha256": code_hashes,
        "checks": checks,
    }
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(result, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps(result, ensure_ascii=False))
    if not result["preflight_pass"]:
        raise SystemExit(2)


def verify(args):
    manifest = _json(args.output)
    current_training = runtime.training_runtime()
    current_physics = runtime.physics_runtime(args.physics_python)
    training_compat = runtime_compatibility(manifest.get("training_runtime"), current_training)
    physics_compat = runtime_compatibility(manifest.get("physics_runtime"), current_physics)
    artifact_checks = all(
        Path(record["path"]).is_file()
        and file_sha256(record["path"]) == record["sha256"]
        for record in manifest.get("artifacts", {}).values()
    )
    gate_checks = all(
        Path(record["path"]).is_file()
        and file_sha256(record["path"]) == record["sha256"]
        for record in manifest.get("original_gates", {}).values()
    )
    view_checks = all(
        Path(record["path"]).is_file()
        and file_sha256(record["path"]) == record["sha256"]
        for group in manifest.get("views", {}).values()
        for record in group.values()
    )
    adapter_checks = all(
        _adapter_record(record["path"]) == record
        for record in manifest.get("frozen_adapters", {}).values()
    )
    checks = {
        "schema": manifest.get("schema") == SCHEMA,
        "extension_id": manifest.get("extension_id") == EXTENSION_ID,
        "preflight_pass": manifest.get("preflight_pass") is True,
        "evaluation_only": manifest.get("evaluation_only") is True
            and manifest.get("training_performed") is False,
        "artifacts_current": artifact_checks,
        "gates_current": gate_checks,
        "views_current": view_checks,
        "adapters_current": adapter_checks,
        "sft_current": _adapter_record(manifest["sft_adapter"]["path"])
            == manifest["sft_adapter"],
        "code_current": _current_code_hashes(manifest.get("code_sha256", {}))
            == manifest.get("code_sha256", {}),
        "base_model_inventory": runtime.model_inventory(args.base_model)
            == manifest.get("base_model_manifest"),
        "training_runtime_compatible": training_compat["compatible"],
        "physics_runtime_compatible": physics_compat["compatible"],
        "bootstrap_reps": manifest.get("bootstrap_reps") == args.bootstrap_reps,
    }
    result = {
        "msg": "GridRank-Select extension runtime verification",
        "checks": checks,
        "verification_pass": all(checks.values()),
    }
    print(json.dumps(result, ensure_ascii=False))
    if not result["verification_pass"]:
        raise SystemExit(2)


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", choices=("create", "verify"), required=True)
    parser.add_argument("--upstream_summary")
    parser.add_argument("--upstream_audit")
    parser.add_argument("--train_jsonl")
    parser.add_argument("--test_jsonl")
    parser.add_argument("--data_summary")
    parser.add_argument("--data_audit")
    parser.add_argument("--original_train_jsonl")
    parser.add_argument("--original_test_jsonl")
    parser.add_argument("--pilot_test_jsonl")
    parser.add_argument("--original_gate", action="append", default=[])
    parser.add_argument("--original_aggregate")
    parser.add_argument("--test_view", action="append", default=[])
    parser.add_argument("--test_view_manifest", action="append", default=[])
    parser.add_argument("--seed_adapter", action="append", default=[])
    parser.add_argument("--sft_adapter")
    parser.add_argument("--base_model", required=True)
    parser.add_argument("--physics_python", required=True)
    parser.add_argument("--bootstrap_reps", type=int, required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    if args.mode == "create":
        required = (
            "upstream_summary", "upstream_audit", "train_jsonl", "test_jsonl",
            "data_summary", "data_audit", "original_train_jsonl",
            "original_test_jsonl", "pilot_test_jsonl", "original_aggregate",
            "sft_adapter",
        )
        missing = [name for name in required if not getattr(args, name)]
        if missing or len(args.original_gate) != 3 or len(args.seed_adapter) != 3 \
                or len(args.test_view) != 2 or len(args.test_view_manifest) != 2:
            raise ValueError(f"missing extension create inputs: {missing}")
    if args.bootstrap_reps <= 0:
        raise ValueError("bootstrap reps must be positive")
    return args


def main():
    args = parse_args()
    (create if args.mode == "create" else verify)(args)


if __name__ == "__main__":
    main()
