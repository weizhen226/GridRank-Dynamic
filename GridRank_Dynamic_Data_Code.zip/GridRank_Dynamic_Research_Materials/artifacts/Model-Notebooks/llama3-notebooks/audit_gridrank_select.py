"""Audit GridRank select."""

from __future__ import annotations

import argparse
import json
import math
from collections import Counter
from pathlib import Path

from build_gridrank_select import (
    CANDIDATE_FIELDS,
    GATE_ANCHOR_FIELDS,
    NOOP,
    ROW_FIELDS,
    ROW_SCHEMA,
    SUMMARY_SCHEMA,
    derive_row,
    file_sha256,
    load_json,
    load_jsonl,
    partition_summary,
    validate_derived_row,
    validate_source_rows,
    validate_upstream,
)


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--upstream_summary", required=True)
    parser.add_argument("--upstream_audit", required=True)
    parser.add_argument("--offline_jsonl", required=True)
    parser.add_argument("--test_jsonl", required=True)
    parser.add_argument("--select_summary", required=True)
    parser.add_argument("--train_jsonl", required=True)
    parser.add_argument("--select_test_jsonl", required=True)
    parser.add_argument("--output", required=True)
    return parser.parse_args()


def _exact_rows(actual, expected, name):
    if len(actual) != len(expected):
        raise ValueError(f"{name} row count mismatch")
    actual_map = {row.get("instance_id"): row for row in actual}
    expected_map = {row["instance_id"]: row for row in expected}
    if len(actual_map) != len(actual) or set(actual_map) != set(expected_map):
        raise ValueError(f"{name} instance set mismatch")
    for instance_id in sorted(expected_map):
        if actual_map[instance_id] != expected_map[instance_id]:
            raise ValueError(f"{name} row is not an exact derivation: {instance_id}")


def _partition_audit(rows, expected_partition, candidate_count):
    network_mix = Counter()
    accepted = Counter()
    unsafe = Counter()
    for row in rows:
        validate_derived_row(row, expected_partition, candidate_count)
        if set(row) != ROW_FIELDS or row["schema"] != ROW_SCHEMA:
            raise ValueError(f"strict row schema failed: {row.get('instance_id')}")
        if any(set(candidate) != CANDIDATE_FIELDS for candidate in row["candidates"]):
            raise ValueError(f"strict candidate schema failed: {row['instance_id']}")
        if set(row["gate_anchor"]) != GATE_ANCHOR_FIELDS:
            raise ValueError(f"strict anchor schema failed: {row['instance_id']}")
        network = str(row["network_id"])
        network_mix[network] += 1
        for candidate in row["candidates"]:
            accepted[network] += int(candidate["accepted_by_gate"] is True)
            unsafe[network] += int(candidate["accepted_by_gate"] is not True)
            if not candidate["ranking_eligible"] and candidate["target_prob"] != 0.0:
                raise ValueError(f"unsafe ranking target mass: {row['instance_id']}")
        if row["gate_anchor"]["action"] != NOOP:
            raise ValueError(f"gate anchor is not no-op: {row['instance_id']}")
        if row["desired_action"] == NOOP or any(
            candidate["action"] == NOOP for candidate in row["candidates"]
        ):
            raise ValueError(f"always-noop shortcut is representable: {row['instance_id']}")
        if not math.isclose(
            sum(candidate["target_prob"] for candidate in row["candidates"]),
            1.0, rel_tol=0.0, abs_tol=1e-10,
        ):
            raise ValueError(f"target distribution is not normalised: {row['instance_id']}")
    if set(network_mix) != {"33", "69"}:
        raise ValueError(f"{expected_partition} does not contain both networks")
    if any(accepted[network] <= 0 or unsafe[network] <= 0 for network in ("33", "69")):
        raise ValueError(f"{expected_partition} lacks accepted/unsafe mix")
    return {
        **partition_summary(rows),
        "accepted_by_network": dict(accepted),
        "unsafe_by_network": dict(unsafe),
    }


def main():
    args = parse_args()
    upstream_artifacts = {
        "offline_train": args.offline_jsonl,
        "test": args.test_jsonl,
    }
    upstream_summary, upstream_audit = validate_upstream(
        args.upstream_summary, args.upstream_audit, upstream_artifacts
    )
    summary = load_json(args.select_summary)
    if summary.get("schema") != SUMMARY_SCHEMA:
        raise ValueError("unexpected GridRank-Select summary schema")
    expected_summary_fields = {
        "msg", "schema", "objective", "llm_ranking_membership",
        "final_gate_anchor", "target_definition", "target_temperature",
        "fixed_nonnoop_candidate_count", "upstream", "partitions",
        "artifacts", "code_sha256", "coverage_pass",
    }
    if set(summary) != expected_summary_fields:
        raise ValueError("GridRank-Select summary field set mismatch")
    if summary["objective"] != "loss" or summary["coverage_pass"] is not True:
        raise ValueError("GridRank-Select summary objective/coverage mismatch")
    upstream_record = summary["upstream"]
    expected_upstream_fields = {
        "summary", "audit", "artifacts", "summary_artifact_sha256",
        "audit_artifact_sha256",
    }
    if set(upstream_record) != expected_upstream_fields:
        raise ValueError("GridRank-Select upstream lock schema mismatch")
    current_upstream_hashes = {
        "summary": file_sha256(args.upstream_summary),
        "audit": file_sha256(args.upstream_audit),
    }
    for name, path in (("summary", args.upstream_summary), ("audit", args.upstream_audit)):
        record = upstream_record[name]
        if set(record) != {"path", "sha256"} or record["sha256"] != current_upstream_hashes[name]:
            raise ValueError(f"select summary upstream {name} hash mismatch")
    current_source_hashes = {
        name: file_sha256(path) for name, path in upstream_artifacts.items()
    }
    if set(upstream_record["artifacts"]) != set(current_source_hashes):
        raise ValueError("select summary upstream artifact set mismatch")
    for name, observed in current_source_hashes.items():
        record = upstream_record["artifacts"][name]
        if set(record) != {"path", "sha256"} or record["sha256"] != observed:
            raise ValueError(f"select summary upstream artifact mismatch: {name}")
    summary_artifact_hashes = {
        name: record["sha256"] for name, record in upstream_summary["artifacts"].items()
    }
    if upstream_record["summary_artifact_sha256"] != summary_artifact_hashes:
        raise ValueError("select summary altered upstream summary artifact locks")
    if upstream_record["audit_artifact_sha256"] != upstream_audit["artifact_sha256"]:
        raise ValueError("select summary altered upstream audit artifact locks")
    if upstream_record["summary_artifact_sha256"] != upstream_record["audit_artifact_sha256"]:
        raise ValueError("upstream summary/audit artifact locks differ")

    expected_source_count = int(upstream_summary["candidate_pool_size"])
    expected_nonnoop_count = expected_source_count - 1
    if summary["fixed_nonnoop_candidate_count"] != expected_nonnoop_count:
        raise ValueError("fixed non-noop candidate count mismatch")
    offline_source = validate_source_rows(
        load_jsonl(args.offline_jsonl), "offline_train", expected_source_count
    )
    test_source = validate_source_rows(
        load_jsonl(args.test_jsonl), "test", expected_source_count
    )
    expected_train = [
        derive_row(row, "train", float(summary["target_temperature"]))
        for row in offline_source
    ]
    expected_test = [
        derive_row(row, "test", float(summary["target_temperature"]))
        for row in test_source
    ]
    train_rows = load_jsonl(args.train_jsonl)
    test_rows = load_jsonl(args.select_test_jsonl)
    _exact_rows(train_rows, expected_train, "train")
    _exact_rows(test_rows, expected_test, "test")
    partition_audits = {
        "train": _partition_audit(train_rows, "train", expected_nonnoop_count),
        "test": _partition_audit(test_rows, "test", expected_nonnoop_count),
    }
    train_states = {row["physical_state_sha256"] for row in train_rows}
    test_states = {row["physical_state_sha256"] for row in test_rows}
    train_loads = {row["load_id"] for row in train_rows}
    test_loads = {row["load_id"] for row in test_rows}
    state_disjoint = not train_states.intersection(test_states)
    load_disjoint = not train_loads.intersection(test_loads)
    artifact_paths = {"train": args.train_jsonl, "test": args.select_test_jsonl}
    artifact_hashes = {name: file_sha256(path) for name, path in artifact_paths.items()}
    artifact_hashes_match = set(summary["artifacts"]) == set(artifact_hashes) and all(
        set(summary["artifacts"][name]) == {"path", "sha256"}
        and summary["artifacts"][name]["sha256"] == digest
        for name, digest in artifact_hashes.items()
    )
    summary_counts_match = summary["partitions"] == {
        name: partition_summary(rows)
        for name, rows in (("train", train_rows), ("test", test_rows))
    }
    build_code_match = summary["code_sha256"] == {
        "build_gridrank_select.py": file_sha256(Path(__file__).with_name("build_gridrank_select.py"))
    }
    checks = {
        "upstream_audit_passed": upstream_audit["audit_pass"] is True,
        "upstream_summary_hash_locked": upstream_record["summary"]["sha256"]
            == current_upstream_hashes["summary"],
        "upstream_audit_hash_locked": upstream_record["audit"]["sha256"]
            == current_upstream_hashes["audit"],
        "upstream_artifact_hashes_locked": upstream_record["summary_artifact_sha256"]
            == upstream_record["audit_artifact_sha256"],
        "derived_rows_exact": True,
        "one_loss_row_per_state": all(
            audit["rows"] == audit["base_states"] for audit in partition_audits.values()
        ),
        "unique_load_per_row": all(
            audit["rows"] == audit["loads"] for audit in partition_audits.values()
        ),
        "both_networks": all(
            set(audit["network_mix"]) == {"33", "69"}
            for audit in partition_audits.values()
        ),
        "fixed_nonnoop_candidate_count": all(
            audit["candidate_count_min"] == expected_nonnoop_count
            and audit["candidate_count_max"] == expected_nonnoop_count
            for audit in partition_audits.values()
        ),
        "noop_absent_from_llm_ranking": all(
            candidate["action"] != NOOP
            for row in [*train_rows, *test_rows] for candidate in row["candidates"]
        ),
        "noop_anchor_separate": all(
            row["gate_anchor"]["role"] == "noop-anchor-only"
            and row["gate_anchor"]["action"] == NOOP
            for row in [*train_rows, *test_rows]
        ),
        "always_noop_policy_impossible": all(
            row["desired_action"] != NOOP for row in [*train_rows, *test_rows]
        ),
        "targets_renormalised": all(
            math.isclose(
                sum(candidate["target_prob"] for candidate in row["candidates"]),
                1.0, rel_tol=0.0, abs_tol=1e-10,
            )
            for row in [*train_rows, *test_rows]
        ),
        "accepted_and_unsafe_mix_each_network": all(
            all(
                audit["accepted_by_network"].get(network, 0) > 0
                and audit["unsafe_by_network"].get(network, 0) > 0
                for network in ("33", "69")
            )
            for audit in partition_audits.values()
        ),
        "train_test_state_disjoint": state_disjoint,
        "train_test_load_disjoint": load_disjoint,
        "artifact_hashes_match_summary": artifact_hashes_match,
        "summary_counts_match": summary_counts_match,
        "build_code_hash_matches": build_code_match,
    }
    result = {
        "msg": "GridRank-Select strict derivation/provenance audit",
        "schema": "gridrank-select-audit-v1",
        "summary_sha256": file_sha256(args.select_summary),
        "artifact_sha256": artifact_hashes,
        "upstream_sha256": {
            **current_upstream_hashes,
            "artifacts": current_source_hashes,
        },
        "code_sha256": {
            "build_gridrank_select.py": file_sha256(Path(__file__).with_name("build_gridrank_select.py")),
            "audit_gridrank_select.py": file_sha256(Path(__file__).resolve()),
        },
        "partition_audits": partition_audits,
        "checks": checks,
        "audit_pass": all(checks.values()),
    }
    Path(args.output).parent.mkdir(parents=True, exist_ok=True)
    Path(args.output).write_text(
        json.dumps(result, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    print(json.dumps(result, ensure_ascii=False))
    if not result["audit_pass"]:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
