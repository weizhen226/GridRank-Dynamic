"""Validate GridRank select extension."""

from __future__ import annotations

import argparse
import ast
import json
import tempfile
from pathlib import Path

import eval_gridrank_select_extension as evaluation
import make_gridrank_extension_state_view as view
from make_no_oracle_state_view import _source_rows


HERE = Path(__file__).resolve().parent


def require(value, message):
    if not value:
        raise AssertionError(message)


def view_regression(specs):
    results = {}
    with tempfile.TemporaryDirectory(prefix="gridrank_extension_") as raw_tmp:
        tmp = Path(raw_tmp)
        for network, source in specs.items():
            selected = []
            for row in _source_rows(source):
                if str(row.get("split")) != "test":
                    continue
                prompt = view.canonical_state_text(str(row["prompt"]), network)
                selected.append({
                    "network_id": network,
                    "physical_state_sha256": view.physical_state_sha256(prompt, network),
                    "load_id": f"{network}:{row['load_id']}",
                })
                if len(selected) == 2:
                    break
            require(len(selected) == 2, f"network {network} raw test too small")
            prior = tmp / f"prior_{network}.jsonl"
            prior.write_text(
                "".join(json.dumps(row) + "\n" for row in selected), encoding="utf-8"
            )
            output = tmp / f"view_{network}.jsonl"
            manifest = tmp / f"view_{network}.manifest.json"
            args = argparse.Namespace(
                input=str(source), network=network, exclude_jsonl=[str(prior)],
                output_jsonl=str(output), manifest_json=str(manifest),
            )
            built = view.build(args)
            checked = view.verify(args)
            emitted = [json.loads(line) for line in open(output, encoding="utf-8") if line.strip()]
            require(checked["verification_pass"], "extension view did not verify")
            require(not {row["load_id"] for row in emitted}.intersection(
                {row["load_id"].split(":", 1)[1] for row in selected}
            ), "excluded loads remain in extension view")
            original = output.read_bytes()
            output.write_bytes(original + b"\n")
            rejected = False
            try:
                view.verify(args)
            except RuntimeError:
                rejected = True
            require(rejected, "mutated extension view was accepted")
            results[network] = {
                "emitted_rows": built["counters"]["emitted_rows"],
                "excluded_loads": built["counters"]["excluded_load"],
                "mutation_rejected": rejected,
            }
    return results


def statistics_regression():
    states = [f"state-{index:03d}" for index in range(64)]
    metadata = {
        state: {"network": "33" if index < 32 else "69"}
        for index, state in enumerate(states)
    }
    matrix = {
        seed: {state: 1.0 + 0.01 * offset for state in states}
        for offset, seed in enumerate(evaluation.SEEDS)
    }
    sft = {state: 4.0 for state in states}
    noop = {state: 6.0 for state in states}
    random = {state: 3.5 for state in states}
    feasible = {seed: 1.0 for seed in evaluation.SEEDS}
    result = evaluation._analysis(
        matrix, sft, noop, random, metadata, feasible, 1000, 20260726
    )
    require(result["gate_pass"], f"positive extension regression failed: {result['checks']}")
    require(result["two_way_seed_state_bootstrap_ci95"][0] > 0.0,
            "two-way synthetic lower bound is not positive")
    return result


def no_training_regression():
    path = HERE / "eval_gridrank_select_extension.py"
    tree = ast.parse(path.read_text(encoding="utf-8"))
    forbidden = []
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        if isinstance(node.func, ast.Attribute) and node.func.attr in {"backward", "step"}:
            forbidden.append(node.func.attr)
        if isinstance(node.func, ast.Name) and node.func.id in {"train", "Adam", "AdamW"}:
            forbidden.append(node.func.id)
    require(not forbidden, f"training calls found in evaluation-only entrypoint: {forbidden}")
    return True


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--test_raw", action="append", required=True,
                        help="NETWORK=RAW_TEST_JSONL")
    args = parser.parse_args()
    specs = {}
    for spec in args.test_raw:
        network, raw = spec.split("=", 1)
        specs[network] = Path(raw).resolve()
    require(set(specs) == {"33", "69"}, "extension regression requires 33/69")
    result = {
        "msg": "GridRank-Select extension dependency-light verification PASS",
        "unused_state_view": view_regression(specs),
        "evaluation_entrypoint_has_no_training_calls": no_training_regression(),
        "extension_and_combined_statistics": statistics_regression()["checks"],
        "fixed_extension_size": {"33": 32, "69": 32},
        "frozen_seeds": list(evaluation.SEEDS),
    }
    print(json.dumps(result, ensure_ascii=False))


if __name__ == "__main__":
    main()
