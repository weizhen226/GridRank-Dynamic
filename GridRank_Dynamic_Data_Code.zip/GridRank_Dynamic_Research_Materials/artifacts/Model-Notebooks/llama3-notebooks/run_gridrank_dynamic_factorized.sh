#!/usr/bin/env bash
set -euo pipefail

CURRENT_STAGE="bootstrap"
on_exit() {
  local rc=$?
  trap - EXIT
  if (( rc != 0 )); then
    printf '{"msg":"GridRank factorized dynamic-policy runner failure","stage":"%s","engineering_gate_pass":false,"exit_code":%d}\n' \
      "$CURRENT_STAGE" "$rc"
  fi
  exit "$rc"
}
trap on_exit EXIT

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"
export HF_HUB_OFFLINE=1
export TRANSFORMERS_OFFLINE=1
if [[ ! "${OMP_NUM_THREADS:-}" =~ ^[1-9][0-9]*$ ]]; then
  export OMP_NUM_THREADS=4
fi
export PYTORCH_CUDA_ALLOC_CONF="${PYTORCH_CUDA_ALLOC_CONF:-max_split_size_mb:64}"

PREFLIGHT_ONLY="${PREFLIGHT_ONLY:-1}"
case "$PREFLIGHT_ONLY" in 0|1) ;; *) echo "PREFLIGHT_ONLY must be 0 or 1" >&2; exit 2;; esac
if [[ "$PREFLIGHT_ONLY" == "1" ]]; then export CUDA_VISIBLE_DEVICES=""; fi

resolve_executable() {
  local requested="$1"
  if [[ "$requested" == */* ]]; then
    [[ -x "$requested" ]] && printf '%s\n' "$requested"
  else
    command -v -- "$requested"
  fi
}
TRAIN_PYTHON_BIN="$(resolve_executable "${TRAIN_PYTHON:-python}")" || exit 2

TAG="${TAG:-gridrank_dynamic_factorized_v1_20260828}"
[[ "$TAG" =~ ^[A-Za-z0-9][A-Za-z0-9._-]*$ ]] || { echo "invalid TAG" >&2; exit 2; }
PAIR_TAG="${PAIR_TAG:-gridrank_instruction_pairs_v2_20260809}"
BENCHMARK_TAG="${BENCHMARK_TAG:-gridrank_dynamic_benchmark_v1_20260826_hotfix1}"
JOINT_TAG="${JOINT_TAG:-gridrank_dynamic_policy_v1_20260827_hotfix2}"
TRAIN_JSONL="${TRAIN_JSONL:-${PAIR_TAG}_train.jsonl}"
VALIDATION_JSONL="${VALIDATION_JSONL:-${PAIR_TAG}_validation.jsonl}"
PAIR_SUMMARY="${PAIR_SUMMARY:-${PAIR_TAG}_summary.json}"
BENCHMARK_MANIFEST="${BENCHMARK_MANIFEST:-${BENCHMARK_TAG}.preflight.json}"
JOINT_PREFLIGHT="${JOINT_PREFLIGHT:-${JOINT_TAG}.preflight.json}"
JOINT_GATE="${JOINT_GATE:-output_${JOINT_TAG}/gridrank_dynamic_policy_gate.json}"
RESUME_ADAPTER="${RESUME_ADAPTER:-output_gridrank_select_confirm_v1_20260725_s42/diagnostic_adapter}"
SFT_ADAPTER="${SFT_ADAPTER:-output_gridintent_gate_33_69_v2_20260717/sft_only}"
BASE_MODEL="${BASE_MODEL:-../../Meta-Llama-3.1-8B-Instruct}"
PREFLIGHT="${PREFLIGHT:-${TAG}.preflight.json}"
OUT="${OUT:-output_${TAG}}"
GATE="$OUT/gridrank_dynamic_factorized_gate.json"

readonly MAX_LENGTH=512
readonly PRIMITIVE_BATCH_SIZE=1
readonly EPOCHS=4
readonly LEARNING_RATE=5e-6
readonly GRAD_ACCUM=4
readonly MAX_GRAD_NORM=1.0
readonly TARGET_TEMPERATURE=0.10
readonly LAMBDA_OBJECTIVE=0.5
readonly LAMBDA_CONSTRAINT=0.5
readonly LAMBDA_PHYSICS=1.0
readonly LAMBDA_HARD=0.5
readonly HARD_MARGIN=0.5
readonly BETA_REFERENCE=0.01
readonly SEED=42
readonly GRADIENT_CHECKPOINTING=1
readonly BOOTSTRAP_REPS=10000

for path in \
  "$TRAIN_JSONL" "$VALIDATION_JSONL" "$PAIR_SUMMARY" "$BENCHMARK_MANIFEST" \
  "$JOINT_PREFLIGHT" "$JOINT_GATE" \
  "$RESUME_ADAPTER/adapter_config.json" "$RESUME_ADAPTER/adapter_model.safetensors" \
  "$SFT_ADAPTER/adapter_config.json" "$SFT_ADAPTER/adapter_model.safetensors" \
  "$BASE_MODEL/config.json" "$BASE_MODEL/tokenizer_config.json" \
  gridrank_dynamic_llm.py preflight_gridrank_dynamic_policy.py \
  train_gridrank_dynamic_policy.py gridrank_dynamic_factorized_llm.py \
  preflight_gridrank_dynamic_factorized.py train_gridrank_dynamic_factorized.py \
  verify_gridrank_dynamic_factorized.py \
  verify_gridrank_dynamic_factorized_dependencies.py \
  preflight_gridrank_dynamic_benchmark.py build_gridrank_instruction_pairs.py \
  train_gridrank_select.py grpo_train.py \
  ../../docs/GRIDRANK_DYNAMIC_FACTORIZED_PROTOCOL.md; do
  test -e "$path" || { echo "missing factorized dynamic-policy input: $path" >&2; exit 2; }
done

COMMON_ARGS=(
  --train_jsonl "$TRAIN_JSONL"
  --validation_jsonl "$VALIDATION_JSONL"
  --pair_summary "$PAIR_SUMMARY"
  --benchmark_manifest "$BENCHMARK_MANIFEST"
  --joint_preflight "$JOINT_PREFLIGHT"
  --joint_gate "$JOINT_GATE"
  --resume_adapter_path "$RESUME_ADAPTER"
  --sft_adapter_path "$SFT_ADAPTER"
  --base_model "$BASE_MODEL"
  --max_length "$MAX_LENGTH"
  --primitive_batch_size "$PRIMITIVE_BATCH_SIZE"
  --epochs "$EPOCHS"
  --learning_rate "$LEARNING_RATE"
  --grad_accum "$GRAD_ACCUM"
  --max_grad_norm "$MAX_GRAD_NORM"
  --target_temperature "$TARGET_TEMPERATURE"
  --lambda_objective "$LAMBDA_OBJECTIVE"
  --lambda_constraint "$LAMBDA_CONSTRAINT"
  --lambda_physics "$LAMBDA_PHYSICS"
  --lambda_hard "$LAMBDA_HARD"
  --hard_margin "$HARD_MARGIN"
  --beta_reference "$BETA_REFERENCE"
  --seed "$SEED"
  --gradient_checkpointing "$GRADIENT_CHECKPOINTING"
  --bootstrap_reps "$BOOTSTRAP_REPS"
)

CURRENT_STAGE="dependency_regressions"
echo "=== 1/4 DEPENDENCY-LIGHT FACTORIZED-POLICY REGRESSIONS ==="
"$TRAIN_PYTHON_BIN" -B verify_gridrank_dynamic_factorized_dependencies.py

CURRENT_STAGE="locked_cpu_preflight"
echo "=== 2/4 LOCK SAME DATA, HIDDEN COMPOSITION, AND FACTORIZED LOSS ==="
"$TRAIN_PYTHON_BIN" -B preflight_gridrank_dynamic_factorized.py \
  "${COMMON_ARGS[@]}" --output "$PREFLIGHT"

if [[ "$PREFLIGHT_ONLY" == "1" ]]; then
  echo "=== GRIDRANK FACTORIZED DYNAMIC-POLICY CPU PREFLIGHT COMPLETE; GPU NOT STARTED ==="
  exit 0
fi

test ! -e "$OUT" || { echo "refusing to overwrite output: $OUT" >&2; exit 2; }

CURRENT_STAGE="cuda_readiness"
echo "=== 3/4 CUDA + BITSANDBYTES NF4 READINESS ==="
"$TRAIN_PYTHON_BIN" -B - <<'PY'
import json
result = {"msg": "GridRank factorized dynamic-policy CUDA readiness"}
try:
    import bitsandbytes as bnb
    import torch
    from transformers import BitsAndBytesConfig
    checks = {"cuda_available": bool(torch.cuda.is_available()), "visible_device_count": torch.cuda.device_count() > 0}
    device = torch.device("cuda:0") if all(checks.values()) else None
    if device is not None:
        probe = torch.ones(1, device=device)
        checks["cuda_tensor_ok"] = float(probe.item()) == 1.0
        free, total = torch.cuda.mem_get_info(device)
        result.update({"device": torch.cuda.get_device_name(device), "free_memory_bytes": int(free), "total_memory_bytes": int(total)})
        config = BitsAndBytesConfig(load_in_4bit=True, bnb_4bit_quant_type="nf4", bnb_4bit_compute_dtype=torch.float16, bnb_4bit_use_double_quant=True)
        layer = bnb.nn.Linear4bit(64, 64, bias=False, compute_dtype=torch.float16, compress_statistics=True, quant_type="nf4").to(device)
        value = layer(torch.randn(2, 64, device=device, dtype=torch.float16))
        torch.cuda.synchronize(device)
        checks["bitsandbytes_nf4_cuda_kernel_ok"] = bool(value.is_cuda and torch.isfinite(value).all())
        checks["bitsandbytes_config_ok"] = bool(config.load_in_4bit and config.bnb_4bit_quant_type == "nf4")
    else:
        checks.update({"cuda_tensor_ok": False, "bitsandbytes_nf4_cuda_kernel_ok": False, "bitsandbytes_config_ok": False})
except Exception as exc:
    checks = locals().get("checks", {})
    checks["exception_free"] = False
    result["error"] = f"{type(exc).__name__}: {exc}"
result["checks"] = checks
result["readiness_pass"] = bool(checks) and all(checks.values())
print(json.dumps(result, ensure_ascii=False))
raise SystemExit(0 if result["readiness_pass"] else 2)
PY

CURRENT_STAGE="gpu_factorized_policy"
echo "=== 4/4 FACTORIZED AC-FEEDBACK LORA + CAUSAL CONTROLS ==="
set +e
"$TRAIN_PYTHON_BIN" -u train_gridrank_dynamic_factorized.py \
  "${COMMON_ARGS[@]}" \
  --preflight_manifest "$PREFLIGHT" \
  --output_dir "$OUT"
TRAIN_RC=$?
set -e
if [[ ! -f "$GATE" ]]; then
  exit "$TRAIN_RC"
fi

CURRENT_STAGE="result_verification"
"$TRAIN_PYTHON_BIN" -B verify_gridrank_dynamic_factorized.py \
  --gate "$GATE" --preflight "$PREFLIGHT"
if (( TRAIN_RC != 0 )); then
  exit "$TRAIN_RC"
fi

echo "=== GRIDRANK FACTORIZED DYNAMIC-POLICY PILOT COMPLETE ==="
