"""Check inputs for GridRank label controls extension."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import preflight_gridrank_feedback as runtime
from build_gridrank_select import file_sha256
from gridrank_runtime_compat import runtime_compatibility


HERE = Path(__file__).resolve().parent
SCHEMA = "gridrank-label-controls-extension-preflight-v1"
EXPERIMENT_ID = "gridrank-matched-label-controls-unused-test-extension-v1"
METHODS = ("full_gridrank", "shuffled_labels", "lindistflow_labels")
CODE_FILES = (
    "gridrank_runtime_compat.py",
    "gridrank_select_llm.py",
    "train_gridrank_select.py",
    "aggregate_gridrank_label_controls_hotfix.py",
    "preflight_gridrank_label_controls_extension.py",
    "eval_gridrank_label_controls_extension.py",
    "verify_gridrank_label_controls_extension.py",
    "run_gridrank_label_controls_extension.sh",
    "../../docs/GRIDRANK_LABEL_CONTROLS_EXTENSION_PROTOCOL.md",
)


def _json(path):
    return json.load(open(path, encoding="utf-8"))


def _rows(path):
    return [json.loads(line) for line in open(path, encoding="utf-8") if line.strip()]


def _mappings(values, expected, label):
    output = {}
    for value in values:
        name, raw = value.split("=", 1)
        if name in output:
            raise ValueError(f"duplicate {label}: {name}")
        output[name] = Path(raw).resolve()
    if set(output) != set(expected):
        raise ValueError(f"{label} requires exactly {tuple(expected)}")
    return output


def _record(path):
    path = Path(path).resolve()
    if not path.is_file():
        raise FileNotFoundError(path)
    return {"path": str(path), "sha256": file_sha256(path)}


def _adapter_record(path):
    root = Path(path).resolve()
    return {
        "path": str(root),
        "adapter_config_json": file_sha256(root / "adapter_config.json"),
        "adapter_model_safetensors": file_sha256(root / "adapter_model.safetensors"),
    }


def _code_hashes():
    output = {}
    for name in CODE_FILES:
        path = HERE / name
        if not path.is_file():
            raise FileNotFoundError(f"missing extension source: {name}")
        output[name] = file_sha256(path)
    return output


def create(args):
    output = Path(args.output)
    if output.exists():
        raise FileExistsError(f"refusing to overwrite {output}")
    gates = _mappings(args.method_gate, METHODS, "method_gate")
    adapters = _mappings(args.method_adapter, METHODS, "method_adapter")
    extension = _json(args.extension_preflight)
    suite = _json(args.label_suite)
    aggregate = _json(args.label_aggregate)
    gate_payloads = {name: _json(path) for name, path in gates.items()}

    extension_rows = _rows(args.extension_test)
    original_rows = _rows(args.original_test)
    ext_states = {row["physical_state_sha256"] for row in extension_rows}
    old_states = {row["physical_state_sha256"] for row in original_rows}
    ext_loads = {(str(row["network_id"]), str(row["load_id"])) for row in extension_rows}
    old_loads = {(str(row["network_id"]), str(row["load_id"])) for row in original_rows}
    ext_networks = {
        network: sum(str(row["network_id"]) == network for row in extension_rows)
        for network in ("33", "69")
    }
    split_checks = {
        "extension_rows_64": len(extension_rows) == 64,
        "original_rows_64": len(original_rows) == 64,
        "extension_one_row_per_state": len(ext_states) == 64,
        "original_one_row_per_state": len(old_states) == 64,
        "extension_balanced_networks": ext_networks == {"33": 32, "69": 32},
        "state_disjoint": not ext_states.intersection(old_states),
        "load_disjoint": not ext_loads.intersection(old_loads),
    }

    gate_records = {name: _record(path) for name, path in gates.items()}
    adapter_records = {name: _adapter_record(path) for name, path in adapters.items()}
    adapter_gate_checks = {}
    for name in METHODS:
        gate = gate_payloads[name]
        adapter_gate_checks[f"{name}_adapter_matches_gate"] = (
            adapter_records[name]["adapter_model_safetensors"]
            == gate.get("diagnostic_adapter", {}).get("sha256", {}).get(
                "adapter_model_safetensors"
            )
        )
        adapter_gate_checks[f"{name}_live_cache_certified"] = all(
            gate.get("live_topk_gate", {}).get("summary", {}).get(key) == 1.0
            for key in (
                "valid_rate", "cache_labels_match_rate",
                "matches_cached_gate_rate", "selected_feasible_rate",
            )
        )

    expected_control_records = aggregate.get("control_gates", {})
    extension_test_record = extension.get("artifacts", {}).get("select_test", {})
    extension_original_record = extension.get("artifacts", {}).get("original_test", {})
    full_gate_record = suite.get("full_control_gate", {})
    sft_record = _adapter_record(args.sft_adapter)
    current_training = runtime.training_runtime()
    current_physics = runtime.physics_runtime(args.physics_python)
    training_compat = runtime_compatibility(
        extension.get("training_runtime"), current_training
    )
    physics_compat = runtime_compatibility(
        extension.get("physics_runtime"), current_physics
    )
    full_rows = gate_payloads["full_gridrank"].get("paired", {}).get(
        "distilled_vs_sft", {}
    ).get("state_rows")
    checks = {
        "extension_manifest_passed": extension.get("preflight_pass") is True
            and extension.get("evaluation_only") is True,
        "extension_split_audit_passed": all(
            extension.get("split_audit", {}).get("checks", {}).values()
        ),
        "extension_test_bound": file_sha256(args.extension_test)
            == extension_test_record.get("sha256"),
        "original_test_bound_extension": file_sha256(args.original_test)
            == extension_original_record.get("sha256"),
        "label_suite_passed": suite.get("preflight_pass") is True,
        "label_aggregate_passed": aggregate.get("audit_pass") is True
            and aggregate.get("schema") == "gridrank-label-controls-aggregate-v2",
        "aggregate_bound_to_suite": aggregate.get("suite_preflight", {}).get("sha256")
            == file_sha256(args.label_suite),
        "original_test_bound_suite": file_sha256(args.original_test)
            == suite.get("artifact_sha256", {}).get("test"),
        "full_gate_bound_suite": gate_records["full_gridrank"]["sha256"]
            == full_gate_record.get("sha256"),
        "shuffled_gate_bound_aggregate": gate_records["shuffled_labels"]["sha256"]
            == expected_control_records.get("shuffled_labels", {}).get("sha256"),
        "lindistflow_gate_bound_aggregate": gate_records["lindistflow_labels"]["sha256"]
            == expected_control_records.get("lindistflow_labels", {}).get("sha256"),
        "full_gate_schema": gate_payloads["full_gridrank"].get("schema")
            == "gridrank-select-confirm-seed-gate-v1",
        "control_gate_schemas": all(
            gate_payloads[name].get("schema") == "gridrank-label-control-gate-v1"
            and gate_payloads[name].get("label_control_variant") == name
            for name in ("shuffled_labels", "lindistflow_labels")
        ),
        "full_gate_has_original_state_evidence": isinstance(full_rows, list)
            and len(full_rows) == 64,
        "same_training_schedule": all(
            gate_payloads[name].get("training_schedule")
            == gate_payloads["full_gridrank"].get("training_schedule")
            for name in METHODS
        ),
        "same_sft_adapter_suite": sft_record["adapter_config_json"]
            == suite.get("resume_adapter_sha256", {}).get("adapter_config_json")
            and sft_record["adapter_model_safetensors"]
            == suite.get("resume_adapter_sha256", {}).get("adapter_model_safetensors"),
        "same_sft_adapter_extension": sft_record
            == extension.get("sft_adapter"),
        "three_distinct_frozen_adapters": len({
            record["adapter_model_safetensors"] for record in adapter_records.values()
        }) == 3,
        "base_model_inventory": runtime.model_inventory(args.base_model)
            == extension.get("base_model_manifest"),
        "training_runtime_compatible": training_compat["compatible"],
        "physics_runtime_compatible": physics_compat["compatible"],
        **split_checks,
        **adapter_gate_checks,
    }
    result = {
        "msg": "GridRank matched label-controls unused-test extension preflight",
        "schema": SCHEMA,
        "experiment_id": EXPERIMENT_ID,
        "preflight_pass": all(checks.values()),
        "evaluation_only": True,
        "training_performed": False,
        "methods": list(METHODS),
        "extension_rows": 64,
        "combined_rows": 128,
        "topk": 3,
        "bootstrap_reps": args.bootstrap_reps,
        "bootstrap_seed": 20260812,
        "artifacts": {
            "extension_preflight": _record(args.extension_preflight),
            "extension_test": _record(args.extension_test),
            "original_test": _record(args.original_test),
            "label_suite": _record(args.label_suite),
            "label_aggregate": _record(args.label_aggregate),
        },
        "method_gates": gate_records,
        "method_adapters": adapter_records,
        "sft_adapter": sft_record,
        "base_model": str(Path(args.base_model).resolve()),
        "base_model_manifest": runtime.model_inventory(args.base_model),
        "training_runtime": current_training,
        "physics_runtime": current_physics,
        "runtime_compatibility": {
            "training": training_compat, "physics": physics_compat,
        },
        "split_audit": {
            "extension_state_sha256s": sorted(ext_states),
            "original_state_sha256s": sorted(old_states),
            "extension_network_mix": ext_networks,
            "checks": split_checks,
        },
        "code_sha256": _code_hashes(),
        "checks": checks,
    }
    output.write_text(json.dumps(result, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps({
        "msg": result["msg"], "preflight_pass": result["preflight_pass"],
        "split_audit": result["split_audit"],
        "failed_checks": [key for key, value in checks.items() if not value],
    }, ensure_ascii=False))
    if not result["preflight_pass"]:
        raise SystemExit(2)


def verify(path, base_model, physics_python, bootstrap_reps):
    manifest = _json(path)
    training_compat = runtime_compatibility(
        manifest.get("training_runtime"), runtime.training_runtime()
    )
    physics_compat = runtime_compatibility(
        manifest.get("physics_runtime"), runtime.physics_runtime(physics_python)
    )
    checks = {
        "schema": manifest.get("schema") == SCHEMA,
        "experiment_id": manifest.get("experiment_id") == EXPERIMENT_ID,
        "preflight_pass": manifest.get("preflight_pass") is True,
        "evaluation_only": manifest.get("evaluation_only") is True
            and manifest.get("training_performed") is False,
        "artifacts_current": all(
            Path(record["path"]).is_file()
            and file_sha256(record["path"]) == record["sha256"]
            for record in manifest.get("artifacts", {}).values()
        ),
        "gates_current": all(
            _record(record["path"]) == record
            for record in manifest.get("method_gates", {}).values()
        ),
        "adapters_current": all(
            _adapter_record(record["path"]) == record
            for record in manifest.get("method_adapters", {}).values()
        ),
        "sft_current": _adapter_record(manifest["sft_adapter"]["path"])
            == manifest["sft_adapter"],
        "code_current": _code_hashes() == manifest.get("code_sha256"),
        "base_model_inventory": runtime.model_inventory(base_model)
            == manifest.get("base_model_manifest"),
        "training_runtime_compatible": training_compat["compatible"],
        "physics_runtime_compatible": physics_compat["compatible"],
        "bootstrap_reps": manifest.get("bootstrap_reps") == bootstrap_reps,
    }
    result = {
        "msg": "GridRank label-controls extension runtime verification",
        "checks": checks,
        "verification_pass": all(checks.values()),
    }
    print(json.dumps(result, ensure_ascii=False))
    if not result["verification_pass"]:
        raise SystemExit(2)
    return manifest


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", choices=("create", "verify"), required=True)
    parser.add_argument("--extension_preflight")
    parser.add_argument("--extension_test")
    parser.add_argument("--original_test")
    parser.add_argument("--label_suite")
    parser.add_argument("--label_aggregate")
    parser.add_argument("--method_gate", action="append", default=[])
    parser.add_argument("--method_adapter", action="append", default=[])
    parser.add_argument("--sft_adapter")
    parser.add_argument("--base_model", required=True)
    parser.add_argument("--physics_python", required=True)
    parser.add_argument("--bootstrap_reps", type=int, default=10000)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    if args.bootstrap_reps != 10000:
        raise ValueError("extension is locked to 10000 bootstrap replicates")
    if args.mode == "create":
        required = (
            "extension_preflight", "extension_test", "original_test",
            "label_suite", "label_aggregate", "sft_adapter",
        )
        missing = [name for name in required if not getattr(args, name)]
        if missing:
            raise ValueError(f"missing create inputs: {missing}")
        create(args)
    else:
        verify(args.output, args.base_model, args.physics_python, args.bootstrap_reps)


if __name__ == "__main__":
    main()
