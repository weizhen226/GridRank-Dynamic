"""Validate GridRank dynamic joint confirmation replication dependencies."""

from __future__ import annotations

import ast
import json
from pathlib import Path


HERE = Path(__file__).resolve().parent


def main():
    evaluator = ast.parse(
        (HERE / "eval_gridrank_dynamic_joint_confirmation_replication.py").read_text(
            encoding="utf-8"
        )
    )
    runner = (
        HERE / "run_gridrank_dynamic_joint_confirmation_replication.sh"
    ).read_text(encoding="utf-8")
    calls = [
        node.func.attr
        for node in ast.walk(evaluator)
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute)
    ]
    checks = {
        "only_predeclared_seeds": 'case "$MODEL_SEED" in 123|2025)' in runner,
        "evaluation_has_no_backward": "backward" not in calls,
        "evaluation_has_no_optimizer_step": "step" not in calls,
        "locked_ablation_evaluator_delegated": any(
            isinstance(node, ast.Import)
            and any(
                alias.name == "eval_gridrank_dynamic_factorization_ablation"
                for alias in node.names
            )
            for node in ast.walk(evaluator)
        ),
        "same_seed_factorized_records_explicit": (
            "FACTORIZED_CONFIRM_TAG" in runner
            and "FACTORIZED_RECORDS" in runner
        ),
        "failed_single_seed_efficacy_retained": (
            "EVAL_RC" in runner and "replication_evaluation_integrity_pass" in runner
        ),
        "no_power_flow_calls": not any(
            name in calls for name in ("runpp", "run_power_flow", "evaluate_action")
        ),
    }
    result = {
        "msg": "GridRank joint-card confirmation dependency verification",
        "checks": checks,
        "verification_pass": all(checks.values()),
        "training_performed": False,
        "model_loaded": False,
        "power_flow_calls": 0,
    }
    print(json.dumps(result, ensure_ascii=False))
    if not result["verification_pass"]:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
