#!/usr/bin/env bash

set -euo pipefail
SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"
export HF_HUB_OFFLINE=1
export TRANSFORMERS_OFFLINE=1
TRAIN_PYTHON_BIN="${TRAIN_PYTHON:-python}"
PHYSICS_PYTHON_BIN="${PHYSICS_PYTHON:-$TRAIN_PYTHON_BIN}"
PREFLIGHT_ONLY="${PREFLIGHT_ONLY:-1}"
case "$PREFLIGHT_ONLY" in 0|1) ;; *) echo "PREFLIGHT_ONLY must be 0 or 1" >&2; exit 2;; esac
if [[ "$PREFLIGHT_ONLY" == 1 ]]; then export CUDA_VISIBLE_DEVICES=""; fi
BASE_MODEL="${BASE_MODEL:-../../Meta-Llama-3.1-8B-Instruct}"
DATA_TAG="gridrank_dynamic_cross_topology_v1_20260907"
TAG="${TAG:-gridrank_dynamic_cross_topology_scoped_20261006_v2}"
[[ "$TAG" =~ ^[A-Za-z0-9][A-Za-z0-9._-]*$ ]] || { echo "invalid TAG" >&2; exit 2; }
[[ "$TAG" != "$DATA_TAG" ]] || { echo "Use a new run tag, not the historical tag" >&2; exit 2; }
PREFLIGHT="${TAG}.preflight.json"
OUT="output_${TAG}"
LLM42_TAG="${LLM42_TAG:-gridrank_dynamic_factorized_v1_20260828}"
LLM123_TAG="${LLM123_TAG:-gridrank_dynamic_factorized_replication_v1_s123_20260830}"
LLM2025_TAG="${LLM2025_TAG:-gridrank_dynamic_factorized_replication_v1_s2025_20260830}"
TRAIN_JSONL="${TRAIN_JSONL:-gridrank_instruction_pairs_v2_20260809_train.jsonl}"
required=("$TRAIN_JSONL" "$BASE_MODEL/config.json" "$BASE_MODEL/tokenizer_config.json"
          "${DATA_TAG}_pairs.jsonl" "${DATA_TAG}_summary.json" "${DATA_TAG}_audit.json")
for tag in "$LLM42_TAG" "$LLM123_TAG" "$LLM2025_TAG"; do
  required+=("output_${tag}/diagnostic_adapter/adapter_config.json"
             "output_${tag}/diagnostic_adapter/adapter_model.safetensors"
             "output_${tag}/gridrank_dynamic_factorized_gate.json")
done
for path in "${required[@]}"; do
  test -f "$path" || { echo "missing frozen input: $path" >&2; exit 2; }
done
ARGS=(--pairs "${DATA_TAG}_pairs.jsonl" --summary "${DATA_TAG}_summary.json"
      --audit "${DATA_TAG}_audit.json" --original_train "$TRAIN_JSONL"
      --llm_adapter "42=output_${LLM42_TAG}/diagnostic_adapter"
      --llm_adapter "123=output_${LLM123_TAG}/diagnostic_adapter"
      --llm_adapter "2025=output_${LLM2025_TAG}/diagnostic_adapter"
      --llm_gate "42=output_${LLM42_TAG}/gridrank_dynamic_factorized_gate.json"
      --llm_gate "123=output_${LLM123_TAG}/gridrank_dynamic_factorized_gate.json"
      --llm_gate "2025=output_${LLM2025_TAG}/gridrank_dynamic_factorized_gate.json"
      --base_model "$BASE_MODEL" --physics_python "$PHYSICS_PYTHON_BIN"
      --max_length 1024 --primitive_batch_size 4 --topk 1
      --bootstrap_reps 10000 --bootstrap_seed 20260907 --output "$PREFLIGHT")
"$TRAIN_PYTHON_BIN" -B verify_gridrank_dynamic_cross_topology_dependencies.py
if [[ ! -e "$PREFLIGHT" ]]; then
  "$TRAIN_PYTHON_BIN" -B preflight_gridrank_dynamic_cross_topology.py "${ARGS[@]}"
fi
"$TRAIN_PYTHON_BIN" -B preflight_gridrank_dynamic_cross_topology.py "${ARGS[@]}" --verify
if [[ "$PREFLIGHT_ONLY" == 1 ]]; then
  echo "Scoped CPU preflight complete; no frozen inference was started."
  exit 0
fi
test ! -e "$OUT" || { echo "refusing to overwrite output: $OUT" >&2; exit 2; }
"$TRAIN_PYTHON_BIN" -u eval_gridrank_dynamic_cross_topology.py \
  --preflight_manifest "$PREFLIGHT" --output_dir "$OUT"
"$TRAIN_PYTHON_BIN" -B verify_gridrank_dynamic_cross_topology.py \
  --gate "$OUT/gridrank_dynamic_cross_topology_gate.json" --preflight "$PREFLIGHT"
