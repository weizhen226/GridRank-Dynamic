"""Case33 authoritative utilities."""

import argparse
import random

BASE_MVA = 10.0
BASE_KV = 12.66
ZBASE = BASE_KV ** 2 / BASE_MVA
N_BUS = 33

_RADIAL = [
    (1, 2, 0.0922, 0.047), (2, 3, 0.493, 0.2511), (3, 4, 0.366, 0.1864),
    (4, 5, 0.3811, 0.1941), (5, 6, 0.819, 0.707), (6, 7, 0.1872, 0.6188),
    (7, 8, 0.7114, 0.2351), (8, 9, 1.03, 0.74), (9, 10, 1.044, 0.74),
    (10, 11, 0.1966, 0.065), (11, 12, 0.3744, 0.1238), (12, 13, 1.468, 1.155),
    (13, 14, 0.5416, 0.7129), (14, 15, 0.591, 0.526), (15, 16, 0.7463, 0.545),
    (16, 17, 1.289, 1.721), (17, 18, 0.732, 0.574), (2, 19, 0.164, 0.1565),
    (19, 20, 1.5042, 1.3554), (20, 21, 0.4095, 0.4784), (21, 22, 0.7089, 0.9373),
    (3, 23, 0.4512, 0.3083), (23, 24, 0.898, 0.7091), (24, 25, 0.896, 0.7011),
    (6, 26, 0.203, 0.1034), (26, 27, 0.2842, 0.1447), (27, 28, 1.059, 0.9337),
    (28, 29, 0.8042, 0.7006), (29, 30, 0.5075, 0.2585), (30, 31, 0.9744, 0.963),
    (31, 32, 0.3105, 0.3619), (32, 33, 0.341, 0.5302),
]

_TIES = [
    (8, 21, 2.0, 2.0), (9, 15, 2.0, 2.0), (12, 22, 2.0, 2.0),
    (18, 33, 0.5, 0.5), (25, 29, 0.5, 0.5),
]

ALL_BRANCHES = _RADIAL + _TIES
TIE_PAIRS = [(a, b) for a, b, _, _ in _TIES]

_LOAD_MW = {
    2: (0.1, 0.06), 3: (0.09, 0.04), 4: (0.12, 0.08), 5: (0.06, 0.03),
    6: (0.06, 0.02), 7: (0.2, 0.1), 8: (0.2, 0.1), 9: (0.06, 0.02),
    10: (0.06, 0.02), 11: (0.045, 0.03), 12: (0.06, 0.035), 13: (0.06, 0.035),
    14: (0.12, 0.08), 15: (0.06, 0.01), 16: (0.06, 0.02), 17: (0.06, 0.02),
    18: (0.09, 0.04), 19: (0.09, 0.04), 20: (0.09, 0.04), 21: (0.09, 0.04),
    22: (0.09, 0.04), 23: (0.09, 0.05), 24: (0.42, 0.2), 25: (0.42, 0.2),
    26: (0.06, 0.025), 27: (0.06, 0.025), 28: (0.06, 0.02), 29: (0.12, 0.07),
    30: (0.2, 0.6), 31: (0.15, 0.07), 32: (0.21, 0.1), 33: (0.06, 0.04),
}


def _key(a, b):
    return tuple(sorted((int(a), int(b))))


def load_vector_pu(scale=1.0):
    loads = [0j] * N_BUS
    for bus, (p, q) in _LOAD_MW.items():
        loads[bus - 1] = complex(p * scale, q * scale) / BASE_MVA
    return loads


def bfs_powerflow(open_pairs, load_pu, z_unit="ohm"):
    
    open_set = {_key(*edge) for edge in (open_pairs or [])}
    zmap = {}
    for a, b, r, x in ALL_BRANCHES:
        impedance = complex(r, x)
        zmap[_key(a, b)] = impedance / ZBASE if z_unit == "ohm" else impedance

    active = [_key(a, b) for a, b, _, _ in ALL_BRANCHES if _key(a, b) not in open_set]
    adjacency = {bus: [] for bus in range(1, N_BUS + 1)}
    for edge in active:
        a, b = edge
        adjacency[a].append((b, zmap[edge]))
        adjacency[b].append((a, zmap[edge]))

    parent = {1: None}
    parent_z = {1: 0j}
    order = [1]
    seen = {1}
    queue = [1]
    while queue:
        bus = queue.pop(0)
        for neighbor, impedance in adjacency[bus]:
            if neighbor not in seen:
                seen.add(neighbor)
                parent[neighbor] = bus
                parent_z[neighbor] = impedance
                order.append(neighbor)
                queue.append(neighbor)

    radial = len(seen) == N_BUS and len(active) == N_BUS - 1
    if not radial:
        return {"converged": False, "loss_kw": None, "min_vm_pu": None,
                "max_vm_pu": None, "radial": False}

    powers = {bus: load_pu[bus - 1] for bus in range(1, N_BUS + 1)}
    voltage = {bus: 1.0 + 0j for bus in range(1, N_BUS + 1)}
    branch_current = {bus: 0j for bus in range(1, N_BUS + 1)}
    converged = False
    for _ in range(500):
        branch_current = {bus: 0j for bus in range(1, N_BUS + 1)}
        for bus in reversed(order):
            branch_current[bus] += (powers[bus] / voltage[bus]).conjugate()
            if parent[bus] is not None:
                branch_current[parent[bus]] += branch_current[bus]
        max_delta = 0.0
        for bus in order[1:]:
            updated = voltage[parent[bus]] - branch_current[bus] * parent_z[bus]
            max_delta = max(max_delta, abs(updated - voltage[bus]))
            voltage[bus] = updated
        if max_delta < 1e-12:
            converged = True
            break

    loss_pu = sum(
        abs(branch_current[bus]) ** 2 * parent_z[bus].real for bus in order[1:]
    )
    magnitudes = [abs(voltage[bus]) for bus in range(1, N_BUS + 1)]
    return {
        "converged": converged,
        "loss_kw": loss_pu * BASE_MVA * 1000.0,
        "min_vm_pu": min(magnitudes),
        "max_vm_pu": max(magnitudes),
        "radial": True,
    }


def _radial_ok(open_pairs):
    open_set = {_key(*edge) for edge in open_pairs}
    active = [_key(a, b) for a, b, _, _ in ALL_BRANCHES if _key(a, b) not in open_set]
    if len(active) != N_BUS - 1:
        return False
    adjacency = {bus: [] for bus in range(1, N_BUS + 1)}
    for a, b in active:
        adjacency[a].append(b)
        adjacency[b].append(a)
    seen = {1}
    stack = [1]
    while stack:
        bus = stack.pop()
        for neighbor in adjacency[bus]:
            if neighbor not in seen:
                seen.add(neighbor)
                stack.append(neighbor)
    return len(seen) == N_BUS


def _random_radial_start(rng, base_open, n_swaps=6):
    current = list(base_open)
    all_edges = [_key(a, b) for a, b, _, _ in ALL_BRANCHES]
    for _ in range(n_swaps):
        for _ in range(30):
            index = rng.randrange(len(current))
            candidate = rng.choice(all_edges)
            if candidate in {_key(*edge) for edge in current}:
                continue
            trial = list(current)
            trial[index] = candidate
            if _radial_ok(trial):
                current = trial
                break
    return current


def branch_exchange_search(load_pu, z_unit="ohm", vmin=0.90, vmax=1.10,
                           n_starts=8, seed=0, max_iters=300):
    
    rng = random.Random(seed)
    starts = [list(TIE_PAIRS)] + [
        _random_radial_start(rng, TIE_PAIRS) for _ in range(max(0, n_starts - 1))
    ]
    all_edges = [_key(a, b) for a, b, _, _ in ALL_BRANCHES]

    def feasible(result):
        return (result["radial"] and result["converged"] and result["min_vm_pu"] is not None
                and result["min_vm_pu"] >= vmin and result["max_vm_pu"] <= vmax)

    best_open, best_loss, best_vm = None, float("inf"), None
    for start in starts:
        current = start
        current_result = bfs_powerflow(current, load_pu, z_unit)
        current_loss = current_result["loss_kw"] if feasible(current_result) else float("inf")
        for _ in range(max_iters):
            improved = False
            current_set = {_key(*edge) for edge in current}
            for index in range(len(current)):
                for candidate in all_edges:
                    if candidate in current_set:
                        continue
                    trial = list(current)
                    trial[index] = candidate
                    result = bfs_powerflow(trial, load_pu, z_unit)
                    if feasible(result) and result["loss_kw"] < current_loss - 1e-6:
                        current = trial
                        current_loss = result["loss_kw"]
                        improved = True
                        break
                if improved:
                    break
            if not improved:
                break
        if current_loss < best_loss:
            result = bfs_powerflow(current, load_pu, z_unit)
            best_open = current
            best_loss = current_loss
            best_vm = result["min_vm_pu"]
    return best_open, best_loss, best_vm


Z_UNIT = "ohm"
INIT_LOSS_KW_REF = 202.677
OPT_LOSS_KW_REF = 139.55


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Authoritative case33 benchmark verification")
    parser.add_argument("--search", action="store_true")
    parser.add_argument("--n_starts", type=int, default=16)
    args = parser.parse_args()

    load = load_vector_pu()
    total = sum(load) * BASE_MVA
    initial = bfs_powerflow(TIE_PAIRS, load, Z_UNIT)
    print(f"total load = {total.real:.4f} MW + j{total.imag:.4f} MVAr")
    print(f"initial loss={initial['loss_kw']:.6f} kW, min_vm={initial['min_vm_pu']:.6f}")
    assert abs(initial["loss_kw"] - INIT_LOSS_KW_REF) < 0.1, (
        f"initial loss {initial['loss_kw']:.4f} kW != pandapower {INIT_LOSS_KW_REF} kW"
    )
    assert abs(initial["min_vm_pu"] - 0.91309) < 1e-4
    print("ASSERT case33 base loss/voltage: PASS")

    if args.search:
        optimal, loss, min_vm = branch_exchange_search(load, n_starts=args.n_starts)
        reduction = 100.0 * (initial["loss_kw"] - loss) / initial["loss_kw"]
        print(f"reference loss={loss:.6f} kW, min_vm={min_vm:.6f}, reduction={reduction:.3f}%")
        print(f"open={sorted(_key(*edge) for edge in optimal)}")
        print(f"published reference is approximately {OPT_LOSS_KW_REF} kW")