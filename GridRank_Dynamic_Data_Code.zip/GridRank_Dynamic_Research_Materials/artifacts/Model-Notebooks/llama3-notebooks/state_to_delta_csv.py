"""State to delta csv utilities."""

import argparse
import csv
import re
import sys
from pathlib import Path

_HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(_HERE))

import grpo_reward_limited as RL
import action_extract


def delta_task(network):
    return (
    f"You are reconfiguring an IEEE {network}-bus radial distribution network to MINIMIZE active power loss. "
    "Starting from the current configuration (see Existing Open Lines below), you may apply AT MOST K "
    "branch exchanges (1 branch exchange = close one currently-open line and open one currently-closed "
    "line), keeping the network radial (a single connected spanning tree) with every bus voltage in "
    "[0.90, 1.10] pu.\n"
    "Respond with EXACTLY ONE action and nothing else:\n"
    "- Action: Replace (u, v) with (x, y)   where (u, v) is one of the current Existing Open Lines "
    "(it will be CLOSED) and (x, y) is a line currently in service (it will be OPENED).\n"
    "- Action: none   if no allowed exchange reduces loss (keep the current configuration unchanged).\n"
    "Do NOT output the full Open Lines list."
    )


def rewrite_prompt(prompt):
    
    match = re.search(r"Busses\s*=\s*(33|69)\b", prompt)
    marker = "\nUnits:"
    if not match or marker not in prompt:
        return prompt, False
    network = int(match.group(1))
    _, suffix = prompt.split(marker, 1)
    return delta_task(network) + marker + suffix, True


def delta_label(existing, label):
    
    K = lambda a, b: tuple(sorted((int(a), int(b))))
    exs = {K(*e): e for e in existing}
    las = {K(*e): e for e in label}
    rem = [exs[k] for k in exs if k not in las]   
    add = [las[k] for k in las if k not in exs]    
    if not rem and not add:
        return "Action: none"
    if len(rem) == 1 and len(add) == 1:
        return f"Action: Replace ({rem[0][0]}, {rem[0][1]}) with ({add[0][0]}, {add[0][1]})"
    return None                                     


def main():
    ap = argparse.ArgumentParser(description="Full-state SFT CSV -> delta-action SFT CSV.")
    ap.add_argument("--in_csv", required=True)
    ap.add_argument("--out_csv", required=True)
    ap.add_argument("--show", type=int, default=3)
    args = ap.parse_args()

    csv.field_size_limit(10 ** 9)
    rows = list(csv.DictReader(open(args.in_csv, encoding="utf-8")))
    if not rows:
        raise SystemExit("empty input CSV")
    fields = list(rows[0].keys())

    n_none = n_repl = n_skip = n_task_ok = 0
    out_rows = []
    for r in rows:
        existing = RL.parse_existing_open(r["prompt"])
        label = action_extract.extract_action(r["output"])     
        if existing is None or label is None:
            n_skip += 1
            continue
        dl = delta_label(existing, label)
        if dl is None:
            n_skip += 1
            continue
        new_prompt, ok = rewrite_prompt(r["prompt"])           
        n_task_ok += int(ok)
        n_none += int(dl == "Action: none"); n_repl += int(dl != "Action: none")
        r2 = dict(r); r2["prompt"] = new_prompt; r2["output"] = dl
        out_rows.append(r2)
    if n_task_ok != len(out_rows):
        raise SystemExit(f"PROMPT REWRITE FAILED on {len(out_rows) - n_task_ok}/{len(out_rows)} rows: "
                         f"the legacy _TASK string was not found -- prompts would lack the delta "
                         f"protocol. Check make_sft_from_benchmark._TASK matches the CSV prompts.")

    with open(args.out_csv, "w", newline="", encoding="utf-8") as fo:
        w = csv.DictWriter(fo, fieldnames=fields)
        w.writeheader()
        w.writerows(out_rows)

    
    from collections import Counter
    splits = Counter(r["split"] for r in out_rows)
    print({"wrote": args.out_csv, "rows": len(out_rows), "prompt_protocol_rewritten": n_task_ok,
           "none": n_none, "replace": n_repl,
           "skipped_multi_or_unparsable": n_skip, "splits": dict(splits)})
    for r in out_rows[: args.show]:
        print("  split=%s bucket=%s | %s" % (r["split"], r.get("bucket"), r["output"]))


if __name__ == "__main__":
    main()
