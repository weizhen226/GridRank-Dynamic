"""Evaluate GridRank dynamic confirmation replication."""

from __future__ import annotations

import sys

import preflight_gridrank_dynamic_factorized_replication as factor_preflight


sys.modules["preflight_gridrank_dynamic_factorized"] = factor_preflight
import train_gridrank_dynamic_factorized as factor_trainer  

sys.modules["train_gridrank_dynamic_factorized"] = factor_trainer

import preflight_gridrank_dynamic_confirmation_replication as confirm_preflight  

sys.modules["preflight_gridrank_dynamic_confirmation"] = confirm_preflight
import eval_gridrank_dynamic_confirmation as locked_evaluator  


if __name__ == "__main__":
    locked_evaluator.main()
