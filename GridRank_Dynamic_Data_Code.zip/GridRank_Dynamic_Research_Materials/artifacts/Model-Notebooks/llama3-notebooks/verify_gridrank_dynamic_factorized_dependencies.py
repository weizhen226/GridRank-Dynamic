"""Validate GridRank dynamic factorized dependencies."""

from __future__ import annotations

import ast
import inspect
import json
from pathlib import Path

import gridrank_dynamic_factorized_llm as factorized


HERE = Path(__file__).resolve().parent


def main():
    row = {
        "instruction_text": "Raise end-of-feeder voltage while branch (7, 8) is unavailable.",
        "oracle_structured_instruction": {
            "objective": "voltage", "hard_constraint": True,
            "forbidden_edges": [[7, 8]],
        },
    }
    prompt_source = (
        inspect.getsource(factorized.primitive_question)
        + inspect.getsource(factorized.render_primitive_prompt)
    )
    trainer = (HERE / "train_gridrank_dynamic_factorized.py").read_text(encoding="utf-8")
    tree = ast.parse(trainer)
    direct_calls = {
        node.func.id for node in ast.walk(tree)
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Name)
    }
    checks = {
        "two_independent_axes": (
            [x["axis"] for x in factorized.PRIMITIVES].count("objective") == 2
            and [x["axis"] for x in factorized.PRIMITIVES].count("constraint") == 2
        ),
        "withheld_card_constructible": "scores[1] + scores[3]" in inspect.getsource(factorized.compose_card_scores),
        "native_instruction_prompt": row["instruction_text"] in factorized.primitive_question(row, factorized.PRIMITIVES[1]),
        "oracle_not_rendered": "oracle_structured_instruction" not in prompt_source,
        "factorized_axis_losses": all(
            token in trainer for token in ("objective_loss", "constraint_loss", "physics_listwise")
        ),
        "composition_withheld": "maintenance_voltage" in trainer,
        "causal_controls_present": all(
            token in trainer for token in ("instruction_removed", "instruction_counterfactual")
        ),
        "one_graph_replay": "primitives=[primitive]" in trainer,
        "reference_adapter_present": "reference" in trainer,
        "no_live_power_flow_calls": not {
            "runpp", "run_power_flow", "simulate", "evaluate_action"
        }.intersection(direct_calls),
    }
    result = {
        "msg": "GridRank factorized dynamic-policy dependency-light verification",
        "checks": checks, "verification_pass": all(checks.values()),
        "training_performed": False, "model_loaded": False,
        "power_flow_calls": 0,
    }
    print(json.dumps(result, ensure_ascii=False))
    if not result["verification_pass"]:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
