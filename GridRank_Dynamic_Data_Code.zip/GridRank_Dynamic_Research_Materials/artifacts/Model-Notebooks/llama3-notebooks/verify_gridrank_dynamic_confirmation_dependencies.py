"""Validate GridRank dynamic confirmation dependencies."""

from __future__ import annotations

import ast
import json
from pathlib import Path


HERE = Path(__file__).resolve().parent


def source(name):
    return (HERE / name).read_text(encoding="utf-8")


def call_names(tree):
    names = []
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        value = node.func
        parts = []
        while isinstance(value, ast.Attribute):
            parts.append(value.attr)
            value = value.value
        if isinstance(value, ast.Name):
            parts.append(value.id)
        names.append(".".join(reversed(parts)))
    return names


def assignment_literal(tree, name):
    for node in tree.body:
        if isinstance(node, ast.Assign) and any(
            isinstance(target, ast.Name) and target.id == name for target in node.targets
        ):
            return ast.literal_eval(node.value)
    raise KeyError(name)


def main():
    builder_text = source("build_gridrank_dynamic_confirmation.py")
    evaluator_text = source("eval_gridrank_dynamic_confirmation.py")
    view_text = source("make_gridrank_dynamic_confirmation_state_view.py")
    builder = ast.parse(builder_text)
    evaluator = ast.parse(evaluator_text)
    templates = assignment_literal(builder, "CONFIRMATION_TEMPLATES")
    old = ast.parse(source("build_gridrank_instruction_pairs.py"))
    old_text = set()
    for bank in ("TRAIN_TEMPLATES", "VALIDATION_TEMPLATES"):
        value = assignment_literal(old, bank)
        old_text.update(text for values in value.values() for text in values)
    fresh_text = {text for values in templates.values() for text in values}
    eval_calls = call_names(evaluator)
    checks = {
        "third_template_bank_exact_text_disjoint": not fresh_text.intersection(old_text),
        "four_semantic_families": set(templates) == {
            "loss", "voltage", "maintenance_loss", "maintenance_voltage"
        },
        "builder_calls_authoritative_physics": "feedback.score_state" in call_names(builder),
        "builder_has_no_model_loading": not any(
            token in builder_text for token in (
                "AutoModelForCausalLM", "PeftModel", "build_model_and_tokenizer"
            )
        ),
        "builder_has_no_model_score_selection": "model_scores_used\": False" in builder_text,
        "evaluator_has_no_optimizer": not any("Optimizer" in name or "optimizer" in name.lower() for name in eval_calls),
        "evaluator_has_no_backward": not any(name.endswith("backward") for name in eval_calls),
        "evaluator_has_no_training_entrypoint": "train_replay" not in evaluator_text,
        "fresh_rows_never_fit_text_parser": (
            "fit_text_parser(original_train" in evaluator_text
            and "fit_text_parser(fresh_rows" not in evaluator_text
        ),
        "correct_removed_counterfactual_controls": all(
            token in evaluator_text for token in (
                '"correct"', '"instruction_removed"', '"instruction_counterfactual"'
            )
        ),
        "primary_withheld_tfidf_comparison": "fresh_composition_aligned_vs_withheld_tfidf" in evaluator_text,
        "positive_control_disclosed": "tfidf_logreg_lindistflow_positive_control" in evaluator_text,
        "primary_48_pair_floor": "primary_hidden_pairs_48_or_more" in builder_text,
        "identity_exclusions_present": all(
            token in builder_text for token in (
                "fresh_state_disjoint_exclusions", "fresh_load_disjoint_exclusions"
            )
        ),
        "role_aware_exclusion_boundary": all(
            token in view_text for token in (
                "identity_exclude_jsonl", "state_exclude_jsonl",
                "excluded_training_or_development_load",
                "excluded_prior_evaluation_state",
            )
        ) and all(
            token in builder_text for token in (
                "exclude_jsonl", "exclude_state_jsonl", "state_only_exclusions"
            )
        ),
    }
    result = {
        "msg": "GridRank fresh dynamic confirmation dependency-light verification",
        "checks": checks,
        "verification_pass": all(checks.values()),
        "training_performed": False,
        "model_loaded": False,
        "power_flow_calls": 0,
    }
    print(json.dumps(result, ensure_ascii=False))
    if not result["verification_pass"]:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
