"""Validate GridRank dynamic joint replication dependencies."""

from __future__ import annotations

import ast
import json
import re
from pathlib import Path


HERE = Path(__file__).resolve().parent


def main():
    runner = (HERE / "run_gridrank_dynamic_joint_replication.sh").read_text(
        encoding="utf-8"
    )
    wrapper = ast.parse(
        (HERE / "train_gridrank_dynamic_joint_replication.py").read_text(
            encoding="utf-8"
        )
    )
    preflight = (HERE / "preflight_gridrank_dynamic_joint_replication.py").read_text(
        encoding="utf-8"
    )
    checks = {
        "only_predeclared_seeds": 'case "$SEED" in 123|2025)' in runner,
        "locked_joint_trainer_delegated": any(
            isinstance(node, ast.Import)
            and any(
                alias.name == "train_gridrank_dynamic_policy"
                for alias in node.names
            )
            for node in ast.walk(wrapper)
        ),
        "old_runner_not_invoked": re.search(
            r"(?m)^[^#\n]*\b(?:bash\s+)?run_gridrank_dynamic_policy[.]sh\b",
            runner,
        )
        is None,
        "seed_only_schedule_contract": all(
            token in preflight
            for token in (
                "seed_is_only_schedule_change",
                "source_artifact_hashes_match_seed42",
                "gridrank_start_adapter_matches_seed42",
                "selection_exactly_reused",
            )
        ),
        "failed_control_gate_does_not_block_adapter": (
            "reference_gate_structurally_valid" in preflight
            and "reference_adapter_valid" in preflight
        ),
        "locked_training_helpers_forwarded": all(
            token in preflight
            for token in (
                "card_outcomes = original.card_outcomes",
                "physics_target = original.physics_target",
            )
        ),
        "runner_requires_structural_verification": (
            "verify_gridrank_dynamic_joint_replication.py" in runner
            and "TRAIN_RC" in runner
        ),
    }
    result = {
        "msg": "GridRank joint-card seed-replication dependency verification",
        "checks": checks,
        "verification_pass": all(checks.values()),
        "training_performed": False,
        "model_loaded": False,
        "power_flow_calls": 0,
    }
    print(json.dumps(result, ensure_ascii=False))
    if not result["verification_pass"]:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
