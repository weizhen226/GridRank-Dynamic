"""Validate GridRank dynamic physics ablation confirmation."""

from __future__ import annotations

import sys

import preflight_gridrank_dynamic_physics_ablation_confirmation as confirm_preflight


sys.modules["preflight_gridrank_dynamic_confirmation"] = confirm_preflight
import verify_gridrank_dynamic_confirmation as locked_verifier  


if __name__ == "__main__":
    locked_verifier.main()
