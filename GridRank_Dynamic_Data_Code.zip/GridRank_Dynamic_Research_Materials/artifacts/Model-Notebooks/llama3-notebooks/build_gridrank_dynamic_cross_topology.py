"""Build GridRank dynamic cross topology."""

from __future__ import annotations

import argparse
import hashlib
import itertools
import json
from collections import Counter, defaultdict
from pathlib import Path
from types import SimpleNamespace

import build_gridrank_simbench_difficulty as difficulty
import gridrank_dynamic_cross_topology as grid
from build_gridrank_dynamic_confirmation import CONFIRMATION_TEMPLATES
from build_gridrank_instruction_pairs import (
    PAIR_TYPES, TRAIN_TEMPLATES, VALIDATION_TEMPLATES,
    baseline_records, candidate_pairs,
)
from build_gridrank_instruct_identifiability import NOOP, edge_text


SCHEMA = "gridrank-dynamic-cross-topology-summary-v1"
PAIR_SCHEMA = "gridrank-dynamic-cross-topology-pair-v1"
PRIMARY_PAIR_TYPE = "maintenance_voltage"
NETWORKS = tuple(grid.network_id(code) for code in grid.PREDECLARED_CODES)


CROSS_TOPOLOGY_TEMPLATES = {
    "loss": (
        "For the present operating window, use a safe branch exchange only when it lowers feeder real-power losses.",
        "Dispatch the network for minimum resistive dissipation, retaining the current switching state if no safe exchange improves it.",
        "Choose the admissible one-exchange configuration with the greatest active-loss saving.",
        "Make electrical efficiency the priority and avoid an exchange that fails to reduce real-power waste.",
    ),
    "voltage": (
        "Raise the minimum nodal voltage as much as possible while allowing no more than a 0.5 percent active-loss increase.",
        "Give the voltage floor precedence; reject unsafe exchanges and those outside the half-percent loss budget.",
        "Support the weakest bus with an admissible single exchange under the stated efficiency tolerance.",
        "Optimize minimum per-unit voltage for this interval, subject to safety and the 0.5 percent loss cap.",
    ),
    "maintenance_loss": (
        "Reduce active-power losses, but switching any branch in {edges} is unavailable under the current work order.",
        "With {edges} isolated for maintenance, select the allowed safe exchange that saves the most real power.",
        "Treat {edges} as a hard lockout and otherwise operate for the lowest feasible feeder loss.",
        "The switching crew cannot touch {edges}; pursue maximum loss reduction among the remaining actions.",
    ),
    "maintenance_voltage": (
        "Improve the voltage floor while {edges} remains locked out, without exceeding a 0.5 percent active-loss increase.",
        "Branches {edges} are unavailable: prioritize the weakest-bus voltage among safe permitted exchanges under the half-percent loss cap.",
        "Apply a hard switching prohibition to {edges} and use the remaining actions to support minimum voltage.",
        "During maintenance on {edges}, maximize the lowest per-unit voltage subject to safety and the stated loss tolerance.",
    ),
}


def file_sha256(path):
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def write_jsonl_exclusive(path, rows):
    output = Path(path)
    if output.exists():
        raise FileExistsError(f"refusing to overwrite: {output}")
    with open(output, "x", encoding="utf-8", newline="\n") as handle:
        for row in rows:
            handle.write(json.dumps(row, ensure_ascii=False, sort_keys=True) + "\n")


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--cache_out", required=True)
    parser.add_argument("--pairs_out", required=True)
    parser.add_argument("--summary_out", required=True)
    parser.add_argument("--scenario_seed", type=int, default=20260907)
    parser.add_argument("--candidate_seed", type=int, default=20260907)
    parser.add_argument("--selection_seed", type=int, default=20260907)
    parser.add_argument("--nonnoop_candidates", type=int, default=32)
    parser.add_argument("--max_scanned_states", type=int, default=160)
    parser.add_argument("--primary_pairs_per_network", type=int, default=16)
    parser.add_argument("--secondary_pairs_per_network", type=int, default=8)
    parser.add_argument("--target_temperature", type=float, default=0.2)
    parser.add_argument("--min_objective_pair_gap", type=float, default=0.02)
    parser.add_argument("--min_constraint_pair_gap", type=float, default=0.02)
    return parser.parse_args()


def quota(pair_type, args):
    return args.primary_pairs_per_network if pair_type == PRIMARY_PAIR_TYPE else args.secondary_pairs_per_network


def pair_args(args):
    return SimpleNamespace(
        target_temperature=args.target_temperature,
        min_objective_pair_gap=args.min_objective_pair_gap,
        min_constraint_pair_gap=args.min_constraint_pair_gap,
    )


def state_order(code, args):
    return sorted(
        range(args.max_scanned_states),
        key=lambda index: hashlib.sha256(
            f"{args.selection_seed}|{grid.SUITE_ID}|{code}|{index}".encode()
        ).digest(),
    )


def pair_rank(item, args):
    return hashlib.sha256(
        (
            f"{args.selection_seed}|pair|{item['network_id']}|{item['pair_type']}|"
            f"{item['load_id']}|{item['physical_state_sha256']}"
        ).encode()
    ).digest()


def count_pool(pool):
    counts = Counter((item["network_id"], item["pair_type"]) for item in pool)
    return {
        f"{network}:{pair_type}": counts[(network, pair_type)]
        for network, pair_type in itertools.product(NETWORKS, PAIR_TYPES)
    }


def network_ready(pool, network, args):
    counts = count_pool(pool)
    return all(counts[f"{network}:{kind}"] >= quota(kind, args) for kind in PAIR_TYPES)


def static_to_state(row):
    candidates = [dict(item) for item in row["candidates"]]
    candidates.append(dict(row["gate_anchor"]))
    return {
        "network_id": str(row["network_id"]),
        "load_id": str(row["load_id"]),
        "physical_state_sha256": row["physical_state_sha256"],
        "state_text": row["state_text"],
        "simbench_code": row["simbench_code"],
        "state_index": int(row["state_index"]),
        "candidates": candidates,
    }


def template_texts():
    return {
        text for bank in (
            TRAIN_TEMPLATES, VALIDATION_TEMPLATES,
            CONFIRMATION_TEMPLATES, CROSS_TOPOLOGY_TEMPLATES,
        ) for values in bank.values() for text in values
    }


def decorate(row, item, pair_id, side):
    family = row["instruction_id"]
    values = CROSS_TOPOLOGY_TEMPLATES[family]
    digest = hashlib.sha256(f"{pair_id}|{side}|{family}".encode()).digest()
    index = int.from_bytes(digest[:4], "big") % len(values)
    forbidden = item["forbidden_edges"] if side == "right" else ()
    value = dict(row)
    value.update({
        "schema": PAIR_SCHEMA,
        "instance_id": f"{pair_id}:{side}",
        "partition": "sealed_cross_topology",
        "pair_id": pair_id,
        "pair_type": item["pair_type"],
        "pair_side": side,
        "paraphrase_index": 0,
        "template_id": f"cross_topology:{family}:{index}",
        "instruction_style": "sealed_cross_topology",
        "instruction_text": values[index].format(edges=edge_text(forbidden)),
        "pair_selection_gap": float(item["strength"]),
        "simbench_code": item["simbench_code"],
        "oracle_structured_instruction": {
            "objective": row["base_objective"],
            "forbidden_edges": [list(edge) for edge in forbidden],
            "hard_constraint": bool(forbidden),
            "loss_increase_limit_pct": 0.5 if row["base_objective"] == "voltage" else None,
        },
    })
    return value


def emit(selected):
    rows, manifest = [], []
    ordered = sorted(selected, key=lambda item: (
        item["network_id"], item["pair_type"], item["physical_state_sha256"], item["load_id"]
    ))
    for index, item in enumerate(ordered):
        pair_id = (
            f"gridrank-cross-topology:{item['network_id']}:"
            f"{item['physical_state_sha256']}:{item['pair_type']}:{index}"
        )
        rows.extend((
            decorate(item["left"], item, pair_id, "left"),
            decorate(item["right"], item, pair_id, "right"),
        ))
        manifest.append({
            "pair_id": pair_id,
            "pair_type": item["pair_type"],
            "network_id": item["network_id"],
            "simbench_code": item["simbench_code"],
            "load_id": item["load_id"],
            "physical_state_sha256": item["physical_state_sha256"],
            "left_desired_action": item["left"]["desired_action"],
            "right_desired_action": item["right"]["desired_action"],
            "forbidden_edges": [list(edge) for edge in item["forbidden_edges"]],
            "strength": float(item["strength"]),
            "directional_gaps": item["directional_gaps"],
        })
    return rows, manifest


def main():
    args = parse_args()
    for output in (args.cache_out, args.pairs_out, args.summary_out):
        if Path(output).exists():
            raise FileExistsError(f"refusing to overwrite: {output}")
    grid.verify_predeclared_codes()
    difficulty.grid = grid
    pool, cache, traces = [], [], defaultdict(list)
    build_args = SimpleNamespace(
        scenario_seed=args.scenario_seed,
        candidate_seed=args.candidate_seed,
        nonnoop_candidates=args.nonnoop_candidates,
    )
    for code in grid.PREDECLARED_CODES:
        network = grid.network_id(code)
        for state_index in state_order(code, args):
            row, reason, anchor = difficulty.build_row(code, state_index, build_args)
            traces[network].append({
                "state_index": state_index, "included": row is not None,
                "reason": reason, "anchor_feedback_valid": bool(anchor.get("feedback_valid")),
            })
            if row is None:
                continue
            state = static_to_state(row)
            cache.append(state)
            values = candidate_pairs(state, "validation", pair_args(args))
            for value in values:
                value["simbench_code"] = code
            pool.extend(values)
            if network_ready(pool, network, args):
                break
        if not network_ready(pool, network, args):
            raise RuntimeError(
                f"network {network}: quotas unavailable after {len(traces[network])} scans; "
                f"availability={count_pool(pool)}"
            )

    selected = []
    for network, pair_type in itertools.product(NETWORKS, PAIR_TYPES):
        values = [item for item in pool if item["network_id"] == network and item["pair_type"] == pair_type]
        selected.extend(sorted(values, key=lambda item: pair_rank(item, args))[:quota(pair_type, args)])
    rows, manifest = emit(selected)
    selected_counts = count_pool(selected)
    available_counts = count_pool(pool)
    prior_text = {
        text for bank in (TRAIN_TEMPLATES, VALIDATION_TEMPLATES, CONFIRMATION_TEMPLATES)
        for values in bank.values() for text in values
    }
    fresh_text = {text for values in CROSS_TOPOLOGY_TEMPLATES.values() for text in values}
    baselines, parser_accuracy = baseline_records(rows, 1)
    state_keys = {(item["network_id"], item["physical_state_sha256"]) for item in manifest}
    checks = {
        "suite_exact": tuple(grid.PREDECLARED_CODES) == (
            "1-MV-rural--2-sw", "1-MV-semiurb--2-sw", "1-MV-urban--2-sw",
        ),
        "prior_codes_excluded": not set(grid.PREDECLARED_CODES).intersection(grid.PRIOR_CODES),
        "pair_quotas_exact": all(
            selected_counts[f"{network}:{kind}"] == quota(kind, args)
            for network, kind in itertools.product(NETWORKS, PAIR_TYPES)
        ),
        "primary_pairs_48": sum(item["pair_type"] == PRIMARY_PAIR_TYPE for item in manifest) == 48,
        "pairs_total_96": len(manifest) == 96 and len(rows) == 192,
        "primary_states_unique": len({
            item["physical_state_sha256"] for item in manifest if item["pair_type"] == PRIMARY_PAIR_TYPE
        }) == 48,
        "all_pairs_change_ac_optimum": all(item["left_desired_action"] != item["right_desired_action"] for item in manifest),
        "material_pair_gaps": all(item["strength"] + 1e-12 >= 0.02 for item in manifest),
        "candidate_count_32": all(row["candidate_count"] == 32 and len(row["candidates"]) == 32 for row in rows),
        "separate_noop_anchor": all(row["gate_anchor"]["action"] == NOOP and all(c["action"] != NOOP for c in row["candidates"]) for row in rows),
        "fourth_language_bank_exact_text_disjoint": not fresh_text.intersection(prior_text),
        "model_scores_unused": True,
        "all_selected_networks_distinct_from_33_69": all(network not in {"33", "69"} for network, _ in state_keys),
    }
    write_jsonl_exclusive(args.cache_out, cache)
    write_jsonl_exclusive(args.pairs_out, rows)
    anchor_calls = sum(len(value) for value in traces.values())
    candidate_calls = len(cache) * args.nonnoop_candidates
    summary = {
        "msg": "GridRank sealed dynamic cross-topology benchmark build",
        "schema": SCHEMA,
        "suite": grid.suite_manifest(),
        "coverage_pass": all(checks.values()),
        "training_performed": False,
        "model_loaded": False,
        "model_scores_used": False,
        "settings": vars(args),
        "networks": list(NETWORKS),
        "power_flow_calls": {
            "anchor_power_flows": anchor_calls,
            "candidate_power_flows": candidate_calls,
            "backend_power_flows": anchor_calls + candidate_calls,
        },
        "scan_trace": dict(traces),
        "cache": {"states": len(cache), "network_mix": dict(Counter(x["network_id"] for x in cache))},
        "pairs": {
            "rows": len(rows), "pair_clusters": len(manifest),
            "unique_states": len(state_keys),
            "available_by_network_type": available_counts,
            "selected_by_network_type": selected_counts,
            "strength_min": min(item["strength"] for item in manifest),
            "strength_mean": sum(item["strength"] for item in manifest) / len(manifest),
            "manifest": manifest,
        },
        "cached_baselines": baselines,
        "frozen_rule_parser_accuracy": parser_accuracy,
        "checks": checks,
        "artifacts": {},
    }
    summary["artifacts"] = {
        "cache": {"path": str(Path(args.cache_out).resolve()), "sha256": file_sha256(args.cache_out)},
        "pairs": {"path": str(Path(args.pairs_out).resolve()), "sha256": file_sha256(args.pairs_out)},
    }
    Path(args.summary_out).write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(summary, ensure_ascii=False))
    if not summary["coverage_pass"]:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
