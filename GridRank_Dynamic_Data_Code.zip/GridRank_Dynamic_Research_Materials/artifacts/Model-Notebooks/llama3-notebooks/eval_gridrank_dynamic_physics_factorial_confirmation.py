"""Evaluate GridRank dynamic physics factorial confirmation."""

from __future__ import annotations

import json
import sys
from pathlib import Path

import preflight_gridrank_dynamic_physics_factorial as factor_preflight


sys.modules["preflight_gridrank_dynamic_factorized"] = factor_preflight
import train_gridrank_dynamic_factorized as factor_trainer  

sys.modules["train_gridrank_dynamic_factorized"] = factor_trainer
import preflight_gridrank_dynamic_physics_factorial_confirmation as confirm_preflight  

sys.modules["preflight_gridrank_dynamic_confirmation"] = confirm_preflight
import eval_gridrank_dynamic_confirmation as locked_evaluator  


def _argument(name):
    index = sys.argv.index(name)
    return sys.argv[index + 1]


def _annotate_gate():
    output = Path(_argument("--output_dir"))
    preflight_path = Path(_argument("--preflight_manifest"))
    gate_path = output / "gridrank_dynamic_confirmation_gate.json"
    if not gate_path.is_file() or not preflight_path.is_file():
        return False
    gate = json.load(open(gate_path, encoding="utf-8"))
    manifest = json.load(open(preflight_path, encoding="utf-8"))
    gate["factorial_cell"] = manifest["factorial_cell"]
    gate["factorial_interpretation"] = manifest["interpretation_boundary"]
    gate_path.write_text(json.dumps(gate, ensure_ascii=False, indent=2), encoding="utf-8")
    return True


if __name__ == "__main__":
    exit_code = 0
    try:
        locked_evaluator.main()
    except SystemExit as exc:
        exit_code = int(exc.code or 0)
    complete = _annotate_gate()
    output = Path(_argument("--output_dir"))
    complete = complete and (
        (output / "gridrank_dynamic_confirmation_gate.json").is_file()
        and (output / "gridrank_dynamic_confirmation_records.jsonl").is_file()
    )
    if exit_code == 2 and complete:
        print(
            '{"msg":"Frozen-SFT factorial confirmation artifact complete",'
            '"original_claim_gate_exit_accepted":true}'
        )
    elif exit_code != 0:
        raise SystemExit(exit_code)

