"""Validate GridRank dynamic confirmation replication."""

from __future__ import annotations

import sys

import preflight_gridrank_dynamic_confirmation_replication as confirm_preflight


sys.modules["preflight_gridrank_dynamic_confirmation"] = confirm_preflight
import verify_gridrank_dynamic_confirmation as locked_verifier  


if __name__ == "__main__":
    locked_verifier.main()
