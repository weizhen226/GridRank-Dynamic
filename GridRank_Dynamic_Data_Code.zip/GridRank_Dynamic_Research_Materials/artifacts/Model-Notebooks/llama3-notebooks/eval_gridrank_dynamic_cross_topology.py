
"""Evaluate GridRank dynamic cross topology."""

from __future__ import annotations

import argparse
import gc
import json
import random
from collections import defaultdict
from pathlib import Path
from types import SimpleNamespace

import preflight_gridrank_dynamic_benchmark as benchmark
import preflight_gridrank_dynamic_cross_topology as preflight
import train_gridrank_dynamic_factorized as factorized
import train_gridrank_dynamic_policy as joint


PRIMARY = "maintenance_voltage"
SEEDS = (42, 123, 2025)
LLM_PREFIX = "physics_aligned_factorized_llm"
TFIDF = "factorized_tfidf_withheld"


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--preflight_manifest", required=True)
    parser.add_argument("--output_dir", required=True)
    return parser.parse_args()


def read_rows(path):
    return [json.loads(line) for line in open(path, encoding="utf-8") if line.strip()]


def mean(values):
    return sum(values) / len(values) if values else None


def brief(records):
    return {
        "n": len(records), "pairs": len({row["pair_id"] for row in records}),
        "physical_states": len({row["physical_state_sha256"] for row in records}),
        "normalised_regret_mean": mean([float(row["normalised_regret"]) for row in records]),
        "physics_optimal_rate": mean([float(row["physics_optimal"]) for row in records]),
        "semantic_accuracy": mean([float(row["semantic_correct"]) for row in records]),
        "constraint_violation_rate": mean([float(row["constraint_violation"]) for row in records]),
        "safe_feasible_rate": mean([float(row["safe_feasible"]) for row in records]),
    }


def summarize(records):
    networks = sorted({row["network"] for row in records})
    pair_types = sorted({row["pair_type"] for row in records})
    result = brief(records)
    grouped = defaultdict(list)
    for row in records:
        grouped[row["pair_id"]].append(row)
    result["instruction_pair_flip_rate"] = mean([
        float(len({item["safe_action"] for item in values}) > 1)
        for values in grouped.values()
    ])
    result["by_network"] = {
        network: brief([row for row in records if row["network"] == network])
        for network in networks
    }
    result["by_pair_type"] = {
        kind: brief([row for row in records if row["pair_type"] == kind])
        for kind in pair_types
    }
    return result


def quantile(values):
    ordered = sorted(values)
    return [ordered[int(0.025 * (len(ordered) - 1))], ordered[int(0.975 * (len(ordered) - 1))]]


def paired(before, after, reps, seed):
    left = {row["instance_id"]: row for row in before}
    right = {row["instance_id"]: row for row in after}
    if set(left) != set(right):
        raise ValueError("paired IDs differ")
    groups, networks = defaultdict(list), {}
    for key in sorted(left):
        pair_id = left[key]["pair_id"]
        groups[pair_id].append(float(left[key]["normalised_regret"]) - float(right[key]["normalised_regret"]))
        networks[pair_id] = left[key]["network"]

    def calculate(ids, draw_seed):
        values = [mean(groups[value]) for value in ids]
        if not values:
            return {"pair_clusters": 0, "improvement_mean": None, "ci95": [None, None]}
        rng = random.Random(draw_seed)
        draws = [mean([values[rng.randrange(len(values))] for _ in values]) for _ in range(reps)]
        return {"pair_clusters": len(values), "improvement_mean": mean(values), "ci95": quantile(draws)}

    ids = sorted(groups)
    result = calculate(ids, seed)
    result.update({
        "rows_better": sum(left[key]["normalised_regret"] > right[key]["normalised_regret"] + 1e-12 for key in left),
        "rows_worse": sum(left[key]["normalised_regret"] + 1e-12 < right[key]["normalised_regret"] for key in left),
        "rows_tied": sum(abs(left[key]["normalised_regret"] - right[key]["normalised_regret"]) <= 1e-12 for key in left),
        "by_network": {
            network: calculate([pair_id for pair_id in ids if networks[pair_id] == network], seed + 1000 + index)
            for index, network in enumerate(sorted(set(networks.values())))
        },
    })
    return result


def subset(records, pair_type=PRIMARY):
    return [row for row in records if row["pair_type"] == pair_type]


def add_state_identity(records, source):
    identities = {row["instance_id"]: row["physical_state_sha256"] for row in source}
    for row in records:
        row["physical_state_sha256"] = identities[row["instance_id"]]
    return records


def multiseed_state_bootstrap(records, baseline, method_names, source_rows, reps, seed):
    state_by_instance = {row["instance_id"]: row["physical_state_sha256"] for row in source_rows}
    network_by_state = {row["physical_state_sha256"]: str(row["network_id"]) for row in source_rows}
    base = {row["instance_id"]: row for row in baseline}
    matrices = {}
    for model_seed, method in zip(SEEDS, method_names):
        current = {row["instance_id"]: row for row in records[method]}
        if set(base) != set(current):
            raise ValueError("multiseed IDs differ")
        by_state = defaultdict(list)
        for instance_id in base:
            by_state[state_by_instance[instance_id]].append(
                float(base[instance_id]["normalised_regret"]) - float(current[instance_id]["normalised_regret"])
            )
        matrices[model_seed] = {state: mean(values) for state, values in by_state.items()}
    states = sorted(next(iter(matrices.values())))
    if any(set(value) != set(states) for value in matrices.values()):
        raise ValueError("state clusters differ across seeds")
    state_means = {state: mean([matrices[s][state] for s in SEEDS]) for state in states}
    per_seed = {str(s): mean(list(matrices[s].values())) for s in SEEDS}
    rng = random.Random(seed)
    state_draws = [mean([state_means[states[rng.randrange(len(states))]] for _ in states]) for _ in range(reps)]
    rng2 = random.Random(seed + 1)
    two_way = []
    for _ in range(reps):
        sampled_seeds = [SEEDS[rng2.randrange(len(SEEDS))] for _ in SEEDS]
        sampled_states = [states[rng2.randrange(len(states))] for _ in states]
        two_way.append(mean([matrices[s][state] for s in sampled_seeds for state in sampled_states]))
    by_network = {}
    for index, network in enumerate(sorted(set(network_by_state.values()))):
        selected = [state_means[state] for state in states if network_by_state[state] == network]
        rngn = random.Random(seed + 100 + index)
        draws = [mean([selected[rngn.randrange(len(selected))] for _ in selected]) for _ in range(reps)]
        by_network[network] = {
            "physical_state_clusters": len(selected), "improvement_mean": mean(selected), "ci95": quantile(draws),
        }
    return {
        "seeds": list(SEEDS), "physical_state_clusters": len(states),
        "improvement_mean": mean(list(state_means.values())),
        "per_seed_improvement_mean": per_seed,
        "positive_seed_count": sum(value > 0 for value in per_seed.values()),
        "physical_state_cluster_ci95": quantile(state_draws),
        "two_way_seed_state_ci95": quantile(two_way),
        "by_network": by_network,
    }


def write_records(path, records):
    with open(path, "x", encoding="utf-8", newline="\n") as handle:
        for method in sorted(records):
            for row in records[method]:
                handle.write(json.dumps({"method": method, **row}, ensure_ascii=False, sort_keys=True) + "\n")


def main():
    import torch
    import grpo_train as training

    args = parse_args()
    output = Path(args.output_dir)
    if output.exists():
        raise FileExistsError(f"refusing to overwrite cross-topology output: {output}")
    manifest = json.load(open(args.preflight_manifest, encoding="utf-8"))
    verify_args = SimpleNamespace(output=args.preflight_manifest, verify=True, **manifest["schedule"])
    preflight.verify(verify_args)
    if not torch.cuda.is_available():
        raise RuntimeError("cross-topology frozen LLM evaluation requires CUDA")
    rows = read_rows(manifest["artifacts"]["pairs"]["path"])
    original_train = read_rows(manifest["artifacts"]["original_train"]["path"])
    schedule = manifest["schedule"]
    records = {}

    withheld_train = [row for row in original_train if row["pair_type"] != PRIMARY]
    parser = benchmark.fit_text_parser(withheld_train, 20260926)
    predictions = {
        "fixed_loss_lindistflow": benchmark.fixed_predictions(rows),
        "frozen_rule_parser_lindistflow": benchmark.rule_predictions(rows),
        TFIDF: benchmark.predict_text_parser(parser, rows),
        "oracle_structured_lindistflow": benchmark.oracle_predictions(rows),
    }
    for name, values in predictions.items():
        records[name] = add_state_identity(joint.records_from_predictions(rows, values, name), rows)
    records["full_ac_oracle"] = add_state_identity(joint.full_ac_oracle_records(rows), rows)

    llm_names = []
    for model_seed in SEEDS:
        random.seed(model_seed)
        torch.manual_seed(model_seed)
        torch.cuda.manual_seed_all(model_seed)
        adapter = manifest["llm_adapters"][str(model_seed)]["path"]
        model_args = SimpleNamespace(
            base_model=manifest["base_model"]["path"], resume_adapter_path=adapter,
            output_dir=str(output), gradient_checkpointing=1,
        )
        model, tokenizer = training.build_model_and_tokenizer(model_args)
        for parameter in model.parameters():
            parameter.requires_grad_(False)
        model.eval(); model.config.use_cache = False
        score_args = SimpleNamespace(
            max_length=schedule["max_length"], primitive_batch_size=schedule["primitive_batch_size"]
        )
        correct = factorized.primitive_score_cache(model, tokenizer, rows, score_args, "default", "correct")
        removed = factorized.primitive_score_cache(model, tokenizer, rows, score_args, "default", "instruction_removed")
        counter = factorized.primitive_score_cache(model, tokenizer, rows, score_args, "default", "instruction_counterfactual")
        name = f"{LLM_PREFIX}_s{model_seed}"
        llm_names.append(name)
        for method, values, condition in (
            (name, correct, "correct"),
            (f"llm_instruction_removed_s{model_seed}", removed, "instruction_removed"),
            (f"llm_instruction_counterfactual_s{model_seed}", counter, "instruction_counterfactual"),
        ):
            composed = factorized.composed_score_cache(values)
            records[method] = add_state_identity(joint.records_from_scores(rows, composed, condition), rows)
        del model, tokenizer, correct, removed, counter
        gc.collect(); torch.cuda.empty_cache()

    summaries = {name: summarize(values) for name, values in records.items()}
    paired_results = {}
    for model_seed, llm_name in zip(SEEDS, llm_names):
        paired_results[f"llm_vs_tfidf_primary_s{model_seed}"] = paired(
            subset(records[TFIDF]), subset(records[llm_name]), schedule["bootstrap_reps"], schedule["bootstrap_seed"] + model_seed
        )
        paired_results[f"llm_correct_vs_removed_s{model_seed}"] = paired(
            records[f"llm_instruction_removed_s{model_seed}"], records[llm_name], schedule["bootstrap_reps"], schedule["bootstrap_seed"] + 20000 + model_seed
        )
        paired_results[f"llm_correct_vs_counterfactual_s{model_seed}"] = paired(
            records[f"llm_instruction_counterfactual_s{model_seed}"], records[llm_name], schedule["bootstrap_reps"], schedule["bootstrap_seed"] + 30000 + model_seed
        )

    primary_rows = [row for row in rows if row["pair_type"] == PRIMARY]
    multi_seed = {
        "llm_over_withheld_tfidf_primary": multiseed_state_bootstrap(
            {name: subset(records[name]) for name in llm_names}, subset(records[TFIDF]), llm_names,
            primary_rows, schedule["bootstrap_reps"], schedule["bootstrap_seed"] + 40000,
        ),
        "llm_over_fixed_loss_primary": multiseed_state_bootstrap(
            {name: subset(records[name]) for name in llm_names}, subset(records["fixed_loss_lindistflow"]), llm_names,
            primary_rows, schedule["bootstrap_reps"], schedule["bootstrap_seed"] + 41000,
        ),
        "llm_over_frozen_rule_primary": multiseed_state_bootstrap(
            {name: subset(records[name]) for name in llm_names}, subset(records["frozen_rule_parser_lindistflow"]), llm_names,
            primary_rows, schedule["bootstrap_reps"], schedule["bootstrap_seed"] + 42000,
        ),
    }
    integrity_checks = {
        "evaluation_only_no_training": True,
        "sealed_outcomes_not_used_for_fit": parser["fit_rows"] == len(withheld_train),
        "all_requested_methods_present": all(name in records for name in [*llm_names, TFIDF, "fixed_loss_lindistflow", "frozen_rule_parser_lindistflow", "oracle_structured_lindistflow", "full_ac_oracle"]),
        "all_llm_feasible": all(summaries[name]["safe_feasible_rate"] == 1.0 for name in llm_names),
        "all_llm_constraint_safe": all(summaries[name]["constraint_violation_rate"] == 0.0 for name in llm_names),
        "three_unseen_networks_reported": all(len(summaries[name]["by_network"]) == 3 for name in llm_names),
    }
    generalisation_checks = {
        "llm_beats_fixed_loss_two_way_ci": multi_seed["llm_over_fixed_loss_primary"]["two_way_seed_state_ci95"][0] > 0,
        "llm_beats_frozen_rule_two_way_ci": multi_seed["llm_over_frozen_rule_primary"]["two_way_seed_state_ci95"][0] > 0,
        "llm_positive_all_three_networks_vs_fixed": all(value["improvement_mean"] > 0 for value in multi_seed["llm_over_fixed_loss_primary"]["by_network"].values()),
        "llm_positive_at_least_2_seeds_vs_fixed": multi_seed["llm_over_fixed_loss_primary"]["positive_seed_count"] >= 2,
    }
    evaluation_pass = all(integrity_checks.values())
    generalisation_gate = evaluation_pass and all(generalisation_checks.values())
    decision = (
        "authorize_framework_cross_topology_claim" if generalisation_gate else
        "report_bounded_cross_topology_result_without_generalisation_claim"
    )
    output.mkdir(parents=True, exist_ok=False)
    records_path = output / "gridrank_dynamic_cross_topology_records.jsonl"
    write_records(records_path, records)
    result = {
        "msg": "GridRank sealed dynamic cross-topology zero-shot evaluation",
        "schema": "gridrank-dynamic-cross-topology-gate-v1",
        "experiment_id": preflight.EXPERIMENT_ID,
        "preflight_sha256": preflight.file_sha256(args.preflight_manifest),
        "evaluation_only": True, "training_performed": False,
        "sealed_outcomes_used_for_fit": False,
        "seeds": list(SEEDS), "primary_pair_type": PRIMARY,
        "summaries": summaries, "paired": paired_results, "multi_seed": multi_seed,
        "integrity_checks": integrity_checks,
        "generalisation_checks": generalisation_checks,
        "evaluation_pass": evaluation_pass,
        "generalisation_gate_pass": generalisation_gate,
        "failed_integrity": [key for key, value in integrity_checks.items() if not value],
        "failed_generalisation": [key for key, value in generalisation_checks.items() if not value],
        "records": {"path": str(records_path.resolve()), "sha256": preflight.file_sha256(records_path), "methods": sorted(records), "rows": sum(len(value) for value in records.values())},
        "interpretation_boundary": manifest["claim_boundary"],
        "decision": decision,
    }
    gate = output / "gridrank_dynamic_cross_topology_gate.json"
    gate.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(result, ensure_ascii=False))
    if not result["evaluation_pass"]:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
