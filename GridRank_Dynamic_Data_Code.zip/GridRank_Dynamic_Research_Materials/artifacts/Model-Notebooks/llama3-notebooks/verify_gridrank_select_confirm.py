"""Validate GridRank select confirm."""

from __future__ import annotations

import argparse
import json
import subprocess
import sys
import tempfile
from pathlib import Path

from aggregate_gridrank_select_confirm import random_top3_baseline
from build_gridrank_select import file_sha256
from make_gridrank_confirm_state_view import build_view, verify_view
from preflight_gridrank_select_confirm import SEEDS
from train_gridrank_select_confirm import GATE_SCHEMA


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def expect_failure(function, message):
    try:
        function()
    except (ValueError, RuntimeError, FileNotFoundError):
        return
    raise RuntimeError(message)


def random_baseline_regression():
    candidates = []
    for index in range(15):
        accepted = index in {0, 1, 2, 3}
        candidates.append({
            "accepted_by_gate": accepted,
            "safe_utility": float(4 - index) if accepted else None,
        })
    row = {
        "instance_id": "synthetic-test",
        "network_id": "33",
        "physical_state_sha256": "state",
        "candidates": candidates,
        "gate_anchor": {"accepted_by_gate": True, "safe_utility": 0.0},
    }
    result = random_top3_baseline([row])[0]
    require(result["subset_count"] == 455, "random Top-3 did not enumerate C(15,3)")
    require(0.0 < result["expected_safe_regret"] < 4.0,
            "random Top-3 expected regret is outside physical bounds")

    noop_only = dict(row)
    noop_only["physical_state_sha256"] = "noop-state"
    noop_only["candidates"] = [
        {"accepted_by_gate": False, "safe_utility": None} for _ in range(15)
    ]
    require(random_top3_baseline([noop_only])[0]["expected_safe_regret"] == 0.0,
            "random equal-budget baseline mishandled the no-op anchor")


def view_regression(raw_paths):
    with tempfile.TemporaryDirectory() as directory:
        root = Path(directory)
        for network, raw in raw_paths.items():
            output = root / f"{network}.jsonl"
            manifest = root / f"{network}.manifest.json"
            built = build_view(raw, output, manifest)
            require(built["source_selected_split"] == "test",
                    "confirmation view did not bind raw test split")
            require(built["emitted_role_split"] == "validation",
                    "confirmation view did not declare internal heldout role")
            require(verify_view(raw, output, manifest)["verification_pass"],
                    "fresh confirmation view failed verification")
            with open(output, "a", encoding="utf-8") as handle:
                handle.write("\n")
            expect_failure(
                lambda: verify_view(raw, output, manifest),
                "mutated confirmation view passed its manifest lock",
            )


def aggregate_regression():
    with tempfile.TemporaryDirectory() as directory:
        root = Path(directory)
        test_path = root / "test.jsonl"
        test_rows = []
        for index in range(64):
            network = "33" if index < 32 else "69"
            candidates = [
                {
                    "accepted_by_gate": candidate_index == 0,
                    "safe_utility": 5.0 if candidate_index == 0 else None,
                }
                for candidate_index in range(15)
            ]
            test_rows.append({
                "instance_id": f"test-{index}",
                "network_id": network,
                "load_id": f"{network}:load-{index}",
                "physical_state_sha256": f"state-{index:02d}",
                "candidates": candidates,
                "gate_anchor": {"accepted_by_gate": True, "safe_utility": 0.0},
            })
        test_path.write_text(
            "".join(json.dumps(row) + "\n" for row in test_rows), encoding="utf-8"
        )
        gates = []
        for offset, seed in enumerate(SEEDS):
            rows = [{
                "instance_id": row["instance_id"],
                "network": row["network_id"],
                "load_id": row["load_id"],
                "physical_state_sha256": row["physical_state_sha256"],
                "sft_safe_regret": 5.0,
                "distilled_safe_regret": 1.0 - 0.1 * offset,
                "safe_regret_improvement": 4.0 + 0.1 * offset,
                "sft_safe_action": "Action: none",
                "distilled_safe_action": "Action: synthetic",
                "sft_safe_feasible": True,
                "distilled_safe_feasible": True,
            } for row in test_rows]
            gate = {
                "schema": GATE_SCHEMA,
                "confirmation_id": "gridrank-select-locked-test-confirm-v1",
                "confirmation_seed": seed,
                "paper_claim_authorized": False,
                "engineering_gate_pass": True,
                "mechanism_checks": {"synthetic": True},
                "safety_checks": {"synthetic": True},
                "diagnostic_adapter": {"valid": True},
                "locked_manifest": {
                    "schema": "gridrank-select-confirm-preflight-v1",
                    "artifact_sha256": {"test": file_sha256(test_path)},
                    "training_schedule": {"seed": seed},
                    "confirmation": {
                        "confirmation_id": "gridrank-select-locked-test-confirm-v1"
                    },
                },
                "paired": {"distilled_vs_sft": {
                    "state_rows": rows,
                    "state_cluster_bootstrap_ci95": [3.0, 5.0],
                }},
                "summaries": {
                    "distilled": {"safe_feasible_rate": 1.0},
                    "always_noop": {"safe_regret_mean": 5.0},
                },
            }
            path = root / f"gate-{seed}.json"
            path.write_text(json.dumps(gate), encoding="utf-8")
            gates.append((seed, path))
        output = root / "aggregate.json"
        csv_path = root / "aggregate.csv"
        command = [
            sys.executable, "-B", str(Path(__file__).with_name(
                "aggregate_gridrank_select_confirm.py"
            )),
        ]
        for seed, path in gates:
            command.extend(("--gate", f"{seed}={path}"))
        command.extend((
            "--test_jsonl", str(test_path), "--output_json", str(output),
            "--output_csv", str(csv_path), "--bootstrap_reps", "2000",
            "--bootstrap_seed", "7",
        ))
        subprocess.run(command, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        result = json.loads(output.read_text(encoding="utf-8"))
        require(result["confirmation_gate_pass"] is True,
                "positive synthetic three-seed confirmation failed")
        require(result["primary_claim_authorized"] is True,
                "passed aggregate did not authorize the scoped claim")
        require(csv_path.is_file() and len(csv_path.read_text(encoding="utf-8").splitlines()) == 65,
                "aggregate row evidence CSV is incomplete")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--test_raw", action="append", required=True,
                        help="NETWORK=RAW_TEST_JSONL")
    args = parser.parse_args()
    raw_paths = {}
    for spec in args.test_raw:
        network, path = spec.split("=", 1)
        raw_paths[network] = Path(path).resolve()
    require(set(raw_paths) == {"33", "69"}, "confirmation regression requires 33/69")
    require(SEEDS == (42, 123, 2025), "confirmation seed set drift")
    random_baseline_regression()
    view_regression(raw_paths)
    aggregate_regression()
    print(json.dumps({
        "msg": "GridRank-Select confirmation dependency-light verification PASS",
        "raw_test_role_mapping": True,
        "oracle_boundary_manifest_locked": True,
        "mutated_view_rejected": True,
        "three_seed_schedule_locked": list(SEEDS),
        "exact_random_top3_equal_budget_baseline": True,
        "three_seed_aggregate_gate_regression": True,
    }, ensure_ascii=False))


if __name__ == "__main__":
    main()
