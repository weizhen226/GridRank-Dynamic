"""Grpo reward limited utilities."""

import atexit
import hashlib
import re
import sys
import threading
from pathlib import Path

_HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(_HERE))

import case33_authoritative as c33
import case69_authoritative as c69
from physics_env import PhysicsEnv, scenario_for_network

_ENGINES = {33: c33, 69: c69}
_EXTERNAL_BACKENDS = {}
_EXTERNAL_BACKEND_LOCK = threading.RLock()

VMIN, VMAX = 0.90, 1.10
_LOAD_RE = re.compile(r"System Load=\[(.*?)\]", re.S)
_EXIST_RE = re.compile(r"Existing Open Lines=\[(.*?)\]", re.S)
_BUDGET_RE = re.compile(r"N_branch_exchanges\s*<=\s*(\d+)")
_OPEN_RE = re.compile(r"Open Lines=\[(.*?)\]", re.S)
_NETWORK_RE = re.compile(r"Busses\s*=\s*(33|69)\b")


def engine_from_prompt(prompt):
    match = _NETWORK_RE.search(str(prompt))
    if not match:
        return None
    return _ENGINES[int(match.group(1))]


def _pairs(s):
    return [(int(a), int(b)) for a, b in re.findall(r"\(\s*(\d+)\s*,\s*(\d+)\s*\)", s)]


def parse_existing_open(prompt):
    m = _EXIST_RE.search(str(prompt))
    return _pairs(m.group(1)) if m else None


def parse_budget(prompt):
    m = _BUDGET_RE.search(str(prompt))
    return int(m.group(1)) if m else None


def parse_load(prompt):
    m = _LOAD_RE.search(str(prompt))
    if not m:
        return None
    out = []
    for tok in re.findall(r"\(?[-0-9.eE+]+[-+][0-9.eE]+j\)?|0j|\(?-?[0-9.eE]+j\)?", m.group(1)):
        try:
            out.append(complex(tok.strip("() ")))
        except ValueError:
            pass
    return out if out else None


def reconstruct_pred_open(completion, existing=None, action_mode="delta", engine=None):
    
    import action_extract
    if action_mode != "state":
        delta = action_extract.extract_delta(completion)
        if delta is not None:
            if existing is None:
                return None, "missing_existing"
            if delta == "none":
                return list(existing), "ok"
            remove_edge, add_edge = delta
            existing_by_key = {_key(*edge): edge for edge in existing}
            branch_keys = (
                {_key(a, b) for a, b, _, _ in engine.ALL_BRANCHES}
                if engine is not None else None
            )
            if _key(*remove_edge) not in existing_by_key:
                return None, "remove_not_open"
            if _key(*add_edge) in existing_by_key:
                return None, "add_already_open"
            if branch_keys is not None and _key(*add_edge) not in branch_keys:
                return None, "add_invalid_branch"
            prediction = [
                edge for edge in existing if _key(*edge) != _key(*remove_edge)
            ] + [add_edge]
            return prediction, "ok"
        if action_mode == "delta":
            return None, "unparsable_action"
    prediction = action_extract.extract_action(completion)
    return (prediction, "ok") if prediction is not None else (None, "unparsable_action")


def parse_pred_open(completion, existing=None, action_mode="delta", engine=None):
    
    prediction, _ = reconstruct_pred_open(completion, existing, action_mode, engine)
    return prediction


def _key(a, b):
    return tuple(sorted((int(a), int(b))))


def budget_distance(pred_open, existing_open):
    
    pe, ex = {_key(*e) for e in pred_open}, {_key(*e) for e in existing_open}
    return len(pe - ex)


def _physics_env(network_id, physics_backend, physics_python, physics_timeout_s):
    backend_name = str(physics_backend).strip().lower()
    if backend_name in {"authoritative", "bfs"}:
        return PhysicsEnv.for_network(network_id, backend=backend_name)
    key = (int(network_id), backend_name, str(physics_python or ""), float(physics_timeout_s))
    with _EXTERNAL_BACKEND_LOCK:
        shared = _EXTERNAL_BACKENDS.get(key)
        if shared is not None and hasattr(shared, "healthy") and not shared.healthy:
            close = getattr(shared, "close", None)
            if callable(close):
                close()
            shared = None
            _EXTERNAL_BACKENDS.pop(key, None)
        if shared is None:
            created = PhysicsEnv.for_network(
                network_id,
                backend=backend_name,
                physics_python=physics_python,
                backend_timeout_s=physics_timeout_s,
            )
            shared = created.backend
            _EXTERNAL_BACKENDS[key] = shared
        return PhysicsEnv(shared)


def _close_external_backends():
    with _EXTERNAL_BACKEND_LOCK:
        for backend in _EXTERNAL_BACKENDS.values():
            close = getattr(backend, "close", None)
            if callable(close):
                close()
        _EXTERNAL_BACKENDS.clear()


atexit.register(_close_external_backends)


def _empty_detail():
    return {
        "network_id": None,
        "prompt_hash": None,
        "state_fingerprint": None,
        "canonical_action": None,
        "candidate_open": None,
        "anchor_loss_kw": None,
        "candidate_loss_kw": None,
        "min_vm_pu": None,
        "max_vm_pu": None,
        "physics_backend": None,
        "parse_ok": False,
        "action_valid": False,
        "within_budget": None,
        "radial": None,
        "converged": None,
        "voltage_ok": None,
        "red": None,
        "feasible": False,
        "feedback_valid": False,
        "reason": None,
    }


def score_completions(
    prompt,
    completions,
    return_detail=False,
    action_mode="delta",
    physics_backend="authoritative",
    physics_python=None,
    physics_timeout_s=60.0,
):
    
    completions = list(completions)
    engine = engine_from_prompt(prompt)
    existing = parse_existing_open(prompt)
    load = parse_load(prompt)
    k = parse_budget(prompt)
    parsed = [
        reconstruct_pred_open(completion, existing, action_mode, engine)
        for completion in completions
    ]
    missing = (
        "missing_network" if engine is None else
        "missing_existing" if existing is None else
        "missing_load" if load is None else
        "missing_budget" if k is None else
        None
    )

    env = None
    if missing is None:
        load_pu = [0j] * engine.N_BUS
        for index, value in enumerate(load[: engine.N_BUS]):
            load_pu[index] = value
        env = _physics_env(
            engine.N_BUS, physics_backend, physics_python, physics_timeout_s
        )
        env.reset(
            scenario_for_network(
                engine.N_BUS,
                existing,
                load_pu,
                exchange_budget=k,
                decision_horizon=1,
                vmin=VMIN,
                vmax=VMAX,
            ),
            require_feasible_initial=False,
            require_known_initial_edges=False,
        )

    output = []
    for completion, (pred, action_reason) in zip(completions, parsed):
        detail = _empty_detail()
        detail.update({
            "network_id": engine.N_BUS if engine is not None else None,
            "prompt_hash": hashlib.sha256(str(prompt).encode("utf-8")).hexdigest(),
            "physics_backend": str(physics_backend),
        })
        detail["parse_ok"] = action_reason != "unparsable_action"
        detail["action_valid"] = pred is not None
        if missing is not None:
            detail["reason"] = missing
            result = (None, False, detail)
        else:
            detail["feedback_valid"] = True
            if pred is None:
                detail["reason"] = action_reason
                result = (None, False, detail)
            else:
                detail["parse_ok"] = True
                detail["action_valid"] = True
                
                evaluation = env.evaluate_open_set(pred, strict=False)
                candidate_flow = evaluation.candidate_flow
                anchor_flow = evaluation.anchor_flow


                import action_extract
                parsed_delta = action_extract.extract_delta(completion)
                if parsed_delta == "none":
                    canonical_action = "Action: none"
                elif parsed_delta is not None:
                    remove_edge, add_edge = parsed_delta
                    remove_edge = tuple(sorted(map(int, remove_edge)))
                    add_edge = tuple(sorted(map(int, add_edge)))
                    canonical_action = (
                        f"Action: Replace ({remove_edge[0]}, {remove_edge[1]}) "
                        f"with ({add_edge[0]}, {add_edge[1]})"
                    )
                else:
                    canonical_action = None
                legacy_base_ok = bool(
                    anchor_flow.radial and anchor_flow.converged and anchor_flow.loss_kw
                )
                detail.update({
                    "state_fingerprint": evaluation.state_fingerprint,
                    "canonical_action": canonical_action,
                    "candidate_open": (
                        [list(edge) for edge in evaluation.candidate_open]
                        if evaluation.candidate_open is not None else None
                    ),
                    "anchor_loss_kw": anchor_flow.loss_kw,
                    "anchor_min_vm_pu": anchor_flow.min_vm_pu,
                    "anchor_max_vm_pu": anchor_flow.max_vm_pu,
                    "candidate_loss_kw": candidate_flow.loss_kw,
                    "min_vm_pu": candidate_flow.min_vm_pu,
                    "max_vm_pu": candidate_flow.max_vm_pu,
                    "within_budget": evaluation.within_budget,
                    "radial": candidate_flow.radial,
                    "converged": candidate_flow.converged,
                    "voltage_ok": evaluation.voltage_ok if legacy_base_ok else None,
                    "red": evaluation.reduction_anchor_pct,
                    "feasible": evaluation.feasible,
                    "feedback_valid": evaluation.feedback_valid,
                    "reason": evaluation.reason,
                })
                result = (
                    evaluation.reduction_anchor_pct,
                    evaluation.feasible,
                    detail,
                )
        output.append(result if return_detail else result[:2])
    return output


def score_completion(
    prompt,
    completion,
    net=None,
    return_detail=False,
    action_mode="delta",
    physics_backend="authoritative",
    physics_python=None,
    physics_timeout_s=60.0,
):
    
    del net  
    return score_completions(
        prompt,
        [completion],
        return_detail=return_detail,
        action_mode=action_mode,
        physics_backend=physics_backend,
        physics_python=physics_python,
        physics_timeout_s=physics_timeout_s,
    )[0]


def score_group(
    prompt,
    completions,
    physics_backend="authoritative",
    physics_python=None,
    physics_timeout_s=60.0,
):
    
    scored = score_completions(
        prompt,
        completions,
        physics_backend=physics_backend,
        physics_python=physics_python,
        physics_timeout_s=physics_timeout_s,
    )
    reds = [item[0] for item in scored]
    feas = [item[1] for item in scored]
    return reds, feas


if __name__ == "__main__":
    import argparse
    import csv
    import json
    ap = argparse.ArgumentParser(description="Smoke-test the limited-action reward on SFT CSV/JSONL.")
    ap.add_argument("--sft_jsonl", required=True, help="Historical name; accepts SFT CSV or JSONL.")
    ap.add_argument("--n", type=int, default=6)
    ap.add_argument(
        "--physics_backend",
        choices=["authoritative", "pandapower", "pandapower-subprocess"],
        default="authoritative",
    )
    ap.add_argument("--physics_python", default=None)
    ap.add_argument("--physics_timeout_s", type=float, default=60.0)
    args = ap.parse_args()

    if str(args.sft_jsonl).lower().endswith(".csv"):
        with open(args.sft_jsonl, encoding="utf-8", newline="") as f:
            rows = list(csv.DictReader(f))
    else:
        rows = []
        with open(args.sft_jsonl, encoding="utf-8") as f:
            for line in f:
                if line.strip():
                    rows.append(json.loads(line))
    rows = rows[: args.n]
    print("checking: GT label feasible & red>=0 ; over-budget action rejected ; existing red~0\n")
    ok_gt = 0
    for i, r in enumerate(rows):
        p = r["prompt"]
        
        
        sm = dict(
            return_detail=True,
            action_mode="state",
            physics_backend=args.physics_backend,
            physics_python=args.physics_python,
            physics_timeout_s=args.physics_timeout_s,
        )
        
        red_gt, feas_gt, d_gt = score_completion(p, r["output"], **sm)
        
        existing_open = r.get("existing_open") or parse_existing_open(p)
        ex_txt = "Output: Open Lines=" + "[" + ", ".join(
            f"({a}, {b})" for a, b in existing_open
        ) + "]"
        red_ex, feas_ex, _ = score_completion(p, ex_txt, **sm)
        
        bad_txt = "Output: Open Lines=[(50, 59), (27, 65), (15, 46), (13, 21), (11, 43)]"
        red_bad, feas_bad, d_bad = score_completion(p, bad_txt, **sm)
        ok_gt += int(feas_gt and (red_gt is not None and red_gt >= -1e-6))
        print(f"[s{i}] bucket={r['bucket']:4s} k={r['k']} | GT: feasible={feas_gt} red={red_gt:.3f} "
              f"({d_gt['reason']}) | existing: red={red_ex if red_ex is None else round(red_ex,3)} "
              f"feas={feas_ex} | over-budget: within={d_bad['within_budget']} feas={feas_bad}")
    print(f"\nGT labels feasible+improving: {ok_gt}/{len(rows)}")

