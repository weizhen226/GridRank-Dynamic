
"""Check inputs for GridRank dynamic cross topology."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path

import preflight_gridrank_feedback as runtime
from gridrank_dynamic_factorized_llm import PRIMITIVES, render_primitive_prompt
from gridrank_runtime_compat import runtime_compatibility


SCHEMA = "gridrank-dynamic-cross-topology-preflight-scoped-v2"
EXPERIMENT_ID = "gridrank-dynamic-scoped-cross-topology-zero-shot-v2"
SEEDS = (42, 123, 2025)
CODE_FILES = (
    "gridrank_dynamic_cross_topology.py",
    "build_gridrank_dynamic_cross_topology.py",
    "audit_gridrank_dynamic_cross_topology.py",
    "preflight_gridrank_dynamic_cross_topology.py",
    "eval_gridrank_dynamic_cross_topology.py",
    "verify_gridrank_dynamic_cross_topology.py",
    "verify_gridrank_dynamic_cross_topology_dependencies.py",
    "run_gridrank_dynamic_cross_topology.sh",
    "../../docs/GRIDRANK_DYNAMIC_CROSS_TOPOLOGY_PROTOCOL.md",
)
HERE = Path(__file__).resolve().parent


def file_sha256(path):
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def artifact(path):
    value = Path(path).resolve()
    return {"path": str(value), "sha256": file_sha256(value)}


def directory_manifest(path, hash_files=True):
    root = Path(path).resolve()
    if not root.is_dir():
        raise FileNotFoundError(root)
    result = {}
    for item in sorted(value for value in root.rglob("*") if value.is_file()):
        relative = item.relative_to(root).as_posix()
        record = {"size": item.stat().st_size}
        if hash_files:
            record["sha256"] = file_sha256(item)
        result[relative] = record
    if not result:
        raise RuntimeError(f"empty model directory: {root}")
    return {"path": str(root), "files": result}


def parse_bindings(values, label):
    result = {}
    for value in values:
        if "=" not in value:
            raise ValueError(f"{label} must use SEED=PATH")
        raw, path = value.split("=", 1)
        result[int(raw)] = path
    if tuple(sorted(result)) != SEEDS:
        raise ValueError(f"{label} seeds must be exactly {SEEDS}")
    return result


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--pairs", required=True)
    parser.add_argument("--summary", required=True)
    parser.add_argument("--audit", required=True)
    parser.add_argument("--original_train", required=True)
    parser.add_argument("--llm_adapter", action="append", required=True)
    parser.add_argument("--llm_gate", action="append", required=True)
    parser.add_argument("--base_model", required=True)
    parser.add_argument("--physics_python", default=sys.executable)
    parser.add_argument("--max_length", type=int, default=1024)
    parser.add_argument("--primitive_batch_size", type=int, default=4)
    parser.add_argument("--topk", type=int, default=1)
    parser.add_argument("--bootstrap_reps", type=int, default=10000)
    parser.add_argument("--bootstrap_seed", type=int, default=20260907)
    parser.add_argument("--output", required=True)
    parser.add_argument("--verify", action="store_true")
    return parser.parse_args()


def read_rows(path):
    return [json.loads(line) for line in open(path, encoding="utf-8") if line.strip()]


def code_hashes():
    missing, result = [], {}
    for name in CODE_FILES:
        path = (HERE / name).resolve()
        if not path.is_file():
            missing.append(name)
        else:
            result[name] = file_sha256(path)
    if missing:
        raise FileNotFoundError(f"missing cross-topology code: {missing}")
    return result


def base_inventory(path):
    return directory_manifest(path, hash_files=False)


def prompt_audit(rows, base_model, max_length):
    from transformers import AutoTokenizer
    tokenizer = AutoTokenizer.from_pretrained(base_model, local_files_only=True)
    maximum, truncated = 0, 0
    for row in rows:
        for primitive in PRIMITIVES:
            text = render_primitive_prompt(tokenizer, row, primitive)
            length = len(tokenizer(text, add_special_tokens=False)["input_ids"])
            maximum = max(maximum, length)
            truncated += int(length > max_length)
    return {
        "prompts": len(rows) * len(PRIMITIVES), "max_tokens": maximum,
        "truncated_prompts": truncated, "prompt_length_pass": truncated == 0,
    }


def schedule(args):
    return {
        "max_length": args.max_length,
        "primitive_batch_size": args.primitive_batch_size,
        "topk": args.topk,
        "bootstrap_reps": args.bootstrap_reps,
        "bootstrap_seed": args.bootstrap_seed,
    }


def create(args):
    output = Path(args.output)
    if output.exists():
        raise FileExistsError(f"refusing to overwrite preflight: {output}")
    llm_adapters = parse_bindings(args.llm_adapter, "llm_adapter")
    llm_gates = parse_bindings(args.llm_gate, "llm_gate")
    summary = json.load(open(args.summary, encoding="utf-8"))
    audit = json.load(open(args.audit, encoding="utf-8"))
    rows = read_rows(args.pairs)
    prompts = prompt_audit(rows, args.base_model, args.max_length)
    artifacts = {
        "pairs": artifact(args.pairs), "summary": artifact(args.summary),
        "audit": artifact(args.audit), "original_train": artifact(args.original_train),
    }
    checks = {
        "summary_coverage_pass": summary.get("coverage_pass") is True,
        "audit_pass": audit.get("audit_pass") is True,
        "sealed_rows_192": len(rows) == 192,
        "sealed_pairs_96": len({row["pair_id"] for row in rows}) == 96,
        "three_unseen_networks": len({row["network_id"] for row in rows}) == 3,
        "primary_pairs_48": len({row["pair_id"] for row in rows if row["pair_type"] == "maintenance_voltage"}) == 48,
        "prompt_length_pass": prompts["prompt_length_pass"],
        "topk_one": args.topk == 1,
        "bootstrap_10000": args.bootstrap_reps == 10000,
    }
    result = {
        "msg": "GridRank sealed dynamic cross-topology preflight",
        "schema": SCHEMA, "experiment_id": EXPERIMENT_ID,
        "preflight_pass": all(checks.values()),
        "evaluation_only": True, "training_performed": False,
        "final_evaluation_performed": False,
        "seeds": list(SEEDS), "schedule": schedule(args),
        "artifacts": artifacts,
        "llm_adapters": {str(seed): directory_manifest(path) for seed, path in llm_adapters.items()},
        "llm_gates": {str(seed): artifact(path) for seed, path in llm_gates.items()},
        "base_model": base_inventory(args.base_model),
        "training_runtime": runtime.training_runtime(),
        "physics_runtime": runtime.physics_runtime(args.physics_python),
        "prompt_audit": prompts,
        "code_sha256": code_hashes(),
        "checks": checks,
        "failed_checks": [key for key, value in checks.items() if not value],
        "claim_boundary": summary["suite"]["claim_boundary"],
    }
    output.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(result, ensure_ascii=False))
    if not result["preflight_pass"]:
        raise SystemExit(2)


def verify(args):
    locked = json.load(open(args.output, encoding="utf-8"))
    current_training = runtime.training_runtime()
    current_physics = runtime.physics_runtime(locked["physics_runtime"]["executable"])
    checks = {
        "schema": locked.get("schema") == SCHEMA,
        "experiment_id": locked.get("experiment_id") == EXPERIMENT_ID,
        "preflight_pass": locked.get("preflight_pass") is True,
        "evaluation_only": locked.get("evaluation_only") is True,
        "artifacts_current": all(file_sha256(value["path"]) == value["sha256"] for value in locked["artifacts"].values()),
        "llm_gates_current": all(file_sha256(value["path"]) == value["sha256"] for value in locked["llm_gates"].values()),
        "llm_adapters_current": all(directory_manifest(value["path"])["files"] == value["files"] for value in locked["llm_adapters"].values()),
        "base_model_current": base_inventory(locked["base_model"]["path"])["files"] == locked["base_model"]["files"],
        "training_runtime_compatible": runtime_compatibility(locked["training_runtime"], current_training)["compatible"],
        "physics_runtime_compatible": runtime_compatibility(locked["physics_runtime"], current_physics)["compatible"],
        "code_current": code_hashes() == locked["code_sha256"],
        "schedule_current": schedule(args) == locked["schedule"],
    }
    result = {
        "msg": "GridRank dynamic cross-topology runtime verification",
        "checks": checks, "verification_pass": all(checks.values()),
        "runtime_compatibility": {
            "training": runtime_compatibility(locked["training_runtime"], current_training),
            "physics": runtime_compatibility(locked["physics_runtime"], current_physics),
        },
    }
    print(json.dumps(result, ensure_ascii=False))
    if not result["verification_pass"]:
        raise SystemExit(2)


def main():
    args = parse_args()
    verify(args) if args.verify else create(args)


if __name__ == "__main__":
    main()
