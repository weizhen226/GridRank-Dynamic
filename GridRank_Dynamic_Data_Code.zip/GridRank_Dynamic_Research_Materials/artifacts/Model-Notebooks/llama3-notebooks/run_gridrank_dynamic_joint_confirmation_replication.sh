#!/usr/bin/env bash
set -euo pipefail

CURRENT_STAGE="bootstrap"
on_exit() {
  local rc=$?
  trap - EXIT
  if (( rc != 0 )); then
    printf '{"msg":"GridRank matched joint-card confirmation failure","stage":"%s","model_seed":%s,"exit_code":%d}\n' \
      "$CURRENT_STAGE" "${MODEL_SEED:-null}" "$rc"
  fi
  exit "$rc"
}
trap on_exit EXIT

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"
export HF_HUB_OFFLINE=1
export TRANSFORMERS_OFFLINE=1
if [[ ! "${OMP_NUM_THREADS:-}" =~ ^[1-9][0-9]*$ ]]; then export OMP_NUM_THREADS=4; fi
export PYTORCH_CUDA_ALLOC_CONF="${PYTORCH_CUDA_ALLOC_CONF:-max_split_size_mb:64}"

PREFLIGHT_ONLY="${PREFLIGHT_ONLY:-1}"
case "$PREFLIGHT_ONLY" in 0|1) ;; *) echo "PREFLIGHT_ONLY must be 0 or 1" >&2; exit 2;; esac
if [[ "$PREFLIGHT_ONLY" == "1" ]]; then export CUDA_VISIBLE_DEVICES=""; fi

resolve_executable() {
  local requested="$1"
  if [[ "$requested" == */* ]]; then [[ -x "$requested" ]] && printf '%s\n' "$requested"; else command -v -- "$requested"; fi
}
TRAIN_PYTHON_BIN="$(resolve_executable "${TRAIN_PYTHON:-python}")" || exit 2

: "${MODEL_SEED:?set MODEL_SEED to 123 or 2025}"
case "$MODEL_SEED" in 123|2025) ;; *) echo "MODEL_SEED must be exactly 123 or 2025" >&2; exit 2;; esac

TAG="${TAG:-gridrank_dynamic_joint_confirmation_v1_s${MODEL_SEED}_20260904}"
[[ "$TAG" =~ ^[A-Za-z0-9][A-Za-z0-9._-]*$ ]] || { echo "invalid TAG" >&2; exit 2; }
FRESH_TAG="${FRESH_TAG:-gridrank_dynamic_confirmation_v1_20260829_hotfix1}"
JOINT_TAG="${JOINT_TAG:-gridrank_dynamic_joint_replication_v1_s${MODEL_SEED}_20260904}"
FACTOR_TAG="${FACTOR_TAG:-gridrank_dynamic_factorized_replication_v1_s${MODEL_SEED}_20260830}"
FACTORIZED_CONFIRM_TAG="${FACTORIZED_CONFIRM_TAG:-gridrank_dynamic_confirmation_replication_v1_s${MODEL_SEED}_20260831}"

FRESH_PAIRS="${FRESH_PAIRS:-${FRESH_TAG}_pairs.jsonl}"
FRESH_SUMMARY="${FRESH_SUMMARY:-${FRESH_TAG}_summary.json}"
FRESH_AUDIT="${FRESH_AUDIT:-${FRESH_TAG}_audit.json}"
JOINT_PREFLIGHT="${JOINT_PREFLIGHT:-${JOINT_TAG}.preflight.json}"
JOINT_GATE="${JOINT_GATE:-output_${JOINT_TAG}/gridrank_dynamic_policy_gate.json}"
JOINT_ADAPTER="${JOINT_ADAPTER:-output_${JOINT_TAG}/diagnostic_adapter}"
FACTOR_PREFLIGHT="${FACTOR_PREFLIGHT:-${FACTOR_TAG}.preflight.json}"
FACTOR_GATE="${FACTOR_GATE:-output_${FACTOR_TAG}/gridrank_dynamic_factorized_gate.json}"
FACTOR_ADAPTER="${FACTOR_ADAPTER:-output_${FACTOR_TAG}/diagnostic_adapter}"
FACTOR_CONFIRM_PREFLIGHT="${FACTOR_CONFIRM_PREFLIGHT:-${FACTORIZED_CONFIRM_TAG}.preflight.json}"
FACTOR_CONFIRM_GATE="${FACTOR_CONFIRM_GATE:-output_${FACTORIZED_CONFIRM_TAG}/gridrank_dynamic_confirmation_gate.json}"
FACTORIZED_RECORDS="${FACTORIZED_RECORDS:-output_${FACTORIZED_CONFIRM_TAG}/gridrank_dynamic_confirmation_records.jsonl}"
BASE_MODEL="${BASE_MODEL:-../../Meta-Llama-3.1-8B-Instruct}"
PREFLIGHT="${PREFLIGHT:-${TAG}.preflight.json}"
OUT="${OUT:-output_${TAG}}"
GATE="$OUT/gridrank_dynamic_factorization_ablation_gate.json"

readonly MAX_LENGTH=512
readonly CARD_BATCH_SIZE=4
readonly TOPK=1
readonly BOOTSTRAP_REPS=10000
readonly EVALUATION_SEED=20260904
readonly GRADIENT_CHECKPOINTING=0

for path in \
  "$FRESH_PAIRS" "$FRESH_SUMMARY" "$FRESH_AUDIT" \
  "$JOINT_PREFLIGHT" "$JOINT_GATE" \
  "$JOINT_ADAPTER/adapter_config.json" "$JOINT_ADAPTER/adapter_model.safetensors" \
  "$FACTOR_PREFLIGHT" "$FACTOR_GATE" \
  "$FACTOR_ADAPTER/adapter_config.json" "$FACTOR_ADAPTER/adapter_model.safetensors" \
  "$FACTOR_CONFIRM_PREFLIGHT" "$FACTOR_CONFIRM_GATE" "$FACTORIZED_RECORDS" \
  "$BASE_MODEL/config.json" "$BASE_MODEL/tokenizer_config.json" \
  preflight_gridrank_dynamic_joint_confirmation_replication.py \
  eval_gridrank_dynamic_joint_confirmation_replication.py \
  verify_gridrank_dynamic_joint_confirmation_replication.py \
  verify_gridrank_dynamic_joint_confirmation_replication_dependencies.py \
  preflight_gridrank_dynamic_factorization_ablation.py \
  eval_gridrank_dynamic_factorization_ablation.py \
  verify_gridrank_dynamic_factorization_ablation.py \
  aggregate_gridrank_dynamic_multiseed.py train_gridrank_dynamic_policy.py \
  ../../docs/GRIDRANK_DYNAMIC_FACTORIZATION_MULTISEED_PROTOCOL.md; do
  test -e "$path" || { echo "missing matched joint confirmation input: $path" >&2; exit 2; }
done

COMMON_ARGS=(
  --fresh_pairs "$FRESH_PAIRS" --fresh_summary "$FRESH_SUMMARY" --fresh_audit "$FRESH_AUDIT"
  --joint_preflight "$JOINT_PREFLIGHT" --joint_gate "$JOINT_GATE" --joint_adapter "$JOINT_ADAPTER"
  --factorized_preflight "$FACTOR_PREFLIGHT" --factorized_gate "$FACTOR_GATE" --factorized_adapter "$FACTOR_ADAPTER"
  --factorized_confirmation_preflight "$FACTOR_CONFIRM_PREFLIGHT"
  --factorized_confirmation_gate "$FACTOR_CONFIRM_GATE"
  --factorized_confirmation_records "$FACTORIZED_RECORDS"
  --base_model "$BASE_MODEL" --model_seed "$MODEL_SEED"
  --max_length "$MAX_LENGTH" --card_batch_size "$CARD_BATCH_SIZE" --topk "$TOPK"
  --bootstrap_reps "$BOOTSTRAP_REPS" --seed "$EVALUATION_SEED"
  --gradient_checkpointing "$GRADIENT_CHECKPOINTING"
)

CURRENT_STAGE="dependency_regressions"
echo "=== 1/4 DEPENDENCY-LIGHT MATCHED-SEED CONFIRMATION REGRESSIONS ==="
"$TRAIN_PYTHON_BIN" -B verify_gridrank_dynamic_joint_confirmation_replication_dependencies.py

CURRENT_STAGE="locked_cpu_preflight"
echo "=== 2/4 LOCK JOINT/FACTORIZED SEED $MODEL_SEED AND IDENTICAL CONFIRMATION BYTES ==="
"$TRAIN_PYTHON_BIN" -B preflight_gridrank_dynamic_joint_confirmation_replication.py \
  "${COMMON_ARGS[@]}" --output "$PREFLIGHT"

if [[ "$PREFLIGHT_ONLY" == "1" ]]; then
  echo "=== GRIDRANK MATCHED JOINT CONFIRMATION SEED-$MODEL_SEED PREFLIGHT COMPLETE; GPU NOT STARTED ==="
  exit 0
fi
test ! -e "$OUT" || { echo "refusing to overwrite output: $OUT" >&2; exit 2; }

CURRENT_STAGE="cuda_readiness"
echo "=== 3/4 CUDA + NF4 READINESS ==="
"$TRAIN_PYTHON_BIN" -B - <<'PY'
import json
try:
    import bitsandbytes as bnb
    import torch
    checks = {"cuda_available": torch.cuda.is_available(), "visible_device_count": torch.cuda.device_count() > 0}
    device = torch.device("cuda:0") if all(checks.values()) else None
    if device is not None:
        layer = bnb.nn.Linear4bit(64, 64, bias=False, compute_dtype=torch.float16, compress_statistics=True, quant_type="nf4").to(device)
        value = layer(torch.randn(2, 64, device=device, dtype=torch.float16))
        torch.cuda.synchronize(device)
        checks["nf4_kernel"] = bool(value.is_cuda and torch.isfinite(value).all())
    else:
        checks["nf4_kernel"] = False
except Exception as exc:
    checks = {"exception_free": False}
    error = f"{type(exc).__name__}: {exc}"
else:
    error = None
result = {"msg": "GridRank matched joint confirmation CUDA readiness", "checks": checks, "error": error, "readiness_pass": bool(checks) and all(checks.values())}
print(json.dumps(result, ensure_ascii=False))
raise SystemExit(0 if result["readiness_pass"] else 2)
PY

CURRENT_STAGE="frozen_joint_evaluation"
echo "=== 4/4 FROZEN JOINT-CARD SEED $MODEL_SEED ON MATCHED CONFIRMATION ==="
set +e
"$TRAIN_PYTHON_BIN" -u eval_gridrank_dynamic_joint_confirmation_replication.py \
  --preflight_manifest "$PREFLIGHT" --joint_adapter "$JOINT_ADAPTER" \
  --base_model "$BASE_MODEL" --output_dir "$OUT" \
  --max_length "$MAX_LENGTH" --card_batch_size "$CARD_BATCH_SIZE" \
  --topk "$TOPK" --bootstrap_reps "$BOOTSTRAP_REPS" --seed "$EVALUATION_SEED" \
  --gradient_checkpointing "$GRADIENT_CHECKPOINTING"
EVAL_RC=$?
set -e
if [[ ! -f "$GATE" ]]; then exit "$EVAL_RC"; fi

CURRENT_STAGE="result_verification"
"$TRAIN_PYTHON_BIN" -B verify_gridrank_dynamic_joint_confirmation_replication.py \
  --gate "$GATE" --preflight "$PREFLIGHT"
"$TRAIN_PYTHON_BIN" -B - "$GATE" <<'PY'
import json, sys
gate = json.load(open(sys.argv[1], encoding="utf-8"))
if not gate.get("replication_evaluation_integrity_pass"):
    raise SystemExit("replication evaluation integrity/safety failed")
print(json.dumps({
    "msg": "GridRank matched joint confirmation accepted for aggregation",
    "model_seed": gate.get("model_seed"),
    "integrity_pass": True,
    "per_seed_factorization_effect_pass": gate.get("replication_factorization_effect_pass"),
}, ensure_ascii=False))
PY
if (( EVAL_RC != 0 && EVAL_RC != 2 )); then exit "$EVAL_RC"; fi
echo "=== GRIDRANK MATCHED JOINT CONFIRMATION SEED-$MODEL_SEED COMPLETE ==="
