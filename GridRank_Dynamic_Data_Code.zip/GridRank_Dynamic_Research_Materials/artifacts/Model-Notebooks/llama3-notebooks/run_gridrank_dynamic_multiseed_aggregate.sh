#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

TAG="${TAG:-gridrank_dynamic_multiseed_v1_20260901}"
REFERENCE_TAG="${REFERENCE_TAG:-gridrank_dynamic_confirmation_v1_20260829_hotfix1}"
SEED123_TAG="${SEED123_TAG:-gridrank_dynamic_confirmation_replication_v1_s123_20260831}"
SEED2025_TAG="${SEED2025_TAG:-gridrank_dynamic_confirmation_replication_v1_s2025_20260831}"
OUT="${OUT:-${TAG}_aggregate.json}"
FRESH_SUMMARY="${FRESH_SUMMARY:-${REFERENCE_TAG}_summary.json}"
FAIRNESS_TAG="${FAIRNESS_TAG:-gridrank_dynamic_fairness_audit_v1_20260901}"
TFIDF_AUDIT="${TFIDF_AUDIT:-${FAIRNESS_TAG}_factorized_tfidf.json}"

for path in \
  "$FRESH_SUMMARY" \
  "$TFIDF_AUDIT" \
  "output_${REFERENCE_TAG}/gridrank_dynamic_confirmation_gate.json" \
  "output_${REFERENCE_TAG}/gridrank_dynamic_confirmation_records.jsonl" \
  "output_${SEED123_TAG}/gridrank_dynamic_confirmation_gate.json" \
  "output_${SEED123_TAG}/gridrank_dynamic_confirmation_records.jsonl" \
  "output_${SEED2025_TAG}/gridrank_dynamic_confirmation_gate.json" \
  "output_${SEED2025_TAG}/gridrank_dynamic_confirmation_records.jsonl"; do
  test -f "$path" || { echo "missing multiseed result: $path" >&2; exit 2; }
done
test ! -e "$OUT" || { echo "refusing to overwrite aggregate: $OUT" >&2; exit 2; }

python -B aggregate_gridrank_dynamic_multiseed.py \
  --seed_gate "42=output_${REFERENCE_TAG}/gridrank_dynamic_confirmation_gate.json" \
  --seed_gate "123=output_${SEED123_TAG}/gridrank_dynamic_confirmation_gate.json" \
  --seed_gate "2025=output_${SEED2025_TAG}/gridrank_dynamic_confirmation_gate.json" \
  --seed_records "42=output_${REFERENCE_TAG}/gridrank_dynamic_confirmation_records.jsonl" \
  --seed_records "123=output_${SEED123_TAG}/gridrank_dynamic_confirmation_records.jsonl" \
  --seed_records "2025=output_${SEED2025_TAG}/gridrank_dynamic_confirmation_records.jsonl" \
  --fresh_summary "$FRESH_SUMMARY" \
  --factorized_tfidf_audit "$TFIDF_AUDIT" \
  --bootstrap_reps 10000 --bootstrap_seed 20260901 --output "$OUT"

python -B verify_gridrank_dynamic_multiseed.py --aggregate "$OUT"
echo "=== GRIDRANK DYNAMIC THREE-SEED AGGREGATE COMPLETE ==="
