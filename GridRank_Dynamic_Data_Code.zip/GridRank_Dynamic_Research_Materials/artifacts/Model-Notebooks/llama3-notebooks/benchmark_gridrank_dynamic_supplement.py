"""Benchmark gridrank dynamic supplement utilities."""

from __future__ import annotations

import argparse
import gc
import hashlib
import json
import random
import time
from collections import defaultdict
from pathlib import Path
from types import SimpleNamespace

import gridrank_dynamic_supplement as supplement
import preflight_gridrank_dynamic_benchmark as language
import preflight_gridrank_dynamic_supplement as preflight
from gridrank_dynamic_factorized_llm import primitive_scores, selected_axes


SCHEMA = "gridrank-dynamic-supplement-latency-v1"
METHODS = (
    "physics_aligned_factorized_llm_s42",
    "factorized_tfidf_withheld",
    "frozen_rule_parser_lindistflow",
    "fixed_loss_lindistflow",
)


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--preflight_manifest", required=True)
    parser.add_argument("--output", required=True)
    return parser.parse_args()


def percentile(values, probability):
    ordered = sorted(float(value) for value in values)
    if not ordered:
        return None
    position = probability * (len(ordered) - 1)
    low = int(position)
    high = min(low + 1, len(ordered) - 1)
    weight = position - low
    return ordered[low] * (1.0 - weight) + ordered[high] * weight


def latency_summary(values):
    return {
        "n": len(values),
        "mean_ms": sum(values) / len(values) if values else None,
        "p50_ms": percentile(values, 0.50),
        "p95_ms": percentile(values, 0.95),
        "min_ms": min(values) if values else None,
        "max_ms": max(values) if values else None,
    }


def sync_cuda(torch):
    if torch.cuda.is_available():
        torch.cuda.synchronize()


def timed(function, torch=None):
    if torch is not None:
        sync_cuda(torch)
    start = time.perf_counter()
    value = function()
    if torch is not None:
        sync_cuda(torch)
    return value, 1000.0 * (time.perf_counter() - start)


def stratified_rows(rows, count):
    
    unique = {row["instance_id"]: row for row in rows}
    groups = defaultdict(list)
    for row in unique.values():
        groups[(
            str(row["network_id"]),
            str(row["pair_type"]),
            str(row["pair_side"]),
        )].append(row)
    for key in groups:
        groups[key].sort(key=lambda row: hashlib.sha256(
            (
                "gridrank-dynamic-supplement-latency|"
                + row["physical_state_sha256"]
                + "|"
                + row["instance_id"]
            ).encode()
        ).digest())
    keys = sorted(groups)
    offsets = {key: 0 for key in keys}
    selected = []
    while len(selected) < count:
        progress = False
        for key in keys:
            offset = offsets[key]
            if offset < len(groups[key]) and len(selected) < count:
                selected.append(groups[key][offset])
                offsets[key] += 1
                progress = True
        if not progress:
            break
    if len(selected) != count:
        raise RuntimeError(
            f"only {len(selected)} unique stratified rows for requested {count}"
        )
    return selected


def semantics_for_method(method, row, *, model=None, tokenizer=None,
                         parser_model=None, schedule=None, torch=None):
    if method == "physics_aligned_factorized_llm_s42":
        def infer():
            scores = primitive_scores(
                model,
                tokenizer,
                row,
                max_length=schedule["llm_max_length"],
                primitive_batch_size=schedule["primitive_batch_size"],
                require_grad=False,
            )
            return selected_axes(scores)

        axes, milliseconds = timed(infer, torch)
        constrained = bool(axes["hard_constraint"])
        return {
            "objective": axes["objective"],
            "hard_constraint": constrained,
            "forbidden_edges": (
                language.extract_edges(row["instruction_text"])
                if constrained else []
            ),
        }, milliseconds
    if method == "factorized_tfidf_withheld":
        prediction, milliseconds = timed(
            lambda: language.predict_text_parser(parser_model, [row])
        )
        return prediction[row["instance_id"]], milliseconds
    if method == "frozen_rule_parser_lindistflow":
        prediction, milliseconds = timed(
            lambda: language.rule_predictions([row])
        )
        return prediction[row["instance_id"]], milliseconds
    if method == "fixed_loss_lindistflow":
        return {
            "objective": "loss",
            "hard_constraint": False,
            "forbidden_edges": [],
        }, 0.0
    raise KeyError(method)


def live_matches_cache(row, anchor, outcome, action):
    cached = supplement.candidate(row, action)
    checks = {
        "anchor_feedback_valid": bool(anchor["feedback_valid"])
        == bool(row["gate_anchor"]["feedback_valid"]),
        "anchor_feasible": bool(anchor["feasible"])
        == bool(row["gate_anchor"]["feasible"]),
        "candidate_feedback_valid": bool(outcome["feedback_valid"])
        == bool(cached["feedback_valid"]),
        "candidate_feasible": bool(outcome["feasible"])
        == bool(cached["feasible"]),
        "candidate_reason": str(outcome["reason"]) == str(cached["reason"]),
    }
    for source, target in (
        ("loss_kw", "candidate_loss_kw"),
        ("min_vm_pu", "candidate_min_vm_pu"),
        ("max_vm_pu", "candidate_max_vm_pu"),
    ):
        left, right = anchor.get(source), row["gate_anchor"].get(target)
        checks[f"anchor_{source}"] = (
            left is None and right is None
            if left is None or right is None
            else abs(float(left) - float(right)) <= 1e-8
        )
    for source, target in (
        ("loss_kw", "candidate_loss_kw"),
        ("min_vm_pu", "candidate_min_vm_pu"),
        ("max_vm_pu", "candidate_max_vm_pu"),
        ("reduction_pct", "reduction_pct"),
    ):
        left, right = outcome.get(source), cached.get(target)
        if left is None or right is None:
            checks[source] = left is None and right is None
        else:
            checks[source] = abs(float(left) - float(right)) <= 1e-8
    return checks


def summarize_method(rows):
    semantic = [row["semantic_ms"] for row in rows]
    ranking = [row["ranking_ms"] for row in rows]
    safety = [row["safety_gate_ms"] for row in rows]
    total = [row["total_ms"] for row in rows]
    return {
        "rows": len(rows),
        "semantic_latency": latency_summary(semantic),
        "ranking_latency": latency_summary(ranking),
        "ac_noop_gate_latency": latency_summary(safety),
        "end_to_end_latency": latency_summary(total),
        "logical_candidate_queries_per_row": 2.0,
        "anchor_power_flows_per_row": 1.0,
        "candidate_power_flows_per_row": 1.0,
        "backend_power_flows_per_row": 2.0,
        "full_pool_backend_power_flows_per_row": 33.0,
        "full_pool_ac_call_reduction": 1.0 - 2.0 / 33.0,
        "live_cache_match_rate": supplement.mean(
            float(all(row["cache_checks"].values())) for row in rows
        ),
    }


def main():
    import torch
    import grpo_train as training
    import gridrank_dynamic_cross_topology as grid

    args = parse_args()
    output = Path(args.output)
    if output.exists():
        raise FileExistsError(f"refusing to overwrite latency result: {output}")
    locked = preflight.verify_manifest(args.preflight_manifest)
    schedule = locked["schedule"]
    if not torch.cuda.is_available():
        raise RuntimeError("dynamic supplement latency benchmark requires CUDA")
    random.seed(schedule["latency_seed"])
    torch.manual_seed(schedule["latency_seed"])
    torch.cuda.manual_seed_all(schedule["latency_seed"])

    pairs = supplement.read_jsonl(locked["artifacts"]["pairs"]["path"])
    original_train = supplement.read_jsonl(
        locked["artifacts"]["original_train"]["path"]
    )
    selected = stratified_rows(pairs, schedule["benchmark_rows"])
    withheld = [
        row for row in original_train if row["pair_type"] != supplement.PRIMARY
    ]
    parser_model, parser_fit_ms = timed(
        lambda: language.fit_text_parser(withheld, 20260926)
    )

    model_args = SimpleNamespace(
        base_model=locked["base_model"]["path"],
        resume_adapter_path=locked["llm_adapter"]["path"],
        output_dir=str(output.parent),
        gradient_checkpointing=0,
    )
    torch.cuda.empty_cache()
    torch.cuda.reset_peak_memory_stats()
    (model, tokenizer), cold_load_ms = timed(
        lambda: training.build_model_and_tokenizer(model_args), torch
    )
    for parameter in model.parameters():
        parameter.requires_grad_(False)
    model.eval()
    model.config.use_cache = False
    gc.collect()
    torch.cuda.empty_cache()
    sync_cuda(torch)
    resident_allocated = int(torch.cuda.memory_allocated())
    resident_reserved = int(torch.cuda.memory_reserved())

    
    for row in selected[: schedule["warmup_rows"]]:
        semantics_for_method(
            METHODS[0], row, model=model, tokenizer=tokenizer,
            schedule=schedule, torch=torch,
        )
        ranking = supplement.masked_proxy_order(
            row, "loss", [],
        )
        grid.score_state(
            row["simbench_code"], supplement.state_index(row),
            schedule["scenario_seed"], [ranking[0]],
        )

    result_rows = []
    peak_allocated, peak_reserved = resident_allocated, resident_reserved
    for method in METHODS:
        for row in selected:
            if method == METHODS[0]:
                torch.cuda.reset_peak_memory_stats()
            semantic, semantic_ms = semantics_for_method(
                method,
                row,
                model=model,
                tokenizer=tokenizer,
                parser_model=parser_model,
                schedule=schedule,
                torch=torch,
            )
            ranking, ranking_ms = timed(lambda: supplement.masked_proxy_order(
                row,
                semantic["objective"],
                semantic["forbidden_edges"],
            ))
            action = ranking[0]
            (anchor, outcomes), safety_ms = timed(lambda: grid.score_state(
                row["simbench_code"],
                supplement.state_index(row),
                schedule["scenario_seed"],
                [action],
            ))
            if len(outcomes) != 1:
                raise RuntimeError(f"live candidate replay incomplete: {row['instance_id']}")
            checks = live_matches_cache(row, anchor, outcomes[0], action)
            if method == METHODS[0]:
                peak_allocated = max(
                    peak_allocated, int(torch.cuda.max_memory_allocated())
                )
                peak_reserved = max(
                    peak_reserved, int(torch.cuda.max_memory_reserved())
                )
            result_rows.append({
                "method": method,
                "instance_id": row["instance_id"],
                "network": str(row["network_id"]),
                "regime": supplement.operating_regime(row),
                "semantic_ms": semantic_ms,
                "ranking_ms": ranking_ms,
                "safety_gate_ms": safety_ms,
                "total_ms": semantic_ms + ranking_ms + safety_ms,
                "selected_action": action,
                "cache_checks": checks,
            })

    summaries = {
        method: summarize_method([
            row for row in result_rows if row["method"] == method
        ])
        for method in METHODS
    }
    for method, value in summaries.items():
        value["gpu_required"] = method == METHODS[0]
    checks = {
        "evaluation_only": True,
        "benchmark_rows_exact": len(selected) == schedule["benchmark_rows"],
        "four_methods": set(summaries) == set(METHODS),
        "live_cache_match_exact": all(
            all(row["cache_checks"].values()) for row in result_rows
        ),
        "two_live_power_flows_per_method_row": True,
        "p95_not_below_p50": all(
            value["end_to_end_latency"]["p95_ms"]
            >= value["end_to_end_latency"]["p50_ms"]
            for value in summaries.values()
        ),
    }
    result = {
        "msg": "GridRank dynamic live efficiency benchmark",
        "schema": SCHEMA,
        "experiment_id": preflight.EXPERIMENT_ID,
        "preflight_sha256": supplement.file_sha256(args.preflight_manifest),
        "evaluation_only": True,
        "training_performed": True,
        "training_scope": "train-only TF-IDF reconstruction for timing",
        "frozen_model_training_performed": False,
        "baseline_tfidf_fit_performed": True,
        "sealed_test_rows_used_for_fit": False,
        "benchmark_rows": len(selected),
        "benchmark_mix": {
            "network": {
                value: sum(str(row["network_id"]) == value for row in selected)
                for value in sorted({str(row["network_id"]) for row in selected})
            },
            "pair_type": {
                value: sum(str(row["pair_type"]) == value for row in selected)
                for value in sorted({str(row["pair_type"]) for row in selected})
            },
            "pair_side": {
                value: sum(str(row["pair_side"]) == value for row in selected)
                for value in sorted({str(row["pair_side"]) for row in selected})
            },
            "operating_regime": {
                value: sum(
                    supplement.operating_regime(row) == value for row in selected
                )
                for value in supplement.REGIMES
            },
        },
        "warmup_rows": schedule["warmup_rows"],
        "cold_start_excluded_from_steady_state": True,
        "model_cold_load_ms": cold_load_ms,
        "tfidf_train_only_fit_ms": parser_fit_ms,
        "gpu_memory": {
            "device": torch.cuda.get_device_name(0),
            "resident_allocated_bytes": resident_allocated,
            "resident_reserved_bytes": resident_reserved,
            "peak_allocated_bytes": peak_allocated,
            "peak_reserved_bytes": peak_reserved,
            "peak_incremental_allocated_bytes": max(
                0, peak_allocated - resident_allocated
            ),
            "peak_incremental_reserved_bytes": max(
                0, peak_reserved - resident_reserved
            ),
        },
        "method_summaries": summaries,
        "power_flow_calls": {
            "measurement": {
                "anchor_power_flows": len(result_rows),
                "candidate_power_flows": len(result_rows),
                "backend_power_flows": 2 * len(result_rows),
            },
            "warmup": {
                "anchor_power_flows": schedule["warmup_rows"],
                "candidate_power_flows": schedule["warmup_rows"],
                "backend_power_flows": 2 * schedule["warmup_rows"],
            },
            "run_total_backend_power_flows": (
                2 * len(result_rows) + 2 * schedule["warmup_rows"]
            ),
        },
        "rows": result_rows,
        "checks": checks,
        "benchmark_pass": all(checks.values()),
        "failed_checks": [
            key for key, value in checks.items() if not value
        ],
    }
    output.write_text(
        json.dumps(result, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    print(json.dumps({
        "msg": result["msg"],
        "benchmark_pass": result["benchmark_pass"],
        "model_cold_load_ms": result["model_cold_load_ms"],
        "gpu_memory": result["gpu_memory"],
        "method_summaries": result["method_summaries"],
        "power_flow_calls": result["power_flow_calls"],
        "failed_checks": result["failed_checks"],
    }, ensure_ascii=False))
    if not result["benchmark_pass"]:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
