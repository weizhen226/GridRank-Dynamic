"""Make gridrank confirm state view utilities."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path

from build_gridrank_feedback import canonical_state_text
from make_no_oracle_state_view import FORBIDDEN, KEEP, _source_rows


SCHEMA = "gridrank-confirm-state-role-v1"
SOURCE_SPLIT = "test"
EMITTED_ROLE_SPLIT = "validation"


def file_sha256(path):
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def build_view(input_path, output_jsonl, manifest_json):
    source = Path(input_path).resolve()
    output = Path(output_jsonl).resolve()
    manifest = Path(manifest_json).resolve()
    if not source.is_file() or source == output:
        raise ValueError("confirmation source must exist and differ from output")
    if output.exists() or manifest.exists():
        raise FileExistsError("refusing to overwrite confirmation view artifacts")

    rows = []
    raw_ids = set()
    for row in _source_rows(source):
        if str(row.get("split")) != SOURCE_SPLIT:
            continue
        instance_id = str(row.get("instance_id", ""))
        if not instance_id or instance_id in raw_ids:
            raise ValueError("raw test instance_id must be nonempty and unique")
        raw_ids.add(instance_id)
        rows.append({
            "instance_id": instance_id,
            "load_id": str(row.get("load_id", "")),
            "prompt": canonical_state_text(str(row.get("prompt", ""))),
            "split": EMITTED_ROLE_SPLIT,
        })
    if not rows or any(not row["load_id"] or not row["prompt"] for row in rows):
        raise ValueError("raw test source yielded no complete confirmation states")

    output.parent.mkdir(parents=True, exist_ok=True)
    tmp = output.with_name(output.name + ".tmp")
    with open(tmp, "w", encoding="utf-8", newline="\n") as handle:
        for row in rows:
            handle.write(json.dumps(row, ensure_ascii=False, separators=(",", ":")) + "\n")
    os.replace(tmp, output)

    emitted = [json.loads(line) for line in open(output, encoding="utf-8") if line.strip()]
    schemas = {frozenset(row) for row in emitted}
    if schemas != {frozenset(KEEP)}:
        raise RuntimeError(f"confirmation state-role schema drift: {schemas}")
    if any(FORBIDDEN.intersection(row) for row in emitted):
        raise RuntimeError("oracle field leaked into confirmation state-role view")
    if any(row["split"] != EMITTED_ROLE_SPLIT for row in emitted):
        raise RuntimeError("confirmation role split mapping failed")

    result = {
        "msg": "GridRank confirmation raw-test to heldout-role state view",
        "schema": SCHEMA,
        "source_path": str(source),
        "source_sha256": file_sha256(source),
        "source_selected_split": SOURCE_SPLIT,
        "emitted_role_split": EMITTED_ROLE_SPLIT,
        "output_path": str(output),
        "output_sha256": file_sha256(output),
        "columns": list(KEEP),
        "forbidden_columns_absent": sorted(FORBIDDEN),
        "prompt_canonicalized": True,
        "source_text_forwarded": False,
        "rows": len(emitted),
        "instance_ids_sha256": hashlib.sha256(
            "\n".join(row["instance_id"] for row in emitted).encode("utf-8")
        ).hexdigest(),
    }
    manifest.parent.mkdir(parents=True, exist_ok=True)
    tmp_manifest = manifest.with_name(manifest.name + ".tmp")
    tmp_manifest.write_text(
        json.dumps(result, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    os.replace(tmp_manifest, manifest)
    return result


def verify_view(input_path, output_jsonl, manifest_json):
    source = Path(input_path).resolve()
    output = Path(output_jsonl).resolve()
    manifest_path = Path(manifest_json).resolve()
    manifest = json.load(open(manifest_path, encoding="utf-8"))
    checks = {
        "schema": manifest.get("schema") == SCHEMA,
        "source_path": manifest.get("source_path") == str(source),
        "source_hash": manifest.get("source_sha256") == file_sha256(source),
        "source_split": manifest.get("source_selected_split") == SOURCE_SPLIT,
        "emitted_role": manifest.get("emitted_role_split") == EMITTED_ROLE_SPLIT,
        "output_path": manifest.get("output_path") == str(output),
        "output_hash": manifest.get("output_sha256") == file_sha256(output),
        "strict_columns": manifest.get("columns") == list(KEEP),
        "no_source_text": manifest.get("source_text_forwarded") is False,
    }
    emitted = [json.loads(line) for line in open(output, encoding="utf-8") if line.strip()]
    checks.update({
        "row_count": manifest.get("rows") == len(emitted) and len(emitted) > 0,
        "strict_emitted_schema": all(set(row) == set(KEEP) for row in emitted),
        "role_split_only": all(row.get("split") == EMITTED_ROLE_SPLIT for row in emitted),
        "forbidden_absent": all(not FORBIDDEN.intersection(row) for row in emitted),
    })
    result = {
        "msg": "GridRank confirmation state-role view verification",
        "checks": checks,
        "verification_pass": all(checks.values()),
    }
    if not result["verification_pass"]:
        raise RuntimeError(f"confirmation view verification failed: {checks}")
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", choices=("build", "verify"), required=True)
    parser.add_argument("--input", required=True)
    parser.add_argument("--output_jsonl", required=True)
    parser.add_argument("--manifest_json", required=True)
    args = parser.parse_args()
    function = build_view if args.mode == "build" else verify_view
    print(json.dumps(function(
        args.input, args.output_jsonl, args.manifest_json
    ), ensure_ascii=False))


if __name__ == "__main__":
    main()
