"""Check inputs for GridRank select confirm."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import preflight_gridrank_feedback as runtime
from build_gridrank_select import file_sha256
from gridrank_runtime_compat import runtime_compatibility
from make_gridrank_confirm_state_view import SCHEMA as VIEW_SCHEMA


HERE = Path(__file__).resolve().parent
SCHEMA = "gridrank-select-confirm-preflight-v1"
CONFIRMATION_ID = "gridrank-select-locked-test-confirm-v1"
SEEDS = (42, 123, 2025)
EXPECTED_ROWS_PER_NETWORK = 32
CONFIRM_CODE_FILES = (
    "gridrank_runtime_compat.py",
    "make_gridrank_confirm_state_view.py",
    "preflight_gridrank_select_confirm.py",
    "train_gridrank_select_confirm.py",
    "aggregate_gridrank_select_confirm.py",
    "verify_gridrank_select_confirm.py",
    "run_gridrank_select_confirm.sh",
    "../../docs/GRIDRANK_SELECT_CONFIRM_PROTOCOL.md",
)


def _json(path):
    with open(path, encoding="utf-8") as handle:
        return json.load(handle)


def _rows(path):
    return [json.loads(line) for line in open(path, encoding="utf-8") if line.strip()]


def _specs(values, label):
    output = {}
    for value in values:
        if "=" not in value:
            raise ValueError(f"{label} must use NETWORK=PATH")
        network, raw_path = value.split("=", 1)
        if network in output:
            raise ValueError(f"duplicate {label} network: {network}")
        path = Path(raw_path).resolve()
        if not path.is_file():
            raise FileNotFoundError(f"missing {label}: {path}")
        output[network] = path
    if set(output) != {"33", "69"}:
        raise ValueError(f"{label} requires networks 33 and 69")
    return output


def _adapter_hash(path):
    root = Path(path)
    return {
        "adapter_config_json": file_sha256(root / "adapter_config.json"),
        "adapter_model_safetensors": file_sha256(root / "adapter_model.safetensors"),
    }


def _current_code_hashes(locked):
    hashes = {}
    for name in locked:
        path = HERE / name
        if not path.is_file():
            raise FileNotFoundError(f"missing locked confirmation code: {name}")
        hashes[name] = file_sha256(path)
    return hashes


def _view_origin(raw_paths, view_paths, manifest_paths, upstream_summary):
    records = {}
    checks = {}
    validation_sources = upstream_summary.get("sources", {}).get("validation", {})
    for network in ("33", "69"):
        record = _json(manifest_paths[network])
        raw = raw_paths[network]
        view = view_paths[network]
        network_checks = {
            "view_schema": record.get("schema") == VIEW_SCHEMA,
            "raw_path": record.get("source_path") == str(raw),
            "raw_hash": record.get("source_sha256") == file_sha256(raw),
            "raw_split_test": record.get("source_selected_split") == "test",
            "role_split_validation": record.get("emitted_role_split") == "validation",
            "view_path": record.get("output_path") == str(view),
            "view_hash": record.get("output_sha256") == file_sha256(view),
            "summary_binds_view": validation_sources.get(network, {}).get("sha256")
                == file_sha256(view),
            "no_source_text": record.get("source_text_forwarded") is False,
        }
        records[network] = {
            "raw_test": {"path": str(raw), "sha256": file_sha256(raw)},
            "role_view": {"path": str(view), "sha256": file_sha256(view)},
            "view_manifest": {
                "path": str(manifest_paths[network]),
                "sha256": file_sha256(manifest_paths[network]),
            },
            "checks": network_checks,
        }
        checks[f"test_origin_{network}"] = all(network_checks.values())
    return records, checks


def _pilot_locks(pilot_gate_path, recheck_gate_path):
    pilot = _json(pilot_gate_path)
    recheck = _json(recheck_gate_path)
    checks = {
        "raw_gate_preserved": pilot.get("engineering_gate_pass") is False,
        "recheck_passed": recheck.get("recheck_gate_pass") is True,
        "recheck_not_training": recheck.get("training_performed") is False,
        "recheck_not_paper_claim": recheck.get("paper_claim_authorized") is False,
    }
    return {
        "raw_gate": {"path": str(Path(pilot_gate_path).resolve()),
                     "sha256": file_sha256(pilot_gate_path)},
        "recheck_gate": {"path": str(Path(recheck_gate_path).resolve()),
                         "sha256": file_sha256(recheck_gate_path)},
        "checks": checks,
    }, checks


def _split_audit(train_jsonl, test_jsonl, pilot_test_jsonl):
    train = _rows(train_jsonl)
    test = _rows(test_jsonl)
    pilot = _rows(pilot_test_jsonl)
    train_states = {row["physical_state_sha256"] for row in train}
    test_states = {row["physical_state_sha256"] for row in test}
    pilot_states = {row["physical_state_sha256"] for row in pilot}
    train_loads = {row["load_id"] for row in train}
    test_loads = {row["load_id"] for row in test}
    by_network = {
        partition: {
            network: sum(str(row["network_id"]) == network for row in rows)
            for network in ("33", "69")
        }
        for partition, rows in (("train", train), ("test", test))
    }
    checks = {
        "train_rows_locked": len(train) == 2 * EXPECTED_ROWS_PER_NETWORK,
        "test_rows_locked": len(test) == 2 * EXPECTED_ROWS_PER_NETWORK,
        "balanced_networks": all(
            by_network[partition][network] == EXPECTED_ROWS_PER_NETWORK
            for partition in ("train", "test") for network in ("33", "69")
        ),
        "train_test_state_disjoint": not train_states.intersection(test_states),
        "train_test_load_disjoint": not train_loads.intersection(test_loads),
        "confirmation_test_disjoint_from_pilot": not test_states.intersection(pilot_states),
        "one_state_per_row": len(train_states) == len(train) and len(test_states) == len(test),
    }
    return {
        "train_rows": len(train),
        "test_rows": len(test),
        "pilot_test_states": len(pilot_states),
        "network_rows": by_network,
        "train_state_sha256s": sorted(train_states),
        "test_state_sha256s": sorted(test_states),
        "pilot_test_state_sha256s": sorted(pilot_states),
        "checks": checks,
    }, checks


def create(args):
    output = Path(args.output)
    if output.exists():
        raise FileExistsError(f"refusing to overwrite confirmation manifest: {output}")
    if args.seed not in SEEDS:
        raise ValueError(f"confirmation seed must be one of {SEEDS}")
    base = _json(args.base_preflight)
    if base.get("schema") != "gridrank-select-preflight-v1" or base.get("preflight_pass") is not True:
        raise ValueError("base GridRank-Select preflight did not pass")
    if base.get("training_schedule", {}).get("seed") != 42:
        raise ValueError("base preflight must use the frozen seed-42 schedule")

    upstream_summary = _json(args.upstream_summary)
    raw_paths = _specs(args.test_raw, "test_raw")
    view_paths = _specs(args.test_view, "test_view")
    view_manifests = _specs(args.test_view_manifest, "test_view_manifest")
    origin, origin_checks = _view_origin(
        raw_paths, view_paths, view_manifests, upstream_summary
    )
    pilot_locks, pilot_checks = _pilot_locks(args.pilot_gate, args.pilot_recheck_gate)
    split_audit, split_checks = _split_audit(
        args.train_jsonl, args.test_jsonl, args.pilot_test_jsonl
    )

    current_training = runtime.training_runtime()
    current_physics = runtime.physics_runtime(args.physics_python)
    training_compat = runtime_compatibility(base.get("training_runtime"), current_training)
    physics_compat = runtime_compatibility(base.get("physics_runtime"), current_physics)
    schedule = dict(base["training_schedule"])
    schedule["seed"] = args.seed
    if schedule.get("epochs") != 4 or schedule.get("topk") != 3:
        raise ValueError("confirmation must retain epochs=4 and Top-3")
    if schedule.get("bootstrap_reps") != args.bootstrap_reps:
        raise ValueError("bootstrap schedule mismatch")

    code_hash = dict(base.get("code_sha256", {}))
    missing_confirm_code = [name for name in CONFIRM_CODE_FILES if not (HERE / name).is_file()]
    if missing_confirm_code:
        raise FileNotFoundError(f"missing confirmation code: {missing_confirm_code}")
    code_hash.update({name: file_sha256(HERE / name) for name in CONFIRM_CODE_FILES})

    base_artifact_hash = base.get("artifact_sha256", {})
    expected_artifacts = {
        "train": file_sha256(args.train_jsonl),
        "test": file_sha256(args.test_jsonl),
        "summary": file_sha256(args.data_summary),
        "audit": file_sha256(args.data_audit),
    }
    checks = {
        "base_preflight_pass": True,
        "base_artifacts_current": base_artifact_hash == expected_artifacts,
        "base_model_inventory_current": {
            name: int(record["bytes"])
            for name, record in base.get("base_model_manifest", {}).items()
        } == runtime.model_inventory(args.base_model),
        "sft_adapter_current": base.get("resume_adapter_sha256")
            == _adapter_hash(args.resume_adapter_path),
        "training_runtime_compatible": training_compat["compatible"],
        "physics_runtime_compatible": physics_compat["compatible"],
        "upstream_summary_current": base.get("upstream_sha256", {}).get("summary")
            == file_sha256(args.upstream_summary),
        "seed_preregistered": args.seed in SEEDS,
        "fixed_method_schedule": schedule.get("epochs") == 4
            and schedule.get("topk") == 3
            and math.isclose(float(schedule.get("learning_rate")), 2e-6),
        **origin_checks,
        **{f"pilot_{key}": value for key, value in pilot_checks.items()},
        **{f"split_{key}": value for key, value in split_checks.items()},
    }
    result = dict(base)
    result.update({
        "msg": "GridRank-Select locked-test three-seed confirmation preflight",
        "schema": SCHEMA,
        "base_preflight": {
            "path": str(Path(args.base_preflight).resolve()),
            "sha256": file_sha256(args.base_preflight),
        },
        "confirmation": {
            "confirmation_id": CONFIRMATION_ID,
            "preregistered_seeds": list(SEEDS),
            "seed": args.seed,
            "test_origin": origin,
            "pilot_locks": pilot_locks,
            "split_audit": split_audit,
            "method_frozen": True,
            "test_used_for_tuning": False,
            "primary_metric": "safe_regret_improvement_distilled_vs_sft",
            "deployment_budget": "Top-3 exchanges plus one no-op anchor",
        },
        "training_schedule": schedule,
        "training_runtime": current_training,
        "physics_runtime": current_physics,
        "runtime_compatibility_to_base": {
            "training": training_compat,
            "physics": physics_compat,
        },
        "code_sha256": code_hash,
        "checks": checks,
        "preflight_pass": all(checks.values()),
    })
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(result, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps(result, ensure_ascii=False))
    if not result["preflight_pass"]:
        raise SystemExit(2)


def verify(args):
    manifest = _json(args.output)
    current_training = runtime.training_runtime()
    current_physics = runtime.physics_runtime(args.physics_python)
    training_compat = runtime_compatibility(manifest.get("training_runtime"), current_training)
    physics_compat = runtime_compatibility(manifest.get("physics_runtime"), current_physics)
    locked_code = manifest.get("code_sha256", {})
    checks = {
        "schema": manifest.get("schema") == SCHEMA,
        "preflight_pass": manifest.get("preflight_pass") is True,
        "confirmation_id": manifest.get("confirmation", {}).get("confirmation_id")
            == CONFIRMATION_ID,
        "seed": manifest.get("training_schedule", {}).get("seed") == args.seed
            and args.seed in SEEDS,
        "training_runtime_compatible": training_compat["compatible"],
        "physics_runtime_compatible": physics_compat["compatible"],
        "base_model_inventory": {
            name: int(record["bytes"])
            for name, record in manifest.get("base_model_manifest", {}).items()
        } == runtime.model_inventory(args.base_model),
        "code_hashes": bool(locked_code) and locked_code == _current_code_hashes(locked_code),
        "bootstrap_reps": manifest.get("training_schedule", {}).get("bootstrap_reps")
            == args.bootstrap_reps,
    }
    result = {
        "msg": "GridRank-Select confirmation runtime verification",
        "checks": checks,
        "runtime_compatibility": {"training": training_compat, "physics": physics_compat},
        "verification_pass": all(checks.values()),
    }
    print(json.dumps(result, ensure_ascii=False))
    if not result["verification_pass"]:
        raise SystemExit(2)


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", choices=("create", "verify"), required=True)
    parser.add_argument("--base_preflight")
    parser.add_argument("--upstream_summary")
    parser.add_argument("--train_jsonl")
    parser.add_argument("--test_jsonl")
    parser.add_argument("--data_summary")
    parser.add_argument("--data_audit")
    parser.add_argument("--pilot_test_jsonl")
    parser.add_argument("--pilot_gate")
    parser.add_argument("--pilot_recheck_gate")
    parser.add_argument("--test_raw", action="append", default=[])
    parser.add_argument("--test_view", action="append", default=[])
    parser.add_argument("--test_view_manifest", action="append", default=[])
    parser.add_argument("--resume_adapter_path")
    parser.add_argument("--base_model", required=True)
    parser.add_argument("--physics_python", required=True)
    parser.add_argument("--bootstrap_reps", type=int, required=True)
    parser.add_argument("--seed", type=int, required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    if args.mode == "create":
        required = (
            "base_preflight", "upstream_summary", "train_jsonl", "test_jsonl",
            "data_summary", "data_audit", "pilot_test_jsonl", "pilot_gate",
            "pilot_recheck_gate", "resume_adapter_path",
        )
        missing = [name for name in required if not getattr(args, name)]
        if missing or len(args.test_raw) != 2 or len(args.test_view) != 2 \
                or len(args.test_view_manifest) != 2:
            raise ValueError(f"missing confirmation create inputs: {missing}")
    if args.seed not in SEEDS or args.bootstrap_reps <= 0:
        raise ValueError("invalid confirmation seed/bootstrap schedule")
    return args


def main():
    args = parse_args()
    (create if args.mode == "create" else verify)(args)


if __name__ == "__main__":
    main()
