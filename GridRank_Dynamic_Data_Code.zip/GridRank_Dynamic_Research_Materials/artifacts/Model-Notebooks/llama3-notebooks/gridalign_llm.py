"""Gridalign llm utilities."""

import hashlib
from functools import lru_cache
from pathlib import Path


PHYSICS_TEXT_SCHEMA = (
    "candidate_type, normalized close/open endpoints and impedances, candidate-tree "
    "depth, downstream-load concentration, LinDistFlow voltage-drop proxy, normalized "
    "resistive-loss proxy and its delta from no-op, close/open endpoint local and "
    "downstream loads"
)
PHYSICS_TEXT_SCHEMA_SHA256 = hashlib.sha256(
    PHYSICS_TEXT_SCHEMA.encode("utf-8")
).hexdigest()


def format_candidate_prompt(state_prompt, action, physics_text=None):
    feature_block = (
        f"\nDeterministic candidate-local physical features (no power-flow result):\n{physics_text}\n"
        if physics_text else "\n"
    )
    return (
        "<|user|>\n"
        f"{state_prompt}\n\n"
        "Candidate switching action under evaluation:\n"
        f"{action}\n"
        f"{feature_block}\n"
        "Evaluate this candidate for the stated operating objective and physical constraints."
        "</s>\n<|assistant|>\nCandidate score:"
    )


def _mean(values):
    return sum(values) / len(values) if values else 0.0


@lru_cache(maxsize=8192)
def _candidate_physics_summary(state_prompt, action):
    
    from physics_graph_policy import graph_for_action

    graph = graph_for_action(state_prompt, action)
    nodes = graph["node_features"]
    edge_index = graph["edge_index"]
    edge_features = graph["edge_features"]
    action_features = graph["action_features"]

    proxy_loss = 0.0
    for offset in range(0, len(edge_index), 2):
        a, b = edge_index[offset]
        child = a if nodes[a][4] > nodes[b][4] else b
        downstream_p, downstream_q = nodes[child][2], nodes[child][3]
        resistance = abs(float(edge_features[offset][0]))
        proxy_loss += resistance * (downstream_p ** 2 + downstream_q ** 2)

    close_nodes = [features for features in nodes if features[7] > 0.5]
    open_nodes = [features for features in nodes if features[8] > 0.5]
    return {
        "candidate_type": "noop" if action == "Action: none" else "exchange",
        "close_u": action_features[0], "close_v": action_features[1],
        "close_span": action_features[2],
        "open_u": action_features[3], "open_v": action_features[4],
        "open_span": action_features[5],
        "close_r": action_features[6], "close_x": action_features[7],
        "open_r": action_features[8], "open_x": action_features[9],
        "tree_depth_max": max(features[4] for features in nodes),
        "downstream_p_max": max(features[2] for features in nodes),
        "downstream_q_max": max(features[3] for features in nodes),
        "voltage_drop_proxy_max": max(features[5] for features in nodes),
        "loss_proxy": proxy_loss,
        "close_local_p_mean": _mean([features[0] for features in close_nodes]),
        "close_downstream_p_mean": _mean([features[2] for features in close_nodes]),
        "close_drop_mean": _mean([features[5] for features in close_nodes]),
        "open_local_p_mean": _mean([features[0] for features in open_nodes]),
        "open_downstream_p_mean": _mean([features[2] for features in open_nodes]),
        "open_drop_mean": _mean([features[5] for features in open_nodes]),
    }


def candidate_physics_texts(state_prompt, actions):
    baseline = _candidate_physics_summary(state_prompt, "Action: none")
    baseline_loss = max(abs(float(baseline["loss_proxy"])), 1e-8)
    texts = []
    for action in actions:
        summary = _candidate_physics_summary(state_prompt, action)
        loss_delta_pct = 100.0 * (
            baseline["loss_proxy"] - summary["loss_proxy"]
        ) / baseline_loss
        ordered = [
            ("type", summary["candidate_type"]),
            ("close_uv", f'{summary["close_u"]:.4f},{summary["close_v"]:.4f}'),
            ("open_uv", f'{summary["open_u"]:.4f},{summary["open_v"]:.4f}'),
            ("close_span", f'{summary["close_span"]:.4f}'),
            ("open_span", f'{summary["open_span"]:.4f}'),
            ("close_rx", f'{summary["close_r"]:.4f},{summary["close_x"]:.4f}'),
            ("open_rx", f'{summary["open_r"]:.4f},{summary["open_x"]:.4f}'),
            ("tree_depth_max", f'{summary["tree_depth_max"]:.4f}'),
            ("downstream_pq_max", f'{summary["downstream_p_max"]:.4f},{summary["downstream_q_max"]:.4f}'),
            ("voltage_drop_proxy_max", f'{summary["voltage_drop_proxy_max"]:.6f}'),
            ("loss_proxy", f'{summary["loss_proxy"]:.6f}'),
            ("loss_proxy_delta_pct", f'{loss_delta_pct:.4f}'),
            ("close_endpoint_local_p", f'{summary["close_local_p_mean"]:.4f}'),
            ("close_endpoint_downstream_p", f'{summary["close_downstream_p_mean"]:.4f}'),
            ("close_endpoint_drop", f'{summary["close_drop_mean"]:.6f}'),
            ("open_endpoint_local_p", f'{summary["open_local_p_mean"]:.4f}'),
            ("open_endpoint_downstream_p", f'{summary["open_downstream_p_mean"]:.4f}'),
            ("open_endpoint_drop", f'{summary["open_drop_mean"]:.6f}'),
        ]
        texts.append("; ".join(f"{key}={value}" for key, value in ordered))
    return texts


def candidate_physics_proxy_scores(state_prompt, actions):
    
    baseline = _candidate_physics_summary(state_prompt, "Action: none")
    baseline_loss = max(abs(float(baseline["loss_proxy"])), 1e-8)
    return [
        (baseline["loss_proxy"] - _candidate_physics_summary(
            state_prompt, action
        )["loss_proxy"]) / baseline_loss
        for action in actions
    ]


def candidate_hidden_states(
    model,
    tokenizer,
    state_prompt,
    actions,
    max_length,
    candidate_batch_size=2,
    candidate_feature_mode="none",
):
    
    import torch

    if not actions:
        raise ValueError("GridAlign requires at least one candidate")
    if candidate_batch_size <= 0:
        raise ValueError("candidate_batch_size must be positive")
    if candidate_feature_mode not in {"none", "physics_text"}:
        raise ValueError(f"unknown candidate_feature_mode: {candidate_feature_mode}")
    device = next(model.parameters()).device
    causal_lm = model.get_base_model()
    backbone = getattr(causal_lm, "model", None)
    if backbone is None:
        raise RuntimeError(f"unsupported causal LM backbone: {type(causal_lm).__name__}")

    previous_truncation = tokenizer.truncation_side
    previous_padding = tokenizer.padding_side
    tokenizer.truncation_side = "left"  
    tokenizer.padding_side = "right"
    feature_texts = (
        candidate_physics_texts(state_prompt, tuple(actions))
        if candidate_feature_mode == "physics_text" else [None] * len(actions)
    )
    outputs = []
    try:
        for offset in range(0, len(actions), candidate_batch_size):
            action_chunk = actions[offset: offset + candidate_batch_size]
            feature_chunk = feature_texts[offset: offset + candidate_batch_size]
            texts = [
                format_candidate_prompt(state_prompt, action, feature_text)
                for action, feature_text in zip(action_chunk, feature_chunk)
            ]
            encoded = tokenizer(
                texts,
                return_tensors="pt",
                padding=True,
                truncation=True,
                max_length=max_length,
            )
            encoded = {key: value.to(device) for key, value in encoded.items()}
            result = backbone(**encoded, use_cache=False, return_dict=True)
            hidden = result.last_hidden_state
            last_index = encoded["attention_mask"].sum(dim=1).long() - 1
            rows = torch.arange(hidden.shape[0], device=hidden.device)
            outputs.append(hidden[rows, last_index])
    finally:
        tokenizer.truncation_side = previous_truncation
        tokenizer.padding_side = previous_padding
    return torch.cat(outputs, dim=0)


def build_score_head(hidden_size):
    import torch

    class CandidateScoreHead(torch.nn.Module):
        def __init__(self):
            super().__init__()
            self.norm = torch.nn.LayerNorm(hidden_size)
            self.score = torch.nn.Linear(hidden_size, 1)

        def forward(self, hidden):
            hidden = hidden.to(dtype=self.norm.weight.dtype)
            return self.score(self.norm(hidden)).squeeze(-1)

    return CandidateScoreHead()


def save_score_head(head, output_dir, metadata):
    import json
    import torch

    output = Path(output_dir)
    output.mkdir(parents=True, exist_ok=True)
    torch.save(head.state_dict(), output / "gridalign_score_head.pt")
    with open(output / "gridalign_config.json", "w", encoding="utf-8") as handle:
        json.dump(metadata, handle, indent=2, ensure_ascii=False)


def load_score_head(output_dir, hidden_size, device):
    import json
    import torch

    output = Path(output_dir)
    with open(output / "gridalign_config.json", encoding="utf-8") as handle:
        config = json.load(handle)
    if int(config["hidden_size"]) != int(hidden_size):
        raise ValueError("GridAlign hidden-size mismatch")
    head = build_score_head(hidden_size).to(device)
    head.load_state_dict(torch.load(
        output / "gridalign_score_head.pt", map_location=device, weights_only=True
    ))
    return head, config

