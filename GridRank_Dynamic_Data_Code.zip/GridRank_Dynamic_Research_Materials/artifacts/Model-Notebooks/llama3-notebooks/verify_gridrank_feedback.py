"""Validate GridRank feedback."""

from __future__ import annotations

import argparse
import json
import tempfile
from pathlib import Path
from types import SimpleNamespace

from build_gridrank_feedback import (
    NOOP,
    base_state,
    canonical_state_text,
    directive_rows,
    label_candidates,
    physical_state_sha256,
    read_state_only,
)
from gridrank_llm import candidate_question, reordered_row
from audit_gridrank_feedback import group_audit
import train_gridrank_feedback as trainer
from train_gridrank_feedback import live_gate_replay, online_query_indices, record_from_scores


HERE = Path(__file__).resolve().parent
GOLDEN = {
    "33": {
        "state": "c045884273d08b8a6b17f80bf9a66a1360fb22a8d3fe8560eb72d124eff8632c",
        "pool": "92cf994dae74b909ea13050c8d6e8e78f69020a898c991deff96c3728cf9aba5",
    },
    "69": {
        "state": "a67d5bd63bac9e1b06103368650919bf6f6298e5890786b02c567833e7b10c09",
        "pool": "4800b418793bae279db0e41712b44ca4614518f3cfd0289a0a8e93ec005d2011",
    },
}


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def _candidate(action, reduction, minimum, feasible=True):
    return {
        "action": action,
        "candidate_feature_text": "type=noop" if action == NOOP else "type=exchange",
        "feedback_revealed": True,
        "feedback_valid": True,
        "feasible": feasible,
        "reason": "ok" if feasible else "infeasible",
        "reduction_pct": reduction,
        "anchor_loss_kw": 100.0,
        "candidate_loss_kw": 100.0 * (1.0 - reduction / 100.0),
        "anchor_min_vm_pu": 0.94,
        "candidate_min_vm_pu": minimum,
        "candidate_max_vm_pu": 1.0,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--train33", default=str(HERE / "limited_k1_33_n500_train_no_oracle_s20260702.csv")
    )
    parser.add_argument(
        "--train69", default=str(HERE / "limited_k1_69_n500_train_no_oracle_s20260702.csv")
    )
    parser.add_argument("--candidate_pool_size", type=int, default=16)
    parser.add_argument("--candidate_seed", type=int, default=20260721)
    args = parser.parse_args()

    bases = {}
    state_hashes = {}
    for network, path in (("33", args.train33), ("69", args.train69)):
        raw = read_state_only(path, "train")[0]
        state_a = physical_state_sha256(canonical_state_text(raw["prompt"], network), network)
        state_b = physical_state_sha256(canonical_state_text(str(raw["prompt"]), network), network)
        require(state_a == state_b, f"network {network}: unstable physical-state hash")
        base_a = base_state(raw, network, args.candidate_pool_size, args.candidate_seed)
        base_b = base_state(raw, network, args.candidate_pool_size, args.candidate_seed)
        require(base_a["physical_state_sha256"] == state_a, "base/state hash mismatch")
        require(base_a["candidate_pool_sha256"] == base_b["candidate_pool_sha256"],
                "candidate pool hash is unstable")
        require(base_a["candidates"] == base_b["candidates"], "candidate pool is unstable")
        require(base_a["candidates"][0]["action"] == NOOP, "no-op is not first")
        require(len({item["action"] for item in base_a["candidates"]}) == len(base_a["candidates"]),
                "duplicate candidate action")
        require("ORACLE" not in base_a["state_text"], "source suffix reached student state")
        leaked = dict(raw)
        leaked["prompt"] = raw["prompt"] + "\nORACLE chosen=Action: none; target_loss_kw=0"
        leaked_base = base_state(leaked, network, args.candidate_pool_size, args.candidate_seed)
        require(leaked_base["state_text"] == base_a["state_text"],
                "oracle suffix changed canonical state")
        require("ORACLE" not in leaked_base["state_text"], "oracle suffix was forwarded")
        mutated = dict(raw)
        mutated["prompt"] = raw["prompt"].replace("(0+0j)", "(0.0001+0j)", 1)
        require(
            physical_state_sha256(canonical_state_text(mutated["prompt"], network), network)
            != state_a,
            "physical-state hash is insensitive to a load mutation",
        )
        bases[network] = base_a
        state_hashes[network] = state_a
        if (
            Path(path).name == f"limited_k1_{network}_n500_train_no_oracle_s20260702.csv"
            and args.candidate_pool_size == 16 and args.candidate_seed == 20260721
        ):
            require(state_a == GOLDEN[network]["state"], "stable-state golden hash drifted")
            require(base_a["candidate_pool_sha256"] == GOLDEN[network]["pool"],
                    "candidate-pool golden hash drifted")

    raw = read_state_only(args.train33, "train")[0]
    extra_load = dict(raw)
    extra_load["prompt"] = raw["prompt"].replace(
        "]\nBudget: N_branch_exchanges", ", (0+0j)]\nBudget: N_branch_exchanges", 1
    )
    try:
        canonical_state_text(extra_load["prompt"], "33")
    except ValueError:
        pass
    else:
        raise RuntimeError("load-vector length mismatch was accepted")

    candidates = [
        _candidate(NOOP, 0.0, 0.94),
        _candidate("Action: Replace (7, 8) with (6, 7)", 3.0, 0.945),
        _candidate("Action: Replace (9, 10) with (8, 9)", -1.0, 0.950),
        _candidate("Action: Replace (14, 15) with (13, 14)", 5.0, 0.930, False),
    ]
    desired, labelled = label_candidates("loss", candidates, 0.20)
    require(desired == 1, "wrong physics optimum")
    require(labelled[0]["accepted_by_gate"] and labelled[1]["accepted_by_gate"],
            "safe candidate rejected")
    require(not labelled[2]["accepted_by_gate"] and not labelled[3]["accepted_by_gate"],
            "unsafe/nonpositive candidate accepted")
    require(abs(sum(item["target_prob"] for item in labelled) - 1.0) < 1e-9,
            "target distribution is not normalized")
    require(labelled[desired]["normalised_regret"] == 0.0, "optimal regret is nonzero")

    tied_candidates = [
        _candidate(NOOP, 0.0, 0.94),
        _candidate("Action: Replace (7, 8) with (6, 7)", 3.0, 0.945),
        _candidate("Action: Replace (9, 10) with (8, 9)", 3.0, 0.945),
    ]
    _, tied = label_candidates("loss", tied_candidates, 0.20)
    require(sum(candidate["is_physics_optimal"] for candidate in tied) == 2,
            "tied physical optima were collapsed to a lexical label")

    unsafe_noop = [_candidate(NOOP, 0.0, 0.80, feasible=False)]
    _, unsafe_labelled = label_candidates("loss", unsafe_noop, 0.20)
    require(not unsafe_labelled[0]["accepted_by_gate"], "infeasible no-op passed the safety gate")

    row = {
        "instance_id": "test:33:one:loss",
        "network_id": "33",
        "load_id": "33:one",
        "physical_state_sha256": "state",
        "instruction_id": "loss",
        "instruction_text": "minimise loss",
        "state_text": "Power Distribution Network: synthetic",
        "desired_index": desired,
        "desired_action": labelled[desired]["action"],
        "optimal_indices": [
            index for index, candidate in enumerate(labelled)
            if candidate["is_physics_optimal"]
        ],
        "optimal_actions": [
            candidate["action"] for candidate in labelled if candidate["is_physics_optimal"]
        ],
        "candidates": labelled,
    }
    
    
    scores = [0.0, 2.0, 1.0, 3.0]
    record = record_from_scores(row, scores, topk=2)
    require(record["top1_action"] == labelled[3]["action"], "unsafe top1 fixture failed")
    require(record["safe_action"] == labelled[1]["action"], "gate did not recover safe top-k action")
    require(record["safe_feasible"] and record["safe_regret"] == 0.0,
            "safe gate did not deliver the optimum")

    original_score_completions = trainer.reward.score_completions
    trainer.reward.score_completions = lambda *args, **kwargs: []
    try:
        failed_live = live_gate_replay(
            [row], [record],
            SimpleNamespace(physics_python="unused", physics_timeout_s=1.0),
        )
    finally:
        trainer.reward.score_completions = original_score_completions
    require(failed_live["rows"][0]["fail_closed"], "live gate backend failure did not fail closed")
    require(failed_live["rows"][0]["selected_action"] == NOOP,
            "live gate backend failure selected a switching action")

    online = dict(row)
    online["candidates"] = [
        {"action": candidate["action"], "candidate_feature_text": candidate["candidate_feature_text"],
         "feedback_revealed": False}
        for candidate in labelled
    ]
    online.pop("desired_index")
    online.pop("desired_action")
    online.pop("optimal_indices")
    online.pop("optimal_actions")
    queried = online_query_indices(scores, online, budget=3, seed=42)
    shifted = online_query_indices([value + 100.0 for value in scores], online, budget=3, seed=42)
    noop = next(index for index, item in enumerate(online["candidates"]) if item["action"] == NOOP)
    require(len(queried) == 3 and len(set(queried)) == 3 and noop not in queried,
            "online query budget/uniqueness failed")
    require(queried == shifted, "online uncertainty query is not score-shift invariant")

    order = list(reversed(range(len(labelled))))
    reversed_row = reordered_row(row, order)
    require(reversed_row["desired_action"] == row["desired_action"], "permutation changed desired action")
    require(reversed_row["candidates"][reversed_row["desired_index"]]["action"] == row["desired_action"],
            "permutation desired index mismatch")
    require(set(reversed_row["optimal_actions"]) == set(row["optimal_actions"]),
            "permutation changed optimal set")
    question = candidate_question(row, labelled[1])
    require("YES" in question and "NO" in question, "shared readout tokens missing")
    require("candidate_loss_kw" not in question and "reduction_pct" not in question,
            "AC outcome leaked into candidate question")

    
    with tempfile.TemporaryDirectory() as directory:
        path = Path(directory) / "leak.jsonl"
        leaked = {key: str(raw[key]) for key in ("instance_id", "load_id", "prompt", "split")}
        leaked["chosen"] = NOOP
        path.write_text(json.dumps(leaked) + "\n", encoding="utf-8")
        try:
            read_state_only(path, "train")
        except ValueError:
            pass
        else:
            raise RuntimeError("strict state reader accepted an oracle field")

    online_rows = directive_rows(bases["33"], "online_stream", "train", 0.20, False)
    source_map = {
        "train": {"33": {"rows": {str(raw["instance_id"]): raw}}},
        "validation": {},
    }
    audit_summary = {
        "candidate_pool_size": args.candidate_pool_size,
        "candidate_seed": args.candidate_seed,
        "target_temperature": 0.20,
    }
    group_audit(online_rows, "online_stream", source_map, audit_summary)

    leaked_online = json.loads(json.dumps(online_rows))
    leaked_online[1]["candidates"][0]["anchor_loss_kw"] = 1.0
    leaked_online[1]["candidates"][0]["feedback_revealed"] = True
    try:
        group_audit(leaked_online, "online_stream", source_map, audit_summary)
    except (ValueError, RuntimeError):
        pass
    else:
        raise RuntimeError("online audit accepted embedded physics feedback")

    wrong_state = json.loads(json.dumps(online_rows))
    wrong_state[1]["state_text"] += "\nORACLE desired_action=Action: none"
    try:
        group_audit(wrong_state, "online_stream", source_map, audit_summary)
    except (ValueError, RuntimeError):
        pass
    else:
        raise RuntimeError("online audit checked only the first directive state")

    duplicate = [*online_rows, json.loads(json.dumps(online_rows[0]))]
    duplicate[-1]["instance_id"] += ":duplicate"
    try:
        group_audit(duplicate, "online_stream", source_map, audit_summary)
    except (ValueError, RuntimeError):
        pass
    else:
        raise RuntimeError("online audit accepted a duplicate directive")

    print(json.dumps({
        "msg": "GridRank dependency-light verification PASS",
        "stable_state_sha256": state_hashes,
        "candidate_pool_size": {network: len(base["candidates"]) for network, base in bases.items()},
        "safe_gate_fail_closed": True,
        "live_gate_backend_error_fail_closed": True,
        "online_noop_excluded_from_query_budget": True,
        "online_query_shift_invariant": True,
        "tie_optimal_set_preserved": True,
        "oracle_suffix_removed": True,
        "strict_oracle_boundary": True,
        "golden_hash_regression": True,
        "online_audit_adversarial_cases_rejected": True,
    }))


if __name__ == "__main__":
    main()
