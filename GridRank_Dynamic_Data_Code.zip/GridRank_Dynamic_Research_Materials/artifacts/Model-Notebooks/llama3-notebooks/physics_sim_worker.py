"""Serve JSON-line requests to the physical simulator in a separate Python runtime."""

import argparse
from dataclasses import asdict
import json
import sys

from pandapower_backend import PandapowerBackend
from physics_env import FlowResult


def _error_result(exc):
    return FlowResult(
        False,
        False,
        None,
        None,
        None,
        f"{type(exc).__name__}: {exc}",
    )


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--network", type=int, choices=[33, 69], required=True)
    parser.add_argument("--backend", choices=["pandapower"], default="pandapower")
    args = parser.parse_args()
    try:
        backend = PandapowerBackend.for_network(args.network)
    except Exception as exc:
        print(json.dumps({
            "ready": False,
            "network_id": args.network,
            "error": f"{type(exc).__name__}: {exc}",
        }), flush=True)
        return 2

    print(json.dumps({
        "ready": True,
        "network_id": backend.network_id,
        "backend": backend.solver_name,
    }), flush=True)
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        request_id = None
        try:
            request = json.loads(line)
            request_id = request.get("id")
            if request.get("command") == "close":
                print(json.dumps({"id": request_id, "closed": True}), flush=True)
                return 0
            loads = [
                complex(float(value[0]), float(value[1]))
                for value in request["load_pu"]
            ]
            result = backend.run(
                request["open_lines"], loads, request.get("z_unit", "ohm")
            )
        except Exception as exc:
            result = _error_result(exc)
        print(json.dumps({
            "id": request_id,
            "result": asdict(result),
        }, ensure_ascii=False), flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
