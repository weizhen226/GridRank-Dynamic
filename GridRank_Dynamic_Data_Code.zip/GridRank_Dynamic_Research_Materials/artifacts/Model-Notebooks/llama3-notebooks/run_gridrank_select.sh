#!/usr/bin/env bash
set -euo pipefail

CURRENT_STAGE="bootstrap"
GATE_JSON_PRINTED=0
on_exit() {
  local rc=$?
  trap - EXIT
  if (( rc != 0 )) && [[ "$GATE_JSON_PRINTED" == "0" ]]; then
    printf '{"msg":"GridRank-Select runner failure","stage":"%s","gate_pass":false,"exit_code":%d}\n' \
      "$CURRENT_STAGE" "$rc"
  fi
  exit "$rc"
}
trap on_exit EXIT

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"
export HF_HUB_OFFLINE=1

PREFLIGHT_ONLY="${PREFLIGHT_ONLY:-1}"
case "$PREFLIGHT_ONLY" in
  0|1) ;;
  *) echo "PREFLIGHT_ONLY must be 0 or 1" >&2; exit 2 ;;
esac
if [[ "$PREFLIGHT_ONLY" == "1" ]]; then
  export CUDA_VISIBLE_DEVICES=""
fi
readonly TOTAL_STAGES=4

resolve_executable() {
  local requested="$1"
  if [[ "$requested" == */* ]]; then
    [[ -x "$requested" ]] || return 1
    printf '%s\n' "$requested"
  else
    command -v -- "$requested"
  fi
}

if ! TRAIN_PYTHON_BIN="$(resolve_executable "${TRAIN_PYTHON:-python}")"; then
  echo "TRAIN_PYTHON is not executable or resolvable on PATH: ${TRAIN_PYTHON:-python}" >&2
  exit 2
fi
if ! PHYSICS_PYTHON_BIN="$(resolve_executable "${PHYSICS_PYTHON:-$TRAIN_PYTHON_BIN}")"; then
  echo "PHYSICS_PYTHON is not executable or resolvable on PATH: ${PHYSICS_PYTHON:-$TRAIN_PYTHON_BIN}" >&2
  exit 2
fi

BASE_MODEL="${BASE_MODEL:-../../Meta-Llama-3.1-8B-Instruct}"
SFT="${SFT:-output_gridintent_gate_33_69_v2_20260717/sft_only}"



UPSTREAM_TAG="${UPSTREAM_TAG:-gridrank_feedback_gate_v1_final_20260721}"
UPSTREAM_SUMMARY="${UPSTREAM_SUMMARY:-${UPSTREAM_TAG}_data_summary.json}"
UPSTREAM_AUDIT="${UPSTREAM_AUDIT:-${UPSTREAM_TAG}_data_audit.json}"
UPSTREAM_OFFLINE="${UPSTREAM_OFFLINE:-${UPSTREAM_TAG}_offline_train.jsonl}"
UPSTREAM_TEST="${UPSTREAM_TEST:-${UPSTREAM_TAG}_validation_test.jsonl}"

TAG="${TAG:-gridrank_select_gate_v1_20260722}"
if [[ ! "$TAG" =~ ^[A-Za-z0-9][A-Za-z0-9._-]*$ ]]; then
  echo "TAG must contain only letters, digits, dot, underscore, or hyphen" >&2
  exit 2
fi
TRAIN_JSONL="${TRAIN_JSONL:-${TAG}_train.jsonl}"
TEST_JSONL="${TEST_JSONL:-${TAG}_test.jsonl}"
DATA_SUMMARY="${DATA_SUMMARY:-${TAG}_data_summary.json}"
DATA_AUDIT="${DATA_AUDIT:-${TAG}_data_audit.json}"
OUT="${OUT:-output_${TAG}}"
PREFLIGHT_MANIFEST="${PREFLIGHT_MANIFEST:-${OUT}.preflight.json}"


readonly TARGET_TEMPERATURE=0.20
readonly MAX_LENGTH=1024
readonly CANDIDATE_BATCH_SIZE=4
readonly EPOCHS=4
readonly TOPK=3
readonly LEARNING_RATE=2e-6
readonly GRAD_ACCUM=4
readonly MAX_GRAD_NORM=1.0
readonly LIST_TEMPERATURE=1.0
readonly LAMBDA_BCE=1.0
readonly LAMBDA_LISTWISE=0.5
readonly LAMBDA_HARD=1.0
readonly HARD_MARGIN=0.5
readonly BETA_REFERENCE=0.02
readonly TRAIN_SEED=42
readonly GRADIENT_CHECKPOINTING=1
readonly PHYSICS_TIMEOUT_S="${PHYSICS_TIMEOUT_S:-60.0}"
readonly BOOTSTRAP_REPS="${BOOTSTRAP_REPS:-2000}"

for path in \
  "$UPSTREAM_SUMMARY" "$UPSTREAM_AUDIT" "$UPSTREAM_OFFLINE" "$UPSTREAM_TEST" \
  "$SFT/adapter_config.json" "$SFT/adapter_model.safetensors" \
  "$BASE_MODEL/config.json" "$BASE_MODEL/tokenizer_config.json"; do
  test -e "$path" || { echo "missing required path: $path" >&2; exit 2; }
done
test ! -e "$OUT" || { echo "refusing to reuse output directory: $OUT" >&2; exit 2; }
if [[ "$PREFLIGHT_ONLY" == "0" ]]; then
  test ! -e "${OUT}.log" || { echo "refusing to overwrite log: ${OUT}.log" >&2; exit 2; }
fi

if [[ "$PREFLIGHT_ONLY" == "1" ]]; then
  echo "=== 1/$TOTAL_STAGES DEPENDENCY-LIGHT GRIDRANK-SELECT REGRESSIONS ==="
  CURRENT_STAGE="dependency_regression"
  "$TRAIN_PYTHON_BIN" -B verify_gridrank_select.py

  derived_existing=0
  for path in "$TRAIN_JSONL" "$TEST_JSONL" "$DATA_SUMMARY"; do
    test -e "$path" && derived_existing=$((derived_existing + 1))
  done
  if [[ "$derived_existing" == "0" ]]; then
    echo "=== 2/$TOTAL_STAGES DERIVE NON-NOOP LOSS-RANKING DATA FROM LOCKED PHYSICS ==="
    CURRENT_STAGE="derived_data_build"
    "$TRAIN_PYTHON_BIN" -u build_gridrank_select.py \
      --upstream_summary "$UPSTREAM_SUMMARY" \
      --upstream_audit "$UPSTREAM_AUDIT" \
      --offline_jsonl "$UPSTREAM_OFFLINE" \
      --test_jsonl "$UPSTREAM_TEST" \
      --train_out "$TRAIN_JSONL" --test_out "$TEST_JSONL" \
      --summary_out "$DATA_SUMMARY" \
      --target_temperature "$TARGET_TEMPERATURE"
  elif [[ "$derived_existing" != "3" ]]; then
    echo "partial GridRank-Select derived artifact set; use a new TAG" >&2
    exit 2
  else
    echo "=== 2/$TOTAL_STAGES REUSE COMPLETE GRIDRANK-SELECT DERIVED DATA ==="
  fi

  echo "=== 3/$TOTAL_STAGES AUDIT DERIVATION, PROVENANCE, AND NO-NOOP RANKING ==="
  CURRENT_STAGE="derived_data_audit"
  if [[ ! -e "$DATA_AUDIT" ]]; then
    "$TRAIN_PYTHON_BIN" -u audit_gridrank_select.py \
      --upstream_summary "$UPSTREAM_SUMMARY" \
      --upstream_audit "$UPSTREAM_AUDIT" \
      --offline_jsonl "$UPSTREAM_OFFLINE" \
      --test_jsonl "$UPSTREAM_TEST" \
      --select_summary "$DATA_SUMMARY" \
      --train_jsonl "$TRAIN_JSONL" \
      --select_test_jsonl "$TEST_JSONL" \
      --output "$DATA_AUDIT"
  else
    echo "reusing existing complete audit: $DATA_AUDIT"
  fi

  CURRENT_STAGE="locked_cpu_preflight"
  test ! -e "$PREFLIGHT_MANIFEST" || {
    echo "refusing to overwrite preflight manifest: $PREFLIGHT_MANIFEST" >&2
    exit 2
  }
  echo "=== 4/$TOTAL_STAGES LOCK UPSTREAM, DATA, CODE, MODEL, RUNTIMES, PROMPTS, AND SCHEDULE ==="
  "$TRAIN_PYTHON_BIN" -u preflight_gridrank_select.py \
    --upstream_summary "$UPSTREAM_SUMMARY" \
    --upstream_audit "$UPSTREAM_AUDIT" \
    --offline_jsonl "$UPSTREAM_OFFLINE" \
    --upstream_test_jsonl "$UPSTREAM_TEST" \
    --train_jsonl "$TRAIN_JSONL" --test_jsonl "$TEST_JSONL" \
    --data_summary "$DATA_SUMMARY" --data_audit "$DATA_AUDIT" \
    --resume_adapter_path "$SFT" --base_model "$BASE_MODEL" \
    --physics_python "$PHYSICS_PYTHON_BIN" \
    --physics_timeout_s "$PHYSICS_TIMEOUT_S" \
    --output "$PREFLIGHT_MANIFEST" \
    --max_length "$MAX_LENGTH" \
    --candidate_batch_size "$CANDIDATE_BATCH_SIZE" \
    --epochs "$EPOCHS" --topk "$TOPK" \
    --learning_rate "$LEARNING_RATE" --grad_accum "$GRAD_ACCUM" \
    --max_grad_norm "$MAX_GRAD_NORM" --list_temperature "$LIST_TEMPERATURE" \
    --lambda_bce "$LAMBDA_BCE" --lambda_listwise "$LAMBDA_LISTWISE" \
    --lambda_hard "$LAMBDA_HARD" --hard_margin "$HARD_MARGIN" \
    --beta_reference "$BETA_REFERENCE" --seed "$TRAIN_SEED" \
    --gradient_checkpointing "$GRADIENT_CHECKPOINTING" \
    --bootstrap_reps "$BOOTSTRAP_REPS"
  echo "=== GRIDRANK-SELECT CPU PREFLIGHT COMPLETE; GPU NOT STARTED ==="
  exit 0
fi

CURRENT_STAGE="locked_cpu_artifact_check"
for path in \
  "$TRAIN_JSONL" "$TEST_JSONL" "$DATA_SUMMARY" "$DATA_AUDIT" \
  "$PREFLIGHT_MANIFEST"; do
  test -f "$path" || {
    echo "missing locked CPU artifact; run PREFLIGHT_ONLY=1 first: $path" >&2
    exit 2
  }
done

echo "=== 1/$TOTAL_STAGES VERIFY LOCKED RUNTIMES + MODEL INVENTORY ==="
CURRENT_STAGE="runtime_lock"
set +e
RUNTIME_JSON="$("$TRAIN_PYTHON_BIN" -B preflight_gridrank_select.py \
  --verify_runtime_manifest "$PREFLIGHT_MANIFEST" \
  --base_model "$BASE_MODEL" \
  --physics_python "$PHYSICS_PYTHON_BIN" \
  --physics_timeout_s "$PHYSICS_TIMEOUT_S" \
  --bootstrap_reps "$BOOTSTRAP_REPS")"
RUNTIME_RC=$?
set -e
printf '%s\n' "$RUNTIME_JSON"
if (( RUNTIME_RC != 0 )); then
  exit "$RUNTIME_RC"
fi

echo "=== 2/$TOTAL_STAGES CUDA + BITSANDBYTES NF4 READINESS ==="
CURRENT_STAGE="gpu_readiness"
set +e
GPU_JSON="$("$TRAIN_PYTHON_BIN" -B - <<'PY'
import json

result = {"msg": "GridRank-Select CUDA/bitsandbytes readiness"}
try:
    import bitsandbytes as bnb
    import torch
    from transformers import BitsAndBytesConfig

    checks = {
        "cuda_available": bool(torch.cuda.is_available()),
        "visible_device_count": int(torch.cuda.device_count()) > 0,
    }
    if all(checks.values()):
        device = torch.device("cuda:0")
        probe = torch.ones(1, device=device)
        checks["cuda_tensor_ok"] = float(probe.item()) == 1.0
        free, total = torch.cuda.mem_get_info(device)
        result.update({
            "device": torch.cuda.get_device_name(device),
            "capability": list(torch.cuda.get_device_capability(device)),
            "free_memory_bytes": int(free),
            "total_memory_bytes": int(total),
        })
        del probe
    else:
        checks["cuda_tensor_ok"] = False
    quant_config = BitsAndBytesConfig(
        load_in_4bit=True,
        bnb_4bit_quant_type="nf4",
        bnb_4bit_compute_dtype=torch.float16,
        bnb_4bit_use_double_quant=True,
    )
    checks["bitsandbytes_4bit_config_ok"] = bool(
        quant_config.load_in_4bit
        and quant_config.bnb_4bit_quant_type == "nf4"
        and quant_config.bnb_4bit_compute_dtype == torch.float16
        and quant_config.bnb_4bit_use_double_quant is True
    )
    if checks["cuda_available"] and checks["visible_device_count"]:
        layer = bnb.nn.Linear4bit(
            64, 64, bias=False, compute_dtype=torch.float16,
            compress_statistics=True, quant_type="nf4",
        ).to(device)
        inputs = torch.randn(2, 64, device=device, dtype=torch.float16)
        with torch.no_grad():
            outputs = layer(inputs)
        torch.cuda.synchronize(device)
        checks["bitsandbytes_nf4_cuda_kernel_ok"] = bool(
            outputs.is_cuda and torch.isfinite(outputs).all().item()
            and tuple(outputs.shape) == (2, 64)
        )
        del inputs, outputs, layer
        torch.cuda.empty_cache()
    else:
        checks["bitsandbytes_nf4_cuda_kernel_ok"] = False
except Exception as exc:
    checks = locals().get("checks", {})
    checks["exception_free"] = False
    result["error"] = f"{type(exc).__name__}: {exc}"
result["checks"] = checks
result["readiness_pass"] = bool(checks) and all(checks.values())
print(json.dumps(result, ensure_ascii=False))
raise SystemExit(0 if result["readiness_pass"] else 2)
PY
)"
GPU_RC=$?
set -e
printf '%s\n' "$GPU_JSON"
if (( GPU_RC != 0 )); then
  exit "$GPU_RC"
fi

echo "=== 3/$TOTAL_STAGES OFFLINE NON-NOOP PHYSICS DISTILLATION + LIVE TOP-K GATE ==="
CURRENT_STAGE="gpu_training"
set +e
"$TRAIN_PYTHON_BIN" -u train_gridrank_select.py \
  --train_jsonl "$TRAIN_JSONL" --test_jsonl "$TEST_JSONL" \
  --data_summary "$DATA_SUMMARY" --data_audit "$DATA_AUDIT" \
  --preflight_manifest "$PREFLIGHT_MANIFEST" \
  --resume_adapter_path "$SFT" --output_dir "$OUT" \
  --base_model "$BASE_MODEL" --physics_python "$PHYSICS_PYTHON_BIN" \
  --physics_timeout_s "$PHYSICS_TIMEOUT_S" \
  --max_length "$MAX_LENGTH" --candidate_batch_size "$CANDIDATE_BATCH_SIZE" \
  --epochs "$EPOCHS" --topk "$TOPK" \
  --learning_rate "$LEARNING_RATE" --grad_accum "$GRAD_ACCUM" \
  --max_grad_norm "$MAX_GRAD_NORM" --list_temperature "$LIST_TEMPERATURE" \
  --lambda_bce "$LAMBDA_BCE" --lambda_listwise "$LAMBDA_LISTWISE" \
  --lambda_hard "$LAMBDA_HARD" --hard_margin "$HARD_MARGIN" \
  --beta_reference "$BETA_REFERENCE" --seed "$TRAIN_SEED" \
  --gradient_checkpointing "$GRADIENT_CHECKPOINTING" \
  --bootstrap_reps "$BOOTSTRAP_REPS" \
  2>&1 | tee "${OUT}.log"
PIPE_STATUS=("${PIPESTATUS[@]}")
set -e
TRAIN_RC="${PIPE_STATUS[0]}"
TEE_RC="${PIPE_STATUS[1]}"
RUN_RC="$TRAIN_RC"
if (( RUN_RC == 0 && TEE_RC != 0 )); then
  RUN_RC="$TEE_RC"
fi

echo "=== 4/$TOTAL_STAGES PRINT LOCKED DECISION ARTIFACT ==="
CURRENT_STAGE="decision_artifact"
if [[ -f "$OUT/gridrank_select_gate.json" ]]; then
  set +e
  GATE_JSON="$("$TRAIN_PYTHON_BIN" -B -c '
import json, sys

with open(sys.argv[1], encoding="utf-8") as handle:
    payload = json.load(handle)
required = {
    "msg", "preflight_sha256", "training_schedule", "summaries", "by_network",
    "paired", "live_topk_gate", "diagnostic_adapter", "mechanism_checks",
    "efficacy_checks", "safety_checks", "engineering_gate_pass",
    "paper_checks", "paper_gate_pass",
}
if not isinstance(payload, dict) or required - set(payload):
    raise ValueError(f"incomplete gate JSON: {sorted(required - set(payload))}")
for name in ("engineering_gate_pass", "paper_gate_pass"):
    if not isinstance(payload[name], bool):
        raise ValueError(f"{name} must be boolean")
for name in ("mechanism_checks", "efficacy_checks", "safety_checks", "paper_checks"):
    if not isinstance(payload[name], dict) or not payload[name] or not all(
        isinstance(value, bool) for value in payload[name].values()
    ):
        raise ValueError(f"invalid {name}")
if not isinstance(payload["diagnostic_adapter"], dict) or not isinstance(
    payload["diagnostic_adapter"].get("valid"), bool
):
    raise ValueError("invalid diagnostic_adapter")
print(json.dumps(payload, ensure_ascii=False))
' "$OUT/gridrank_select_gate.json")"
  GATE_READ_RC=$?
  set -e
  if (( GATE_READ_RC == 0 )); then
    printf '%s\n' "$GATE_JSON"
    GATE_JSON_PRINTED=1
  elif (( RUN_RC == 0 )); then
    RUN_RC="$GATE_READ_RC"
  fi
elif (( RUN_RC == 0 )); then
  echo "training returned success but gridrank_select_gate.json is missing" >&2
  exit 3
fi
exit "$RUN_RC"
