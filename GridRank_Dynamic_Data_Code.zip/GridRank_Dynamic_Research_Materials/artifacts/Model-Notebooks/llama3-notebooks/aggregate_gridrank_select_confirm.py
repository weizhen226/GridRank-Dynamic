"""Aggregate GridRank select confirm."""

from __future__ import annotations

import argparse
import csv
import itertools
import json
import math
import random
from collections import defaultdict
from pathlib import Path

from build_gridrank_select import file_sha256
from preflight_gridrank_select_confirm import CONFIRMATION_ID, SEEDS
from train_gridrank_select_confirm import GATE_SCHEMA


SCHEMA = "gridrank-select-confirm-aggregate-v1"


def _json(path):
    with open(path, encoding="utf-8") as handle:
        return json.load(handle)


def _quantile(values, fraction):
    ordered = sorted(values)
    return ordered[int(fraction * (len(ordered) - 1))]


def _bootstrap(values, reps, seed):
    rng = random.Random(seed)
    draws = []
    for _ in range(reps):
        sample = [values[rng.randrange(len(values))] for _ in values]
        draws.append(sum(sample) / len(sample))
    return [_quantile(draws, 0.025), _quantile(draws, 0.975)]


def _two_way_bootstrap(matrix, reps, seed):
    seeds = sorted(matrix)
    states = sorted(next(iter(matrix.values())))
    rng = random.Random(seed)
    draws = []
    for _ in range(reps):
        sampled_seeds = [seeds[rng.randrange(len(seeds))] for _ in seeds]
        sampled_states = [states[rng.randrange(len(states))] for _ in states]
        values = [matrix[train_seed][state] for train_seed in sampled_seeds
                  for state in sampled_states]
        draws.append(sum(values) / len(values))
    return [_quantile(draws, 0.025), _quantile(draws, 0.975)]


def _safe_utility(candidate):
    if candidate.get("accepted_by_gate") is not True:
        return None
    value = candidate.get("safe_utility")
    if value is None or not math.isfinite(float(value)):
        return None
    return float(value)


def random_top3_baseline(test_rows):
    records = []
    for row in test_rows:
        if len(row["candidates"]) != 15:
            raise ValueError("random baseline requires exactly 15 exchanges")
        anchor = _safe_utility(row["gate_anchor"])
        if anchor is None:
            raise ValueError("random baseline requires an operational no-op anchor")
        values = [_safe_utility(candidate) for candidate in row["candidates"]]
        pool_best = max([anchor, *[value for value in values if value is not None]])
        regrets = []
        for indices in itertools.combinations(range(len(values)), 3):
            selected = max([anchor, *[
                values[index] for index in indices if values[index] is not None
            ]])
            regrets.append(max(0.0, pool_best - selected))
        records.append({
            "instance_id": row["instance_id"],
            "network": str(row["network_id"]),
            "physical_state_sha256": row["physical_state_sha256"],
            "subset_count": len(regrets),
            "expected_safe_regret": sum(regrets) / len(regrets),
        })
    return records


def _gate_spec(values):
    output = {}
    for value in values:
        seed_text, path_text = value.split("=", 1)
        seed = int(seed_text)
        if seed in output:
            raise ValueError(f"duplicate seed gate: {seed}")
        path = Path(path_text).resolve()
        if not path.is_file():
            raise FileNotFoundError(path)
        output[seed] = path
    if set(output) != set(SEEDS):
        raise ValueError(f"aggregate requires gates for {SEEDS}")
    return output


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--gate", action="append", required=True, help="SEED=PATH")
    parser.add_argument("--test_jsonl", required=True)
    parser.add_argument("--output_json", required=True)
    parser.add_argument("--output_csv", required=True)
    parser.add_argument("--bootstrap_reps", type=int, default=10000)
    parser.add_argument("--bootstrap_seed", type=int, default=20260725)
    args = parser.parse_args()
    if args.bootstrap_reps < 2000:
        raise ValueError("confirmation aggregate requires at least 2000 bootstrap reps")
    output_json = Path(args.output_json)
    output_csv = Path(args.output_csv)
    if output_json.exists() or output_csv.exists():
        raise FileExistsError("refusing to overwrite confirmation aggregate")

    gate_paths = _gate_spec(args.gate)
    gates = {seed: _json(path) for seed, path in gate_paths.items()}
    test_rows = [
        json.loads(line) for line in open(args.test_jsonl, encoding="utf-8") if line.strip()
    ]
    if len(test_rows) != 64:
        raise ValueError("confirmation aggregate requires 64 locked test states")
    random_records = random_top3_baseline(test_rows)
    random_by_state = {
        row["physical_state_sha256"]: row["expected_safe_regret"]
        for row in random_records
    }

    matrix = {}
    row_metadata = {}
    per_seed = []
    reference_sft = None
    source_test_hashes = set()
    checks = {
        "seed_set_exact": set(gates) == set(SEEDS),
        "all_seed_gate_schemas": all(gate.get("schema") == GATE_SCHEMA for gate in gates.values()),
        "confirmation_id_exact": all(
            gate.get("confirmation_id") == CONFIRMATION_ID for gate in gates.values()
        ),
        "all_mechanism_checks": all(
            bool(gate.get("mechanism_checks"))
            and all(gate["mechanism_checks"].values()) for gate in gates.values()
        ),
        "all_safety_checks": all(
            bool(gate.get("safety_checks"))
            and all(gate["safety_checks"].values()) for gate in gates.values()
        ),
        "all_adapters_saved": all(
            gate.get("diagnostic_adapter", {}).get("valid") is True for gate in gates.values()
        ),
        "per_seed_claims_withheld": all(
            gate.get("paper_claim_authorized") is False for gate in gates.values()
        ),
    }

    for seed in SEEDS:
        gate = gates[seed]
        if gate.get("confirmation_seed") != seed:
            raise ValueError(f"gate seed identity mismatch: {seed}")
        locked = gate.get("locked_manifest", {})
        if (
            locked.get("schema") != "gridrank-select-confirm-preflight-v1"
            or locked.get("confirmation", {}).get("confirmation_id") != CONFIRMATION_ID
            or locked.get("training_schedule", {}).get("seed") != seed
        ):
            raise ValueError(f"seed {seed} gate is not bound to its confirmation preflight")
        source_test_hashes.add(locked.get("artifact_sha256", {}).get("test"))
        rows = gate.get("paired", {}).get("distilled_vs_sft", {}).get("state_rows")
        if not isinstance(rows, list) or len(rows) != 64:
            raise ValueError(f"seed {seed} lacks 64 paired state rows")
        state_map = {}
        sft_map = {}
        for row in rows:
            state = row["physical_state_sha256"]
            if state in state_map:
                raise ValueError(f"duplicate state evidence for seed {seed}")
            state_map[state] = float(row["safe_regret_improvement"])
            sft_map[state] = (float(row["sft_safe_regret"]), row["sft_safe_action"])
            row_metadata.setdefault(state, {
                "instance_id": row["instance_id"],
                "network": str(row["network"]),
                "load_id": row["load_id"],
            })
        if set(state_map) != set(random_by_state):
            raise ValueError(f"seed {seed} row set differs from locked test")
        if reference_sft is None:
            reference_sft = sft_map
        elif any(
            abs(reference_sft[state][0] - sft_map[state][0]) > 1e-8
            or reference_sft[state][1] != sft_map[state][1]
            for state in state_map
        ):
            checks["sft_seed_invariant"] = False
        matrix[seed] = state_map
        values = list(state_map.values())
        paired = gate["paired"]["distilled_vs_sft"]
        per_seed.append({
            "seed": seed,
            "mean_improvement": sum(values) / len(values),
            "rows_better": sum(value > 1e-12 for value in values),
            "rows_worse": sum(value < -1e-12 for value in values),
            "rows_tied": sum(abs(value) <= 1e-12 for value in values),
            "ci95": paired["state_cluster_bootstrap_ci95"],
            "safe_feasible_rate": gate["summaries"]["distilled"]["safe_feasible_rate"],
            "engineering_gate_pass": gate["engineering_gate_pass"],
        })
    checks.setdefault("sft_seed_invariant", True)
    checks["test_artifact_hash_same"] = (
        len(source_test_hashes) == 1
        and next(iter(source_test_hashes)) == file_sha256(args.test_jsonl)
    )

    states = sorted(row_metadata)
    state_means = {
        state: sum(matrix[seed][state] for seed in SEEDS) / len(SEEDS)
        for state in states
    }
    pooled_mean = sum(state_means.values()) / len(state_means)
    state_ci = _bootstrap(list(state_means.values()), args.bootstrap_reps, args.bootstrap_seed)
    two_way_ci = _two_way_bootstrap(
        matrix, args.bootstrap_reps, args.bootstrap_seed + 1
    )
    by_network = {}
    for offset, network in enumerate(("33", "69")):
        network_states = [state for state in states if row_metadata[state]["network"] == network]
        values = [state_means[state] for state in network_states]
        by_network[network] = {
            "n_states": len(values),
            "pooled_mean_improvement": sum(values) / len(values),
            "state_bootstrap_ci95": _bootstrap(
                values, args.bootstrap_reps, args.bootstrap_seed + 10 + offset
            ),
            "positive_states": sum(value > 1e-12 for value in values),
            "negative_states": sum(value < -1e-12 for value in values),
        }

    sft_mean = sum(value[0] for value in reference_sft.values()) / len(reference_sft)
    distilled_mean = sft_mean - pooled_mean
    random_mean = sum(random_by_state.values()) / len(random_by_state)
    always_noop_values = [
        float(gates[seed]["summaries"]["always_noop"]["safe_regret_mean"])
        for seed in SEEDS
    ]
    checks["always_noop_seed_invariant"] = (
        max(always_noop_values) - min(always_noop_values) <= 1e-8
    )
    baselines = {
        "sft_safe_regret_mean": sft_mean,
        "distilled_three_seed_safe_regret_mean": distilled_mean,
        "always_noop_safe_regret_mean": sum(always_noop_values) / len(always_noop_values),
        "random_top3_plus_anchor_expected_safe_regret_mean": random_mean,
        "random_top3_exact_subsets_per_state": 455,
        "full_pool_oracle_safe_regret_mean": 0.0,
    }

    positive_seeds = sum(item["mean_improvement"] > 0.0 for item in per_seed)
    primary_checks = {
        "at_least_2_of_3_positive_seeds": positive_seeds >= 2,
        "pooled_state_ci_lower_gt_zero": state_ci[0] > 0.0,
        "two_way_seed_state_ci_lower_gt_zero": two_way_ci[0] > 0.0,
        "both_networks_positive": all(
            item["pooled_mean_improvement"] > 0.0 for item in by_network.values()
        ),
        "distilled_beats_random_equal_budget": distilled_mean < random_mean,
        "distilled_beats_always_noop": distilled_mean < baselines["always_noop_safe_regret_mean"],
        "all_seed_feasibility_100pct": all(
            item["safe_feasible_rate"] == 1.0 for item in per_seed
        ),
    }
    aggregate_pass = all({**checks, **primary_checks}.values())
    result = {
        "msg": "GridRank-Select locked-test three-seed confirmation aggregate",
        "schema": SCHEMA,
        "confirmation_id": CONFIRMATION_ID,
        "seeds": list(SEEDS),
        "n_states": len(states),
        "n_states_by_network": {
            network: sum(row_metadata[state]["network"] == network for state in states)
            for network in ("33", "69")
        },
        "test_jsonl": {
            "path": str(Path(args.test_jsonl).resolve()),
            "sha256": file_sha256(args.test_jsonl),
        },
        "gate_sha256": {
            str(seed): {"path": str(gate_paths[seed]), "sha256": file_sha256(gate_paths[seed])}
            for seed in SEEDS
        },
        "per_seed": per_seed,
        "positive_seed_count": positive_seeds,
        "pooled_state_mean_improvement": pooled_mean,
        "pooled_state_bootstrap_ci95": state_ci,
        "two_way_seed_state_bootstrap_ci95": two_way_ci,
        "by_network": by_network,
        "baselines": baselines,
        "checks": checks,
        "primary_checks": primary_checks,
        "confirmation_gate_pass": aggregate_pass,
        "primary_claim_authorized": aggregate_pass,
        "claim_scope": (
            "physics-distilled LLM shortlist improves equal-budget safe regret over "
            "frozen SFT on locked 33/69-bus test states"
        ),
        "bootstrap_reps": args.bootstrap_reps,
        "bootstrap_seed": args.bootstrap_seed,
    }
    output_json.parent.mkdir(parents=True, exist_ok=True)
    output_json.write_text(json.dumps(result, indent=2, ensure_ascii=False), encoding="utf-8")
    output_csv.parent.mkdir(parents=True, exist_ok=True)
    with open(output_csv, "w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=[
            "physical_state_sha256", "network", "load_id", "instance_id",
            "sft_safe_regret", "random_top3_expected_safe_regret",
            *[f"seed_{seed}_improvement" for seed in SEEDS],
            "mean_improvement",
        ])
        writer.writeheader()
        for state in states:
            writer.writerow({
                "physical_state_sha256": state,
                **row_metadata[state],
                "sft_safe_regret": reference_sft[state][0],
                "random_top3_expected_safe_regret": random_by_state[state],
                **{f"seed_{seed}_improvement": matrix[seed][state] for seed in SEEDS},
                "mean_improvement": state_means[state],
            })
    print(json.dumps(result, ensure_ascii=False))
    if not aggregate_pass:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
