"""Validate GridRank dynamic supplement."""

from __future__ import annotations

import argparse
import json

import gridrank_dynamic_supplement as supplement
import preflight_gridrank_dynamic_supplement as preflight


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--preflight_manifest", required=True)
    parser.add_argument("--cached_result", required=True)
    parser.add_argument("--latency_result", required=True)
    parser.add_argument("--gate", required=True)
    return parser.parse_args()


def main():
    args = parse_args()
    locked = preflight.verify_manifest(args.preflight_manifest)
    cached = json.load(open(args.cached_result, encoding="utf-8"))
    latency = json.load(open(args.latency_result, encoding="utf-8"))
    gate = json.load(open(args.gate, encoding="utf-8"))
    pairs = supplement.read_jsonl(locked["artifacts"]["pairs"]["path"])
    records = supplement.read_jsonl(
        locked["artifacts"]["cross_records"]["path"]
    )
    recomputed = supplement.cached_analysis(
        pairs,
        records,
        bootstrap_reps=locked["schedule"]["bootstrap_reps"],
        bootstrap_seed=locked["schedule"]["bootstrap_seed"],
    )
    recomputed.update({
        "experiment_id": preflight.EXPERIMENT_ID,
        "preflight_sha256": supplement.file_sha256(
            args.preflight_manifest
        ),
        "input_sha256": {
            key: value["sha256"]
            for key, value in locked["artifacts"].items()
        },
    })
    checks = {
        "gate_schema": gate.get("schema")
        == "gridrank-dynamic-supplement-gate-v1",
        "experiment_id": gate.get("experiment_id") == preflight.EXPERIMENT_ID,
        "supplement_evidence_ready": (
            gate.get("supplement_evidence_ready") is True
        ),
        "preflight_hash": gate.get("preflight_sha256")
        == supplement.file_sha256(args.preflight_manifest),
        "cached_hash": gate["artifacts"]["cached"]["sha256"]
        == supplement.file_sha256(args.cached_result),
        "latency_hash": gate["artifacts"]["latency"]["sha256"]
        == supplement.file_sha256(args.latency_result),
        "exact_cached_recomputation": recomputed == cached,
        "live_benchmark_pass": latency.get("benchmark_pass") is True,
        "live_cache_replay_exact": all(
            value["live_cache_match_rate"] == 1.0
            for value in latency["method_summaries"].values()
        ),
        "decision_consistent": all(gate["checks"].values()),
    }
    result = {
        "msg": "GridRank dynamic supplement result verification",
        "checks": checks,
        "verification_pass": all(checks.values()),
        "supplement_evidence_ready": gate.get("supplement_evidence_ready"),
    }
    print(json.dumps(result, ensure_ascii=False))
    if not result["verification_pass"]:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
