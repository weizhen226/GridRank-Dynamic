#!/usr/bin/env bash
set -euo pipefail

CURRENT_STAGE="bootstrap"
GATE_JSON_PRINTED=0
on_exit() {
  local rc=$?
  trap - EXIT
  if (( rc != 0 )) && [[ "$GATE_JSON_PRINTED" == "0" ]]; then
    printf '{"msg":"GridRank-Select confirmation runner failure","stage":"%s","gate_pass":false,"exit_code":%d}\n' \
      "$CURRENT_STAGE" "$rc"
  fi
  exit "$rc"
}
trap on_exit EXIT

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"
export HF_HUB_OFFLINE=1

PREFLIGHT_ONLY="${PREFLIGHT_ONLY:-1}"
AGGREGATE_ONLY="${AGGREGATE_ONLY:-0}"
case "$PREFLIGHT_ONLY:$AGGREGATE_ONLY" in
  0:0|1:0|0:1|1:1) ;;
  *) echo "PREFLIGHT_ONLY/AGGREGATE_ONLY must be 0 or 1" >&2; exit 2 ;;
esac
if [[ "$PREFLIGHT_ONLY" == "1" || "$AGGREGATE_ONLY" == "1" ]]; then
  export CUDA_VISIBLE_DEVICES=""
fi

resolve_executable() {
  local requested="$1"
  if [[ "$requested" == */* ]]; then
    [[ -x "$requested" ]] || return 1
    printf '%s\n' "$requested"
  else
    command -v -- "$requested"
  fi
}
TRAIN_PYTHON_BIN="$(resolve_executable "${TRAIN_PYTHON:-python}")" || {
  echo "TRAIN_PYTHON is not executable" >&2; exit 2;
}
PHYSICS_PYTHON_BIN="$(resolve_executable "${PHYSICS_PYTHON:-$TRAIN_PYTHON_BIN}")" || {
  echo "PHYSICS_PYTHON is not executable" >&2; exit 2;
}

BASE_MODEL="${BASE_MODEL:-../../Meta-Llama-3.1-8B-Instruct}"
SFT="${SFT:-output_gridintent_gate_33_69_v2_20260717/sft_only}"
TRAIN33="${TRAIN33:-limited_k1_33_n500_train_no_oracle_s20260702.csv}"
TRAIN69="${TRAIN69:-limited_k1_69_n500_train_no_oracle_s20260702.csv}"
TEST33_RAW="${TEST33_RAW:-structured_action_33_fixed_locked_eval_test.jsonl}"
TEST69_RAW="${TEST69_RAW:-structured_action_69_s42_locked_eval_test.jsonl}"

PILOT_TAG="${PILOT_TAG:-gridrank_select_gate_v1_20260722}"
PILOT_TEST_JSONL="${PILOT_TEST_JSONL:-${PILOT_TAG}_test.jsonl}"
PILOT_GATE="${PILOT_GATE:-output_${PILOT_TAG}_gpu1/gridrank_select_gate.json}"
PILOT_RECHECK_GATE="${PILOT_RECHECK_GATE:-output_gridrank_select_recheck_v3_20260724/gridrank_select_recheck_gate.json}"

TAG="${TAG:-gridrank_select_confirm_v1_20260725}"
if [[ ! "$TAG" =~ ^[A-Za-z0-9][A-Za-z0-9._-]*$ ]]; then
  echo "TAG contains invalid characters" >&2; exit 2
fi
TEST33_VIEW="${TEST33_VIEW:-${TAG}_test33_heldout_role.jsonl}"
TEST69_VIEW="${TEST69_VIEW:-${TAG}_test69_heldout_role.jsonl}"
TEST33_VIEW_MANIFEST="${TEST33_VIEW_MANIFEST:-${TAG}_test33_heldout_role.manifest.json}"
TEST69_VIEW_MANIFEST="${TEST69_VIEW_MANIFEST:-${TAG}_test69_heldout_role.manifest.json}"
UPSTREAM_OFFLINE="${UPSTREAM_OFFLINE:-${TAG}_offline_train.jsonl}"
UPSTREAM_ONLINE="${UPSTREAM_ONLINE:-${TAG}_sealed_online.jsonl}"
UPSTREAM_TEST="${UPSTREAM_TEST:-${TAG}_locked_test.jsonl}"
UPSTREAM_SUMMARY="${UPSTREAM_SUMMARY:-${TAG}_feedback_summary.json}"
UPSTREAM_AUDIT="${UPSTREAM_AUDIT:-${TAG}_feedback_audit.json}"
TRAIN_JSONL="${TRAIN_JSONL:-${TAG}_train.jsonl}"
TEST_JSONL="${TEST_JSONL:-${TAG}_test.jsonl}"
DATA_SUMMARY="${DATA_SUMMARY:-${TAG}_data_summary.json}"
DATA_AUDIT="${DATA_AUDIT:-${TAG}_data_audit.json}"
BASE_PREFLIGHT="${BASE_PREFLIGHT:-${TAG}_base_seed42.preflight.json}"
AGGREGATE_JSON="${AGGREGATE_JSON:-${TAG}_three_seed_aggregate.json}"
AGGREGATE_CSV="${AGGREGATE_CSV:-${TAG}_three_seed_rows.csv}"

readonly OFFLINE_LOADS_PER_NETWORK=32
readonly ONLINE_LOADS_PER_NETWORK=1
readonly TEST_LOADS_PER_NETWORK=32
readonly CANDIDATE_POOL_SIZE=16
readonly CANDIDATE_SEED=20260721
readonly ROW_SEED=20260725
readonly TARGET_TEMPERATURE=0.20
readonly MAX_LENGTH=1024
readonly CANDIDATE_BATCH_SIZE=4
readonly EPOCHS=4
readonly TOPK=3
readonly LEARNING_RATE=2e-6
readonly GRAD_ACCUM=4
readonly MAX_GRAD_NORM=1.0
readonly LIST_TEMPERATURE=1.0
readonly LAMBDA_BCE=1.0
readonly LAMBDA_LISTWISE=0.5
readonly LAMBDA_HARD=1.0
readonly HARD_MARGIN=0.5
readonly BETA_REFERENCE=0.02
readonly GRADIENT_CHECKPOINTING=1
readonly PHYSICS_TIMEOUT_S="${PHYSICS_TIMEOUT_S:-60.0}"
readonly BOOTSTRAP_REPS="${BOOTSTRAP_REPS:-10000}"
readonly CONFIRM_SEEDS=(42 123 2025)

for path in \
  "$TRAIN33" "$TRAIN69" "$TEST33_RAW" "$TEST69_RAW" \
  "$PILOT_TEST_JSONL" "$PILOT_GATE" "$PILOT_RECHECK_GATE" \
  "$SFT/adapter_config.json" "$SFT/adapter_model.safetensors" \
  "$BASE_MODEL/config.json" "$BASE_MODEL/tokenizer_config.json"; do
  test -e "$path" || { echo "missing confirmation input: $path" >&2; exit 2; }
done

if [[ "$AGGREGATE_ONLY" == "1" ]]; then
  CURRENT_STAGE="aggregate"
  test ! -e "$AGGREGATE_JSON" || { echo "refusing to overwrite $AGGREGATE_JSON" >&2; exit 2; }
  test ! -e "$AGGREGATE_CSV" || { echo "refusing to overwrite $AGGREGATE_CSV" >&2; exit 2; }
  GATE_ARGS=()
  for seed in "${CONFIRM_SEEDS[@]}"; do
    gate="output_${TAG}_s${seed}/gridrank_select_gate.json"
    test -f "$gate" || { echo "missing seed gate: $gate" >&2; exit 2; }
    GATE_ARGS+=(--gate "${seed}=${gate}")
  done
  "$TRAIN_PYTHON_BIN" -u aggregate_gridrank_select_confirm.py \
    "${GATE_ARGS[@]}" --test_jsonl "$TEST_JSONL" \
    --output_json "$AGGREGATE_JSON" --output_csv "$AGGREGATE_CSV" \
    --bootstrap_reps "$BOOTSTRAP_REPS" --bootstrap_seed 20260725
  exit $?
fi

if [[ "$PREFLIGHT_ONLY" == "1" ]]; then
  echo "=== 1/8 BUILD/VERIFY RAW-TEST NO-ORACLE ROLE VIEWS ==="
  CURRENT_STAGE="test_role_views"
  if [[ ! -e "$TEST33_VIEW" && ! -e "$TEST33_VIEW_MANIFEST" ]]; then
    "$TRAIN_PYTHON_BIN" -B make_gridrank_confirm_state_view.py --mode build \
      --input "$TEST33_RAW" --output_jsonl "$TEST33_VIEW" \
      --manifest_json "$TEST33_VIEW_MANIFEST"
  elif [[ ! -e "$TEST33_VIEW" || ! -e "$TEST33_VIEW_MANIFEST" ]]; then
    echo "partial 33-bus confirmation view; use a new TAG" >&2; exit 2
  fi
  if [[ ! -e "$TEST69_VIEW" && ! -e "$TEST69_VIEW_MANIFEST" ]]; then
    "$TRAIN_PYTHON_BIN" -B make_gridrank_confirm_state_view.py --mode build \
      --input "$TEST69_RAW" --output_jsonl "$TEST69_VIEW" \
      --manifest_json "$TEST69_VIEW_MANIFEST"
  elif [[ ! -e "$TEST69_VIEW" || ! -e "$TEST69_VIEW_MANIFEST" ]]; then
    echo "partial 69-bus confirmation view; use a new TAG" >&2; exit 2
  fi
  "$TRAIN_PYTHON_BIN" -B make_gridrank_confirm_state_view.py --mode verify \
    --input "$TEST33_RAW" --output_jsonl "$TEST33_VIEW" \
    --manifest_json "$TEST33_VIEW_MANIFEST"
  "$TRAIN_PYTHON_BIN" -B make_gridrank_confirm_state_view.py --mode verify \
    --input "$TEST69_RAW" --output_jsonl "$TEST69_VIEW" \
    --manifest_json "$TEST69_VIEW_MANIFEST"

  echo "=== 2/8 DEPENDENCY-LIGHT CONFIRMATION REGRESSIONS ==="
  CURRENT_STAGE="dependency_regression"
  "$TRAIN_PYTHON_BIN" -B verify_gridrank_select.py
  "$TRAIN_PYTHON_BIN" -B verify_gridrank_select_confirm.py \
    --test_raw "33=$TEST33_RAW" --test_raw "69=$TEST69_RAW"

  echo "=== 3/8 BUILD LOCKED TRAIN/TEST PHYSICS OUTCOMES ==="
  CURRENT_STAGE="physics_data_build"
  data_existing=0
  for path in "$UPSTREAM_OFFLINE" "$UPSTREAM_ONLINE" "$UPSTREAM_TEST" "$UPSTREAM_SUMMARY"; do
    test -e "$path" && data_existing=$((data_existing + 1))
  done
  if [[ "$data_existing" == "0" ]]; then
    "$TRAIN_PYTHON_BIN" -u build_gridrank_feedback.py \
      --train_source "33=$TRAIN33" --train_source "69=$TRAIN69" \
      --validation_source "33=$TEST33_VIEW" --validation_source "69=$TEST69_VIEW" \
      --offline_loads_per_network "$OFFLINE_LOADS_PER_NETWORK" \
      --online_loads_per_network "$ONLINE_LOADS_PER_NETWORK" \
      --test_loads_per_network "$TEST_LOADS_PER_NETWORK" \
      --candidate_pool_size "$CANDIDATE_POOL_SIZE" \
      --candidate_seed "$CANDIDATE_SEED" --row_seed "$ROW_SEED" \
      --physics_backend pandapower-subprocess \
      --physics_python "$PHYSICS_PYTHON_BIN" \
      --physics_timeout_s "$PHYSICS_TIMEOUT_S" \
      --offline_out "$UPSTREAM_OFFLINE" --online_out "$UPSTREAM_ONLINE" \
      --test_out "$UPSTREAM_TEST" --summary_out "$UPSTREAM_SUMMARY"
  elif [[ "$data_existing" != "4" ]]; then
    echo "partial confirmation physics artifacts; use a new TAG" >&2; exit 2
  else
    echo "reusing complete confirmation physics artifacts"
  fi

  echo "=== 4/8 AUDIT PROVENANCE + LIVE PANDAPOWER REPLAY ==="
  CURRENT_STAGE="physics_data_audit"
  if [[ ! -e "$UPSTREAM_AUDIT" ]]; then
    "$TRAIN_PYTHON_BIN" -u audit_gridrank_feedback.py \
      --train_source "33=$TRAIN33" --train_source "69=$TRAIN69" \
      --validation_source "33=$TEST33_VIEW" --validation_source "69=$TEST69_VIEW" \
      --offline_jsonl "$UPSTREAM_OFFLINE" --online_jsonl "$UPSTREAM_ONLINE" \
      --test_jsonl "$UPSTREAM_TEST" --summary_json "$UPSTREAM_SUMMARY" \
      --physics_python "$PHYSICS_PYTHON_BIN" \
      --physics_timeout_s "$PHYSICS_TIMEOUT_S" --replay_states_per_network 1 \
      --output "$UPSTREAM_AUDIT"
  fi

  echo "=== 5/8 DERIVE FROZEN EXCHANGE-ONLY LOSS RANKING ==="
  CURRENT_STAGE="select_data_build"
  select_existing=0
  for path in "$TRAIN_JSONL" "$TEST_JSONL" "$DATA_SUMMARY"; do
    test -e "$path" && select_existing=$((select_existing + 1))
  done
  if [[ "$select_existing" == "0" ]]; then
    "$TRAIN_PYTHON_BIN" -u build_gridrank_select.py \
      --upstream_summary "$UPSTREAM_SUMMARY" --upstream_audit "$UPSTREAM_AUDIT" \
      --offline_jsonl "$UPSTREAM_OFFLINE" --test_jsonl "$UPSTREAM_TEST" \
      --train_out "$TRAIN_JSONL" --test_out "$TEST_JSONL" \
      --summary_out "$DATA_SUMMARY" --target_temperature "$TARGET_TEMPERATURE"
  elif [[ "$select_existing" != "3" ]]; then
    echo "partial confirmation Select artifacts; use a new TAG" >&2; exit 2
  fi

  echo "=== 6/8 AUDIT EXCHANGE-ONLY DERIVATION ==="
  CURRENT_STAGE="select_data_audit"
  if [[ ! -e "$DATA_AUDIT" ]]; then
    "$TRAIN_PYTHON_BIN" -u audit_gridrank_select.py \
      --upstream_summary "$UPSTREAM_SUMMARY" --upstream_audit "$UPSTREAM_AUDIT" \
      --offline_jsonl "$UPSTREAM_OFFLINE" --test_jsonl "$UPSTREAM_TEST" \
      --select_summary "$DATA_SUMMARY" --train_jsonl "$TRAIN_JSONL" \
      --select_test_jsonl "$TEST_JSONL" --output "$DATA_AUDIT"
  fi

  echo "=== 7/8 CREATE BASE HASH/MODEL/PROMPT PREFLIGHT ==="
  CURRENT_STAGE="base_preflight"
  if [[ ! -e "$BASE_PREFLIGHT" ]]; then
    "$TRAIN_PYTHON_BIN" -u preflight_gridrank_select.py \
      --upstream_summary "$UPSTREAM_SUMMARY" --upstream_audit "$UPSTREAM_AUDIT" \
      --offline_jsonl "$UPSTREAM_OFFLINE" --upstream_test_jsonl "$UPSTREAM_TEST" \
      --train_jsonl "$TRAIN_JSONL" --test_jsonl "$TEST_JSONL" \
      --data_summary "$DATA_SUMMARY" --data_audit "$DATA_AUDIT" \
      --resume_adapter_path "$SFT" --base_model "$BASE_MODEL" \
      --physics_python "$PHYSICS_PYTHON_BIN" --physics_timeout_s "$PHYSICS_TIMEOUT_S" \
      --output "$BASE_PREFLIGHT" --max_length "$MAX_LENGTH" \
      --candidate_batch_size "$CANDIDATE_BATCH_SIZE" --epochs "$EPOCHS" --topk "$TOPK" \
      --learning_rate "$LEARNING_RATE" --grad_accum "$GRAD_ACCUM" \
      --max_grad_norm "$MAX_GRAD_NORM" --list_temperature "$LIST_TEMPERATURE" \
      --lambda_bce "$LAMBDA_BCE" --lambda_listwise "$LAMBDA_LISTWISE" \
      --lambda_hard "$LAMBDA_HARD" --hard_margin "$HARD_MARGIN" \
      --beta_reference "$BETA_REFERENCE" --seed 42 \
      --gradient_checkpointing "$GRADIENT_CHECKPOINTING" \
      --bootstrap_reps "$BOOTSTRAP_REPS"
  fi

  echo "=== 8/8 CREATE THREE PREREGISTERED SEED MANIFESTS ==="
  CURRENT_STAGE="seed_manifests"
  for seed in "${CONFIRM_SEEDS[@]}"; do
    manifest="${TAG}_s${seed}.preflight.json"
    out="output_${TAG}_s${seed}"
    test ! -e "$out" || { echo "seed output already exists: $out" >&2; exit 2; }
    if [[ ! -e "$manifest" ]]; then
      "$TRAIN_PYTHON_BIN" -u preflight_gridrank_select_confirm.py --mode create \
        --base_preflight "$BASE_PREFLIGHT" --upstream_summary "$UPSTREAM_SUMMARY" \
        --train_jsonl "$TRAIN_JSONL" --test_jsonl "$TEST_JSONL" \
        --data_summary "$DATA_SUMMARY" --data_audit "$DATA_AUDIT" \
        --pilot_test_jsonl "$PILOT_TEST_JSONL" --pilot_gate "$PILOT_GATE" \
        --pilot_recheck_gate "$PILOT_RECHECK_GATE" \
        --test_raw "33=$TEST33_RAW" --test_raw "69=$TEST69_RAW" \
        --test_view "33=$TEST33_VIEW" --test_view "69=$TEST69_VIEW" \
        --test_view_manifest "33=$TEST33_VIEW_MANIFEST" \
        --test_view_manifest "69=$TEST69_VIEW_MANIFEST" \
        --resume_adapter_path "$SFT" --base_model "$BASE_MODEL" \
        --physics_python "$PHYSICS_PYTHON_BIN" --bootstrap_reps "$BOOTSTRAP_REPS" \
        --seed "$seed" --output "$manifest"
    fi
    "$TRAIN_PYTHON_BIN" -B preflight_gridrank_select_confirm.py --mode verify \
      --base_model "$BASE_MODEL" --physics_python "$PHYSICS_PYTHON_BIN" \
      --bootstrap_reps "$BOOTSTRAP_REPS" --seed "$seed" --output "$manifest"
  done
  echo "=== GRIDRANK-SELECT CONFIRMATION CPU PREFLIGHT COMPLETE; GPU NOT STARTED ==="
  exit 0
fi

TRAIN_SEED="${TRAIN_SEED:-}"
case "$TRAIN_SEED" in
  42|123|2025) ;;
  *) echo "TRAIN_SEED must be 42, 123, or 2025" >&2; exit 2 ;;
esac
MANIFEST="${MANIFEST:-${TAG}_s${TRAIN_SEED}.preflight.json}"
OUT="${OUT:-output_${TAG}_s${TRAIN_SEED}}"
test -f "$MANIFEST" || { echo "missing seed preflight: $MANIFEST" >&2; exit 2; }
test ! -e "$OUT" || { echo "refusing to reuse output: $OUT" >&2; exit 2; }
test ! -e "${OUT}.log" || { echo "refusing to overwrite log: ${OUT}.log" >&2; exit 2; }

echo "=== 1/3 VERIFY LOCKED CONFIRMATION MANIFEST ==="
CURRENT_STAGE="runtime_lock"
"$TRAIN_PYTHON_BIN" -B preflight_gridrank_select_confirm.py --mode verify \
  --base_model "$BASE_MODEL" --physics_python "$PHYSICS_PYTHON_BIN" \
  --bootstrap_reps "$BOOTSTRAP_REPS" --seed "$TRAIN_SEED" --output "$MANIFEST"

echo "=== 2/3 CUDA + NF4 READINESS ==="
CURRENT_STAGE="gpu_readiness"
"$TRAIN_PYTHON_BIN" -B - <<'PY'
import json, torch
from transformers import BitsAndBytesConfig
checks = {"cuda": bool(torch.cuda.is_available()), "device_count": torch.cuda.device_count() > 0}
config = BitsAndBytesConfig(load_in_4bit=True, bnb_4bit_quant_type="nf4",
    bnb_4bit_compute_dtype=torch.float16, bnb_4bit_use_double_quant=True)
checks["nf4_config"] = bool(config.load_in_4bit and config.bnb_4bit_quant_type == "nf4")
result = {"msg":"GridRank-Select confirmation CUDA readiness", "checks":checks,
          "readiness_pass":all(checks.values())}
if checks["cuda"]: result["device"] = torch.cuda.get_device_name(0)
print(json.dumps(result, ensure_ascii=False))
raise SystemExit(0 if result["readiness_pass"] else 2)
PY

echo "=== 3/3 TRAIN FROZEN METHOD + LIVE LOCKED-TEST GATE ==="
CURRENT_STAGE="gpu_training"
set +e
"$TRAIN_PYTHON_BIN" -u train_gridrank_select_confirm.py \
  --train_jsonl "$TRAIN_JSONL" --test_jsonl "$TEST_JSONL" \
  --data_summary "$DATA_SUMMARY" --data_audit "$DATA_AUDIT" \
  --preflight_manifest "$MANIFEST" --resume_adapter_path "$SFT" \
  --output_dir "$OUT" --base_model "$BASE_MODEL" \
  --physics_python "$PHYSICS_PYTHON_BIN" --physics_timeout_s "$PHYSICS_TIMEOUT_S" \
  --max_length "$MAX_LENGTH" --candidate_batch_size "$CANDIDATE_BATCH_SIZE" \
  --epochs "$EPOCHS" --topk "$TOPK" --learning_rate "$LEARNING_RATE" \
  --grad_accum "$GRAD_ACCUM" --max_grad_norm "$MAX_GRAD_NORM" \
  --list_temperature "$LIST_TEMPERATURE" --lambda_bce "$LAMBDA_BCE" \
  --lambda_listwise "$LAMBDA_LISTWISE" --lambda_hard "$LAMBDA_HARD" \
  --hard_margin "$HARD_MARGIN" --beta_reference "$BETA_REFERENCE" \
  --seed "$TRAIN_SEED" --gradient_checkpointing "$GRADIENT_CHECKPOINTING" \
  --bootstrap_reps "$BOOTSTRAP_REPS" 2>&1 | tee "${OUT}.log"
PIPE_STATUS=("${PIPESTATUS[@]}")
set -e
RUN_RC="${PIPE_STATUS[0]}"
if (( RUN_RC == 0 && PIPE_STATUS[1] != 0 )); then RUN_RC="${PIPE_STATUS[1]}"; fi

CURRENT_STAGE="decision_artifact"
if [[ -f "$OUT/gridrank_select_gate.json" ]]; then
  GATE_JSON="$($TRAIN_PYTHON_BIN -B -c '
import json,sys
p=json.load(open(sys.argv[1],encoding="utf-8"))
if p.get("schema")!="gridrank-select-confirm-seed-gate-v1": raise ValueError("bad schema")
if p.get("confirmation_seed")!=int(sys.argv[2]): raise ValueError("bad seed")
if p.get("row_level_paired_evidence") is not True: raise ValueError("missing rows")
print(json.dumps(p,ensure_ascii=False))
' "$OUT/gridrank_select_gate.json" "$TRAIN_SEED")"
  printf '%s\n' "$GATE_JSON"
  GATE_JSON_PRINTED=1
elif (( RUN_RC == 0 )); then
  echo "confirmation trainer returned success without gate JSON" >&2; exit 3
fi
exit "$RUN_RC"
