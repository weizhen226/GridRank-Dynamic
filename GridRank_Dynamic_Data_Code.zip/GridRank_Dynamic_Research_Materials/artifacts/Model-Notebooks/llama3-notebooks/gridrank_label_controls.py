"""Gridrank label controls utilities."""

from __future__ import annotations

import copy
import hashlib
import json
import math
import random
from collections import Counter

from gridrank_traditional_baselines import score_method


VARIANTS = ("shuffled_labels", "lindistflow_labels")
SUPERVISION_FIELDS = ("accepted_by_gate", "target_prob", "safe_utility")
INPUT_CANDIDATE_FIELDS = ("action", "candidate_feature_text")


def _canonical_hash(value) -> str:
    payload = json.dumps(
        value, ensure_ascii=False, sort_keys=True, separators=(",", ":")
    ).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def input_surface(rows) -> list[dict]:
    return [
        {
            "instance_id": row["instance_id"],
            "state_text": row["state_text"],
            "instruction_text": row["instruction_text"],
            "candidates": [
                {field: candidate[field] for field in INPUT_CANDIDATE_FIELDS}
                for candidate in row["candidates"]
            ],
        }
        for row in rows
    ]


def supervision_surface(rows) -> list[dict]:
    return [
        {
            "instance_id": row["instance_id"],
            "candidates": [
                {field: candidate[field] for field in SUPERVISION_FIELDS}
                for candidate in row["candidates"]
            ],
        }
        for row in rows
    ]


def input_sha256(rows) -> str:
    return _canonical_hash(input_surface(rows))


def supervision_sha256(rows) -> str:
    return _canonical_hash(supervision_surface(rows))


def _derangement(row: dict, seed: int) -> list[int]:
    count = len(row["candidates"])
    if count < 2:
        raise ValueError("label control requires at least two candidates")
    digest = hashlib.sha256(
        f'{seed}:{row["physical_state_sha256"]}'.encode("utf-8")
    ).digest()
    rng = random.Random(int.from_bytes(digest, "big"))
    for _ in range(100):
        order = list(range(count))
        rng.shuffle(order)
        if all(index != donor for index, donor in enumerate(order)):
            return order
    
    offset = 1 + int.from_bytes(digest[:8], "big") % (count - 1)
    return [(index + offset) % count for index in range(count)]


def _softmax(values: list[float], temperature: float) -> list[float]:
    if temperature <= 0 or not math.isfinite(temperature):
        raise ValueError("target temperature must be positive and finite")
    if not values or any(not math.isfinite(float(value)) for value in values):
        raise ValueError("control scores must be nonempty and finite")
    maximum = max(values)
    weights = [math.exp((float(value) - maximum) / temperature) for value in values]
    total = sum(weights)
    if not math.isfinite(total) or total <= 0:
        raise ValueError("invalid control softmax normalizer")
    return [weight / total for weight in weights]


def _shuffle_row(row: dict, seed: int) -> dict:
    output = copy.deepcopy(row)
    source = row["candidates"]
    assignment = _derangement(row, seed)
    for candidate, donor_index in zip(output["candidates"], assignment):
        donor = source[donor_index]
        for field in SUPERVISION_FIELDS:
            candidate[field] = donor[field]
    return output


def _lindistflow_row(
    row: dict,
    target_temperature: float,
    proxy_scorer=None,
) -> dict:
    output = copy.deepcopy(row)
    actions = [candidate["action"] for candidate in row["candidates"]]
    scorer = proxy_scorer or (
        lambda state_text, values: score_method(
            state_text, values, "lindistflow_tree"
        )
    )
    scores = [float(value) for value in scorer(row["state_text"], actions)]
    if len(scores) != len(actions) or any(not math.isfinite(value) for value in scores):
        raise ValueError(f'invalid LinDistFlow scores: {row["instance_id"]}')
    targets = _softmax(scores, target_temperature)


    labels = [value > 0.0 for value in scores]
    for candidate, label, target, score in zip(
        output["candidates"], labels, targets, scores
    ):
        candidate["accepted_by_gate"] = bool(label)
        candidate["target_prob"] = float(target)
        candidate["safe_utility"] = float(score)
    return output


def transform_rows(
    rows: list[dict],
    variant: str,
    *,
    label_seed: int,
    target_temperature: float,
    proxy_scorer=None,
) -> list[dict]:
    if variant not in VARIANTS:
        raise ValueError(f"unknown label control: {variant}")
    if variant == "shuffled_labels":
        output = [_shuffle_row(row, label_seed) for row in rows]
    else:
        output = [
            _lindistflow_row(row, target_temperature, proxy_scorer)
            for row in rows
        ]
    validate_control(rows, output, variant)
    return output


def validate_control(original: list[dict], controlled: list[dict], variant: str) -> None:
    if len(original) != len(controlled) or not original:
        raise ValueError("control row count changed")
    if input_sha256(original) != input_sha256(controlled):
        raise ValueError("model-visible inputs changed under label control")
    if supervision_sha256(original) == supervision_sha256(controlled):
        raise ValueError("label control did not change supervision")
    for before, after in zip(original, controlled):
        if before["instance_id"] != after["instance_id"]:
            raise ValueError("control row identity changed")
        if len(before["candidates"]) != len(after["candidates"]):
            raise ValueError("control candidate count changed")
        targets = [float(item["target_prob"]) for item in after["candidates"]]
        if any(value < 0 or not math.isfinite(value) for value in targets):
            raise ValueError("control target probability is invalid")
        if not math.isclose(sum(targets), 1.0, rel_tol=0.0, abs_tol=1e-8):
            raise ValueError("control target probabilities do not sum to one")
    labels = [
        bool(candidate["accepted_by_gate"])
        for row in controlled for candidate in row["candidates"]
    ]
    if not any(labels) or all(labels):
        raise ValueError("control BCE does not contain both classes")
    if variant == "shuffled_labels":
        before = Counter(
            (
                bool(candidate["accepted_by_gate"]),
                float(candidate["target_prob"]),
                candidate["safe_utility"],
            )
            for row in original for candidate in row["candidates"]
        )
        after = Counter(
            (
                bool(candidate["accepted_by_gate"]),
                float(candidate["target_prob"]),
                candidate["safe_utility"],
            )
            for row in controlled for candidate in row["candidates"]
        )
        if before != after:
            raise ValueError("shuffled control changed the supervision multiset")


def audit_control(original: list[dict], controlled: list[dict], variant: str) -> dict:
    validate_control(original, controlled, variant)
    candidates = sum(len(row["candidates"]) for row in original)
    label_changes = 0
    argmax_changes = 0
    positives = 0
    for before, after in zip(original, controlled):
        label_changes += sum(
            bool(left["accepted_by_gate"]) != bool(right["accepted_by_gate"])
            for left, right in zip(before["candidates"], after["candidates"])
        )
        before_best = max(
            range(len(before["candidates"])),
            key=lambda index: (
                float(before["candidates"][index]["target_prob"]),
                before["candidates"][index]["action"],
            ),
        )
        after_best = max(
            range(len(after["candidates"])),
            key=lambda index: (
                float(after["candidates"][index]["target_prob"]),
                after["candidates"][index]["action"],
            ),
        )
        argmax_changes += int(before_best != after_best)
        positives += sum(bool(item["accepted_by_gate"]) for item in after["candidates"])
    return {
        "variant": variant,
        "rows": len(original),
        "candidates": candidates,
        "input_sha256_before": input_sha256(original),
        "input_sha256_after": input_sha256(controlled),
        "supervision_sha256_before": supervision_sha256(original),
        "supervision_sha256_after": supervision_sha256(controlled),
        "positive_labels": positives,
        "negative_labels": candidates - positives,
        "label_change_rate_vs_ac": label_changes / candidates,
        "target_argmax_change_rate_vs_ac": argmax_changes / len(original),
        "model_visible_inputs_identical": input_sha256(original) == input_sha256(controlled),
        "supervision_changed": supervision_sha256(original) != supervision_sha256(controlled),
    }
