"""Build GridRank simbench difficulty."""

from __future__ import annotations

import argparse
import hashlib
import itertools
import json
import math
from collections import Counter, defaultdict
from pathlib import Path

import gridrank_simbench as grid


SCHEMA = "gridrank-simbench-difficulty-summary-v1"
ROW_SCHEMA = "gridrank-select-row-v1"
INSTRUCTION = (
    "Choose the feasible exchange that cuts resistive losses the most; "
    "otherwise leave every switch as it is."
)
TARGET_TEMPERATURE = 0.20
OPTIMAL_TOL = 1e-12
HARD_REGRET_PCT = 0.05
LOCKED_NONNOOP_CANDIDATES = 32
LOCKED_THRESHOLDS = {
    "minimum_structurally_eligible_networks": 2,
    "minimum_total_states": 64,
    "minimum_improvable_state_rate": 0.50,
    "minimum_proxy_topk_miss_rate": 0.10,
    "minimum_proxy_safe_regret_mean": 0.02,
    "minimum_random_topk_expected_regret_mean": 0.05,
    "minimum_hard_states": 8,
    "minimum_hard_networks": 2,
}


def file_sha256(path):
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def write_jsonl(path, rows):
    with open(path, "w", encoding="utf-8", newline="\n") as handle:
        for row in rows:
            handle.write(json.dumps(row, ensure_ascii=False, separators=(",", ":")) + "\n")


def _physics_fields(action, feature, anchor, outcome):
    reduction = 0.0 if action == grid.NOOP else outcome["reduction_pct"]
    valid = bool(outcome["feedback_valid"])
    feasible = bool(outcome["feasible"])
    utility = float(reduction) if valid and feasible and reduction is not None else None
    accepted = utility is not None and (
        action == grid.NOOP or utility > grid.DEADBAND_PCT
    )
    return {
        "action": action,
        "candidate_feature_text": feature,
        "feedback_revealed": True,
        "feedback_valid": valid,
        "feasible": feasible,
        "reason": outcome["reason"],
        "reduction_pct": reduction,
        "anchor_loss_kw": anchor["loss_kw"],
        "candidate_loss_kw": outcome["loss_kw"],
        "anchor_min_vm_pu": anchor["min_vm_pu"],
        "candidate_min_vm_pu": outcome["min_vm_pu"],
        "candidate_max_vm_pu": outcome["max_vm_pu"],
        "instruction_utility": utility,
        "safe_utility": utility if accepted else None,
        "accepted_by_gate": bool(accepted),
    }


def _ranking_fields(candidates):
    eligible = [
        bool(item["feedback_valid"] and item["feasible"])
        and item["reduction_pct"] is not None
        for item in candidates
    ]
    if not any(eligible):
        raise ValueError("state has no AC-feasible ranking candidate")
    utilities = [
        float(item["reduction_pct"]) if eligible[index] else float("-inf")
        for index, item in enumerate(candidates)
    ]
    best = max(utilities)
    optimal = {
        index for index, value in enumerate(utilities)
        if eligible[index]
        and math.isclose(value, best, rel_tol=OPTIMAL_TOL, abs_tol=OPTIMAL_TOL)
    }
    order = sorted(
        range(len(candidates)),
        key=lambda index: (
            not eligible[index], -utilities[index], candidates[index]["action"]
        ),
    )
    ranks = {index: rank for rank, index in enumerate(order)}
    finite = [utilities[index] for index in range(len(candidates)) if eligible[index]]
    worst = min(finite)
    scale = max(best - worst, 1e-12)
    regrets = [
        min(1.0, max(0.0, (best - utilities[index]) / scale))
        if eligible[index] else 1.0
        for index in range(len(candidates))
    ]
    weights = [
        math.exp((utilities[index] - best) / TARGET_TEMPERATURE)
        if eligible[index] else 0.0
        for index in range(len(candidates))
    ]
    total = sum(weights)
    output = []
    for index, item in enumerate(candidates):
        record = dict(item)
        record.update({
            "ranking_utility": utilities[index] if eligible[index] else None,
            "ranking_eligible": bool(eligible[index]),
            "is_ranking_optimal": index in optimal,
            "ranking_regret": regrets[index],
            "ranking_rank": ranks[index],
            "target_prob": weights[index] / total,
        })
        output.append(record)
    return output, order[0], sorted(optimal)


def build_row(code, state_index, args):
    net = grid.state_network(code, state_index, args.scenario_seed)
    state_sha = grid.state_identity(code, net, state_index, args.scenario_seed)
    selected = grid.select_action_pool(
        code, state_sha, args.nonnoop_candidates, args.candidate_seed
    )
    actions = [item["action"] for item in selected]
    features = grid.candidate_feature_texts(code, net, actions)
    anchor, outcomes = grid.score_state(
        code, state_index, args.scenario_seed, actions
    )
    if not anchor["feedback_valid"] or not anchor["feasible"]:
        return None, "anchor_not_operational", anchor
    if len(outcomes) != len(actions):
        return None, "candidate_evaluation_incomplete", anchor
    if not all(item["feedback_valid"] for item in outcomes):
        return None, "candidate_feedback_invalid", anchor
    if not any(item["feasible"] for item in outcomes):
        return None, "no_feasible_exchange", anchor
    by_action = {item["action"]: item for item in outcomes}
    raw = [
        _physics_fields(action, features[action], anchor, by_action[action])
        for action in actions
    ]
    candidates, desired, optimal = _ranking_fields(raw)
    anchor_outcome = dict(anchor)
    anchor_outcome["reduction_pct"] = 0.0
    gate_anchor = {"role": "noop-anchor-only"}
    gate_anchor.update(_physics_fields(
        grid.NOOP, features[grid.NOOP], anchor, anchor_outcome
    ))
    network = grid.network_id(code)
    return {
        "schema": ROW_SCHEMA,
        "instance_id": f"simbench-difficulty:test:{code}:{state_sha}",
        "partition": "test",
        "upstream_instance_id": f"simbench:{code}:{state_index}",
        "source_split": "external-unseen-model-blind",
        "source_instance_id": f"simbench:{code}:{state_index}",
        "load_id": f"{network}:{state_index}",
        "network_id": network,
        "simbench_code": code,
        "state_index": int(state_index),
        "operating_regime": grid.operating_regime(state_index),
        "state_text": grid.state_text(code, net),
        "physical_state_sha256": state_sha,
        "full_candidate_count": len(grid.complete_actions(code)) + 1,
        "upstream_candidate_pool_sha256": hashlib.sha256(
            "\n".join(actions).encode()
        ).hexdigest(),
        "instruction_id": "loss",
        "instruction_style": "unseen-simbench-difficulty-test",
        "instruction_text": INSTRUCTION,
        "feedback_status": "authoritative-gridrank-select-v1",
        "desired_index": desired,
        "desired_action": candidates[desired]["action"],
        "optimal_indices": optimal,
        "optimal_actions": [candidates[index]["action"] for index in optimal],
        "candidates": candidates,
        "gate_anchor": gate_anchor,
    }, "included", anchor


def _accepted_value(candidate):
    if candidate.get("accepted_by_gate") is not True:
        return None
    value = candidate.get("safe_utility")
    if value is None or not math.isfinite(float(value)):
        return None
    return float(value)


def row_difficulty(row, topk=3):
    values = [_accepted_value(item) for item in row["candidates"]]
    anchor = _accepted_value(row["gate_anchor"])
    if anchor is None:
        raise ValueError("difficulty row lacks operational no-op anchor")
    safe_values = [value for value in values if value is not None]
    pool_best = max([anchor, *safe_values])
    scores = [grid.proxy_score(item["candidate_feature_text"]) for item in row["candidates"]]
    ranked = sorted(
        range(len(scores)),
        key=lambda index: (-scores[index], row["candidates"][index]["action"]),
    )
    proxy_indices = ranked[:topk]
    proxy_selected = max([
        anchor,
        *[values[index] for index in proxy_indices if values[index] is not None],
    ])
    proxy_regret = max(0.0, pool_best - proxy_selected)
    random_regrets = []
    for indices in itertools.combinations(range(len(values)), topk):
        selected = max([
            anchor,
            *[values[index] for index in indices if values[index] is not None],
        ])
        random_regrets.append(max(0.0, pool_best - selected))
    optimal = {
        index for index, value in enumerate(values)
        if value is not None and abs(value - pool_best) <= 1e-12
    }
    return {
        "instance_id": row["instance_id"],
        "network_id": row["network_id"],
        "operating_regime": row.get("operating_regime", "unknown"),
        "physical_state_sha256": row["physical_state_sha256"],
        "improvable": pool_best > anchor + 1e-12,
        "pool_best_safe_utility": pool_best,
        "always_noop_safe_regret": max(0.0, pool_best - anchor),
        "proxy_topk_indices": proxy_indices,
        "proxy_topk_actions": [row["candidates"][index]["action"] for index in proxy_indices],
        "proxy_safe_regret": proxy_regret,
        "proxy_topk_miss": proxy_regret > 1e-12,
        "proxy_topk_contains_pool_optimum": bool(optimal.intersection(proxy_indices)),
        "random_topk_subset_count": len(random_regrets),
        "random_topk_expected_safe_regret": sum(random_regrets) / len(random_regrets),
        "hard": proxy_regret > HARD_REGRET_PCT,
        "accepted_candidate_count": sum(value is not None for value in values),
    }


def _mean(values):
    values = list(values)
    return 0.0 if not values else sum(values) / len(values)


def _difficulty_group(records):
    n = len(records)
    return {
        "states": n,
        "improvable_states": sum(item["improvable"] for item in records),
        "improvable_state_rate": _mean(item["improvable"] for item in records),
        "proxy_topk_miss_states": sum(item["proxy_topk_miss"] for item in records),
        "proxy_topk_miss_rate": _mean(item["proxy_topk_miss"] for item in records),
        "proxy_safe_regret_mean": _mean(item["proxy_safe_regret"] for item in records),
        "random_topk_expected_regret_mean": _mean(
            item["random_topk_expected_safe_regret"] for item in records
        ),
        "always_noop_safe_regret_mean": _mean(
            item["always_noop_safe_regret"] for item in records
        ),
        "hard_states": sum(item["hard"] for item in records),
        "hard_state_rate": _mean(item["hard"] for item in records),
        "hard_mean_headroom": _mean(
            item["proxy_safe_regret"] for item in records if item["hard"]
        ),
        "accepted_candidate_count_mean": _mean(
            item["accepted_candidate_count"] for item in records
        ),
    }


def difficulty_summary(rows, topk=3):
    records = [row_difficulty(row, topk) for row in rows]
    by_network = defaultdict(list)
    by_regime = defaultdict(list)
    for item in records:
        by_network[item["network_id"]].append(item)
        by_regime[item["operating_regime"]].append(item)
    aggregate = _difficulty_group(records)
    aggregate["hard_networks"] = sum(
        any(item["hard"] for item in values) for values in by_network.values()
    )
    return {
        "definition": {
            "topk": int(topk),
            "hard_regret_threshold_pct": HARD_REGRET_PCT,
            "proxy": "loss_proxy_delta_pct from the frozen non-AC candidate interface",
            "random": "exact expectation over all C(K,topk) equal-budget subsets",
        },
        "aggregate": aggregate,
        "by_network": {
            network: _difficulty_group(values)
            for network, values in sorted(by_network.items())
        },
        "by_operating_regime": {
            regime: _difficulty_group(values)
            for regime, values in sorted(by_regime.items())
        },
        "state_records": records,
    }


def _partition_summary(rows):
    candidates = [item for row in rows for item in row["candidates"]]
    return {
        "rows": len(rows),
        "base_states": len({row["physical_state_sha256"] for row in rows}),
        "loads": len({row["load_id"] for row in rows}),
        "network_mix": dict(Counter(row["network_id"] for row in rows)),
        "operating_regime_mix": dict(Counter(row["operating_regime"] for row in rows)),
        "candidate_count_min": min((len(row["candidates"]) for row in rows), default=0),
        "candidate_count_max": max((len(row["candidates"]) for row in rows), default=0),
        "accepted_candidates": sum(item["accepted_by_gate"] for item in candidates),
        "unsafe_candidates": sum(not item["accepted_by_gate"] for item in candidates),
        "anchor_feasible_rate": _mean(row["gate_anchor"]["feasible"] for row in rows),
        "candidate_feedback_valid_rate": _mean(item["feedback_valid"] for item in candidates),
        "candidate_feasible_rate": _mean(item["feasible"] for item in candidates),
    }


def _gate_checks(rows, networks, difficulty, args):
    aggregate = difficulty["aggregate"]
    eligible = [item for item in networks.values() if item.get("structurally_eligible")]
    built = [item for item in eligible if item.get("states_built") == args.states_per_code]
    threshold = LOCKED_THRESHOLDS
    candidates = [item for row in rows for item in row["candidates"]]
    return {
        "predeclared_code_inventory_exact": set(networks) == set(grid.PREDECLARED_CODES),
        "structurally_eligible_networks_ge_2": (
            len(eligible) >= threshold["minimum_structurally_eligible_networks"]
        ),
        "all_structurally_eligible_networks_fully_built": len(built) == len(eligible),
        "total_states_ge_64": len(rows) >= threshold["minimum_total_states"],
        "unique_state_identities": len({row["physical_state_sha256"] for row in rows}) == len(rows),
        "fixed_32_exchange_pool": bool(rows) and all(
            len(row["candidates"]) == args.nonnoop_candidates for row in rows
        ),
        "all_anchors_operational": bool(rows) and all(
            row["gate_anchor"]["feedback_valid"]
            and row["gate_anchor"]["feasible"]
            for row in rows
        ),
        "all_candidate_feedback_valid": bool(candidates) and all(
            item["feedback_valid"] for item in candidates
        ),
        "improvable_state_rate_ge_50pct": (
            aggregate["improvable_state_rate"]
            >= threshold["minimum_improvable_state_rate"]
        ),
        "proxy_topk_miss_rate_ge_10pct": (
            aggregate["proxy_topk_miss_rate"]
            >= threshold["minimum_proxy_topk_miss_rate"]
        ),
        "proxy_safe_regret_mean_ge_0_02": (
            aggregate["proxy_safe_regret_mean"]
            >= threshold["minimum_proxy_safe_regret_mean"]
        ),
        "random_topk_expected_regret_mean_ge_0_05": (
            aggregate["random_topk_expected_regret_mean"]
            >= threshold["minimum_random_topk_expected_regret_mean"]
        ),
        "hard_states_ge_8": aggregate["hard_states"] >= threshold["minimum_hard_states"],
        "hard_cases_span_at_least_2_networks": (
            aggregate["hard_networks"] >= threshold["minimum_hard_networks"]
        ),
        "model_blind_build": True,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--states_per_code", type=int, default=32)
    parser.add_argument("--max_scanned_per_code", type=int, default=96)
    parser.add_argument("--nonnoop_candidates", type=int, default=LOCKED_NONNOOP_CANDIDATES)
    parser.add_argument("--scenario_seed", type=int, default=20260818)
    parser.add_argument("--candidate_seed", type=int, default=20260818)
    parser.add_argument("--topk", type=int, default=1)
    parser.add_argument("--out_jsonl", required=True)
    parser.add_argument("--out_summary", required=True)
    args = parser.parse_args()
    if args.states_per_code != 32 or args.max_scanned_per_code != 96:
        raise ValueError("locked qualification requires 32 states and scan cap 96 per code")
    if args.nonnoop_candidates != LOCKED_NONNOOP_CANDIDATES or args.topk != 1:
        raise ValueError("locked hard benchmark requires 32 exchanges and Top-1")
    for path in (args.out_jsonl, args.out_summary):
        if Path(path).exists():
            raise FileExistsError(f"refusing to overwrite {path}")

    versions = grid._check_runtime()
    code_inventory = grid.verify_predeclared_codes()
    networks = {}
    rows = []
    traces = {}
    for code in grid.PREDECLARED_CODES:
        trace = []
        traces[code] = trace
        try:
            net = grid.base_network(code)
            topology = grid.topology_audit(code, net)
            actions = grid.complete_actions(code)
            structurally_eligible = (
                all(topology["checks"].values())
                and len(actions) >= args.nonnoop_candidates
            )
            record = {
                "code": code,
                "network_id": grid.network_id(code),
                "inventory": grid.network_inventory(code, net),
                "network_fingerprint": grid.network_fingerprint(code, net),
                "topology": topology,
                "complete_action_count": len(actions),
                "structurally_eligible": bool(structurally_eligible),
                "states_requested": args.states_per_code,
                "states_built": 0,
                "states_scanned": 0,
                "error": None,
            }
            networks[code] = record
            if not structurally_eligible:
                continue
            for state_index in range(args.max_scanned_per_code):
                row, reason, anchor = build_row(code, state_index, args)
                trace.append({
                    "state_index": state_index,
                    "included": row is not None,
                    "reason": reason,
                    "anchor_reason": anchor.get("reason"),
                })
                record["states_scanned"] = state_index + 1
                if row is not None:
                    rows.append(row)
                    record["states_built"] += 1
                    if record["states_built"] % 8 == 0:
                        print(json.dumps({
                            "msg": "SimBench difficulty physics progress",
                            "code": code,
                            "states_complete": record["states_built"],
                            "states_target": args.states_per_code,
                            "states_scanned": state_index + 1,
                        }), flush=True)
                if record["states_built"] == args.states_per_code:
                    break
        except Exception as exc:
            networks.setdefault(code, {
                "code": code,
                "network_id": grid.network_id(code),
                "structurally_eligible": False,
                "states_requested": args.states_per_code,
                "states_built": 0,
                "states_scanned": 0,
            })["error"] = f"{type(exc).__name__}: {exc}"

    difficulty = difficulty_summary(rows, args.topk)
    checks = _gate_checks(rows, networks, difficulty, args)
    write_jsonl(args.out_jsonl, rows)
    summary = {
        "msg": "GridRank model-blind unseen SimBench difficulty qualification",
        "schema": SCHEMA,
        "benchmark_id": "gridrank-unseen-simbench-mv-difficulty-v1",
        "coverage_pass": all(checks.values()),
        "decision": (
            "authorize_frozen_llm_evaluation"
            if all(checks.values()) else "stop_before_gpu_evaluation"
        ),
        "training_performed": False,
        "model_loaded": False,
        "model_outputs_used_for_selection": False,
        "source": {
            "provider": "official SimBench Python package",
            "api": "simbench.get_simbench_net(code)",
            "runtime_versions": versions,
            "predeclared_code_check": code_inventory,
            "predeclared_codes": list(grid.PREDECLARED_CODES),
        },
        "protocol": {
            "trained_networks": ["IEEE33", "IEEE69"],
            "prior_external_test": "pandapower MV Oberrhein 179-bus",
            "state_selection": (
                "identity-ordered scan; include operational anchor and at least one "
                "AC-feasible exchange; no model output"
            ),
            "candidate_membership": (
                "complete topology-only internal K=1 enumeration then fixed SHA-256 truncation"
            ),
            "authoritative_feedback": "Pandapower Newton-Raphson AC power flow",
            "source_generation_domain": (
                "predeclared load_only/moderate_der/high_der regimes; generator and "
                "storage controls disabled"
            ),
            "states_per_structurally_eligible_code": args.states_per_code,
            "max_scanned_per_code": args.max_scanned_per_code,
            "nonnoop_candidates": args.nonnoop_candidates,
            "topk": args.topk,
            "scenario_seed": args.scenario_seed,
            "candidate_seed": args.candidate_seed,
        },
        "locked_thresholds": LOCKED_THRESHOLDS,
        "networks": networks,
        "selection_trace": traces,
        "partition": _partition_summary(rows),
        "difficulty": difficulty,
        "power_flow_calls": {
            "included_anchor": len(rows),
            "included_candidates": len(rows) * args.nonnoop_candidates,
            "selection_screen_upper_bound": sum(
                item.get("states_scanned", 0) for item in networks.values()
            ),
            "reported_total_lower_bound": len(rows) * (args.nonnoop_candidates + 1),
        },
        "artifact": {
            "path": str(Path(args.out_jsonl)),
            "sha256": file_sha256(args.out_jsonl),
        },
        "code_sha256": {
            "gridrank_simbench.py": file_sha256(Path(__file__).with_name("gridrank_simbench.py")),
            "build_gridrank_simbench_difficulty.py": file_sha256(__file__),
        },
        "checks": checks,
        "failed_checks": [name for name, passed in checks.items() if not passed],
    }
    
    summary["difficulty"]["state_records_sha256"] = hashlib.sha256(
        json.dumps(
            difficulty.pop("state_records"), sort_keys=True, separators=(",", ":")
        ).encode()
    ).hexdigest()
    with open(args.out_summary, "w", encoding="utf-8", newline="\n") as handle:
        json.dump(summary, handle, ensure_ascii=False, indent=2)
        handle.write("\n")
    print(json.dumps({
        "msg": summary["msg"],
        "coverage_pass": summary["coverage_pass"],
        "decision": summary["decision"],
        "partition": summary["partition"],
        "difficulty": summary["difficulty"],
        "failed_checks": summary["failed_checks"],
    }, ensure_ascii=False))


if __name__ == "__main__":
    main()
