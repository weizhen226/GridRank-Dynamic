#!/usr/bin/env bash
set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$HERE"

TAG="${TAG:-gridrank_dynamic_supplement_v1_20260908}"
CROSS_TAG="${CROSS_TAG:-gridrank_dynamic_cross_topology_v1_20260907}"
PREFLIGHT_ONLY="${PREFLIGHT_ONLY:-1}"
TRAIN_PYTHON="${TRAIN_PYTHON:-$(command -v python)}"

PREFLIGHT="${TAG}.preflight.json"
CACHED="${TAG}_cached.json"
LATENCY="${TAG}_latency.json"
OUTPUT_DIR="output_${TAG}"
GATE="${OUTPUT_DIR}/gridrank_dynamic_supplement_gate.json"
CROSS_PREFLIGHT="${CROSS_TAG}.preflight.json"
CROSS_GATE="output_${CROSS_TAG}/gridrank_dynamic_cross_topology_gate.json"
CROSS_RECORDS="output_${CROSS_TAG}/gridrank_dynamic_cross_topology_records.jsonl"

stage="bootstrap"
failure() {
  code=$?
  printf '{"msg":"GridRank dynamic supplement runner failure","stage":"%s","supplement_evidence_ready":false,"exit_code":%d}\n' "$stage" "$code"
  exit "$code"
}
trap failure ERR

required=(
  gridrank_dynamic_supplement.py
  preflight_gridrank_dynamic_supplement.py
  eval_gridrank_dynamic_supplement_cached.py
  benchmark_gridrank_dynamic_supplement.py
  aggregate_gridrank_dynamic_supplement.py
  verify_gridrank_dynamic_supplement.py
  verify_gridrank_dynamic_supplement_dependencies.py
  ../../docs/GRIDRANK_DYNAMIC_SUPPLEMENT_PROTOCOL.md
  "$CROSS_PREFLIGHT"
  "$CROSS_GATE"
  "$CROSS_RECORDS"
)
for path in "${required[@]}"; do
  if [[ ! -e "$path" ]]; then
    echo "missing dynamic-supplement input: $path" >&2
    exit 2
  fi
done

stage="dependency_regressions"
echo "=== 1/6 DEPENDENCY-LIGHT SAFETY/RANKING/REGIME/EFFICIENCY REGRESSIONS ==="
"$TRAIN_PYTHON" -B verify_gridrank_dynamic_supplement_dependencies.py

stage="locked_preflight"
echo "=== 2/6 LOCK/VERIFY SEALED CROSS-TOPOLOGY INPUTS AND SCHEDULE ==="
if [[ ! -e "$PREFLIGHT" ]]; then
  if [[ -e "$CACHED" ]]; then
    echo "cached result exists without preflight: $CACHED" >&2
    exit 2
  fi
  CUDA_VISIBLE_DEVICES="" "$TRAIN_PYTHON" -B \
    preflight_gridrank_dynamic_supplement.py \
    --cross_preflight "$CROSS_PREFLIGHT" \
    --cross_gate "$CROSS_GATE" \
    --cross_records "$CROSS_RECORDS" \
    --output "$PREFLIGHT" \
    --benchmark_rows 32 \
    --warmup_rows 1 \
    --latency_seed 42 \
    --bootstrap_reps 10000 \
    --bootstrap_seed 20260908
else
  CUDA_VISIBLE_DEVICES="" "$TRAIN_PYTHON" -B \
    preflight_gridrank_dynamic_supplement.py \
    --cross_preflight "$CROSS_PREFLIGHT" \
    --cross_gate "$CROSS_GATE" \
    --cross_records "$CROSS_RECORDS" \
    --output "$PREFLIGHT" --verify
fi

stage="cached_analysis"
echo "=== 3/6 CACHED SAFETY-GATE/MASK, RANKER AND SIMBENCH-REGIME ANALYSES ==="
if [[ ! -e "$CACHED" ]]; then
  CUDA_VISIBLE_DEVICES="" "$TRAIN_PYTHON" -B \
    eval_gridrank_dynamic_supplement_cached.py \
    --preflight "$PREFLIGHT" \
    --output "$CACHED"
fi

if [[ "$PREFLIGHT_ONLY" == "1" ]]; then
  echo "=== GRIDRANK DYNAMIC SUPPLEMENT CPU PREFLIGHT COMPLETE; GPU/LIVE AC TIMING NOT STARTED ==="
  exit 0
fi
if [[ "$PREFLIGHT_ONLY" != "0" ]]; then
  echo "PREFLIGHT_ONLY must be 0 or 1" >&2
  exit 2
fi
if [[ -e "$LATENCY" || -e "$OUTPUT_DIR" ]]; then
  echo "refusing to overwrite live supplement output" >&2
  exit 2
fi

stage="cuda_readiness"
echo "=== 4/6 CUDA + FROZEN 8B ADAPTER READINESS ==="
"$TRAIN_PYTHON" -B - <<'PY'
import json
import torch

checks = {
    "cuda_available": torch.cuda.is_available(),
    "visible_device_count": torch.cuda.device_count() == 1,
}
if checks["cuda_available"]:
    value = torch.ones(1, device="cuda")
    checks["cuda_tensor_ok"] = bool(value.item() == 1.0)
else:
    checks["cuda_tensor_ok"] = False
result = {
    "msg": "GridRank dynamic supplement CUDA readiness",
    "device": torch.cuda.get_device_name(0) if torch.cuda.is_available() else None,
    "free_memory_bytes": (
        torch.cuda.mem_get_info()[0] if torch.cuda.is_available() else 0
    ),
    "total_memory_bytes": (
        torch.cuda.mem_get_info()[1] if torch.cuda.is_available() else 0
    ),
    "checks": checks,
    "readiness_pass": all(checks.values()),
}
print(json.dumps(result, ensure_ascii=False))
if not result["readiness_pass"]:
    raise SystemExit(2)
PY

stage="live_efficiency"
echo "=== 5/6 LIVE P50/P95, GPU MEMORY AND EXACT AC-CALL BENCHMARK ==="
"$TRAIN_PYTHON" -u benchmark_gridrank_dynamic_supplement.py \
  --preflight_manifest "$PREFLIGHT" \
  --output "$LATENCY"

stage="aggregate_verify"
echo "=== 6/6 AGGREGATE AND VERIFY FOUR-PART SUPPLEMENT ==="
mkdir "$OUTPUT_DIR"
"$TRAIN_PYTHON" -B aggregate_gridrank_dynamic_supplement.py \
  --preflight_manifest "$PREFLIGHT" \
  --cached_result "$CACHED" \
  --latency_result "$LATENCY" \
  --output "$GATE"
"$TRAIN_PYTHON" -B verify_gridrank_dynamic_supplement.py \
  --preflight_manifest "$PREFLIGHT" \
  --cached_result "$CACHED" \
  --latency_result "$LATENCY" \
  --gate "$GATE"

echo "=== GRIDRANK DYNAMIC SUPPLEMENT COMPLETE ==="
