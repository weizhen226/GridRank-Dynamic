"""Validate GridRank instruction pairs."""

from __future__ import annotations

import argparse
import ast
import json
from collections import defaultdict
from pathlib import Path


HERE = Path(__file__).resolve().parent


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--summary")
    return parser.parse_args()


def synthetic_state():
    candidates = []
    anchor_loss = 100.0
    anchor_min = 0.94
    for index in range(15):
        action = (
            f"Action: Replace ({index + 1}, {index + 2}) "
            f"with ({index + 31}, {index + 32})"
        )
        if index == 0:
            reduction, minimum = 5.0, 0.941
        elif index == 1:
            reduction, minimum = 0.0, 0.970
        elif index == 2:
            reduction, minimum = 4.0, 0.942
        else:
            reduction, minimum = 0.1, 0.9401
        candidates.append({
            "action": action,
            "candidate_feature_text": (
                f"voltage_drop_proxy_max={1.0 - minimum:.6f}; "
                f"loss_proxy_delta_pct={reduction:.4f}"
            ),
            "feedback_valid": True,
            "feasible": True,
            "reason": "synthetic",
            "reduction_pct": reduction,
            "anchor_loss_kw": anchor_loss,
            "candidate_loss_kw": anchor_loss * (1.0 - reduction / 100.0),
            "anchor_min_vm_pu": anchor_min,
            "candidate_min_vm_pu": minimum,
            "candidate_max_vm_pu": 1.0,
        })
    candidates.insert(0, {
        "action": "Action: none",
        "candidate_feature_text": (
            "voltage_drop_proxy_max=0.060000; loss_proxy_delta_pct=0.0000"
        ),
        "feedback_valid": True,
        "feasible": True,
        "reason": "synthetic",
        "reduction_pct": 0.0,
        "anchor_loss_kw": anchor_loss,
        "candidate_loss_kw": anchor_loss,
        "anchor_min_vm_pu": anchor_min,
        "candidate_min_vm_pu": anchor_min,
        "candidate_max_vm_pu": 1.0,
    })
    return {
        "network_id": "33",
        "load_id": "synthetic-load",
        "physical_state_sha256": "a" * 64,
        "state_text": "synthetic physical state",
        "candidates": candidates,
    }


def regressions():
    import build_gridrank_instruction_pairs as build

    builder = (HERE / "build_gridrank_instruction_pairs.py").read_text(encoding="utf-8")
    scorer = (HERE / "gridrank_select_llm.py").read_text(encoding="utf-8")
    ast.parse(builder)
    state = synthetic_state()
    args = type("Args", (), {
        "target_temperature": 0.2,
        "min_objective_pair_gap": 0.02,
        "min_constraint_pair_gap": 0.20,
    })()
    pairs = build.candidate_pairs(state, "train", args)
    by_type = {item["pair_type"]: item for item in pairs}
    rows, manifest = build.emit_rows(pairs, "train", 2)
    objective = by_type["objective"]
    maintenance_loss = by_type["maintenance_loss"]
    maintenance_voltage = by_type["maintenance_voltage"]
    sample = rows[0]
    oracle = sample["oracle_structured_instruction"]
    ranking = build.structured_proxy_order(
        sample, oracle["objective"], oracle["forbidden_edges"]
    )
    checks = {
        "builder_ast_valid": True,
        "cached_only_static": all(token not in builder for token in (
            "score_completions(", "build_model_and_tokenizer(", ".backward(",
            "pandapower.runpp", "torch.cuda",
        )),
        "three_pair_types_constructed": set(by_type) == set(build.PAIR_TYPES),
        "objective_pair_changes_action": (
            objective["left"]["desired_action"]
            != objective["right"]["desired_action"]
        ),
        "loss_constraint_changes_action": (
            maintenance_loss["left"]["desired_action"]
            != maintenance_loss["right"]["desired_action"]
        ),
        "voltage_constraint_changes_action": (
            maintenance_voltage["left"]["desired_action"]
            != maintenance_voltage["right"]["desired_action"]
        ),
        "pair_rows_share_physical_inputs": all(
            row["state_text"] == rows[0]["state_text"]
            and [x["action"] for x in row["candidates"]]
            == [x["action"] for x in rows[0]["candidates"]]
            and [x["candidate_feature_text"] for x in row["candidates"]]
            == [x["candidate_feature_text"] for x in rows[0]["candidates"]]
            for row in rows
        ),
        "two_paraphrases_each_side": len(rows) == 4 * len(pairs),
        "manifest_actions_differ": all(
            item["left_desired_action"] != item["right_desired_action"]
            for item in manifest
        ),
        "structured_proxy_finite_order": len(ranking) == 15 and len(set(ranking)) == 15,
        "instruction_is_native_llm_input": (
            'row["instruction_text"]' in scorer
            or "row['instruction_text']" in scorer
        ),
        "structured_oracle_not_rendered": "oracle_structured_instruction" not in scorer,
        "ac_labels_not_rendered": all(token not in scorer for token in (
            'candidate["safe_utility"]', 'candidate["target_prob"]',
            'candidate["normalised_regret"]',
        )),
        "train_validation_templates_disjoint": not {
            text for values in build.TRAIN_TEMPLATES.values() for text in values
        }.intersection({
            text for values in build.VALIDATION_TEMPLATES.values() for text in values
        }),
    }
    result = {
        "msg": "GridRank strong instruction-pair dependency-light regressions",
        "checks": checks,
        "verification_pass": all(checks.values()),
    }
    print(json.dumps(result, ensure_ascii=False))
    if not result["verification_pass"]:
        raise SystemExit(2)


def load_rows(path):
    return [json.loads(line) for line in open(path, encoding="utf-8") if line.strip()]


def verify_summary(path):
    from build_gridrank_instruction_pairs import (
        PAIR_TYPES, SCHEMA, code_hashes, file_sha256,
    )

    summary = json.load(open(path, encoding="utf-8"))
    artifact_checks = {
        name: Path(item["path"]).is_file() and file_sha256(item["path"]) == item["sha256"]
        for name, item in summary.get("artifacts", {}).items()
    }
    rows = {
        name: load_rows(item["path"])
        for name, item in summary.get("artifacts", {}).items()
    }
    pair_checks = {}
    for partition, values in rows.items():
        groups = defaultdict(list)
        for row in values:
            groups[row["pair_id"]].append(row)
        pair_checks[partition] = bool(groups) and all(
            len({row["pair_side"] for row in group}) == 2
            and len({row["desired_action"] for row in group}) == 2
            and len({row["physical_state_sha256"] for row in group}) == 1
            and len({tuple(item["action"] for item in row["candidates"]) for row in group}) == 1
            and len({tuple(item["candidate_feature_text"] for item in row["candidates"]) for row in group}) == 1
            for group in groups.values()
        )
    current_hashes, missing = code_hashes()
    settings = summary.get("settings", {})
    counts = summary.get("partitions", {})
    checks = {
        "schema": summary.get("schema") == SCHEMA,
        "coverage_pass": summary.get("coverage_pass") is True,
        "cached_only": summary.get("cached_only") is True,
        "no_training_model_or_power_flow": (
            summary.get("training_performed") is False
            and summary.get("model_loaded") is False
            and summary.get("power_flow_calls") == 0
        ),
        "artifacts_current": bool(artifact_checks) and all(artifact_checks.values()),
        "paired_artifact_structure": bool(pair_checks) and all(pair_checks.values()),
        "code_current": not missing and summary.get("code_sha256") == current_hashes,
        "pair_types_complete": all(
            counts[partition]["pairs_by_network_type"].get(f"{network}:{pair_type}", 0)
            >= settings["min_pairs_per_type_network"]
            for partition in ("train", "validation")
            for network in ("33", "69")
            for pair_type in PAIR_TYPES
        ),
        "all_declared_checks_pass": all(summary.get("checks", {}).values()),
    }
    result = {
        "msg": "GridRank strong instruction-pair artifact audit",
        "checks": checks,
        "verification_pass": all(checks.values()),
        "coverage_pass": summary.get("coverage_pass"),
        "train": counts.get("train"),
        "validation": counts.get("validation"),
    }
    print(json.dumps(result, ensure_ascii=False))
    if not result["verification_pass"]:
        raise SystemExit(2)


def main():
    args = parse_args()
    regressions()
    if args.summary:
        verify_summary(args.summary)


if __name__ == "__main__":
    main()
