"""Validate GridRank dynamic factorization ablation."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import aggregate_gridrank_dynamic_multiseed as aggregate
import eval_gridrank_dynamic_factorization_ablation as evaluation
import preflight_gridrank_dynamic_factorization_ablation as preflight
import train_gridrank_dynamic_policy as joint


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--gate", required=True)
    parser.add_argument("--preflight", required=True)
    return parser.parse_args()


def main():
    args = parse_args()
    gate = json.load(open(args.gate, encoding="utf-8"))
    manifest = json.load(open(args.preflight, encoding="utf-8"))
    output_methods = aggregate.read_records(gate["records"]["path"])
    factor_methods = aggregate.read_records(
        manifest["artifacts"]["factorized_confirmation_records"]["path"]
    )
    methods = {
        evaluation.FACTORIZED: factor_methods[evaluation.FACTORIZED],
        evaluation.JOINT: output_methods[evaluation.JOINT],
        evaluation.JOINT_REMOVED: output_methods[evaluation.JOINT_REMOVED],
        evaluation.JOINT_COUNTERFACTUAL: output_methods[
            evaluation.JOINT_COUNTERFACTUAL
        ],
    }
    summaries = {name: joint.summarize(values) for name, values in methods.items()}
    pair_to_state, state_network, manifest_rows = aggregate.physical_state_units(
        manifest["artifacts"]["fresh_summary"]["path"]
    )
    reps, seed = (
        manifest["schedule"]["bootstrap_reps"],
        manifest["schedule"]["seed"],
    )
    comparisons = {
        "factorized_vs_joint_all": evaluation.comparison(
            methods,
            evaluation.JOINT,
            evaluation.FACTORIZED,
            pair_to_state,
            state_network,
            reps,
            seed + 100,
        ),
        "factorized_vs_joint_primary": evaluation.comparison(
            methods,
            evaluation.JOINT,
            evaluation.FACTORIZED,
            pair_to_state,
            state_network,
            reps,
            seed + 200,
            evaluation.PRIMARY,
        ),
        "joint_correct_vs_removed": evaluation.comparison(
            methods,
            evaluation.JOINT_REMOVED,
            evaluation.JOINT,
            pair_to_state,
            state_network,
            reps,
            seed + 300,
        ),
        "joint_correct_vs_counterfactual": evaluation.comparison(
            methods,
            evaluation.JOINT_COUNTERFACTUAL,
            evaluation.JOINT,
            pair_to_state,
            state_network,
            reps,
            seed + 400,
        ),
    }
    factor_cards = {
        row["instance_id"]: row["selected_card"]
        for row in methods[evaluation.FACTORIZED]
    }
    joint_cards = {
        row["instance_id"]: row["selected_card"]
        for row in methods[evaluation.JOINT]
    }
    changed = sum(factor_cards[key] != joint_cards[key] for key in factor_cards)
    expected_gate = all(gate.get("checks", {}).values())
    expected_decision = (
        "authorize_joint_card_seed123_2025_replication"
        if expected_gate
        else "do_not_expand_joint_card_ablation"
    )
    artifact_checks = {
        name: Path(item["path"]).is_file()
        and preflight.file_sha256(item["path"]) == item["sha256"]
        for name, item in manifest.get("artifacts", {}).items()
    }
    adapter_checks = {
        name: preflight.adapter_hash(item["path"]) == item["sha256"]
        for name, item in manifest.get("adapters", {}).items()
    }
    checks = {
        "schema": gate.get("schema")
        == "gridrank-dynamic-factorization-ablation-gate-v1",
        "experiment_id": gate.get("experiment_id") == preflight.EXPERIMENT_ID,
        "preflight_schema": manifest.get("schema") == preflight.SCHEMA,
        "preflight_pass": manifest.get("preflight_pass") is True,
        "preflight_hash": gate.get("preflight_sha256")
        == preflight.file_sha256(args.preflight),
        "evaluation_only": gate.get("evaluation_only") is True
        and gate.get("training_performed") is False,
        "fresh_outcomes_not_fit": gate.get("fresh_outcomes_used_for_fit") is False,
        "confirmation_reuse_disclosed": gate.get("confirmation_reuse_disclosed")
        is True,
        "records_hash": gate.get("records", {}).get("sha256")
        == preflight.file_sha256(gate["records"]["path"]),
        "records_methods": gate.get("records", {}).get("methods")
        == sorted(output_methods),
        "records_rows": gate.get("records", {}).get("rows")
        == sum(len(values) for values in output_methods.values()),
        "summaries_recomputed": gate.get("summaries") == summaries,
        "comparisons_recomputed": gate.get("comparisons") == comparisons,
        "selected_card_changes_recomputed": gate.get(
            "selected_card_changed_rows"
        )
        == changed,
        "fresh_manifest_present": bool(manifest_rows),
        "matched_contract_preserved": gate.get("matched_training_contract")
        == manifest.get("matched_training_contract"),
        "artifacts_current": bool(artifact_checks) and all(artifact_checks.values()),
        "adapters_current": bool(adapter_checks) and all(adapter_checks.values()),
        "factorization_gate_consistent": gate.get("factorization_gate_pass")
        is expected_gate,
        "failed_checks_consistent": gate.get("failed_checks")
        == [key for key, value in gate.get("checks", {}).items() if not value],
        "decision_consistent": gate.get("decision") == expected_decision,
        "interpretation_boundary_present": bool(gate.get("interpretation_boundary")),
    }
    result = {
        "msg": "GridRank factorization-ablation result verification",
        "checks": checks,
        "verification_pass": all(checks.values()),
        "factorization_gate_pass": gate.get("factorization_gate_pass"),
        "decision": gate.get("decision"),
        "failed_checks": gate.get("failed_checks"),
    }
    print(json.dumps(result, ensure_ascii=False))
    if not result["verification_pass"]:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
