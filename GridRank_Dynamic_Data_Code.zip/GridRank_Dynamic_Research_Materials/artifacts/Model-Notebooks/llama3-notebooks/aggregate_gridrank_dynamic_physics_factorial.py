"""Aggregate GridRank dynamic physics factorial."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import aggregate_gridrank_dynamic_multiseed as multi


HERE = Path(__file__).resolve().parent
SCHEMA = "gridrank-dynamic-physics-source-factorial-aggregate-v1"
EXPERIMENT_ID = "gridrank-dynamic-physics-source-2x2-factorial-v1"
SEEDS = (42, 123, 2025)
CELLS = ("gridrank_p1", "gridrank_p0", "sft_p1", "sft_p0")
ALIGNED = "physics_aligned_factorized_llm"
WITHHELD = "tfidf_logreg_withheld_composition"
PRIMARY_PAIR_TYPE = "maintenance_voltage"
CODE_FILES = (
    "aggregate_gridrank_dynamic_physics_factorial.py",
    "verify_gridrank_dynamic_physics_factorial.py",
    "verify_gridrank_dynamic_physics_factorial_dependencies.py",
    "run_gridrank_dynamic_physics_factorial.sh",
    "../../docs/GRIDRANK_DYNAMIC_PHYSICS_FACTORIAL_PROTOCOL.md",
)


def file_sha256(path):
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def code_hashes():
    missing = [name for name in CODE_FILES if not (HERE / name).is_file()]
    if missing:
        raise FileNotFoundError(f"missing factorial aggregate code: {missing}")
    return {name: file_sha256(HERE / name) for name in CODE_FILES}


def parse_cell_seed_values(values, label):
    output = {cell: {} for cell in CELLS}
    for value in values:
        if "=" not in value or ":" not in value.split("=", 1)[0]:
            raise ValueError(f"{label} must use CELL:SEED=PATH: {value}")
        raw_key, path = value.split("=", 1)
        cell, raw_seed = raw_key.split(":", 1)
        seed = int(raw_seed)
        if cell not in output:
            raise ValueError(f"unknown cell {cell} in {label}")
        if seed in output[cell]:
            raise ValueError(f"duplicate {label} {cell}:{seed}")
        output[cell][seed] = path
    for cell in CELLS:
        if tuple(sorted(output[cell])) != SEEDS:
            raise ValueError(
                f"{label} {cell} seeds must be {SEEDS}, got {sorted(output[cell])}"
            )
    return output


def parse_args():
    parser = argparse.ArgumentParser()
    for name in ("gate", "records", "factor_preflight", "confirmation_preflight"):
        parser.add_argument(f"--{name}", action="append", required=True)
    parser.add_argument("--fresh_summary", required=True)
    parser.add_argument("--bootstrap_reps", type=int, default=10000)
    parser.add_argument("--bootstrap_seed", type=int, default=20260905)
    parser.add_argument("--output", required=True)
    return parser.parse_args()


def _input_item(path):
    return {"path": str(Path(path).resolve()), "sha256": file_sha256(path)}


def _method_rows(methods, pair_type=None):
    rows = methods[ALIGNED]
    if pair_type is not None:
        rows = [row for row in rows if row["pair_type"] == pair_type]
    return {row["instance_id"]: row for row in rows}


def _baseline_signature(methods):
    return {
        row["instance_id"]: {
            "normalised_regret": row["normalised_regret"],
            "safe_action": row["safe_action"],
        }
        for row in methods[WITHHELD]
    }


def _pair_effects(before, after, pair_type=None):
    
    left = _method_rows(before, pair_type)
    right = _method_rows(after, pair_type)
    if set(left) != set(right):
        raise ValueError("factorial aligned instance IDs differ")
    values = {}
    for instance_id in sorted(left):
        pair_id = left[instance_id]["pair_id"]
        values.setdefault(pair_id, []).append(
            float(left[instance_id]["normalised_regret"])
            - float(right[instance_id]["normalised_regret"])
        )
    return {pair_id: multi.mean(items) for pair_id, items in values.items()}


def _combine(left, right, operation):
    if set(left) != set(right):
        raise ValueError("factorial pair maps differ")
    if operation == "average":
        return {key: 0.5 * (left[key] + right[key]) for key in left}
    if operation == "left_minus_right":
        return {key: left[key] - right[key] for key in left}
    raise ValueError(operation)


def _effect_matrices(loaded, pair_type=None):
    matrices = {
        name: {} for name in (
            "prealignment_at_p1",
            "prealignment_at_p0",
            "static_prealignment_main",
            "dynamic_loss_with_gridrank",
            "dynamic_loss_with_sft",
            "dynamic_loss_main",
            "interaction_dynamic_loss_sft_minus_gridrank",
            "tested_pipeline_full_vs_minimal",
        )
    }
    for seed in SEEDS:
        rows = {cell: loaded[cell][seed]["records"] for cell in CELLS}
        pre_p1 = _pair_effects(rows["sft_p1"], rows["gridrank_p1"], pair_type)
        pre_p0 = _pair_effects(rows["sft_p0"], rows["gridrank_p0"], pair_type)
        dyn_grid = _pair_effects(rows["gridrank_p0"], rows["gridrank_p1"], pair_type)
        dyn_sft = _pair_effects(rows["sft_p0"], rows["sft_p1"], pair_type)
        matrices["prealignment_at_p1"][seed] = pre_p1
        matrices["prealignment_at_p0"][seed] = pre_p0
        matrices["static_prealignment_main"][seed] = _combine(
            pre_p1, pre_p0, "average"
        )
        matrices["dynamic_loss_with_gridrank"][seed] = dyn_grid
        matrices["dynamic_loss_with_sft"][seed] = dyn_sft
        matrices["dynamic_loss_main"][seed] = _combine(
            dyn_grid, dyn_sft, "average"
        )
        matrices["interaction_dynamic_loss_sft_minus_gridrank"][seed] = _combine(
            dyn_sft, dyn_grid, "left_minus_right"
        )
        matrices["tested_pipeline_full_vs_minimal"][seed] = _pair_effects(
            rows["sft_p0"], rows["gridrank_p1"], pair_type
        )
    return matrices


def _cell_summary(methods, pair_type=None):
    rows = list(_method_rows(methods, pair_type).values())
    return {
        "n": len(rows),
        "normalised_regret_mean": multi.mean(
            [float(row["normalised_regret"]) for row in rows]
        ),
        "physics_optimal_rate": multi.mean(
            [float(row["physics_optimal"]) for row in rows]
        ),
        "safe_feasible_rate": multi.mean(
            [float(row["safe_feasible"]) for row in rows]
        ),
        "constraint_violation_rate": multi.mean(
            [float(row["constraint_violation"]) for row in rows]
        ),
    }


def _effect_gate(value, integrity_pass, safety_pass):
    checks = {
        "at_least_2_of_3_seed_points_positive": value["positive_seed_count"] >= 2,
        "physical_state_ci_lower_positive": value[
            "physical_state_cluster_bootstrap_ci95"
        ][0] > 0,
        "two_way_seed_state_ci_lower_positive": value[
            "two_way_seed_state_bootstrap_ci95"
        ][0] > 0,
        "hierarchical_ci_lower_positive": value[
            "hierarchical_seed_state_pair_bootstrap_ci95"
        ][0] > 0,
        "both_network_point_effects_positive": all(
            value["by_network"][network]["improvement_mean"] > 0
            for network in ("33", "69")
        ),
        "integrity_pass": integrity_pass,
        "safety_pass": safety_pass,
    }
    return {
        "checks": checks,
        "gate_pass": all(checks.values()),
        "failed_checks": [key for key, item in checks.items() if not item],
    }


def build(groups, fresh_summary, reps, bootstrap_seed):
    loaded = {cell: {} for cell in CELLS}
    inputs = {"cells": {}, "fresh_summary": _input_item(fresh_summary)}
    integrity = {}
    expected_lambda = {"gridrank_p1": 1.0, "gridrank_p0": 0.0, "sft_p1": 1.0, "sft_p0": 0.0}

    for cell in CELLS:
        inputs["cells"][cell] = {}
        for seed in SEEDS:
            items = {}
            input_items = {}
            for name, paths in groups.items():
                path = paths[cell][seed]
                input_items[name] = _input_item(path)
                items[name] = (
                    multi.read_records(path)
                    if name == "records"
                    else json.load(open(path, encoding="utf-8"))
                )
            inputs["cells"][cell][str(seed)] = input_items
            loaded[cell][seed] = items
            gate = items["gate"]
            records = items["records"]
            factor = items["factor_preflight"]
            confirm = items["confirmation_preflight"]
            integrity.update({
                f"{cell}_seed_{seed}_records_hash": gate.get("records", {}).get(
                    "sha256"
                ) == file_sha256(groups["records"][cell][seed]),
                f"{cell}_seed_{seed}_confirmation_bound": gate.get("preflight_sha256")
                == file_sha256(groups["confirmation_preflight"][cell][seed]),
                f"{cell}_seed_{seed}_factor_preflight_pass": factor.get(
                    "preflight_pass"
                ) is True,
                f"{cell}_seed_{seed}_confirmation_preflight_pass": confirm.get(
                    "preflight_pass"
                ) is True,
                f"{cell}_seed_{seed}_lambda_matches": factor.get("schedule", {}).get(
                    "lambda_physics"
                ) == expected_lambda[cell],
                f"{cell}_seed_{seed}_same_method_present": ALIGNED in records,
                f"{cell}_seed_{seed}_freshness_role_valid": (
                    cell == "gridrank_p1"
                    or "not a fresh test" in str(confirm.get("freshness_status", ""))
                ),
            })
            if cell.startswith("sft_"):
                integrity[f"{cell}_seed_{seed}_sft_cell_bound"] = (
                    factor.get("factorial_cell", {}).get("initialization")
                    == "frozen_gridintent_sft"
                    and gate.get("factorial_cell") == factor.get("factorial_cell")
                )

    for seed in SEEDS:
        reference = loaded["gridrank_p1"][seed]["factor_preflight"]
        reference_selection = reference.get("selection")
        reference_schedule = {
            key: value for key, value in reference.get("schedule", {}).items()
            if key != "lambda_physics"
        }
        reference_methods = loaded["gridrank_p1"][seed]["records"]
        reference_rows = set(_method_rows(reference_methods))
        reference_baseline = _baseline_signature(reference_methods)
        for cell in CELLS[1:]:
            factor = loaded[cell][seed]["factor_preflight"]
            schedule_without = {
                key: value for key, value in factor.get("schedule", {}).items()
                if key != "lambda_physics"
            }
            records = loaded[cell][seed]["records"]
            integrity.update({
                f"seed_{seed}_{cell}_selection_matched": factor.get("selection")
                == reference_selection,
                f"seed_{seed}_{cell}_schedule_matched_except_physics": schedule_without
                == reference_schedule,
                f"seed_{seed}_{cell}_aligned_rows_matched": set(_method_rows(records))
                == reference_rows,
                f"seed_{seed}_{cell}_baseline_replay_identical": _baseline_signature(
                    records
                ) == reference_baseline,
            })
        grid_hash = reference.get("adapters", {}).get("gridrank", {}).get("sha256")
        grid0_hash = loaded["gridrank_p0"][seed]["factor_preflight"].get(
            "adapters", {}
        ).get("gridrank", {}).get("sha256")
        sft_hash = reference.get("adapters", {}).get("sft", {}).get("sha256")
        sft1_hash = loaded["sft_p1"][seed]["factor_preflight"].get(
            "adapters", {}
        ).get("initial", {}).get("sha256")
        sft0_hash = loaded["sft_p0"][seed]["factor_preflight"].get(
            "adapters", {}
        ).get("initial", {}).get("sha256")
        integrity.update({
            f"seed_{seed}_gridrank_initial_matched_across_physics": bool(grid_hash)
            and grid_hash == grid0_hash,
            f"seed_{seed}_sft_initial_matched_across_physics": bool(sft_hash)
            and sft_hash == sft1_hash == sft0_hash,
            f"seed_{seed}_initialization_factor_nontrivial": bool(grid_hash)
            and bool(sft_hash) and grid_hash != sft_hash,
        })

    pair_to_state, state_network, manifest = multi.physical_state_units(fresh_summary)
    integrity["fresh_summary_96_pairs"] = len(manifest) == 96
    integrity["fresh_summary_66_states"] = len(set(pair_to_state.values())) == 66
    integrity_pass = all(integrity.values())

    cell_summaries = {
        cell: {
            "overall": {
                str(seed): _cell_summary(loaded[cell][seed]["records"])
                for seed in SEEDS
            },
            "primary": {
                str(seed): _cell_summary(
                    loaded[cell][seed]["records"], PRIMARY_PAIR_TYPE
                ) for seed in SEEDS
            },
        }
        for cell in CELLS
    }
    safety = {
        f"{cell}_all_seed_feasible_100pct": all(
            item["safe_feasible_rate"] == 1.0
            for item in cell_summaries[cell]["overall"].values()
        )
        for cell in CELLS
    }
    safety.update({
        f"{cell}_all_seed_constraint_violation_zero": all(
            item["constraint_violation_rate"] == 0.0
            for item in cell_summaries[cell]["overall"].values()
        )
        for cell in CELLS
    })
    safety_pass = all(safety.values())

    effect_results = {"overall": {}, "primary": {}}
    for subset, pair_type, offset in (
        ("overall", None, 100),
        ("primary", PRIMARY_PAIR_TYPE, 1000),
    ):
        matrices = _effect_matrices(loaded, pair_type)
        for index, (name, matrix) in enumerate(matrices.items()):
            effect_results[subset][name] = multi.bootstrap_state_matrix(
                matrix,
                pair_to_state,
                state_network,
                reps,
                bootstrap_seed + offset + 100 * index,
            )

    gates = {
        "static_prealignment_main": _effect_gate(
            effect_results["primary"]["static_prealignment_main"],
            integrity_pass,
            safety_pass,
        ),
        "dynamic_ac_listwise_main": _effect_gate(
            effect_results["primary"]["dynamic_loss_main"],
            integrity_pass,
            safety_pass,
        ),
        "tested_pipeline_full_vs_minimal": _effect_gate(
            effect_results["primary"]["tested_pipeline_full_vs_minimal"],
            integrity_pass,
            safety_pass,
        ),
    }
    return {
        "msg": "GridRank dynamic physics-source 2x2 factorial aggregate",
        "schema": SCHEMA,
        "experiment_id": EXPERIMENT_ID,
        "seeds": list(SEEDS),
        "cells": list(CELLS),
        "bootstrap_reps": reps,
        "bootstrap_seed": bootstrap_seed,
        "training_performed": False,
        "model_loaded": False,
        "power_flow_calls": 0,
        "post_confirmation_supplement": True,
        "freshness_boundary": (
            "The already opened byte-locked confirmation is reused.  This is a "
            "post-confirmation factorial sensitivity analysis, not a fresh test."
        ),
        "interpretation_boundary": (
            "The sft_p0 cell still uses the physics-certified dynamic corpus and "
            "semantic labels.  The full-versus-minimal contrast is the total effect "
            "of the two tested channels, not an all-physics versus zero-physics claim."
        ),
        "effect_orientations": {
            "static_prealignment": "SFT-init regret minus GridRank-init regret",
            "dynamic_ac_listwise": "lambda0 regret minus lambda1 regret",
            "interaction": "dynamic-loss effect under SFT minus under GridRank",
            "tested_pipeline": "sft_p0 regret minus gridrank_p1 regret",
        },
        "inputs": inputs,
        "cell_summaries": cell_summaries,
        "effects": effect_results,
        "integrity_checks": integrity,
        "safety_checks": safety,
        "channel_gates": gates,
        "audit_pass": integrity_pass,
        "safety_pass": safety_pass,
        "factorial_explanatory_gate_pass": all(
            value["gate_pass"] for value in gates.values()
        ),
        "failed_integrity": [key for key, value in integrity.items() if not value],
        "failed_safety": [key for key, value in safety.items() if not value],
        "decision": "report_channel_specific_factorial_effects",
        "code_sha256": code_hashes(),
    }


def main():
    args = parse_args()
    output = Path(args.output)
    if output.exists():
        raise FileExistsError(f"refusing to overwrite factorial aggregate: {output}")
    groups = {
        name: parse_cell_seed_values(getattr(args, name), name)
        for name in ("gate", "records", "factor_preflight", "confirmation_preflight")
    }
    result = build(groups, args.fresh_summary, args.bootstrap_reps, args.bootstrap_seed)
    output.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(result, ensure_ascii=False))
    if not result["audit_pass"]:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
