#!/usr/bin/env bash
set -euo pipefail

CURRENT_STAGE="bootstrap"
on_exit() {
  local rc=$?
  trap - EXIT
  if (( rc != 0 )); then
    printf '{"msg":"GridRank-Select extension runner failure","stage":"%s","gate_pass":false,"exit_code":%d}\n' \
      "$CURRENT_STAGE" "$rc"
  fi
  exit "$rc"
}
trap on_exit EXIT

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"
export HF_HUB_OFFLINE=1

PREFLIGHT_ONLY="${PREFLIGHT_ONLY:-1}"
case "$PREFLIGHT_ONLY" in 0|1) ;; *) echo "PREFLIGHT_ONLY must be 0 or 1" >&2; exit 2;; esac
if [[ "$PREFLIGHT_ONLY" == "1" ]]; then export CUDA_VISIBLE_DEVICES=""; fi

resolve_executable() {
  local requested="$1"
  if [[ "$requested" == */* ]]; then [[ -x "$requested" ]] && printf '%s\n' "$requested"
  else command -v -- "$requested"; fi
}
TRAIN_PYTHON_BIN="$(resolve_executable "${TRAIN_PYTHON:-python}")" || exit 2
PHYSICS_PYTHON_BIN="$(resolve_executable "${PHYSICS_PYTHON:-$TRAIN_PYTHON_BIN}")" || exit 2

TAG="${TAG:-gridrank_select_extension_v1_20260726}"
[[ "$TAG" =~ ^[A-Za-z0-9][A-Za-z0-9._-]*$ ]] || { echo "invalid TAG" >&2; exit 2; }
BASE_MODEL="${BASE_MODEL:-../../Meta-Llama-3.1-8B-Instruct}"
SFT="${SFT:-output_gridintent_gate_33_69_v2_20260717/sft_only}"
TRAIN33="${TRAIN33:-limited_k1_33_n500_train_no_oracle_s20260702.csv}"
TRAIN69="${TRAIN69:-limited_k1_69_n500_train_no_oracle_s20260702.csv}"
RAW33="${RAW33:-structured_action_33_fixed_locked_eval_test.jsonl}"
RAW69="${RAW69:-structured_action_69_s42_locked_eval_test.jsonl}"

CONFIRM_TAG="${CONFIRM_TAG:-gridrank_select_confirm_v1_20260725}"
ORIGINAL_TRAIN="${ORIGINAL_TRAIN:-${CONFIRM_TAG}_train.jsonl}"
ORIGINAL_TEST="${ORIGINAL_TEST:-${CONFIRM_TAG}_test.jsonl}"
PILOT_TEST="${PILOT_TEST:-gridrank_select_gate_v1_20260722_test.jsonl}"
ORIGINAL_AGGREGATE="${ORIGINAL_AGGREGATE:-${CONFIRM_TAG}_three_seed_aggregate.json}"

VIEW33="${TAG}_unused_test33_role.jsonl"
VIEW69="${TAG}_unused_test69_role.jsonl"
VIEW33_MANIFEST="${TAG}_unused_test33_role.manifest.json"
VIEW69_MANIFEST="${TAG}_unused_test69_role.manifest.json"
UPSTREAM_OFFLINE="${TAG}_offline_lock.jsonl"
UPSTREAM_ONLINE="${TAG}_online_lock.jsonl"
UPSTREAM_TEST="${TAG}_extension_test_upstream.jsonl"
UPSTREAM_SUMMARY="${TAG}_feedback_summary.json"
UPSTREAM_AUDIT="${TAG}_feedback_audit.json"
SELECT_TRAIN="${TAG}_select_train_lock.jsonl"
SELECT_TEST="${TAG}_select_test.jsonl"
SELECT_SUMMARY="${TAG}_select_summary.json"
SELECT_AUDIT="${TAG}_select_audit.json"
PREFLIGHT="${TAG}.preflight.json"
OUT="${OUT:-output_${TAG}}"
GATE="$OUT/gridrank_select_extension_gate.json"

readonly OFFLINE_LOADS_PER_NETWORK=32
readonly ONLINE_LOADS_PER_NETWORK=1
readonly TEST_LOADS_PER_NETWORK=32
readonly CANDIDATE_POOL_SIZE=16
readonly CANDIDATE_SEED=20260721
readonly ROW_SEED=20260726
readonly TARGET_TEMPERATURE=0.20
readonly TOPK=3
readonly BOOTSTRAP_REPS=10000
readonly PHYSICS_TIMEOUT_S="${PHYSICS_TIMEOUT_S:-60.0}"

GATE_ARGS=()
ADAPTER_ARGS=()
for seed in 42 123 2025; do
  gate="output_${CONFIRM_TAG}_s${seed}/gridrank_select_gate.json"
  adapter="output_${CONFIRM_TAG}_s${seed}/diagnostic_adapter"
  test -f "$gate" || { echo "missing original gate: $gate" >&2; exit 2; }
  test -f "$adapter/adapter_model.safetensors" || { echo "missing adapter: $adapter" >&2; exit 2; }
  GATE_ARGS+=(--original_gate "${seed}=${gate}")
  ADAPTER_ARGS+=(--seed_adapter "${seed}=${adapter}")
done
for path in "$RAW33" "$RAW69" "$ORIGINAL_TRAIN" "$ORIGINAL_TEST" "$PILOT_TEST" \
  "$ORIGINAL_AGGREGATE" "$SFT/adapter_model.safetensors" "$BASE_MODEL/config.json"; do
  test -e "$path" || { echo "missing extension input: $path" >&2; exit 2; }
done

if [[ "$PREFLIGHT_ONLY" == "1" ]]; then
  echo "=== 1/7 BUILD/VERIFY UNUSED RAW-TEST VIEWS ==="
  CURRENT_STAGE="unused_test_views"
  for network in 33 69; do
    if [[ "$network" == "33" ]]; then raw="$RAW33"; view="$VIEW33"; manifest="$VIEW33_MANIFEST";
    else raw="$RAW69"; view="$VIEW69"; manifest="$VIEW69_MANIFEST"; fi
    if [[ ! -e "$view" && ! -e "$manifest" ]]; then
      "$TRAIN_PYTHON_BIN" -B make_gridrank_extension_state_view.py --mode build \
        --network "$network" --input "$raw" \
        --exclude_jsonl "$ORIGINAL_TRAIN" --exclude_jsonl "$ORIGINAL_TEST" \
        --exclude_jsonl "$PILOT_TEST" --output_jsonl "$view" --manifest_json "$manifest"
    elif [[ ! -e "$view" || ! -e "$manifest" ]]; then
      echo "partial extension view; use a new TAG" >&2; exit 2
    fi
    "$TRAIN_PYTHON_BIN" -B make_gridrank_extension_state_view.py --mode verify \
      --network "$network" --input "$raw" \
      --exclude_jsonl "$ORIGINAL_TRAIN" --exclude_jsonl "$ORIGINAL_TEST" \
      --exclude_jsonl "$PILOT_TEST" --output_jsonl "$view" --manifest_json "$manifest"
  done

  echo "=== 2/7 DEPENDENCY-LIGHT EXTENSION REGRESSIONS ==="
  CURRENT_STAGE="dependency_regression"
  "$TRAIN_PYTHON_BIN" -B verify_gridrank_select.py
  "$TRAIN_PYTHON_BIN" -B verify_gridrank_select_extension.py \
    --test_raw "33=$RAW33" --test_raw "69=$RAW69"

  echo "=== 3/7 BUILD AUTHORITATIVE EXTENSION PHYSICS OUTCOMES ==="
  CURRENT_STAGE="physics_build"
  existing=0
  for path in "$UPSTREAM_OFFLINE" "$UPSTREAM_ONLINE" "$UPSTREAM_TEST" "$UPSTREAM_SUMMARY"; do
    test -e "$path" && existing=$((existing + 1))
  done
  if [[ "$existing" == "0" ]]; then
    "$TRAIN_PYTHON_BIN" -u build_gridrank_feedback.py \
      --train_source "33=$TRAIN33" --train_source "69=$TRAIN69" \
      --validation_source "33=$VIEW33" --validation_source "69=$VIEW69" \
      --offline_loads_per_network "$OFFLINE_LOADS_PER_NETWORK" \
      --online_loads_per_network "$ONLINE_LOADS_PER_NETWORK" \
      --test_loads_per_network "$TEST_LOADS_PER_NETWORK" \
      --candidate_pool_size "$CANDIDATE_POOL_SIZE" --candidate_seed "$CANDIDATE_SEED" \
      --row_seed "$ROW_SEED" --physics_backend pandapower-subprocess \
      --physics_python "$PHYSICS_PYTHON_BIN" --physics_timeout_s "$PHYSICS_TIMEOUT_S" \
      --offline_out "$UPSTREAM_OFFLINE" --online_out "$UPSTREAM_ONLINE" \
      --test_out "$UPSTREAM_TEST" --summary_out "$UPSTREAM_SUMMARY"
  elif [[ "$existing" != "4" ]]; then echo "partial physics artifacts" >&2; exit 2
  fi

  echo "=== 4/7 AUDIT PROVENANCE + LIVE PANDAPOWER REPLAY ==="
  CURRENT_STAGE="physics_audit"
  if [[ ! -e "$UPSTREAM_AUDIT" ]]; then
    "$TRAIN_PYTHON_BIN" -u audit_gridrank_feedback.py \
      --train_source "33=$TRAIN33" --train_source "69=$TRAIN69" \
      --validation_source "33=$VIEW33" --validation_source "69=$VIEW69" \
      --offline_jsonl "$UPSTREAM_OFFLINE" --online_jsonl "$UPSTREAM_ONLINE" \
      --test_jsonl "$UPSTREAM_TEST" --summary_json "$UPSTREAM_SUMMARY" \
      --physics_python "$PHYSICS_PYTHON_BIN" --physics_timeout_s "$PHYSICS_TIMEOUT_S" \
      --replay_states_per_network 1 --output "$UPSTREAM_AUDIT"
  fi

  echo "=== 5/7 DERIVE FROZEN EXCHANGE-ONLY LOSS CORPUS ==="
  CURRENT_STAGE="select_build"
  existing=0
  for path in "$SELECT_TRAIN" "$SELECT_TEST" "$SELECT_SUMMARY"; do
    test -e "$path" && existing=$((existing + 1))
  done
  if [[ "$existing" == "0" ]]; then
    "$TRAIN_PYTHON_BIN" -u build_gridrank_select.py \
      --upstream_summary "$UPSTREAM_SUMMARY" --upstream_audit "$UPSTREAM_AUDIT" \
      --offline_jsonl "$UPSTREAM_OFFLINE" --test_jsonl "$UPSTREAM_TEST" \
      --train_out "$SELECT_TRAIN" --test_out "$SELECT_TEST" \
      --summary_out "$SELECT_SUMMARY" --target_temperature "$TARGET_TEMPERATURE"
  elif [[ "$existing" != "3" ]]; then echo "partial Select artifacts" >&2; exit 2
  fi

  echo "=== 6/7 AUDIT EXCHANGE-ONLY DERIVATION ==="
  CURRENT_STAGE="select_audit"
  if [[ ! -e "$SELECT_AUDIT" ]]; then
    "$TRAIN_PYTHON_BIN" -u audit_gridrank_select.py \
      --upstream_summary "$UPSTREAM_SUMMARY" --upstream_audit "$UPSTREAM_AUDIT" \
      --offline_jsonl "$UPSTREAM_OFFLINE" --test_jsonl "$UPSTREAM_TEST" \
      --select_summary "$SELECT_SUMMARY" --train_jsonl "$SELECT_TRAIN" \
      --select_test_jsonl "$SELECT_TEST" --output "$SELECT_AUDIT"
  fi

  echo "=== 7/7 LOCK FROZEN-ADAPTER EXTENSION MANIFEST ==="
  CURRENT_STAGE="extension_preflight"
  if [[ ! -e "$PREFLIGHT" ]]; then
    "$TRAIN_PYTHON_BIN" -u preflight_gridrank_select_extension.py --mode create \
      --upstream_summary "$UPSTREAM_SUMMARY" --upstream_audit "$UPSTREAM_AUDIT" \
      --train_jsonl "$SELECT_TRAIN" --test_jsonl "$SELECT_TEST" \
      --data_summary "$SELECT_SUMMARY" --data_audit "$SELECT_AUDIT" \
      --original_train_jsonl "$ORIGINAL_TRAIN" --original_test_jsonl "$ORIGINAL_TEST" \
      --pilot_test_jsonl "$PILOT_TEST" "${GATE_ARGS[@]}" \
      --original_aggregate "$ORIGINAL_AGGREGATE" \
      --test_view "33=$VIEW33" --test_view "69=$VIEW69" \
      --test_view_manifest "33=$VIEW33_MANIFEST" --test_view_manifest "69=$VIEW69_MANIFEST" \
      "${ADAPTER_ARGS[@]}" --sft_adapter "$SFT" --base_model "$BASE_MODEL" \
      --physics_python "$PHYSICS_PYTHON_BIN" --bootstrap_reps "$BOOTSTRAP_REPS" \
      --output "$PREFLIGHT"
  fi
  "$TRAIN_PYTHON_BIN" -B preflight_gridrank_select_extension.py --mode verify \
    --base_model "$BASE_MODEL" --physics_python "$PHYSICS_PYTHON_BIN" \
    --bootstrap_reps "$BOOTSTRAP_REPS" --output "$PREFLIGHT"
  echo "=== GRIDRANK-SELECT EXTENSION CPU PREFLIGHT COMPLETE; GPU NOT STARTED ==="
  exit 0
fi

test -f "$PREFLIGHT" || { echo "missing extension preflight" >&2; exit 2; }
test ! -e "$OUT" || { echo "refusing to reuse $OUT" >&2; exit 2; }
test ! -e "${OUT}.log" || { echo "refusing to overwrite ${OUT}.log" >&2; exit 2; }

echo "=== 1/3 VERIFY LOCKED EVALUATION-ONLY MANIFEST ==="
CURRENT_STAGE="runtime_lock"
"$TRAIN_PYTHON_BIN" -B preflight_gridrank_select_extension.py --mode verify \
  --base_model "$BASE_MODEL" --physics_python "$PHYSICS_PYTHON_BIN" \
  --bootstrap_reps "$BOOTSTRAP_REPS" --output "$PREFLIGHT"

echo "=== 2/3 CUDA + NF4 READINESS ==="
CURRENT_STAGE="gpu_readiness"
"$TRAIN_PYTHON_BIN" -B - <<'PY'
import json, torch
from transformers import BitsAndBytesConfig
c = {"cuda": bool(torch.cuda.is_available()), "device_count": torch.cuda.device_count() > 0}
q = BitsAndBytesConfig(load_in_4bit=True, bnb_4bit_quant_type="nf4",
    bnb_4bit_compute_dtype=torch.float16, bnb_4bit_use_double_quant=True)
c["nf4_config"] = bool(q.load_in_4bit and q.bnb_4bit_quant_type == "nf4")
print(json.dumps({"msg":"extension CUDA readiness","checks":c,"pass":all(c.values())}))
raise SystemExit(0 if all(c.values()) else 2)
PY

echo "=== 3/3 FROZEN SFT/THREE-ADAPTER FORWARD + LIVE TOP-3 REPLAY ==="
CURRENT_STAGE="extension_evaluation"
mkdir "$OUT"
set +e
"$TRAIN_PYTHON_BIN" -u eval_gridrank_select_extension.py \
  --test_jsonl "$SELECT_TEST" --original_test_jsonl "$ORIGINAL_TEST" \
  "${GATE_ARGS[@]}" "${ADAPTER_ARGS[@]}" --preflight_manifest "$PREFLIGHT" \
  --sft_adapter "$SFT" --base_model "$BASE_MODEL" \
  --physics_python "$PHYSICS_PYTHON_BIN" --physics_timeout_s "$PHYSICS_TIMEOUT_S" \
  --max_length 1024 --candidate_batch_size 4 --topk "$TOPK" \
  --bootstrap_reps "$BOOTSTRAP_REPS" --bootstrap_seed 20260726 \
  --output "$GATE" 2>&1 | tee "${OUT}.log"
PIPE_STATUS=("${PIPESTATUS[@]}")
set -e
RC="${PIPE_STATUS[0]}"; if (( RC == 0 && PIPE_STATUS[1] != 0 )); then RC="${PIPE_STATUS[1]}"; fi
exit "$RC"
