"""Validate GridRank dynamic physics factorial confirmation."""

from __future__ import annotations

import argparse
import json
import sys

import preflight_gridrank_dynamic_physics_factorial_confirmation as confirm_preflight


sys.modules["preflight_gridrank_dynamic_confirmation"] = confirm_preflight
import verify_gridrank_dynamic_confirmation as locked_verifier  


def _args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--gate", required=True)
    parser.add_argument("--preflight", required=True)
    return parser.parse_args()


if __name__ == "__main__":
    args = _args()
    locked_verifier.main()
    gate = json.load(open(args.gate, encoding="utf-8"))
    manifest = json.load(open(args.preflight, encoding="utf-8"))
    checks = {
        "factorial_cell_bound": gate.get("factorial_cell")
        == manifest.get("factorial_cell"),
        "factorial_interpretation_present": bool(gate.get("factorial_interpretation")),
    }
    result = {
        "msg": "GridRank Frozen-SFT factorial confirmation artifact verification",
        "checks": checks,
        "verification_pass": all(checks.values()),
    }
    print(json.dumps(result, ensure_ascii=False))
    if not result["verification_pass"]:
        raise SystemExit(2)
