"""Validate GridRank label controls."""

from __future__ import annotations

import argparse
import json

from gridrank_label_controls import VARIANTS, transform_rows
from preflight_gridrank_label_controls import EXPERIMENT_ID, file_sha256, verify


def synthetic_rows():
    candidates = []
    for index in range(4):
        candidates.append({
            "action": f"Action: Replace ({index + 1}, {index + 2}) with ({index + 10}, {index + 11})",
            "candidate_feature_text": f"feature={index}",
            "accepted_by_gate": index < 2,
            "target_prob": [0.6, 0.3, 0.1, 0.0][index],
            "safe_utility": [4.0, 3.0, 1.0, 0.0][index],
        })
    return [{
        "instance_id": "synthetic-control-row",
        "physical_state_sha256": "a" * 64,
        "state_text": "synthetic state",
        "instruction_text": "minimize loss",
        "candidates": candidates,
    }]


def dependency_regression():
    rows = synthetic_rows()
    shuffled = transform_rows(
        rows, "shuffled_labels", label_seed=7, target_temperature=0.2
    )
    proxy = transform_rows(
        rows, "lindistflow_labels", label_seed=7, target_temperature=0.2,
        proxy_scorer=lambda state, actions: [0.4, 0.1, -0.1, -0.3],
    )
    checks = {
        "variants": VARIANTS == ("shuffled_labels", "lindistflow_labels"),
        "shuffled_inputs_unchanged": [x["action"] for x in shuffled[0]["candidates"]]
            == [x["action"] for x in rows[0]["candidates"]],
        "shuffled_label_multiset_preserved": sorted(
            bool(x["accepted_by_gate"]) for x in shuffled[0]["candidates"]
        ) == sorted(bool(x["accepted_by_gate"]) for x in rows[0]["candidates"]),
        "proxy_labels_expected": [
            bool(x["accepted_by_gate"]) for x in proxy[0]["candidates"]
        ] == [True, True, False, False],
        "proxy_targets_sum_one": abs(sum(
            float(x["target_prob"]) for x in proxy[0]["candidates"]
        ) - 1.0) < 1e-12,
    }
    result = {
        "msg": "GridRank matched label-controls dependency regression",
        "checks": checks,
        "verification_pass": all(checks.values()),
    }
    print(json.dumps(result, ensure_ascii=False))
    if not result["verification_pass"]:
        raise SystemExit(2)


def verify_gate(path, variant, suite_path):
    suite = verify(suite_path)
    gate = json.load(open(path, encoding="utf-8"))
    checks = {
        "schema": gate.get("schema") == "gridrank-label-control-gate-v1",
        "experiment_id": gate.get("experiment_id") == EXPERIMENT_ID,
        "variant": gate.get("label_control_variant") == variant,
        "suite": gate.get("label_control_suite_sha256") == file_sha256(suite_path),
        "training_complete": gate.get("control_training_complete") is True,
        "input_identity": gate.get("training_supervision_audit", {}).get(
            "model_visible_inputs_identical"
        ) is True,
        "supervision_changed": gate.get("training_supervision_audit", {}).get(
            "supervision_changed"
        ) is True,
        "reference_frozen": gate.get("reference_parameter_delta", {}).get(
            "changed_tensors"
        ) == 0,
        "adapter_changed": gate.get("parameter_delta", {}).get("changed_tensors", 0) > 0,
        "final_feasible": gate.get("summaries", {}).get("distilled", {}).get(
            "safe_feasible_rate"
        ) == 1.0,
        "suite_variant": variant in suite["variants"],
    }
    result = {
        "msg": "GridRank matched label-control gate verification",
        "variant": variant,
        "checks": checks,
        "verification_pass": all(checks.values()),
    }
    print(json.dumps(result, ensure_ascii=False))
    if not result["verification_pass"]:
        raise SystemExit(2)


def verify_aggregate(path, suite_path):
    verify(suite_path)
    result = json.load(open(path, encoding="utf-8"))
    checks = {
        "schema": result.get("schema") == "gridrank-label-controls-aggregate-v1",
        "experiment_id": result.get("experiment_id") == EXPERIMENT_ID,
        "audit_pass": result.get("audit_pass") is True,
        "variants": set(result.get("controls", {})) == set(VARIANTS),
        "causal_decision_present": isinstance(result.get("causal_decision"), dict),
    }
    payload = {
        "msg": "GridRank matched label-controls aggregate verification",
        "checks": checks,
        "verification_pass": all(checks.values()),
        "causal_decision": result.get("causal_decision"),
    }
    print(json.dumps(payload, ensure_ascii=False))
    if not payload["verification_pass"]:
        raise SystemExit(2)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--gate")
    parser.add_argument("--variant", choices=VARIANTS)
    parser.add_argument("--aggregate")
    parser.add_argument("--suite_preflight")
    args = parser.parse_args()
    if args.gate:
        if not args.variant or not args.suite_preflight:
            raise SystemExit("gate verification requires variant and suite")
        verify_gate(args.gate, args.variant, args.suite_preflight)
    elif args.aggregate:
        if not args.suite_preflight:
            raise SystemExit("aggregate verification requires suite")
        verify_aggregate(args.aggregate, args.suite_preflight)
    else:
        dependency_regression()


if __name__ == "__main__":
    main()
