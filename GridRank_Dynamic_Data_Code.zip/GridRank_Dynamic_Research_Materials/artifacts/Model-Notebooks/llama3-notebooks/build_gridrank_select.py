"""Derive the locked GridRank-Select train/test corpus.

Schema contract (``gridrank-select-row-v1``): ``candidates`` contains only
non-noop exchanges and is the only list scored by the LLM.  ``gate_anchor``
contains the authoritative no-op outcome for the post-ranking physics gate;
it is never a ranking target.  Targets are re-normalised over valid, feasible
non-noop loss outcomes, so an always-noop ranking policy is unrepresentable.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
from collections import Counter, defaultdict
from pathlib import Path


NOOP = "Action: none"
ROW_SCHEMA = "gridrank-select-row-v1"
SUMMARY_SCHEMA = "gridrank-select-summary-v1"
INSTRUCTION_IDS = {"loss", "voltage", "balanced", "conservative"}
OPTIMAL_TOL = 1e-12

SOURCE_ROW_FIELDS = {
    "instance_id", "partition", "source_split", "instruction_id",
    "instruction_style", "instruction_text", "source_instance_id",
    "load_id", "network_id", "state_text", "physical_state_sha256",
    "full_candidate_count", "candidate_pool_sha256", "feedback_status",
    "desired_index", "desired_action", "optimal_indices", "optimal_actions",
    "candidates",
}
SOURCE_CANDIDATE_FIELDS = {
    "action", "candidate_feature_text", "feedback_revealed", "feedback_valid",
    "feasible", "reason", "reduction_pct", "anchor_loss_kw",
    "candidate_loss_kw", "anchor_min_vm_pu", "candidate_min_vm_pu",
    "candidate_max_vm_pu", "instruction_utility", "safe_utility",
    "accepted_by_gate", "is_physics_optimal", "fallback_candidate",
    "normalised_regret", "physics_rank", "target_prob",
}
PHYSICS_FIELDS = (
    "action", "candidate_feature_text", "feedback_revealed", "feedback_valid",
    "feasible", "reason", "reduction_pct", "anchor_loss_kw",
    "candidate_loss_kw", "anchor_min_vm_pu", "candidate_min_vm_pu",
    "candidate_max_vm_pu", "instruction_utility", "safe_utility",
    "accepted_by_gate",
)
RANKING_FIELDS = (
    "ranking_utility", "ranking_eligible", "is_ranking_optimal",
    "ranking_regret", "ranking_rank", "target_prob",
)
ROW_FIELDS = {
    "schema", "instance_id", "partition", "upstream_instance_id",
    "source_split", "source_instance_id", "load_id", "network_id",
    "state_text", "physical_state_sha256", "full_candidate_count",
    "upstream_candidate_pool_sha256", "instruction_id", "instruction_style",
    "instruction_text", "feedback_status", "desired_index", "desired_action",
    "optimal_indices", "optimal_actions", "candidates", "gate_anchor",
}
CANDIDATE_FIELDS = set(PHYSICS_FIELDS) | set(RANKING_FIELDS)
GATE_ANCHOR_FIELDS = {"role", *PHYSICS_FIELDS}


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--upstream_summary", required=True)
    parser.add_argument("--upstream_audit", required=True)
    parser.add_argument("--offline_jsonl", required=True)
    parser.add_argument("--test_jsonl", required=True)
    parser.add_argument("--train_out", required=True)
    parser.add_argument("--test_out", required=True)
    parser.add_argument("--summary_out", required=True)
    parser.add_argument("--target_temperature", type=float, default=0.20)
    return parser.parse_args()


def file_sha256(path):
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def load_json(path):
    with open(path, encoding="utf-8") as handle:
        return json.load(handle)


def load_jsonl(path):
    rows = [json.loads(line) for line in open(path, encoding="utf-8") if line.strip()]
    if not rows:
        raise ValueError(f"empty JSONL: {path}")
    if len({str(row.get("instance_id")) for row in rows}) != len(rows):
        raise ValueError(f"duplicate instance_id: {path}")
    return rows


def finite_number(value):
    return not isinstance(value, bool) and isinstance(value, (int, float)) and math.isfinite(value)


def validate_upstream(summary_path, audit_path, artifacts):
    summary = load_json(summary_path)
    audit = load_json(audit_path)
    if summary.get("schema") != "gridrank-feedback-v1":
        raise ValueError("unexpected upstream GridRank summary schema")
    checks = audit.get("checks")
    if audit.get("audit_pass") is not True or not isinstance(checks, dict) or not checks:
        raise ValueError("upstream GridRank audit did not pass")
    if not all(value is True for value in checks.values()):
        raise ValueError("upstream GridRank audit contains a failed check")
    summary_sha = file_sha256(summary_path)
    if audit.get("summary_sha256") != summary_sha:
        raise ValueError("upstream audit is not bound to the supplied summary")
    summary_artifacts = summary.get("artifacts")
    audit_artifacts = audit.get("artifact_sha256")
    if not isinstance(summary_artifacts, dict) or not isinstance(audit_artifacts, dict):
        raise ValueError("upstream artifact hash maps are missing")
    if set(summary_artifacts) != set(audit_artifacts):
        raise ValueError("upstream summary/audit artifact sets differ")
    for name, record in summary_artifacts.items():
        if set(record) != {"path", "sha256"} or audit_artifacts[name] != record["sha256"]:
            raise ValueError(f"upstream artifact lock mismatch: {name}")
    for name, path in artifacts.items():
        if name not in summary_artifacts:
            raise ValueError(f"upstream summary lacks artifact: {name}")
        observed = file_sha256(path)
        if observed != summary_artifacts[name]["sha256"] or observed != audit_artifacts[name]:
            raise ValueError(f"supplied upstream artifact hash mismatch: {name}")
    if summary.get("coverage_pass") is not True:
        raise ValueError("upstream GridRank coverage did not pass")
    pool_size = summary.get("candidate_pool_size")
    if isinstance(pool_size, bool) or not isinstance(pool_size, int) or pool_size < 3:
        raise ValueError("GridRank-Select requires a fixed candidate pool of at least three")
    return summary, audit


def validate_source_rows(rows, expected_partition, expected_count):
    by_state = defaultdict(list)
    for row in rows:
        if set(row) != SOURCE_ROW_FIELDS:
            raise ValueError(f"unexpected upstream row schema: {row.get('instance_id')}")
        if row["partition"] != expected_partition:
            raise ValueError(f"wrong upstream partition: {row['instance_id']}")
        if str(row["network_id"]) not in {"33", "69"}:
            raise ValueError(f"unexpected network: {row['instance_id']}")
        candidates = row["candidates"]
        if len(candidates) != expected_count:
            raise ValueError(f"non-fixed upstream candidate count: {row['instance_id']}")
        if any(set(candidate) != SOURCE_CANDIDATE_FIELDS for candidate in candidates):
            raise ValueError(f"unexpected upstream candidate schema: {row['instance_id']}")
        actions = [candidate["action"] for candidate in candidates]
        if len(set(actions)) != len(actions) or actions.count(NOOP) != 1:
            raise ValueError(f"upstream actions/no-op malformed: {row['instance_id']}")
        if not all(candidate["feedback_revealed"] is True for candidate in candidates):
            raise ValueError(f"unrevealed upstream feedback: {row['instance_id']}")
        by_state[str(row["physical_state_sha256"])].append(row)
    selected = []
    for state_sha, directives in by_state.items():
        if len(directives) != len(INSTRUCTION_IDS):
            raise ValueError(f"state does not have four directives: {state_sha}")
        if {row["instruction_id"] for row in directives} != INSTRUCTION_IDS:
            raise ValueError(f"state directive set mismatch: {state_sha}")
        common = (
            "source_instance_id", "load_id", "network_id", "state_text",
            "physical_state_sha256", "full_candidate_count", "candidate_pool_sha256",
        )
        reference = directives[0]
        if any(any(row[key] != reference[key] for key in common) for row in directives[1:]):
            raise ValueError(f"state fields differ across directives: {state_sha}")
        loss_rows = [row for row in directives if row["instruction_id"] == "loss"]
        if len(loss_rows) != 1:
            raise ValueError(f"state does not have exactly one loss row: {state_sha}")
        selected.append(loss_rows[0])
    selected.sort(key=lambda row: (str(row["network_id"]), str(row["physical_state_sha256"])))
    return selected


def _ranking_regrets(utilities, eligible, best):
    finite = [utilities[index] for index in range(len(utilities)) if eligible[index]]
    worst = min(finite)
    scale = max(best - worst, 1e-12)
    return [
        min(1.0, max(0.0, (best - utilities[index]) / scale)) if eligible[index] else 1.0
        for index in range(len(utilities))
    ]


def derive_row(source, partition, target_temperature):
    if target_temperature <= 0 or not math.isfinite(target_temperature):
        raise ValueError("target_temperature must be positive and finite")
    anchors = [candidate for candidate in source["candidates"] if candidate["action"] == NOOP]
    if len(anchors) != 1:
        raise ValueError(f"source must contain one no-op: {source['instance_id']}")
    anchor = anchors[0]
    if not (anchor["feedback_valid"] is True and anchor["feasible"] is True):
        raise ValueError(f"no-op anchor is not operational: {source['instance_id']}")
    source_candidates = [candidate for candidate in source["candidates"] if candidate["action"] != NOOP]
    eligible = [
        candidate["feedback_valid"] is True
        and candidate["feasible"] is True
        and finite_number(candidate["reduction_pct"])
        for candidate in source_candidates
    ]
    if not any(eligible):
        raise ValueError(f"no rankable non-noop candidate: {source['instance_id']}")
    utilities = [
        float(candidate["reduction_pct"]) if eligible[index] else float("-inf")
        for index, candidate in enumerate(source_candidates)
    ]
    best = max(utilities)
    optimal = {
        index for index, value in enumerate(utilities)
        if eligible[index] and math.isclose(value, best, rel_tol=OPTIMAL_TOL, abs_tol=OPTIMAL_TOL)
    }
    ranking_order = sorted(
        range(len(source_candidates)),
        key=lambda index: (not eligible[index], -utilities[index], source_candidates[index]["action"]),
    )
    ranks = {index: rank for rank, index in enumerate(ranking_order)}
    desired = ranking_order[0]
    regrets = _ranking_regrets(utilities, eligible, best)
    weights = [
        math.exp((utilities[index] - best) / target_temperature) if eligible[index] else 0.0
        for index in range(len(source_candidates))
    ]
    total = sum(weights)
    if not math.isfinite(total) or total <= 0:
        raise ValueError(f"invalid target weights: {source['instance_id']}")
    candidates = []
    for index, source_candidate in enumerate(source_candidates):
        candidate = {key: source_candidate[key] for key in PHYSICS_FIELDS}
        candidate.update({
            "ranking_utility": utilities[index] if eligible[index] else None,
            "ranking_eligible": bool(eligible[index]),
            "is_ranking_optimal": index in optimal,
            "ranking_regret": regrets[index],
            "ranking_rank": ranks[index],
            "target_prob": weights[index] / total,
        })
        candidates.append(candidate)
    gate_anchor = {"role": "noop-anchor-only"}
    gate_anchor.update({key: anchor[key] for key in PHYSICS_FIELDS})
    row = {
        "schema": ROW_SCHEMA,
        "instance_id": f"select:{partition}:{source['network_id']}:{source['physical_state_sha256']}",
        "partition": partition,
        "upstream_instance_id": source["instance_id"],
        "source_split": source["source_split"],
        "source_instance_id": source["source_instance_id"],
        "load_id": source["load_id"],
        "network_id": str(source["network_id"]),
        "state_text": source["state_text"],
        "physical_state_sha256": source["physical_state_sha256"],
        "full_candidate_count": source["full_candidate_count"],
        "upstream_candidate_pool_sha256": source["candidate_pool_sha256"],
        "instruction_id": "loss",
        "instruction_style": source["instruction_style"],
        "instruction_text": source["instruction_text"],
        "feedback_status": "authoritative-gridrank-select-v1",
        "desired_index": desired,
        "desired_action": candidates[desired]["action"],
        "optimal_indices": sorted(optimal),
        "optimal_actions": [candidates[index]["action"] for index in sorted(optimal)],
        "candidates": candidates,
        "gate_anchor": gate_anchor,
    }
    validate_derived_row(row, partition, len(source_candidates))
    return row


def validate_derived_row(row, expected_partition, expected_candidate_count):
    if set(row) != ROW_FIELDS or row.get("schema") != ROW_SCHEMA:
        raise ValueError(f"derived row schema mismatch: {row.get('instance_id')}")
    if row["partition"] != expected_partition or row["instruction_id"] != "loss":
        raise ValueError(f"derived row identity mismatch: {row['instance_id']}")
    candidates = row["candidates"]
    if len(candidates) != expected_candidate_count or len(candidates) < 2:
        raise ValueError(f"derived candidate count mismatch: {row['instance_id']}")
    if any(set(candidate) != CANDIDATE_FIELDS for candidate in candidates):
        raise ValueError(f"derived candidate schema mismatch: {row['instance_id']}")
    if any(candidate["action"] == NOOP for candidate in candidates):
        raise ValueError(f"no-op leaked into LLM ranking: {row['instance_id']}")
    if set(row["gate_anchor"]) != GATE_ANCHOR_FIELDS:
        raise ValueError(f"gate anchor schema mismatch: {row['instance_id']}")
    if row["gate_anchor"]["role"] != "noop-anchor-only" or row["gate_anchor"]["action"] != NOOP:
        raise ValueError(f"gate anchor is not a segregated no-op: {row['instance_id']}")
    target_sum = sum(float(candidate["target_prob"]) for candidate in candidates)
    if not math.isclose(target_sum, 1.0, rel_tol=0.0, abs_tol=1e-10):
        raise ValueError(f"targets do not sum to one: {row['instance_id']}")
    if any(candidate["target_prob"] != 0.0 for candidate in candidates if not candidate["ranking_eligible"]):
        raise ValueError(f"ineligible candidate has target mass: {row['instance_id']}")
    if not row["optimal_indices"] or row["desired_index"] not in row["optimal_indices"]:
        raise ValueError(f"derived optimum mismatch: {row['instance_id']}")
    if row["desired_action"] == NOOP:
        raise ValueError(f"always-noop target is representable: {row['instance_id']}")


def write_jsonl(path, rows):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8", newline="\n") as handle:
        for row in rows:
            handle.write(json.dumps(row, ensure_ascii=False, separators=(",", ":")) + "\n")


def partition_summary(rows):
    return {
        "rows": len(rows),
        "base_states": len({row["physical_state_sha256"] for row in rows}),
        "loads": len({row["load_id"] for row in rows}),
        "network_mix": dict(Counter(row["network_id"] for row in rows)),
        "candidate_count_min": min(len(row["candidates"]) for row in rows),
        "candidate_count_max": max(len(row["candidates"]) for row in rows),
        "accepted_candidates": sum(
            candidate["accepted_by_gate"] for row in rows for candidate in row["candidates"]
        ),
        "unsafe_candidates": sum(
            not candidate["accepted_by_gate"] for row in rows for candidate in row["candidates"]
        ),
        "ranking_eligible_candidates": sum(
            candidate["ranking_eligible"] for row in rows for candidate in row["candidates"]
        ),
        "all_noop_anchor_only": all(
            row["gate_anchor"]["action"] == NOOP
            and all(candidate["action"] != NOOP for candidate in row["candidates"])
            for row in rows
        ),
    }


def main():
    args = parse_args()
    upstream_artifacts = {
        "offline_train": args.offline_jsonl,
        "test": args.test_jsonl,
    }
    upstream_summary, upstream_audit = validate_upstream(
        args.upstream_summary, args.upstream_audit, upstream_artifacts
    )
    expected_count = int(upstream_summary["candidate_pool_size"])
    offline_source = validate_source_rows(
        load_jsonl(args.offline_jsonl), "offline_train", expected_count
    )
    test_source = validate_source_rows(load_jsonl(args.test_jsonl), "test", expected_count)
    train_rows = [derive_row(row, "train", args.target_temperature) for row in offline_source]
    test_rows = [derive_row(row, "test", args.target_temperature) for row in test_source]
    all_counts = {len(row["candidates"]) for row in [*train_rows, *test_rows]}
    if all_counts != {expected_count - 1}:
        raise RuntimeError(f"non-noop candidate count is not fixed: {all_counts}")
    for name, rows in (("train", train_rows), ("test", test_rows)):
        if {row["network_id"] for row in rows} != {"33", "69"}:
            raise RuntimeError(f"{name} does not cover both networks")
        accepted = Counter()
        unsafe = Counter()
        for row in rows:
            for candidate in row["candidates"]:
                accepted[row["network_id"]] += int(candidate["accepted_by_gate"])
                unsafe[row["network_id"]] += int(not candidate["accepted_by_gate"])
        if any(accepted[network] <= 0 or unsafe[network] <= 0 for network in ("33", "69")):
            raise RuntimeError(f"{name} lacks accepted/unsafe mix in a network")
    train_states = {row["physical_state_sha256"] for row in train_rows}
    test_states = {row["physical_state_sha256"] for row in test_rows}
    train_loads = {row["load_id"] for row in train_rows}
    test_loads = {row["load_id"] for row in test_rows}
    if train_states.intersection(test_states) or train_loads.intersection(test_loads):
        raise RuntimeError("GridRank-Select train/test state or load overlap")
    write_jsonl(args.train_out, train_rows)
    write_jsonl(args.test_out, test_rows)
    upstream_summary_sha = file_sha256(args.upstream_summary)
    upstream_audit_sha = file_sha256(args.upstream_audit)
    summary = {
        "msg": "GridRank-Select non-noop loss-ranking data build",
        "schema": SUMMARY_SCHEMA,
        "objective": "loss",
        "llm_ranking_membership": "all fixed-pool non-noop K=1 exchanges only",
        "final_gate_anchor": "authoritative no-op stored separately and never scored as a ranking candidate",
        "target_definition": "softmax of authoritative feasible non-noop loss reduction",
        "target_temperature": args.target_temperature,
        "fixed_nonnoop_candidate_count": expected_count - 1,
        "upstream": {
            "summary": {"path": args.upstream_summary, "sha256": upstream_summary_sha},
            "audit": {"path": args.upstream_audit, "sha256": upstream_audit_sha},
            "artifacts": {
                name: {"path": path, "sha256": file_sha256(path)}
                for name, path in upstream_artifacts.items()
            },
            "summary_artifact_sha256": {
                name: record["sha256"]
                for name, record in upstream_summary["artifacts"].items()
            },
            "audit_artifact_sha256": dict(upstream_audit["artifact_sha256"]),
        },
        "partitions": {
            "train": partition_summary(train_rows),
            "test": partition_summary(test_rows),
        },
        "artifacts": {
            "train": {"path": args.train_out, "sha256": file_sha256(args.train_out)},
            "test": {"path": args.test_out, "sha256": file_sha256(args.test_out)},
        },
        "code_sha256": {"build_gridrank_select.py": file_sha256(Path(__file__).resolve())},
    }
    summary["coverage_pass"] = all(
        partition["rows"] == partition["base_states"] == partition["loads"]
        and partition["network_mix"].get("33", 0) > 0
        and partition["network_mix"].get("69", 0) > 0
        and partition["candidate_count_min"] == expected_count - 1
        and partition["candidate_count_max"] == expected_count - 1
        and partition["accepted_candidates"] > 0
        and partition["unsafe_candidates"] > 0
        and partition["all_noop_anchor_only"] is True
        for partition in summary["partitions"].values()
    )
    if not summary["coverage_pass"]:
        raise RuntimeError("GridRank-Select coverage gate failed")
    Path(args.summary_out).parent.mkdir(parents=True, exist_ok=True)
    Path(args.summary_out).write_text(
        json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    print(json.dumps(summary, ensure_ascii=False))


if __name__ == "__main__":
    main()
