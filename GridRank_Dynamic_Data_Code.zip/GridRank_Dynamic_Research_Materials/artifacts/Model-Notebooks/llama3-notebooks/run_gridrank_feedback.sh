#!/usr/bin/env bash
set -euo pipefail

CURRENT_STAGE="bootstrap"
GATE_JSON_PRINTED=0
on_exit() {
  local rc=$?
  trap - EXIT
  if (( rc != 0 )) && [[ "$GATE_JSON_PRINTED" == "0" ]]; then
    printf '{"msg":"GridRank runner failure","stage":"%s","gate_pass":false,"exit_code":%d}\n' \
      "$CURRENT_STAGE" "$rc"
  fi
  exit "$rc"
}
trap on_exit EXIT

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"
export HF_HUB_OFFLINE=1

PREFLIGHT_ONLY="${PREFLIGHT_ONLY:-1}"
case "$PREFLIGHT_ONLY" in
  0|1) ;;
  *) echo "PREFLIGHT_ONLY must be 0 or 1" >&2; exit 2 ;;
esac
if [[ "$PREFLIGHT_ONLY" == "1" ]]; then
  export CUDA_VISIBLE_DEVICES=""
  TOTAL_STAGES=5
else
  TOTAL_STAGES=4
fi
readonly TOTAL_STAGES

resolve_executable() {
  local requested="$1"
  if [[ "$requested" == */* ]]; then
    [[ -x "$requested" ]] || return 1
    printf '%s\n' "$requested"
  else
    command -v -- "$requested"
  fi
}

if ! TRAIN_PYTHON_BIN="$(resolve_executable "${TRAIN_PYTHON:-python}")"; then
  echo "TRAIN_PYTHON is not executable or resolvable on PATH: ${TRAIN_PYTHON:-python}" >&2
  exit 2
fi
if ! PHYSICS_PYTHON_BIN="$(resolve_executable "${PHYSICS_PYTHON:-$TRAIN_PYTHON_BIN}")"; then
  echo "PHYSICS_PYTHON is not executable or resolvable on PATH: ${PHYSICS_PYTHON:-$TRAIN_PYTHON_BIN}" >&2
  exit 2
fi

BASE_MODEL="${BASE_MODEL:-../../Meta-Llama-3.1-8B-Instruct}"
SFT="${SFT:-output_gridintent_gate_33_69_v2_20260717/sft_only}"

TRAIN33="${TRAIN33:-limited_k1_33_n500_train_no_oracle_s20260702.csv}"
TRAIN69="${TRAIN69:-limited_k1_69_n500_train_no_oracle_s20260702.csv}"
VAL33_RAW="${VAL33_RAW:-structured_action_33_fixed_full_validation.jsonl}"
VAL69_RAW="${VAL69_RAW:-structured_action_69_s42_full_validation.jsonl}"

TAG="${TAG:-gridrank_feedback_gate_v1_20260721}"
if [[ ! "$TAG" =~ ^[A-Za-z0-9][A-Za-z0-9._-]*$ ]]; then
  echo "TAG must contain only letters, digits, dot, underscore, or hyphen" >&2
  exit 2
fi
VAL33="${VAL33:-${TAG}_validation33_state_only.jsonl}"
VAL69="${VAL69:-${TAG}_validation69_state_only.jsonl}"
VAL33_MANIFEST="${VAL33_MANIFEST:-${TAG}_validation33_state_only.manifest.json}"
VAL69_MANIFEST="${VAL69_MANIFEST:-${TAG}_validation69_state_only.manifest.json}"
OFFLINE_JSONL="${OFFLINE_JSONL:-${TAG}_offline_train.jsonl}"
ONLINE_JSONL="${ONLINE_JSONL:-${TAG}_online_stream.jsonl}"
TEST_JSONL="${TEST_JSONL:-${TAG}_validation_test.jsonl}"
DATA_SUMMARY="${DATA_SUMMARY:-${TAG}_data_summary.json}"
DATA_AUDIT="${DATA_AUDIT:-${TAG}_data_audit.json}"
OUT="${OUT:-output_${TAG}}"
PREFLIGHT_MANIFEST="${PREFLIGHT_MANIFEST:-${OUT}.preflight.json}"


readonly OFFLINE_LOADS_PER_NETWORK="${OFFLINE_LOADS_PER_NETWORK:-16}"
readonly ONLINE_LOADS_PER_NETWORK="${ONLINE_LOADS_PER_NETWORK:-4}"
readonly TEST_LOADS_PER_NETWORK="${TEST_LOADS_PER_NETWORK:-8}"
readonly CANDIDATE_POOL_SIZE="${CANDIDATE_POOL_SIZE:-16}"
readonly CANDIDATE_SEED="${CANDIDATE_SEED:-20260721}"
readonly ROW_SEED="${ROW_SEED:-42}"

readonly MAX_LENGTH=1024
readonly CANDIDATE_BATCH_SIZE=4
readonly OFFLINE_EPOCHS=2
readonly ONLINE_ROUNDS=2
readonly ONLINE_QUERY_BUDGET=4
readonly TOPK=4
readonly LEARNING_RATE=2e-6
readonly GRAD_ACCUM=4
readonly MAX_GRAD_NORM=1.0
readonly LIST_TEMPERATURE=1.0
readonly LAMBDA_MARGIN=1.0
readonly OFFLINE_MARGIN=0.5
readonly BETA_REFERENCE=0.04
readonly ONLINE_MARGIN=0.5
readonly ONLINE_OFFLINE_KL=0.10
readonly ONLINE_REPLAY_MASS=0.50
readonly TRAIN_SEED=42
readonly GRADIENT_CHECKPOINTING=1
readonly PHYSICS_TIMEOUT_S="${PHYSICS_TIMEOUT_S:-60.0}"
readonly BOOTSTRAP_REPS="${BOOTSTRAP_REPS:-2000}"

for path in \
  "$TRAIN33" "$TRAIN69" "$VAL33_RAW" "$VAL69_RAW" \
  "$SFT/adapter_config.json" "$SFT/adapter_model.safetensors" \
  "$BASE_MODEL/config.json" "$BASE_MODEL/tokenizer_config.json"; do
  test -e "$path" || { echo "missing required path: $path" >&2; exit 2; }
done
test ! -e "$OUT" || { echo "refusing to reuse output directory: $OUT" >&2; exit 2; }
if [[ "$PREFLIGHT_ONLY" == "0" ]]; then
  test ! -e "${OUT}.log" || { echo "refusing to overwrite log: ${OUT}.log" >&2; exit 2; }
fi

if [[ "$PREFLIGHT_ONLY" == "1" ]]; then
echo "=== 1/$TOTAL_STAGES CREATE STRICT VALIDATION STATE VIEWS ==="
CURRENT_STAGE="validation_views"
if [[ ! -e "$VAL33" && ! -e "$VAL33_MANIFEST" ]]; then
  "$TRAIN_PYTHON_BIN" -B make_no_oracle_state_view.py \
    --input "$VAL33_RAW" --split validation \
    --output_jsonl "$VAL33" --manifest_json "$VAL33_MANIFEST"
elif [[ ! -e "$VAL33" || ! -e "$VAL33_MANIFEST" ]]; then
  echo "partial 33-bus validation state-only artifact set; use a new TAG" >&2; exit 2
fi
if [[ ! -e "$VAL69" && ! -e "$VAL69_MANIFEST" ]]; then
  "$TRAIN_PYTHON_BIN" -B make_no_oracle_state_view.py \
    --input "$VAL69_RAW" --split validation \
    --output_jsonl "$VAL69" --manifest_json "$VAL69_MANIFEST"
elif [[ ! -e "$VAL69" || ! -e "$VAL69_MANIFEST" ]]; then
  echo "partial 69-bus validation state-only artifact set; use a new TAG" >&2; exit 2
fi


"$TRAIN_PYTHON_BIN" -B -c '
import json,sys
from preflight_gridrank_feedback import validation_view_locks
locks=validation_view_locks(
    [f"33={sys.argv[1]}", f"69={sys.argv[2]}"],
    [f"33={sys.argv[3]}", f"69={sys.argv[4]}"],
    [f"33={sys.argv[5]}", f"69={sys.argv[6]}"],
)
print(json.dumps({"msg":"validation view lock PASS","locks":locks},ensure_ascii=False))
' "$VAL33_RAW" "$VAL69_RAW" "$VAL33" "$VAL69" "$VAL33_MANIFEST" "$VAL69_MANIFEST"

echo "=== 2/$TOTAL_STAGES DEPENDENCY-LIGHT GRIDRANK REGRESSION TESTS ==="
CURRENT_STAGE="dependency_regression"
"$TRAIN_PYTHON_BIN" -B verify_gridrank_feedback.py \
  --train33 "$TRAIN33" --train69 "$TRAIN69" \
  --candidate_pool_size "$CANDIDATE_POOL_SIZE" \
  --candidate_seed "$CANDIDATE_SEED"

data_existing=0
for path in "$OFFLINE_JSONL" "$ONLINE_JSONL" "$TEST_JSONL" "$DATA_SUMMARY"; do
  test -e "$path" && data_existing=$((data_existing + 1))
done
if [[ "$data_existing" == "0" ]]; then
  echo "=== 3/$TOTAL_STAGES BUILD SEALED STREAM + LIVE PANDAPOWER TEACHER DATA ==="
  CURRENT_STAGE="data_build"
  "$PHYSICS_PYTHON_BIN" -c \
    "import pandapower,sys; print(sys.executable); print('pandapower',pandapower.__version__)"
  "$TRAIN_PYTHON_BIN" -u build_gridrank_feedback.py \
    --train_source "33=$TRAIN33" --train_source "69=$TRAIN69" \
    --validation_source "33=$VAL33" --validation_source "69=$VAL69" \
    --offline_loads_per_network "$OFFLINE_LOADS_PER_NETWORK" \
    --online_loads_per_network "$ONLINE_LOADS_PER_NETWORK" \
    --test_loads_per_network "$TEST_LOADS_PER_NETWORK" \
    --candidate_pool_size "$CANDIDATE_POOL_SIZE" \
    --candidate_seed "$CANDIDATE_SEED" --row_seed "$ROW_SEED" \
    --physics_backend pandapower-subprocess \
    --physics_python "$PHYSICS_PYTHON_BIN" \
    --physics_timeout_s "$PHYSICS_TIMEOUT_S" \
    --offline_out "$OFFLINE_JSONL" --online_out "$ONLINE_JSONL" \
    --test_out "$TEST_JSONL" --summary_out "$DATA_SUMMARY"
elif [[ "$data_existing" != "4" ]]; then
  echo "partial GridRank data artifact set; use a new TAG" >&2; exit 2
else
  echo "=== 3/$TOTAL_STAGES REUSE COMPLETE GRIDRANK DATA ARTIFACT SET ==="
fi

echo "=== 4/$TOTAL_STAGES AUDIT MEMBERSHIP, SEALED ONLINE DATA, TARGETS, AND PP REPLAY ==="
CURRENT_STAGE="data_audit"
if [[ ! -e "$DATA_AUDIT" ]]; then
  "$TRAIN_PYTHON_BIN" -u audit_gridrank_feedback.py \
    --train_source "33=$TRAIN33" --train_source "69=$TRAIN69" \
    --validation_source "33=$VAL33" --validation_source "69=$VAL69" \
    --offline_jsonl "$OFFLINE_JSONL" --online_jsonl "$ONLINE_JSONL" \
    --test_jsonl "$TEST_JSONL" --summary_json "$DATA_SUMMARY" \
    --physics_python "$PHYSICS_PYTHON_BIN" \
    --physics_timeout_s "$PHYSICS_TIMEOUT_S" --replay_states_per_network 1 \
    --output "$DATA_AUDIT"
else
  echo "reusing existing complete audit: $DATA_AUDIT"
fi

if [[ "$PREFLIGHT_ONLY" == "1" ]]; then
  CURRENT_STAGE="locked_cpu_preflight"
  test ! -e "$PREFLIGHT_MANIFEST" || {
    echo "refusing to overwrite preflight manifest: $PREFLIGHT_MANIFEST" >&2; exit 2;
  }
  echo "=== 5/$TOTAL_STAGES LOCK DATA, MODEL, CODE, RUNTIME, AND TRAINING SCHEDULE ==="
  "$TRAIN_PYTHON_BIN" -u preflight_gridrank_feedback.py \
    --train_source "33=$TRAIN33" --train_source "69=$TRAIN69" \
    --validation_source "33=$VAL33" --validation_source "69=$VAL69" \
    --validation_raw "33=$VAL33_RAW" --validation_raw "69=$VAL69_RAW" \
    --validation_view_manifest "33=$VAL33_MANIFEST" \
    --validation_view_manifest "69=$VAL69_MANIFEST" \
    --offline_jsonl "$OFFLINE_JSONL" --online_jsonl "$ONLINE_JSONL" \
    --test_jsonl "$TEST_JSONL" --data_summary "$DATA_SUMMARY" \
    --data_audit "$DATA_AUDIT" --resume_adapter_path "$SFT" \
    --base_model "$BASE_MODEL" --physics_python "$PHYSICS_PYTHON_BIN" \
    --physics_timeout_s "$PHYSICS_TIMEOUT_S" \
    --output "$PREFLIGHT_MANIFEST" \
    --max_length "$MAX_LENGTH" --candidate_batch_size "$CANDIDATE_BATCH_SIZE" \
    --offline_epochs "$OFFLINE_EPOCHS" --online_rounds "$ONLINE_ROUNDS" \
    --online_query_budget "$ONLINE_QUERY_BUDGET" --topk "$TOPK" \
    --learning_rate "$LEARNING_RATE" --grad_accum "$GRAD_ACCUM" \
    --max_grad_norm "$MAX_GRAD_NORM" --list_temperature "$LIST_TEMPERATURE" \
    --lambda_margin "$LAMBDA_MARGIN" --offline_margin "$OFFLINE_MARGIN" \
    --beta_reference "$BETA_REFERENCE" --online_margin "$ONLINE_MARGIN" \
    --online_offline_kl "$ONLINE_OFFLINE_KL" \
    --online_replay_mass "$ONLINE_REPLAY_MASS" --seed "$TRAIN_SEED" \
    --gradient_checkpointing "$GRADIENT_CHECKPOINTING" \
    --bootstrap_reps "$BOOTSTRAP_REPS"
  echo "=== GRIDRANK CPU PREFLIGHT COMPLETE; GPU NOT STARTED ==="
  exit 0
fi
fi

CURRENT_STAGE="locked_cpu_artifact_check"
for path in \
  "$VAL33" "$VAL69" "$VAL33_MANIFEST" "$VAL69_MANIFEST" \
  "$OFFLINE_JSONL" "$ONLINE_JSONL" "$TEST_JSONL" "$DATA_SUMMARY" \
  "$DATA_AUDIT" "$PREFLIGHT_MANIFEST"; do
  test -f "$path" || {
    echo "missing locked CPU artifact; run PREFLIGHT_ONLY=1 first: $path" >&2; exit 2;
  }
done

echo "=== 1/$TOTAL_STAGES VERIFY LOCKED SOFTWARE RUNTIMES + MODEL INVENTORY ==="
CURRENT_STAGE="runtime_lock"
set +e
RUNTIME_JSON="$("$TRAIN_PYTHON_BIN" -B preflight_gridrank_feedback.py \
  --verify_runtime_manifest "$PREFLIGHT_MANIFEST" \
  --base_model "$BASE_MODEL" \
  --physics_python "$PHYSICS_PYTHON_BIN" \
  --physics_timeout_s "$PHYSICS_TIMEOUT_S" \
  --bootstrap_reps "$BOOTSTRAP_REPS")"
RUNTIME_RC=$?
set -e
printf '%s\n' "$RUNTIME_JSON"
if (( RUNTIME_RC != 0 )); then
  exit "$RUNTIME_RC"
fi

echo "=== 2/$TOTAL_STAGES CUDA + BITSANDBYTES NF4 READINESS ==="
CURRENT_STAGE="gpu_readiness"
set +e
GPU_JSON="$("$TRAIN_PYTHON_BIN" -B - <<'PY'
import json
result={"msg":"GridRank CUDA/bitsandbytes readiness"}
try:
    import bitsandbytes as bnb
    import torch
    from transformers import BitsAndBytesConfig
    checks={
        "cuda_available": bool(torch.cuda.is_available()),
        "visible_device_count": int(torch.cuda.device_count()) > 0,
    }
    if all(checks.values()):
        device=torch.device("cuda:0")
        probe=torch.ones(1,device=device)
        checks["cuda_tensor_ok"]=float(probe.item()) == 1.0
        free,total=torch.cuda.mem_get_info(device)
        result.update({
            "device":torch.cuda.get_device_name(device),
            "capability":list(torch.cuda.get_device_capability(device)),
            "free_memory_bytes":int(free),
            "total_memory_bytes":int(total),
        })
        del probe
    else:
        checks["cuda_tensor_ok"]=False
    quant_config=BitsAndBytesConfig(
        load_in_4bit=True,
        bnb_4bit_quant_type="nf4",
        bnb_4bit_compute_dtype=torch.float16,
        bnb_4bit_use_double_quant=True,
    )
    checks["bitsandbytes_4bit_config_ok"]=(
        quant_config.load_in_4bit
        and quant_config.bnb_4bit_quant_type == "nf4"
        and quant_config.bnb_4bit_compute_dtype == torch.float16
        and quant_config.bnb_4bit_use_double_quant is True
    )
    if checks["cuda_available"] and checks["visible_device_count"]:
        layer=bnb.nn.Linear4bit(
            64,64,bias=False,compute_dtype=torch.float16,
            compress_statistics=True,quant_type="nf4",
        ).to(device)
        inputs=torch.randn(2,64,device=device,dtype=torch.float16)
        with torch.no_grad():
            outputs=layer(inputs)
        torch.cuda.synchronize(device)
        checks["bitsandbytes_nf4_cuda_kernel_ok"]=(
            outputs.is_cuda and bool(torch.isfinite(outputs).all().item())
            and tuple(outputs.shape) == (2,64)
        )
        del inputs,outputs,layer
        torch.cuda.empty_cache()
    else:
        checks["bitsandbytes_nf4_cuda_kernel_ok"]=False
except Exception as exc:
    checks=locals().get("checks",{})
    checks["exception_free"]=False
    result["error"]=f"{type(exc).__name__}: {exc}"
result["checks"]=checks
result["readiness_pass"]=bool(checks) and all(checks.values())
print(json.dumps(result,ensure_ascii=False))
raise SystemExit(0 if result["readiness_pass"] else 2)
PY
)"
GPU_RC=$?
set -e
printf '%s\n' "$GPU_JSON"
if (( GPU_RC != 0 )); then
  exit "$GPU_RC"
fi

echo "=== 3/$TOTAL_STAGES OFFLINE PHYSICS DISTILLATION + BUDGETED ONLINE COUNTEREXAMPLES ==="
CURRENT_STAGE="gpu_training"
set +e
"$TRAIN_PYTHON_BIN" -u train_gridrank_feedback.py \
  --offline_jsonl "$OFFLINE_JSONL" --online_jsonl "$ONLINE_JSONL" \
  --test_jsonl "$TEST_JSONL" --data_summary "$DATA_SUMMARY" \
  --data_audit "$DATA_AUDIT" --preflight_manifest "$PREFLIGHT_MANIFEST" \
  --resume_adapter_path "$SFT" --base_model "$BASE_MODEL" \
  --physics_python "$PHYSICS_PYTHON_BIN" --physics_timeout_s "$PHYSICS_TIMEOUT_S" \
  --output_dir "$OUT" \
  --max_length "$MAX_LENGTH" --candidate_batch_size "$CANDIDATE_BATCH_SIZE" \
  --offline_epochs "$OFFLINE_EPOCHS" --online_rounds "$ONLINE_ROUNDS" \
  --online_query_budget "$ONLINE_QUERY_BUDGET" --topk "$TOPK" \
  --learning_rate "$LEARNING_RATE" --grad_accum "$GRAD_ACCUM" \
  --max_grad_norm "$MAX_GRAD_NORM" --list_temperature "$LIST_TEMPERATURE" \
  --lambda_margin "$LAMBDA_MARGIN" --offline_margin "$OFFLINE_MARGIN" \
  --beta_reference "$BETA_REFERENCE" --online_margin "$ONLINE_MARGIN" \
  --online_offline_kl "$ONLINE_OFFLINE_KL" \
  --online_replay_mass "$ONLINE_REPLAY_MASS" --seed "$TRAIN_SEED" \
  --gradient_checkpointing "$GRADIENT_CHECKPOINTING" \
  --bootstrap_reps "$BOOTSTRAP_REPS" \
  2>&1 | tee "${OUT}.log"
PIPE_STATUS=("${PIPESTATUS[@]}")
set -e
TRAIN_RC="${PIPE_STATUS[0]}"
TEE_RC="${PIPE_STATUS[1]}"
RUN_RC="$TRAIN_RC"
if (( RUN_RC == 0 && TEE_RC != 0 )); then
  RUN_RC="$TEE_RC"
fi

echo "=== 4/$TOTAL_STAGES PRINT LOCKED DECISION ARTIFACT ==="
CURRENT_STAGE="decision_artifact"
if [[ -f "$OUT/gridrank_gate.json" ]]; then
  set +e
  GATE_JSON="$("$TRAIN_PYTHON_BIN" -B -c '
import json,sys
with open(sys.argv[1],encoding="utf-8") as handle:
    payload=json.load(handle)
required={
    "msg","preflight_sha256","training_schedule","live_topk_gate",
    "engineering_checks","paper_checks","adapter_save",
    "engineering_gate_pass","paper_gate_pass",
}
if not isinstance(payload,dict) or required-set(payload):
    raise ValueError(f"incomplete gate JSON: {sorted(required-set(payload))}")
if not all(isinstance(payload[name],bool) for name in (
    "engineering_gate_pass","paper_gate_pass"
)):
    raise ValueError("gate decisions must be booleans")
for name in ("engineering_checks","paper_checks"):
    if not isinstance(payload[name],dict) or not payload[name] or not all(
        isinstance(value,bool) for value in payload[name].values()
    ):
        raise ValueError(f"invalid {name}")
if not isinstance(payload["adapter_save"],dict) or not isinstance(
    payload["adapter_save"].get("valid"),bool
):
    raise ValueError("invalid adapter_save decision")
print(json.dumps(payload,ensure_ascii=False))
' "$OUT/gridrank_gate.json")"
  GATE_READ_RC=$?
  set -e
  if (( GATE_READ_RC == 0 )); then
    printf '%s\n' "$GATE_JSON"
    GATE_JSON_PRINTED=1
  elif (( RUN_RC == 0 )); then
    RUN_RC="$GATE_READ_RC"
  fi
elif (( RUN_RC == 0 )); then
  echo "training returned success but gridrank_gate.json is missing" >&2
  exit 3
fi
exit "$RUN_RC"
