"""Validate GridRank dynamic factorization ablation dependencies."""

from __future__ import annotations

import ast
import json
from pathlib import Path

import eval_gridrank_dynamic_factorization_ablation as evaluation


HERE = Path(__file__).resolve().parent


def source(name):
    return (HERE / name).read_text(encoding="utf-8")


def call_names(tree):
    names = []
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        value = node.func
        parts = []
        while isinstance(value, ast.Attribute):
            parts.append(value.attr)
            value = value.value
        if isinstance(value, ast.Name):
            parts.append(value.id)
        names.append(".".join(reversed(parts)))
    return names


def fake_row(instance, pair, state_value, method, pair_type="maintenance_voltage"):
    return {
        "instance_id": instance,
        "pair_id": pair,
        "pair_type": pair_type,
        "network": "33",
        "normalised_regret": state_value,
        "method": method,
    }


def main():
    evaluator_text = source("eval_gridrank_dynamic_factorization_ablation.py")
    preflight_text = source("preflight_gridrank_dynamic_factorization_ablation.py")
    runner_text = source("run_gridrank_dynamic_factorization_ablation.sh")
    joint_text = source("gridrank_dynamic_llm.py")
    factor_text = source("gridrank_dynamic_factorized_llm.py")
    evaluator_calls = call_names(ast.parse(evaluator_text))
    methods = {
        "before": [
            fake_row("a", "p1", 1.0, "before"),
            fake_row("b", "p2", 2.0, "before"),
        ],
        "after": [
            fake_row("a", "p1", 0.0, "after"),
            fake_row("b", "p2", 1.0, "after"),
        ],
    }
    synthetic = evaluation.comparison(
        methods,
        "before",
        "after",
        {"p1": "s1", "p2": "s2"},
        {"s1": "33", "s2": "33"},
        200,
        17,
        "maintenance_voltage",
    )
    state = synthetic["physical_state_statistics"]
    checks = {
        "evaluation_has_no_optimizer": not any(
            "optimizer" in name.lower() for name in evaluator_calls
        ),
        "evaluation_has_no_backward": not any(
            name.endswith("backward") for name in evaluator_calls
        ),
        "evaluation_has_no_training_entrypoint": all(
            token not in evaluator_text
            for token in ("train_replay(", "loss_terms(", ".fit(")
        ),
        "evaluation_has_no_live_power_flow": all(
            token not in evaluator_text
            for token in (
                "score_state(",
                "runpp(",
                "physics_python",
                "subprocess_physics_backend",
            )
        ),
        "joint_adapter_is_frozen_input": (
            "resume_adapter_path=args.joint_adapter" in evaluator_text
            and "parameter.requires_grad_(False)" in evaluator_text
        ),
        "factorized_records_reused_not_rescored": (
            "factorized_confirmation_records" in evaluator_text
            and "primitive_score_cache" not in evaluator_text
        ),
        "correct_removed_counterfactual_controls": all(
            token in evaluator_text
            for token in (
                '"correct"',
                '"instruction_removed"',
                '"instruction_counterfactual"',
            )
        ),
        "primary_is_withheld_composition": (
            "PRIMARY = preflight.PRIMARY_PAIR_TYPE" in evaluator_text
            and 'PRIMARY_PAIR_TYPE = "maintenance_voltage"' in preflight_text
        ),
        "physical_state_cluster_primary": (
            "bootstrap_state_matrix" in evaluator_text
            and "physical_state_statistics" in evaluator_text
        ),
        "orientation_joint_minus_factorized": (
            "evaluation.JOINT" in source(
                "verify_gridrank_dynamic_factorization_ablation.py"
            )
            and synthetic["positive_favors"] == "after"
            and state["improvement_mean"] == 1.0
            and state["physical_state_cluster_bootstrap_ci95"] == [1.0, 1.0]
        ),
        "matched_schedule_explicit": all(
            token in preflight_text
            for token in (
                "same_training_row_ids",
                "same_initial_gridrank_adapter",
                "same_scalar_training_schedule",
                "same_total_semantic_loss_weight",
                "same_four_score_calls_per_row",
            )
        ),
        "joint_has_four_cards": joint_text.count('"card_id":') == 4,
        "factorized_has_four_primitives": all(
            token in factor_text
            for token in (
                '"objective_loss"',
                '"objective_voltage"',
                '"constraint_none"',
                '"constraint_maintenance"',
            )
        ),
        "runner_evaluation_only": (
            "eval_gridrank_dynamic_factorization_ablation.py" in runner_text
            and '"$TRAIN_PYTHON_BIN" -u train_gridrank_dynamic_policy.py'
            not in runner_text
            and '"$TRAIN_PYTHON_BIN" -u train_gridrank_dynamic_factorized.py'
            not in runner_text
        ),
        "post_confirmation_reuse_disclosed": (
            "confirmation_reuse_disclosed" in preflight_text
            and "post-confirmation matched ablation" in preflight_text
        ),
    }
    result = {
        "msg": "GridRank factorization-ablation dependency-light verification",
        "checks": checks,
        "verification_pass": all(checks.values()),
        "synthetic_statistics": synthetic,
        "training_performed": False,
        "model_loaded": False,
        "power_flow_calls": 0,
    }
    print(json.dumps(result, ensure_ascii=False))
    if not result["verification_pass"]:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
