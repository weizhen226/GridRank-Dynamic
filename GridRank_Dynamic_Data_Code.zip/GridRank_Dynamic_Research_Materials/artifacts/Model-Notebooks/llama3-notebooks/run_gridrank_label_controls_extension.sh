#!/usr/bin/env bash
set -euo pipefail

CURRENT_STAGE="bootstrap"
on_exit() {
  local rc=$?
  trap - EXIT
  if (( rc != 0 )); then
    printf '{"msg":"GridRank label-controls extension runner failure","stage":"%s","evaluation_gate_pass":false,"exit_code":%d}\n' "$CURRENT_STAGE" "$rc"
  fi
  exit "$rc"
}
trap on_exit EXIT

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"
export HF_HUB_OFFLINE=1
export OMP_NUM_THREADS="${OMP_NUM_THREADS:-1}"

PREFLIGHT_ONLY="${PREFLIGHT_ONLY:-1}"
case "$PREFLIGHT_ONLY" in 0|1) ;; *) echo "PREFLIGHT_ONLY must be 0 or 1" >&2; exit 2;; esac
if [[ "$PREFLIGHT_ONLY" == "1" ]]; then export CUDA_VISIBLE_DEVICES=""; fi

resolve_executable() {
  local requested="$1"
  if [[ "$requested" == */* ]]; then [[ -x "$requested" ]] && printf '%s\n' "$requested"
  else command -v -- "$requested"; fi
}
TRAIN_PYTHON_BIN="$(resolve_executable "${TRAIN_PYTHON:-python}")" || exit 2
PHYSICS_PYTHON_BIN="$(resolve_executable "${PHYSICS_PYTHON:-$TRAIN_PYTHON_BIN}")" || exit 2

TAG="${TAG:-gridrank_label_controls_extension_v1_20260812}"
LABEL_TAG="${LABEL_TAG:-gridrank_label_controls_v1_20260811}"
CONFIRM_TAG="${CONFIRM_TAG:-gridrank_select_confirm_v1_20260725}"
EXTENSION_TAG="${EXTENSION_TAG:-gridrank_select_extension_v2_20260726}"
BASE_MODEL="${BASE_MODEL:-../../Meta-Llama-3.1-8B-Instruct}"
SFT="${SFT:-output_gridintent_gate_33_69_v2_20260717/sft_only}"

EXTENSION_PREFLIGHT="${EXTENSION_PREFLIGHT:-${EXTENSION_TAG}.preflight.json}"
EXTENSION_TEST="${EXTENSION_TEST:-${EXTENSION_TAG}_select_test.jsonl}"
ORIGINAL_TEST="${ORIGINAL_TEST:-${CONFIRM_TAG}_test.jsonl}"
LABEL_SUITE="${LABEL_SUITE:-${LABEL_TAG}.preflight.json}"
LABEL_AGGREGATE="${LABEL_AGGREGATE:-${LABEL_TAG}_aggregate_hotfix.json}"
PREFLIGHT="${TAG}.preflight.json"
OUT="${OUT:-output_${TAG}}"
GATE="$OUT/gridrank_label_controls_extension_gate.json"

FULL_GATE="${FULL_GATE:-output_${CONFIRM_TAG}_s42/gridrank_select_gate.json}"
FULL_ADAPTER="${FULL_ADAPTER:-output_${CONFIRM_TAG}_s42/diagnostic_adapter}"
SHUFFLED_GATE="${SHUFFLED_GATE:-output_${LABEL_TAG}_shuffled_labels/gridrank_select_gate.json}"
SHUFFLED_ADAPTER="${SHUFFLED_ADAPTER:-output_${LABEL_TAG}_shuffled_labels/diagnostic_adapter}"
LINDISTFLOW_GATE="${LINDISTFLOW_GATE:-output_${LABEL_TAG}_lindistflow_labels/gridrank_select_gate.json}"
LINDISTFLOW_ADAPTER="${LINDISTFLOW_ADAPTER:-output_${LABEL_TAG}_lindistflow_labels/diagnostic_adapter}"

GATE_ARGS=(
  --method_gate "full_gridrank=$FULL_GATE"
  --method_gate "shuffled_labels=$SHUFFLED_GATE"
  --method_gate "lindistflow_labels=$LINDISTFLOW_GATE"
)
ADAPTER_ARGS=(
  --method_adapter "full_gridrank=$FULL_ADAPTER"
  --method_adapter "shuffled_labels=$SHUFFLED_ADAPTER"
  --method_adapter "lindistflow_labels=$LINDISTFLOW_ADAPTER"
)
for path in "$EXTENSION_PREFLIGHT" "$EXTENSION_TEST" "$ORIGINAL_TEST" \
  "$LABEL_SUITE" "$LABEL_AGGREGATE" "$FULL_GATE" "$SHUFFLED_GATE" \
  "$LINDISTFLOW_GATE" "$FULL_ADAPTER/adapter_model.safetensors" \
  "$SHUFFLED_ADAPTER/adapter_model.safetensors" \
  "$LINDISTFLOW_ADAPTER/adapter_model.safetensors" \
  "$SFT/adapter_model.safetensors" "$BASE_MODEL/config.json"; do
  test -e "$path" || { echo "missing label-extension input: $path" >&2; exit 2; }
done

if [[ "$PREFLIGHT_ONLY" == "1" ]]; then
  echo "=== 1/3 DEPENDENCY-LIGHT EVALUATION-ONLY REGRESSIONS ==="
  CURRENT_STAGE="dependency_regression"
  "$TRAIN_PYTHON_BIN" -B verify_gridrank_label_controls_extension.py

  echo "=== 2/3 LOCK UNUSED TEST, THREE GATES, AND THREE FROZEN ADAPTERS ==="
  CURRENT_STAGE="preflight_create"
  if [[ ! -e "$PREFLIGHT" ]]; then
    "$TRAIN_PYTHON_BIN" -B preflight_gridrank_label_controls_extension.py --mode create \
      --extension_preflight "$EXTENSION_PREFLIGHT" --extension_test "$EXTENSION_TEST" \
      --original_test "$ORIGINAL_TEST" --label_suite "$LABEL_SUITE" \
      --label_aggregate "$LABEL_AGGREGATE" "${GATE_ARGS[@]}" "${ADAPTER_ARGS[@]}" \
      --sft_adapter "$SFT" --base_model "$BASE_MODEL" \
      --physics_python "$PHYSICS_PYTHON_BIN" --bootstrap_reps 10000 \
      --output "$PREFLIGHT"
  fi

  echo "=== 3/3 VERIFY LOCKED EXTENSION MANIFEST ==="
  CURRENT_STAGE="preflight_verify"
  "$TRAIN_PYTHON_BIN" -B preflight_gridrank_label_controls_extension.py --mode verify \
    --base_model "$BASE_MODEL" --physics_python "$PHYSICS_PYTHON_BIN" \
    --bootstrap_reps 10000 --output "$PREFLIGHT"
  echo "=== GRIDRANK LABEL-CONTROLS EXTENSION CPU PREFLIGHT COMPLETE; GPU NOT STARTED ==="
  exit 0
fi

test -f "$PREFLIGHT" || { echo "missing label-extension preflight" >&2; exit 2; }
test ! -e "$OUT" || { echo "refusing to reuse output: $OUT" >&2; exit 2; }
test ! -e "${OUT}.log" || { echo "refusing to overwrite log: ${OUT}.log" >&2; exit 2; }

echo "=== 1/4 VERIFY LOCKED EVALUATION-ONLY MANIFEST ==="
CURRENT_STAGE="runtime_lock"
"$TRAIN_PYTHON_BIN" -B preflight_gridrank_label_controls_extension.py --mode verify \
  --base_model "$BASE_MODEL" --physics_python "$PHYSICS_PYTHON_BIN" \
  --bootstrap_reps 10000 --output "$PREFLIGHT"

echo "=== 2/4 CUDA + NF4 READINESS ==="
CURRENT_STAGE="gpu_readiness"
"$TRAIN_PYTHON_BIN" -B - <<'PY'
import json, torch
from transformers import BitsAndBytesConfig
c = {"cuda": bool(torch.cuda.is_available()), "device_count": torch.cuda.device_count() > 0}
q = BitsAndBytesConfig(load_in_4bit=True, bnb_4bit_quant_type="nf4",
    bnb_4bit_compute_dtype=torch.float16, bnb_4bit_use_double_quant=True)
c["nf4_config"] = bool(q.load_in_4bit and q.bnb_4bit_quant_type == "nf4")
print(json.dumps({"msg":"label-extension CUDA readiness","checks":c,"pass":all(c.values())}))
raise SystemExit(0 if all(c.values()) else 2)
PY

echo "=== 3/4 THREE FROZEN-ADAPTER FORWARDS + LIVE TOP-3 REPLAY ==="
CURRENT_STAGE="frozen_evaluation"
mkdir "$OUT"
"$TRAIN_PYTHON_BIN" -u eval_gridrank_label_controls_extension.py \
  --extension_test "$EXTENSION_TEST" --original_test "$ORIGINAL_TEST" \
  "${GATE_ARGS[@]}" "${ADAPTER_ARGS[@]}" --preflight_manifest "$PREFLIGHT" \
  --sft_adapter "$SFT" --base_model "$BASE_MODEL" \
  --physics_python "$PHYSICS_PYTHON_BIN" --physics_timeout_s 60 \
  --max_length 1024 --candidate_batch_size 4 --topk 3 \
  --bootstrap_reps 10000 --bootstrap_seed 20260812 --output "$GATE" 2>&1 | tee "${OUT}.log"

echo "=== 4/4 VERIFY 64-STATE EXTENSION AND 128-STATE COMBINED DECISION ==="
CURRENT_STAGE="result_verify"
"$TRAIN_PYTHON_BIN" -B verify_gridrank_label_controls_extension.py --gate "$GATE"
echo "=== GRIDRANK LABEL-CONTROLS EXTENSION COMPLETE ==="
