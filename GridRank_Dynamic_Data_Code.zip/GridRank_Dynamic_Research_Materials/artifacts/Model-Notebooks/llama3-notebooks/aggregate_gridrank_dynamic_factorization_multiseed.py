"""Aggregate GridRank dynamic factorization multiseed."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import aggregate_gridrank_dynamic_multiseed as statistics
import train_gridrank_dynamic_policy as joint


SCHEMA = "gridrank-dynamic-factorization-multiseed-aggregate-v1"
EXPERIMENT_ID = "gridrank-dynamic-factorized-vs-joint-card-three-seed-v1"
SEEDS = (42, 123, 2025)
FACTORIZED = "physics_aligned_factorized_llm"
JOINT = "physics_aligned_joint_card_llm"
PRIMARY = "maintenance_voltage"


def file_sha256(path):
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def parse_mapping(values, name):
    result = {}
    for value in values:
        raw_seed, path = value.split("=", 1)
        seed = int(raw_seed)
        if seed in result:
            raise ValueError(f"duplicate {name} seed: {seed}")
        result[seed] = path
    if tuple(sorted(result)) != SEEDS:
        raise ValueError(f"{name} seeds must be exactly {SEEDS}")
    return result


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--factor_gate", action="append", required=True)
    parser.add_argument("--factor_preflight", action="append", required=True)
    parser.add_argument("--factor_records", action="append", required=True)
    parser.add_argument("--joint_gate", action="append", required=True)
    parser.add_argument("--joint_preflight", action="append", required=True)
    parser.add_argument("--joint_records", action="append", required=True)
    parser.add_argument("--fresh_summary", required=True)
    parser.add_argument("--bootstrap_reps", type=int, default=10000)
    parser.add_argument("--bootstrap_seed", type=int, default=20260904)
    parser.add_argument("--output", required=True)
    return parser.parse_args()


def _method(methods, name, source):
    if name not in methods:
        raise ValueError(f"{source}: missing method {name}")
    return methods[name]


def _index(rows):
    return {row["instance_id"]: row for row in rows}


def _state_effect_matrix(records, pair_type=None):
    matrix = {}
    for seed in SEEDS:
        methods = records[seed]
        values, _ = statistics.pair_effects(
            methods, JOINT, FACTORIZED, pair_type
        )
        matrix[seed] = values
    return matrix


def _method_summary(records, method, pair_type=None):
    rows = records[method]
    if pair_type is not None:
        rows = [row for row in rows if row["pair_type"] == pair_type]
    return joint.brief(rows)


def build(
    factor_preflights,
    factor_gates,
    factor_records,
    joint_preflights,
    joint_gates,
    joint_records,
    fresh_summary,
    reps,
    bootstrap_seed,
):
    combined = {}
    integrity = {}
    input_manifest = {}
    per_seed = {}
    factor_primary_semantic_wins = 0
    factor_primary_point_wins = 0
    for seed in SEEDS:
        fp = json.load(open(factor_preflights[seed], encoding="utf-8"))
        fg = json.load(open(factor_gates[seed], encoding="utf-8"))
        jp = json.load(open(joint_preflights[seed], encoding="utf-8"))
        jg = json.load(open(joint_gates[seed], encoding="utf-8"))
        fm = statistics.read_records(factor_records[seed])
        jm = statistics.read_records(joint_records[seed])
        factor_rows = _method(fm, FACTORIZED, factor_records[seed])
        joint_rows = _method(jm, JOINT, joint_records[seed])
        factor_index, joint_index = _index(factor_rows), _index(joint_rows)
        combined[seed] = {FACTORIZED: factor_rows, JOINT: joint_rows}
        factor_summary = _method_summary(combined[seed], FACTORIZED)
        joint_summary = _method_summary(combined[seed], JOINT)
        factor_primary = _method_summary(combined[seed], FACTORIZED, PRIMARY)
        joint_primary = _method_summary(combined[seed], JOINT, PRIMARY)
        pair_effect, _ = statistics.pair_effects(
            combined[seed], JOINT, FACTORIZED, PRIMARY
        )
        primary_point = statistics.mean(list(pair_effect.values()))
        factor_primary_point_wins += int(primary_point > 0)
        factor_primary_semantic_wins += int(
            factor_primary["semantic_accuracy"]
            > joint_primary["semantic_accuracy"]
        )
        expected_model_seed = fp.get("model_seed", 42)
        joint_model_seed = jp.get("model_seed", 42)
        seed_checks = {
            "factor_gate_bound_to_preflight": fg.get("preflight_sha256")
            == file_sha256(factor_preflights[seed]),
            "joint_gate_bound_to_preflight": jg.get("preflight_sha256")
            == file_sha256(joint_preflights[seed]),
            "factor_records_bound_to_gate": fg.get("records", {}).get("sha256")
            == file_sha256(factor_records[seed]),
            "joint_records_bound_to_gate": jg.get("records", {}).get("sha256")
            == file_sha256(joint_records[seed]),
            "factor_model_seed": expected_model_seed == seed,
            "joint_model_seed": joint_model_seed == seed,
            "record_ids_match": set(factor_index) == set(joint_index),
            "rows_192_each": len(factor_rows) == len(joint_rows) == 192,
            "factor_confirmation_pass": fg.get("confirmation_gate_pass") is True,
            "joint_evaluation_integrity": (
                jg.get("factorization_gate_pass") is True
                if seed == 42
                else jg.get("replication_evaluation_integrity_pass") is True
            ),
            "factor_feasible_100pct": factor_summary["safe_feasible_rate"] == 1.0,
            "joint_feasible_100pct": joint_summary["safe_feasible_rate"] == 1.0,
            "factor_constraint_zero": factor_summary["constraint_violation_rate"]
            == 0.0,
            "joint_constraint_zero": joint_summary["constraint_violation_rate"]
            == 0.0,
        }
        for name, value in seed_checks.items():
            integrity[f"seed_{seed}:{name}"] = value
        per_seed[str(seed)] = {
            "primary_improvement_mean": primary_point,
            "factorized": factor_summary,
            "joint_card": joint_summary,
            "factorized_primary": factor_primary,
            "joint_card_primary": joint_primary,
            "checks": seed_checks,
        }
        input_manifest[str(seed)] = {
            "factor_preflight": {
                "path": str(Path(factor_preflights[seed]).resolve()),
                "sha256": file_sha256(factor_preflights[seed]),
            },
            "factor_gate": {
                "path": str(Path(factor_gates[seed]).resolve()),
                "sha256": file_sha256(factor_gates[seed]),
            },
            "factor_records": {
                "path": str(Path(factor_records[seed]).resolve()),
                "sha256": file_sha256(factor_records[seed]),
            },
            "joint_preflight": {
                "path": str(Path(joint_preflights[seed]).resolve()),
                "sha256": file_sha256(joint_preflights[seed]),
            },
            "joint_gate": {
                "path": str(Path(joint_gates[seed]).resolve()),
                "sha256": file_sha256(joint_gates[seed]),
            },
            "joint_records": {
                "path": str(Path(joint_records[seed]).resolve()),
                "sha256": file_sha256(joint_records[seed]),
            },
        }

    pair_to_state, state_network, manifest = statistics.physical_state_units(
        fresh_summary
    )
    integrity.update(
        {
            "fresh_manifest_96_pairs": len(pair_to_state) == 96,
            "fresh_manifest_66_states": len(state_network) == 66,
            "fresh_manifest_nonempty": bool(manifest),
        }
    )
    primary = statistics.bootstrap_state_matrix(
        _state_effect_matrix(combined, PRIMARY),
        pair_to_state,
        state_network,
        reps,
        bootstrap_seed + 100,
    )
    overall = statistics.bootstrap_state_matrix(
        _state_effect_matrix(combined),
        pair_to_state,
        state_network,
        reps,
        bootstrap_seed + 200,
    )
    integrity["primary_48_pairs_are_48_states"] = (
        primary["pair_clusters"] == primary["physical_state_clusters"] == 48
        and primary["states_with_multiple_pairs"] == 0
    )
    robustness = {
        "primary_at_least_2_of_3_seed_points_positive": (
            factor_primary_point_wins >= 2
        ),
        "primary_pooled_state_ci_lower_positive": primary[
            "physical_state_cluster_bootstrap_ci95"
        ][0]
        > 0,
        "primary_two_way_seed_state_ci_lower_positive": primary[
            "two_way_seed_state_bootstrap_ci95"
        ][0]
        > 0,
        "primary_hierarchical_ci_lower_positive": primary[
            "hierarchical_seed_state_pair_bootstrap_ci95"
        ][0]
        > 0,
        "primary_both_networks_positive": all(
            primary["by_network"][network]["improvement_mean"] > 0
            for network in ("33", "69")
        ),
        "overall_two_way_seed_state_ci_lower_positive": overall[
            "two_way_seed_state_bootstrap_ci95"
        ][0]
        > 0,
        "factorized_primary_semantic_higher_at_least_2_of_3": (
            factor_primary_semantic_wins >= 2
        ),
        "all_integrity_and_safety_checks": all(integrity.values()),
    }
    audit_pass = all(integrity.values())
    robustness_pass = audit_pass and all(robustness.values())
    return {
        "msg": "GridRank factorized-vs-joint-card three-seed aggregate",
        "schema": SCHEMA,
        "experiment_id": EXPERIMENT_ID,
        "seeds": list(SEEDS),
        "bootstrap_reps": reps,
        "bootstrap_seed": bootstrap_seed,
        "training_performed": False,
        "model_loaded": False,
        "power_flow_calls": 0,
        "confirmation_reuse_disclosed": True,
        "freshness_boundary": (
            "Seed 42 retains the one-time fresh-confirmation status; seeds 123 "
            "and 2025 are post-confirmation robustness replications on identical bytes."
        ),
        "comparison": "joint_card_regret_minus_factorized_regret",
        "positive_favors": FACTORIZED,
        "inputs": {
            "fresh_summary": {
                "path": str(Path(fresh_summary).resolve()),
                "sha256": file_sha256(fresh_summary),
            },
            "seeds": input_manifest,
        },
        "primary_unseen_maintenance_voltage": primary,
        "overall": overall,
        "per_seed": per_seed,
        "integrity_checks": integrity,
        "robustness_checks": robustness,
        "audit_pass": audit_pass,
        "factorization_multiseed_gate_pass": robustness_pass,
        "failed_integrity": [key for key, value in integrity.items() if not value],
        "failed_robustness": [
            key for key, value in robustness.items() if not value
        ],
        "decision": (
            "authorize_multiseed_factorization_contribution"
            if robustness_pass
            else "retain_seed42_factorization_ablation_and_report_replication_variance"
        ),
        "interpretation_boundary": (
            "This comparison isolates the implemented factorized and direct "
            "four-card interfaces under a matched contract; it does not cover "
            "every possible non-factorized architecture."
        ),
    }


def main():
    args = parse_args()
    output = Path(args.output)
    if output.exists():
        raise FileExistsError(f"refusing to overwrite aggregate: {output}")
    result = build(
        parse_mapping(args.factor_preflight, "factor_preflight"),
        parse_mapping(args.factor_gate, "factor_gate"),
        parse_mapping(args.factor_records, "factor_records"),
        parse_mapping(args.joint_preflight, "joint_preflight"),
        parse_mapping(args.joint_gate, "joint_gate"),
        parse_mapping(args.joint_records, "joint_records"),
        args.fresh_summary,
        args.bootstrap_reps,
        args.bootstrap_seed,
    )
    output.write_text(
        json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps(result, ensure_ascii=False))
    if not result["audit_pass"]:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
