"""Validate GridRank dynamic physics factorial."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import aggregate_gridrank_dynamic_physics_factorial as aggregate


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--result", required=True)
    return parser.parse_args()


def main():
    args = parse_args()
    result = json.load(open(args.result, encoding="utf-8"))
    groups = {
        name: {cell: {} for cell in aggregate.CELLS}
        for name in ("gate", "records", "factor_preflight", "confirmation_preflight")
    }
    input_checks = {}
    for cell, seeds in result.get("inputs", {}).get("cells", {}).items():
        for raw_seed, items in seeds.items():
            seed = int(raw_seed)
            for name, item in items.items():
                groups[name][cell][seed] = item["path"]
                input_checks[f"{cell}_{seed}_{name}"] = (
                    Path(item["path"]).is_file()
                    and aggregate.file_sha256(item["path"]) == item["sha256"]
                )
    fresh = result.get("inputs", {}).get("fresh_summary", {})
    input_checks["fresh_summary"] = (
        Path(fresh.get("path", "")).is_file()
        and aggregate.file_sha256(fresh["path"]) == fresh.get("sha256")
    )
    rebuilt = aggregate.build(
        groups,
        fresh["path"],
        result["bootstrap_reps"],
        result["bootstrap_seed"],
    )
    checks = {
        "schema": result.get("schema") == aggregate.SCHEMA,
        "experiment_id": result.get("experiment_id") == aggregate.EXPERIMENT_ID,
        "all_inputs_current": bool(input_checks) and all(input_checks.values()),
        "exact_recomputation": rebuilt == result,
        "audit_consistent": result.get("audit_pass")
        == all(result.get("integrity_checks", {}).values()),
        "safety_consistent": result.get("safety_pass")
        == all(result.get("safety_checks", {}).values()),
        "factorial_gate_consistent": result.get("factorial_explanatory_gate_pass")
        == all(
            item.get("gate_pass")
            for item in result.get("channel_gates", {}).values()
        ),
        "boundaries_present": bool(
            result.get("post_confirmation_supplement")
            and result.get("freshness_boundary")
            and result.get("interpretation_boundary")
        ),
    }
    verification = {
        "msg": "GridRank dynamic physics-source factorial result verification",
        "checks": checks,
        "verification_pass": all(checks.values()),
        "audit_pass": result.get("audit_pass"),
        "safety_pass": result.get("safety_pass"),
        "factorial_explanatory_gate_pass": result.get(
            "factorial_explanatory_gate_pass"
        ),
        "channel_gates": result.get("channel_gates"),
    }
    print(json.dumps(verification, ensure_ascii=False))
    if not verification["verification_pass"]:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
