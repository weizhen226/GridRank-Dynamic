"""Validate GridRank dynamic observation robustness."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import gridrank_dynamic_observation_robustness as robust
import preflight_gridrank_dynamic_observation_robustness as preflight


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--preflight_manifest", required=True)
    parser.add_argument("--gate", required=True)
    return parser.parse_args()


def main():
    args = parse_args()
    locked = preflight.verify_manifest(args.preflight_manifest)
    gate = json.load(open(args.gate, encoding="utf-8"))
    records_manifest = gate.get("records", {})
    records_path = Path(records_manifest.get("path", ""))
    records = (
        robust.read_jsonl(records_path) if records_path.is_file() else []
    )
    recomputed = robust.summarize(
        records,
        locked["schedule"]["bootstrap_reps"],
        locked["schedule"]["bootstrap_seed"],
    ) if records else None
    expected_rows = (
        48 * 2 * len(robust.SEEDS)
        * (
            len(robust.operating_conditions())
            + len(robust.noise_conditions())
        )
    )
    checks = {
        "schema": gate.get("schema") == robust.SCHEMA,
        "experiment_id": gate.get("experiment_id") == robust.EXPERIMENT_ID,
        "preflight_hash": gate.get("preflight_sha256")
        == robust.file_sha256(args.preflight_manifest),
        "evaluation_only": gate.get("evaluation_only") is True,
        "training_not_performed": gate.get("training_performed") is False,
        "model_not_loaded": gate.get("model_loaded") is False,
        "records_exist": records_path.is_file(),
        "records_hash": records_path.is_file()
        and robust.file_sha256(records_path) == records_manifest.get("sha256"),
        "records_exact": len(records) == expected_rows
        and records_manifest.get("rows") == expected_rows,
        "summary_exact": recomputed == gate.get("summaries"),
        "evaluation_pass": gate.get("evaluation_pass") is True,
        "decision_consistent": gate.get("decision") == (
            "robustness_evidence_pass"
            if gate.get("robustness_gate_pass")
            else "retain_results_and_report_robustness_boundary"
        ),
        "power_flow_calls_nonzero": (
            gate.get("power_flow_calls", {}).get("backend_power_flows", 0) > 0
        ),
    }
    result = {
        "msg": "GridRank dynamic observation robustness result verification",
        "checks": checks,
        "verification_pass": all(checks.values()),
        "evaluation_pass": gate.get("evaluation_pass"),
        "robustness_gate_pass": gate.get("robustness_gate_pass"),
        "decision": gate.get("decision"),
        "failed_scientific_checks": gate.get(
            "failed_scientific_checks", []
        ),
    }
    print(json.dumps(result, ensure_ascii=False))
    if not result["verification_pass"]:
        raise SystemExit(2)


if __name__ == "__main__":
    main()

