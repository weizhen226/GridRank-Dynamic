"""Build GridRank instruction pairs."""

from __future__ import annotations

import argparse
import hashlib
import itertools
import json
import math
import re
from collections import Counter, defaultdict
from pathlib import Path

from build_gridrank_instruct_identifiability import (
    NOOP,
    action_edges,
    edge_text,
    file_sha256,
    label_instruction,
    load_cached_states,
    merge_cached_states,
)


HERE = Path(__file__).resolve().parent
SCHEMA = "gridrank-strong-instruction-pairs-v1"
PAIR_TYPES = ("objective", "maintenance_loss", "maintenance_voltage")

TRAIN_TEMPLATES = {
    "loss": (
        "Minimize active-power loss. Choose the feasible exchange with the largest positive loss reduction.",
        "Use active-power loss as the primary objective and retain the current topology if no feasible exchange reduces it.",
        "Give priority to reducing feeder loss; only a physically feasible beneficial exchange may be used.",
        "Select the admissible exchange that produces the greatest active-power loss saving.",
    ),
    "voltage": (
        "Maximize the minimum bus voltage while keeping any active-power loss increase within 0.5 percent.",
        "Give first priority to the weakest bus voltage, subject to feasibility and a 0.5 percent loss-increase limit.",
        "Use minimum bus voltage as the primary objective and reject exchanges that add more than 0.5 percent loss.",
        "Select the feasible exchange that best improves the lowest bus voltage without exceeding the loss limit.",
    ),
    "maintenance_loss": (
        "Minimize active-power loss, but do not operate maintenance-restricted branch {edges}.",
        "Use the loss objective while a temporary prohibition prevents any switching action that touches branch {edges}.",
        "Reduce feeder loss subject to this hard switching restriction: branch {edges} must not be operated.",
        "Choose the best loss-saving exchange, excluding every action involving the unavailable branch {edges}.",
    ),
    "maintenance_voltage": (
        "Maximize the minimum bus voltage, but do not operate maintenance-restricted branch {edges}; keep loss increase within 0.5 percent.",
        "Improve the weakest bus voltage while a temporary prohibition prevents switching branch {edges}.",
        "Raise the minimum voltage subject to a hard restriction on branch {edges} and the 0.5 percent loss limit.",
        "Choose the best voltage-supporting exchange, excluding every action involving unavailable branch {edges}.",
    ),
}

VALIDATION_TEMPLATES = {
    "loss": (
        "Operate the feeder for the smallest I-squared-R dissipation; leave it unchanged if no safe exchange helps.",
        "Choose the safe reconfiguration that wastes the least real power in the conductors.",
        "Prefer the topology with the greatest efficiency gain from an admissible single exchange.",
        "Cut avoidable real-power dissipation as much as possible using one safe exchange.",
    ),
    "voltage": (
        "Raise the floor of the voltage profile, allowing no more than a 0.5 percent penalty in real-power dissipation.",
        "Support the electrically weakest node first and reject any unsafe or excessively lossy exchange.",
        "Give precedence to undervoltage relief; the real-power penalty may not exceed 0.5 percent.",
        "Strengthen the lowest per-unit node value while respecting the stated efficiency tolerance.",
    ),
    "maintenance_loss": (
        "A field crew has tagged branch {edges}; leave it untouched while seeking the most efficient safe topology.",
        "The switching permit excludes {edges}. Among the remaining exchanges, minimize conductor dissipation.",
        "Treat {edges} as unavailable and choose the admissible action with the largest real-power saving.",
        "No switching action may involve {edges}; otherwise operate for maximum feeder efficiency.",
    ),
    "maintenance_voltage": (
        "A field crew has tagged branch {edges}; leave it untouched while raising the floor of the voltage profile.",
        "The switching permit excludes {edges}. Support the weakest node without more than a 0.5 percent efficiency penalty.",
        "Treat {edges} as unavailable and prioritize undervoltage relief under the real-power tolerance.",
        "No switching action may involve {edges}; otherwise strengthen the lowest per-unit node value.",
    ),
}

CODE_FILES = (
    "build_gridrank_instruction_pairs.py",
    "verify_gridrank_instruction_pairs.py",
    "run_gridrank_instruction_pairs.sh",
    "../../docs/GRIDRANK_STRONG_INSTRUCTION_PAIRS_PROTOCOL.md",
)


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--train_cache", required=True)
    parser.add_argument("--validation_cache", required=True, nargs="+")
    parser.add_argument("--train_out", required=True)
    parser.add_argument("--validation_out", required=True)
    parser.add_argument("--summary_out", required=True)
    parser.add_argument("--selection_seed", type=int, default=20260808)
    parser.add_argument("--target_temperature", type=float, default=0.20)
    parser.add_argument("--max_pairs_per_type_network", type=int, default=8)
    parser.add_argument("--min_pairs_per_type_network", type=int, default=4)
    parser.add_argument("--train_paraphrases", type=int, default=2)
    parser.add_argument("--validation_paraphrases", type=int, default=2)
    parser.add_argument("--min_objective_pair_gap", type=float, default=0.02)
    parser.add_argument("--min_constraint_pair_gap", type=float, default=0.20)
    parser.add_argument("--topk", type=int, default=1)
    return parser.parse_args()


def code_hashes():
    missing = [name for name in CODE_FILES if not (HERE / name).is_file()]
    return (
        {name: file_sha256(HERE / name) for name in CODE_FILES if (HERE / name).is_file()},
        missing,
    )


def _candidate(row, action):
    if action == NOOP:
        return row["gate_anchor"]
    return next(item for item in row["candidates"] if item["action"] == action)


def regret(row, action):
    return float(_candidate(row, action)["normalised_regret"])


def _template_indices(count, total, key):
    if count <= 0 or count > total:
        raise ValueError(f"invalid paraphrase count {count} for {total} templates")
    return sorted(
        range(total),
        key=lambda index: hashlib.sha256(f"{key}|{index}".encode("utf-8")).digest(),
    )[:count]


def _decorate_rows(row, *, pair_id, pair_type, side, style, paraphrases,
                   forbidden_edges, selection_gap):
    templates = TRAIN_TEMPLATES if style == "train" else VALIDATION_TEMPLATES
    family = row["instruction_id"]
    indices = _template_indices(
        paraphrases, len(templates[family]), f"{pair_id}|{side}|{style}"
    )
    output = []
    for paraphrase_index, template_index in enumerate(indices):
        value = dict(row)
        value.update({
            "schema": SCHEMA,
            "instance_id": f"{pair_id}:{side}:p{paraphrase_index}",
            "pair_id": pair_id,
            "pair_type": pair_type,
            "pair_side": side,
            "paraphrase_index": paraphrase_index,
            "template_id": f"{style}:{family}:{template_index}",
            "instruction_style": style,
            "instruction_text": templates[family][template_index].format(
                edges=edge_text(forbidden_edges)
            ),
            "pair_selection_gap": float(selection_gap),
            "oracle_structured_instruction": {
                "objective": row["base_objective"],
                "forbidden_edges": [list(edge) for edge in forbidden_edges],
                "hard_constraint": bool(forbidden_edges),
                "loss_increase_limit_pct": 0.5 if row["base_objective"] == "voltage" else None,
            },
        })
        output.append(value)
    return output


def _maintenance_counterfactual(state, base_family, style, temperature,
                                min_gap):
    base = label_instruction(state, base_family, style, (), temperature)
    base_action = base["desired_action"]
    if base_action == NOOP:
        return None
    maintenance_family = f"maintenance_{base_family}"
    target_edges = tuple(action_edges(base_action))
    choices = [(edge,) for edge in target_edges]
    if len(target_edges) > 1:
        choices.append(target_edges)
    candidates = []
    for forbidden in choices:
        constrained = label_instruction(
            state, maintenance_family, style, forbidden, temperature
        )
        if constrained["desired_action"] == base_action:
            continue
        gap = regret(constrained, base_action)
        candidates.append((gap, forbidden, constrained))
    if not candidates:
        return None
    gap, forbidden, constrained = max(
        candidates,
        key=lambda item: (
            item[0],
            tuple(item[1]),
            item[2]["desired_action"],
        ),
    )
    if gap + 1e-12 < min_gap:
        return None
    return base, constrained, tuple(forbidden), float(gap)


def candidate_pairs(state, style, args):
    loss = label_instruction(state, "loss", style, (), args.target_temperature)
    voltage = label_instruction(state, "voltage", style, (), args.target_temperature)
    result = []
    if loss["desired_action"] != voltage["desired_action"]:
        left_gap = regret(loss, voltage["desired_action"])
        right_gap = regret(voltage, loss["desired_action"])
        strength = min(left_gap, right_gap)
        if strength + 1e-12 >= args.min_objective_pair_gap:
            result.append({
                "pair_type": "objective",
                "left": loss,
                "right": voltage,
                "forbidden_edges": (),
                "strength": float(strength),
                "directional_gaps": [float(left_gap), float(right_gap)],
            })
    for base_family in ("loss", "voltage"):
        item = _maintenance_counterfactual(
            state, base_family, style, args.target_temperature,
            args.min_constraint_pair_gap,
        )
        if item is None:
            continue
        base, constrained, forbidden, strength = item
        result.append({
            "pair_type": f"maintenance_{base_family}",
            "left": base,
            "right": constrained,
            "forbidden_edges": forbidden,
            "strength": strength,
            "directional_gaps": [float(regret(base, constrained["desired_action"])), strength],
        })
    for value in result:
        value.update({
            "network_id": str(state["network_id"]),
            "load_id": str(state["load_id"]),
            "physical_state_sha256": state["physical_state_sha256"],
        })
    return result


def select_pairs(states, style, args):
    pool = []
    for state in states:
        pool.extend(candidate_pairs(state, style, args))
    selected = []
    availability = {}
    for network, pair_type in itertools.product(("33", "69"), PAIR_TYPES):
        subset = [
            item for item in pool
            if item["network_id"] == network and item["pair_type"] == pair_type
        ]
        availability[f"{network}:{pair_type}"] = len(subset)
        ranked = sorted(
            subset,
            key=lambda item: hashlib.sha256(
                (
                    f"{args.selection_seed}|{style}|{network}|{pair_type}|"
                    f"{item['load_id']}|{item['physical_state_sha256']}"
                ).encode("utf-8")
            ).digest(),
        )
        selected.extend(ranked[: args.max_pairs_per_type_network])
    return selected, availability


def emit_rows(pairs, style, paraphrases):
    rows = []
    pair_manifest = []
    for index, item in enumerate(sorted(
        pairs,
        key=lambda value: (
            value["network_id"], value["pair_type"],
            value["physical_state_sha256"], value["load_id"],
        ),
    )):
        pair_id = (
            f"gridrank-strong:{style}:{item['network_id']}:"
            f"{item['physical_state_sha256']}:{item['pair_type']}:{index}"
        )
        left = _decorate_rows(
            item["left"], pair_id=pair_id, pair_type=item["pair_type"],
            side="left", style=style, paraphrases=paraphrases,
            forbidden_edges=(), selection_gap=item["strength"],
        )
        right = _decorate_rows(
            item["right"], pair_id=pair_id, pair_type=item["pair_type"],
            side="right", style=style, paraphrases=paraphrases,
            forbidden_edges=item["forbidden_edges"], selection_gap=item["strength"],
        )
        rows.extend([*left, *right])
        pair_manifest.append({
            "pair_id": pair_id,
            "pair_type": item["pair_type"],
            "network_id": item["network_id"],
            "load_id": item["load_id"],
            "physical_state_sha256": item["physical_state_sha256"],
            "left_desired_action": item["left"]["desired_action"],
            "right_desired_action": item["right"]["desired_action"],
            "forbidden_edges": [list(edge) for edge in item["forbidden_edges"]],
            "strength": item["strength"],
            "directional_gaps": item["directional_gaps"],
        })
    return rows, pair_manifest


def parse_feature_text(text):
    output = {}
    for field in str(text).split(";"):
        if "=" not in field:
            continue
        key, value = field.strip().split("=", 1)
        output[key] = value
    return output


def structured_proxy_order(row, objective, forbidden_edges):
    forbidden = {tuple(sorted(map(int, edge))) for edge in forbidden_edges}
    scored = []
    for item in row["candidates"]:
        touches = bool(forbidden.intersection(action_edges(item["action"])))
        features = parse_feature_text(item["candidate_feature_text"])
        if touches:
            score = -math.inf
        elif objective == "voltage":
            score = -float(features["voltage_drop_proxy_max"])
        else:
            score = float(features["loss_proxy_delta_pct"])
        scored.append((score, item["action"]))
    return [action for _, action in sorted(scored, key=lambda x: (-x[0], x[1]))]


EDGE_RE = re.compile(r"\((\d+)\s*,\s*(\d+)\)")


def frozen_template_rule_parser(text):
    
    lowered = str(text).lower()
    voltage_cues = (
        "minimum bus voltage", "weakest bus voltage", "lowest bus voltage",
    )
    objective = "voltage" if any(cue in lowered for cue in voltage_cues) else "loss"
    restriction_cues = (
        "do not operate", "maintenance-restricted", "temporary prohibition",
        "hard switching restriction", "unavailable branch",
    )
    constrained = any(cue in lowered for cue in restriction_cues)
    edges = []
    if constrained:
        edges = [list(map(int, match)) for match in EDGE_RE.findall(lowered)]
    return {"objective": objective, "forbidden_edges": edges, "hard_constraint": constrained}


def selected_action(row, ranking, topk):
    considered = ranking[:topk]
    values = [(0.0, NOOP)]
    by_action = {item["action"]: item for item in row["candidates"]}
    for action in considered:
        utility = by_action[action]["safe_utility"]
        if utility is not None:
            values.append((float(utility), action))
    return max(values, key=lambda item: (item[0], item[1]))[1]


def baseline_records(rows, topk):
    records = defaultdict(list)
    parser_correct = []
    for row in rows:
        oracle = row["oracle_structured_instruction"]
        rule = frozen_template_rule_parser(row["instruction_text"])
        parser_correct.append(
            rule["objective"] == oracle["objective"]
            and {tuple(edge) for edge in rule["forbidden_edges"]}
            == {tuple(edge) for edge in oracle["forbidden_edges"]}
        )
        rankings = {
            "fixed_loss_lindistflow": structured_proxy_order(row, "loss", []),
            "rule_parser_lindistflow": structured_proxy_order(
                row, rule["objective"], rule["forbidden_edges"]
            ),
            "oracle_structured_lindistflow": structured_proxy_order(
                row, oracle["objective"], oracle["forbidden_edges"]
            ),
        }
        for name, ranking in rankings.items():
            action = selected_action(row, ranking, topk)
            records[name].append(regret(row, action))
    result = {
        name: {
            "n": len(values),
            "normalised_regret_mean": sum(values) / len(values),
            "physics_optimal_rate": sum(value <= 1e-12 for value in values) / len(values),
        }
        for name, values in records.items()
    }
    result["full_ac_oracle"] = {
        "n": len(rows), "normalised_regret_mean": 0.0, "physics_optimal_rate": 1.0,
    }
    return result, sum(parser_correct) / len(parser_correct)


def partition_summary(rows, pairs, availability, topk):
    pair_counts = Counter((item["network_id"], item["pair_type"]) for item in pairs)
    strengths = [float(item["strength"]) for item in pairs]
    baselines, parser_accuracy = baseline_records(rows, topk)
    return {
        "rows": len(rows),
        "pairs": len(pairs),
        "unique_states": len({(item["network_id"], item["physical_state_sha256"]) for item in pairs}),
        "unique_loads": len({(item["network_id"], item["load_id"]) for item in pairs}),
        "pairs_by_network_type": {
            f"{network}:{pair_type}": pair_counts[(network, pair_type)]
            for network, pair_type in itertools.product(("33", "69"), PAIR_TYPES)
        },
        "available_pairs_by_network_type": availability,
        "pair_strength_min": min(strengths) if strengths else None,
        "pair_strength_mean": sum(strengths) / len(strengths) if strengths else None,
        "desired_action_diff_rate": (sum(
            item["left_desired_action"] != item["right_desired_action"] for item in pairs
        ) / len(pairs)) if pairs else 0.0,
        "frozen_rule_parser_accuracy": parser_accuracy,
        "cached_baselines_topk": topk,
        "cached_baselines": baselines,
    }


def write_jsonl(path, rows):
    with open(path, "x", encoding="utf-8", newline="\n") as handle:
        for row in rows:
            handle.write(json.dumps(row, ensure_ascii=False, sort_keys=True) + "\n")


def main():
    args = parse_args()
    outputs = [Path(args.train_out), Path(args.validation_out), Path(args.summary_out)]
    if any(path.exists() for path in outputs):
        raise FileExistsError(f"refusing to overwrite outputs: {outputs}")
    if args.min_pairs_per_type_network > args.max_pairs_per_type_network:
        raise ValueError("minimum pair count exceeds maximum")

    train_states = load_cached_states(args.train_cache)
    validation_pool, duplicate_states = merge_cached_states(args.validation_cache)
    train_state_ids = {(x["network_id"], x["physical_state_sha256"]) for x in train_states}
    train_load_ids = {(x["network_id"], x["load_id"]) for x in train_states}
    validation_states = [
        x for x in validation_pool
        if (x["network_id"], x["physical_state_sha256"]) not in train_state_ids
        and (x["network_id"], x["load_id"]) not in train_load_ids
    ]

    train_selected, train_available = select_pairs(train_states, "train", args)
    validation_selected, validation_available = select_pairs(validation_states, "validation", args)
    train_rows, train_pairs = emit_rows(
        train_selected, "train", args.train_paraphrases
    )
    validation_rows, validation_pairs = emit_rows(
        validation_selected, "validation", args.validation_paraphrases
    )

    train_summary = partition_summary(
        train_rows, train_pairs, train_available, args.topk
    )
    validation_summary = partition_summary(
        validation_rows, validation_pairs, validation_available, args.topk
    )
    train_keys = {(x["network_id"], x["physical_state_sha256"]) for x in train_pairs}
    validation_keys = {(x["network_id"], x["physical_state_sha256"]) for x in validation_pairs}
    train_loads = {(x["network_id"], x["load_id"]) for x in train_pairs}
    validation_loads = {(x["network_id"], x["load_id"]) for x in validation_pairs}
    train_template_text = {text for values in TRAIN_TEMPLATES.values() for text in values}
    validation_template_text = {text for values in VALIDATION_TEMPLATES.values() for text in values}
    code_sha256, missing_code = code_hashes()

    minimum_counts = {
        key: value >= args.min_pairs_per_type_network
        for key, value in {
            **{f"train:{k}": v for k, v in train_summary["pairs_by_network_type"].items()},
            **{f"validation:{k}": v for k, v in validation_summary["pairs_by_network_type"].items()},
        }.items()
    }
    fixed_validation = validation_summary["cached_baselines"]["fixed_loss_lindistflow"]
    checks = {
        "minimum_pairs_each_network_type": all(minimum_counts.values()),
        "all_pairs_change_ac_optimum": (
            train_summary["desired_action_diff_rate"] == 1.0
            and validation_summary["desired_action_diff_rate"] == 1.0
        ),
        "material_train_pairs": (
            train_summary["pair_strength_min"] is not None
            and train_summary["pair_strength_min"] >= min(
                args.min_objective_pair_gap, args.min_constraint_pair_gap
            )
        ),
        "material_validation_pairs": (
            validation_summary["pair_strength_min"] is not None
            and validation_summary["pair_strength_min"] >= min(
                args.min_objective_pair_gap, args.min_constraint_pair_gap
            )
        ),
        "train_validation_state_disjoint": not train_keys.intersection(validation_keys),
        "train_validation_load_disjoint": not train_loads.intersection(validation_loads),
        "train_validation_templates_disjoint": not train_template_text.intersection(validation_template_text),
        "validation_fixed_policy_has_material_regret": fixed_validation["normalised_regret_mean"] >= 0.05,
        "all_rows_same_candidate_count": all(
            row["candidate_count"] == 15 and len(row["candidates"]) == 15
            for row in [*train_rows, *validation_rows]
        ),
        "all_rows_have_separate_noop_anchor": all(
            row["gate_anchor"]["action"] == NOOP
            and all(item["action"] != NOOP for item in row["candidates"])
            for row in [*train_rows, *validation_rows]
        ),
        "code_files_present": not missing_code,
    }

    write_jsonl(args.train_out, train_rows)
    write_jsonl(args.validation_out, validation_rows)
    summary = {
        "msg": "GridRank strongly identifiable paired-instruction build",
        "schema": SCHEMA,
        "cached_only": True,
        "training_performed": False,
        "model_loaded": False,
        "power_flow_calls": 0,
        "construction_disclosure": (
            "AC outcomes identify counterfactual benchmark pairs and labels; "
            "state/candidate physics and natural-language instructions are the "
            "only native-LLM inputs. Pair selection metadata is never rendered."
        ),
        "settings": vars(args),
        "sources": {
            "train": {"path": str(Path(args.train_cache).resolve()), "sha256": file_sha256(args.train_cache)},
            "validation": [
                {"path": str(Path(path).resolve()), "sha256": file_sha256(path)}
                for path in args.validation_cache
            ],
            "validation_duplicate_states": duplicate_states,
        },
        "partitions": {"train": train_summary, "validation": validation_summary},
        "minimum_pair_checks": minimum_counts,
        "checks": checks,
        "code_sha256": code_sha256,
        "missing_code_files": missing_code,
    }
    summary["artifacts"] = {
        "train": {"path": str(Path(args.train_out).resolve()), "sha256": file_sha256(args.train_out)},
        "validation": {"path": str(Path(args.validation_out).resolve()), "sha256": file_sha256(args.validation_out)},
    }
    summary["coverage_pass"] = all(checks.values())
    with open(args.summary_out, "x", encoding="utf-8", newline="\n") as handle:
        json.dump(summary, handle, ensure_ascii=False, indent=2, sort_keys=True)
        handle.write("\n")
    print(json.dumps(summary, ensure_ascii=False))
    if not summary["coverage_pass"]:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
