"""Evaluate GridRank dynamic supplement cached."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import gridrank_dynamic_supplement as supplement
import preflight_gridrank_dynamic_supplement as preflight


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--preflight", required=True)
    parser.add_argument("--output", required=True)
    return parser.parse_args()


def main():
    args = parse_args()
    output = Path(args.output)
    if output.exists():
        raise FileExistsError(f"refusing to overwrite cached result: {output}")
    locked = preflight.verify_manifest(args.preflight)
    rows = supplement.read_jsonl(locked["artifacts"]["pairs"]["path"])
    records = supplement.read_jsonl(
        locked["artifacts"]["cross_records"]["path"]
    )
    result = supplement.cached_analysis(
        rows,
        records,
        bootstrap_reps=locked["schedule"]["bootstrap_reps"],
        bootstrap_seed=locked["schedule"]["bootstrap_seed"],
    )
    result.update({
        "experiment_id": preflight.EXPERIMENT_ID,
        "preflight_sha256": supplement.file_sha256(args.preflight),
        "input_sha256": {
            key: value["sha256"]
            for key, value in locked["artifacts"].items()
        },
    })
    output.write_text(
        json.dumps(result, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    print(json.dumps({
        "analysis_pass": result["analysis_pass"],
        "safety": result["safety_and_maintenance_mask"][
            "pooled_three_seed"
        ],
        "ranking_primary": result["matched_ranking_controls"][
            "primary_withheld_composition"
        ],
        "regime_mix": result["simbench_operating_regimes"][
            "unique_state_regime_mix"
        ],
        "failed_checks": result["failed_checks"],
    }, ensure_ascii=False))
    if not result["analysis_pass"]:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
