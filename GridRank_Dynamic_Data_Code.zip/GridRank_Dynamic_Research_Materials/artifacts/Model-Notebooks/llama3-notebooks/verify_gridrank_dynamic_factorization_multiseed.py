"""Validate GridRank dynamic factorization multiseed."""

from __future__ import annotations

import argparse
import json

import aggregate_gridrank_dynamic_factorization_multiseed as aggregate


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--result", required=True)
    return parser.parse_args()


def main():
    args = parse_args()
    observed = json.load(open(args.result, encoding="utf-8"))
    seeds = observed["inputs"]["seeds"]
    rebuilt = aggregate.build(
        {
            int(seed): value["factor_preflight"]["path"]
            for seed, value in seeds.items()
        },
        {int(seed): value["factor_gate"]["path"] for seed, value in seeds.items()},
        {
            int(seed): value["factor_records"]["path"]
            for seed, value in seeds.items()
        },
        {
            int(seed): value["joint_preflight"]["path"]
            for seed, value in seeds.items()
        },
        {int(seed): value["joint_gate"]["path"] for seed, value in seeds.items()},
        {
            int(seed): value["joint_records"]["path"]
            for seed, value in seeds.items()
        },
        observed["inputs"]["fresh_summary"]["path"],
        observed["bootstrap_reps"],
        observed["bootstrap_seed"],
    )
    checks = {
        "schema": observed.get("schema") == aggregate.SCHEMA,
        "experiment_id": observed.get("experiment_id") == aggregate.EXPERIMENT_ID,
        "exact_recomputation": observed == rebuilt,
        "audit_consistent": observed.get("audit_pass")
        is all(observed.get("integrity_checks", {}).values()),
        "gate_consistent": observed.get("factorization_multiseed_gate_pass")
        is (
            observed.get("audit_pass") is True
            and all(observed.get("robustness_checks", {}).values())
        ),
    }
    result = {
        "msg": "GridRank factorization multiseed result verification",
        "checks": checks,
        "verification_pass": all(checks.values()),
        "audit_pass": observed.get("audit_pass"),
        "factorization_multiseed_gate_pass": observed.get(
            "factorization_multiseed_gate_pass"
        ),
        "failed_robustness": observed.get("failed_robustness"),
    }
    print(json.dumps(result, ensure_ascii=False))
    if not result["verification_pass"]:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
