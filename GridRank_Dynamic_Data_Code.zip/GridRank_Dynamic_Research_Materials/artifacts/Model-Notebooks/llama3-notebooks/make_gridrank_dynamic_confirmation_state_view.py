"""Make gridrank dynamic confirmation state view utilities."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path

from build_gridrank_feedback import canonical_state_text, physical_state_sha256
from make_no_oracle_state_view import FORBIDDEN, KEEP, _source_rows


SCHEMA = "gridrank-dynamic-confirmation-state-view-v1"


def file_sha256(path):
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def jsonl(path):
    return [json.loads(line) for line in open(path, encoding="utf-8") if line.strip()]


def identities(paths, network, include_loads):
    states, loads, artifacts = set(), set(), []
    for raw in paths:
        path = Path(raw).resolve()
        if not path.is_file():
            raise FileNotFoundError(path)
        for row in jsonl(path):
            if str(row.get("network_id", row.get("network", ""))) != str(network):
                continue
            state = row.get("physical_state_sha256")
            load = str(row.get("load_id", ""))
            if state:
                states.add(str(state))
            if include_loads and load:
                loads.add(load if ":" in load else f"{network}:{load}")
        artifacts.append({"path": str(path), "sha256": file_sha256(path)})
    return states, loads, artifacts


def expected(args):
    hard_states, hard_loads, hard_artifacts = identities(
        args.identity_exclude_jsonl, args.network, True
    )
    eval_states, _, eval_artifacts = identities(
        args.state_exclude_jsonl, args.network, False
    )
    source = Path(args.input).resolve()
    rows, raw_ids = [], set()
    counters = {
        "raw_test_rows": 0,
        "excluded_training_or_development_state": 0,
        "excluded_training_or_development_load": 0,
        "excluded_prior_evaluation_state": 0,
    }
    for row in _source_rows(source):
        if str(row.get("split")) != "test":
            continue
        counters["raw_test_rows"] += 1
        instance_id = str(row.get("instance_id", ""))
        load = str(row.get("load_id", ""))
        if not instance_id or not load or instance_id in raw_ids:
            raise ValueError("raw-test identity must be complete and unique")
        raw_ids.add(instance_id)
        prompt = canonical_state_text(str(row.get("prompt", "")), args.network)
        state = physical_state_sha256(prompt, args.network)
        if state in hard_states:
            counters["excluded_training_or_development_state"] += 1
            continue
        if f"{args.network}:{load}" in hard_loads:
            counters["excluded_training_or_development_load"] += 1
            continue
        if state in eval_states:
            counters["excluded_prior_evaluation_state"] += 1
            continue
        rows.append({
            "instance_id": instance_id,
            "load_id": load,
            "prompt": prompt,
            "split": "validation",
        })
    counters["emitted_rows"] = len(rows)
    if len(rows) < args.min_rows:
        raise RuntimeError(
            f"network {args.network}: only {len(rows)} fresh rows after role-aware "
            f"exclusions; need {args.min_rows}; counters={counters}"
        )
    return rows, counters, {
        "identity": hard_artifacts,
        "state_only": eval_artifacts,
    }, {
        "identity_state_count": len(hard_states),
        "identity_load_count": len(hard_loads),
        "state_only_state_count": len(eval_states),
    }


def build(args):
    output = Path(args.output_jsonl).resolve()
    manifest_path = Path(args.manifest_json).resolve()
    if output.exists() or manifest_path.exists():
        raise FileExistsError("refusing to overwrite dynamic confirmation state view")
    rows, counters, artifacts, counts = expected(args)
    output.parent.mkdir(parents=True, exist_ok=True)
    temporary = output.with_name(output.name + ".tmp")
    with open(temporary, "w", encoding="utf-8", newline="\n") as handle:
        for row in rows:
            handle.write(json.dumps(row, ensure_ascii=False, separators=(",", ":")) + "\n")
    os.replace(temporary, output)
    emitted = jsonl(output)
    if any(set(row) != set(KEEP) or FORBIDDEN.intersection(row) for row in emitted):
        raise RuntimeError("dynamic confirmation state-view oracle boundary failed")
    result = {
        "msg": "GridRank role-aware fresh dynamic confirmation state view",
        "schema": SCHEMA,
        "network": str(args.network),
        "source": {
            "path": str(Path(args.input).resolve()),
            "sha256": file_sha256(args.input),
            "selected_split": "test",
        },
        "output": {"path": str(output), "sha256": file_sha256(output)},
        "emitted_role_split": "validation",
        "minimum_rows": args.min_rows,
        "identity_exclusions": artifacts["identity"],
        "state_only_exclusions": artifacts["state_only"],
        "exclusion_counts": counts,
        "counters": counters,
        "source_text_forwarded": False,
        "forbidden_columns_absent": sorted(FORBIDDEN),
    }
    temporary_manifest = manifest_path.with_name(manifest_path.name + ".tmp")
    temporary_manifest.write_text(
        json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    os.replace(temporary_manifest, manifest_path)
    return result


def verify(args):
    output = Path(args.output_jsonl).resolve()
    stored = json.load(open(args.manifest_json, encoding="utf-8"))
    rows, counters, artifacts, counts = expected(args)
    expected_bytes = "".join(
        json.dumps(row, ensure_ascii=False, separators=(",", ":")) + "\n"
        for row in rows
    ).encode("utf-8")
    checks = {
        "schema": stored.get("schema") == SCHEMA,
        "network": stored.get("network") == str(args.network),
        "source_hash": stored["source"]["sha256"] == file_sha256(args.input),
        "output_hash": stored["output"]["sha256"] == file_sha256(output),
        "deterministic_bytes": output.read_bytes() == expected_bytes,
        "identity_exclusions": stored.get("identity_exclusions") == artifacts["identity"],
        "state_only_exclusions": stored.get("state_only_exclusions") == artifacts["state_only"],
        "exclusion_counts": stored.get("exclusion_counts") == counts,
        "counters": stored.get("counters") == counters,
        "minimum_rows": stored.get("minimum_rows") == args.min_rows,
    }
    result = {
        "msg": "GridRank role-aware fresh state-view verification",
        "checks": checks,
        "verification_pass": all(checks.values()),
    }
    if not result["verification_pass"]:
        raise RuntimeError(f"state-view verification failed: {checks}")
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", choices=("build", "verify"), required=True)
    parser.add_argument("--network", choices=("33", "69"), required=True)
    parser.add_argument("--input", required=True)
    parser.add_argument("--identity_exclude_jsonl", action="append", required=True)
    parser.add_argument("--state_exclude_jsonl", action="append", default=[])
    parser.add_argument("--min_rows", type=int, default=64)
    parser.add_argument("--output_jsonl", required=True)
    parser.add_argument("--manifest_json", required=True)
    args = parser.parse_args()
    print(json.dumps((build if args.mode == "build" else verify)(args), ensure_ascii=False))


if __name__ == "__main__":
    main()
