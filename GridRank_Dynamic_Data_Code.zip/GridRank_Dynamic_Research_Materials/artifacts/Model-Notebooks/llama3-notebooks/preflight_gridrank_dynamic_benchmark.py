"""Check inputs for GridRank dynamic benchmark."""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import re
from collections import defaultdict
from pathlib import Path

from build_gridrank_instruction_pairs import (
    PAIR_TYPES,
    frozen_template_rule_parser,
    selected_action,
    structured_proxy_order,
)


HERE = Path(__file__).resolve().parent
SCHEMA = "gridrank-dynamic-benchmark-preflight-v1"
EXPERIMENT_ID = "gridrank-dynamic-operator-language-benchmark-v1"
PRIMARY_TOPK = 1
COMPOSITION_PAIR_TYPE = "maintenance_voltage"
EDGE_RE = re.compile(r"\((\d+)\s*,\s*(\d+)\)")

CODE_FILES = (
    "build_gridrank_instruction_pairs.py",
    "preflight_gridrank_dynamic_benchmark.py",
    "verify_gridrank_dynamic_benchmark.py",
    "run_gridrank_dynamic_benchmark.sh",
    "../../docs/GRIDRANK_DYNAMIC_BENCHMARK_PROTOCOL.md",
)


def file_sha256(path):
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--train_jsonl", required=True)
    parser.add_argument("--validation_jsonl", required=True)
    parser.add_argument("--pair_summary", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--seed", type=int, default=20260826)
    parser.add_argument("--topk", type=int, default=PRIMARY_TOPK)
    parser.add_argument("--min_primary_pairs", type=int, default=36)
    parser.add_argument("--min_composition_pairs", type=int, default=8)
    parser.add_argument("--min_fixed_regret", type=float, default=0.02)
    parser.add_argument("--min_interface_headroom", type=float, default=0.005)
    parser.add_argument("--max_structured_oracle_regret", type=float, default=0.001)
    parser.add_argument("--verify_manifest", action="store_true")
    return parser.parse_args()


def load_rows(path, partition):
    rows = [
        json.loads(line)
        for line in open(path, encoding="utf-8")
        if line.strip()
    ]
    if not rows:
        raise ValueError(f"empty dynamic benchmark partition: {path}")
    seen = set()
    required = {
        "schema", "instance_id", "pair_id", "pair_type", "pair_side",
        "paraphrase_index", "template_id", "partition", "network_id",
        "load_id", "physical_state_sha256", "instruction_text",
        "desired_action", "candidates", "gate_anchor",
        "oracle_structured_instruction", "pair_selection_gap",
    }
    for row in rows:
        if not required.issubset(row):
            missing = sorted(required.difference(row))
            raise ValueError(f"row missing {missing}: {row.get('instance_id')}")
        if row["partition"] != partition or row["instance_id"] in seen:
            raise ValueError(f"partition/identity mismatch: {row['instance_id']}")
        seen.add(row["instance_id"])
        if row["pair_type"] not in PAIR_TYPES:
            raise ValueError(f"unknown pair type: {row['instance_id']}")
        if row["pair_side"] not in {"left", "right"}:
            raise ValueError(f"unknown pair side: {row['instance_id']}")
        if str(row["network_id"]) not in {"33", "69"}:
            raise ValueError(f"unexpected network: {row['instance_id']}")
        if len(row["candidates"]) != 15:
            raise ValueError(f"candidate count mismatch: {row['instance_id']}")
        if float(row["pair_selection_gap"]) <= 0:
            raise ValueError(f"non-positive pair gap: {row['instance_id']}")
    return rows


def semantic_target(row):
    oracle = row["oracle_structured_instruction"]
    return {
        "objective": str(oracle["objective"]),
        "hard_constraint": bool(oracle["hard_constraint"]),
        "forbidden_edges": [
            [int(edge[0]), int(edge[1])]
            for edge in oracle.get("forbidden_edges", [])
        ],
    }


def extract_edges(text):
    return [[int(a), int(b)] for a, b in EDGE_RE.findall(str(text))]


def fit_text_parser(rows, seed):
    
    from sklearn.feature_extraction.text import TfidfVectorizer
    from sklearn.pipeline import FeatureUnion
    from sklearn.linear_model import LogisticRegression

    text = [str(row["instruction_text"]) for row in rows]
    objective = [semantic_target(row)["objective"] for row in rows]
    constraint = [int(semantic_target(row)["hard_constraint"]) for row in rows]
    features = FeatureUnion([
        ("word", TfidfVectorizer(
            lowercase=True, ngram_range=(1, 2), min_df=1,
            sublinear_tf=True, max_features=12000,
        )),
        ("char", TfidfVectorizer(
            lowercase=True, analyzer="char_wb", ngram_range=(3, 5), min_df=1,
            sublinear_tf=True, max_features=12000,
        )),
    ])
    matrix = features.fit_transform(text)
    objective_model = LogisticRegression(
        C=1.0, class_weight="balanced", max_iter=2000,
        random_state=seed, solver="liblinear",
    ).fit(matrix, objective)
    constraint_model = LogisticRegression(
        C=1.0, class_weight="balanced", max_iter=2000,
        random_state=seed + 1, solver="liblinear",
    ).fit(matrix, constraint)
    return {
        "features": features,
        "objective": objective_model,
        "constraint": constraint_model,
        "fit_rows": len(rows),
    }


def predict_text_parser(model, rows):
    matrix = model["features"].transform(
        [str(row["instruction_text"]) for row in rows]
    )
    objectives = model["objective"].predict(matrix)
    constraints = model["constraint"].predict(matrix)
    output = {}
    for row, objective, constrained in zip(rows, objectives, constraints):
        output[row["instance_id"]] = {
            "objective": str(objective),
            "hard_constraint": bool(int(constrained)),
            "forbidden_edges": extract_edges(row["instruction_text"])
            if int(constrained) else [],
        }
    return output


def action_regret(row, action):
    if action == "Action: none":
        return float(row["gate_anchor"]["normalised_regret"])
    for item in row["candidates"]:
        if item["action"] == action:
            return float(item["normalised_regret"])
    raise KeyError(action)


def action_touches(action, forbidden_edges):
    if action == "Action: none":
        return False
    numbers = [int(value) for value in re.findall(r"\d+", str(action))]
    action_edges = {
        tuple(sorted((numbers[index], numbers[index + 1])))
        for index in range(0, len(numbers) - 1, 2)
    }
    forbidden = {
        tuple(sorted((int(edge[0]), int(edge[1]))))
        for edge in forbidden_edges
    }
    return bool(action_edges.intersection(forbidden))


def rule_predictions(rows):
    return {
        row["instance_id"]: frozen_template_rule_parser(row["instruction_text"])
        for row in rows
    }


def fixed_predictions(rows):
    return {
        row["instance_id"]: {
            "objective": "loss", "hard_constraint": False,
            "forbidden_edges": [],
        }
        for row in rows
    }


def oracle_predictions(rows):
    return {row["instance_id"]: semantic_target(row) for row in rows}


def select_from_semantics(row, semantic, topk):
    ranking = structured_proxy_order(
        row, semantic["objective"], semantic["forbidden_edges"]
    )
    return selected_action(row, ranking, topk)


def semantic_accuracy(rows, predictions):
    exact = objective = constraint = edge = 0
    for row in rows:
        target = semantic_target(row)
        value = predictions[row["instance_id"]]
        objective_ok = value["objective"] == target["objective"]
        constraint_ok = bool(value["hard_constraint"]) == target["hard_constraint"]
        predicted_edges = {
            tuple(sorted(map(int, item))) for item in value["forbidden_edges"]
        }
        target_edges = {
            tuple(sorted(map(int, item))) for item in target["forbidden_edges"]
        }
        edge_ok = predicted_edges == target_edges
        objective += int(objective_ok)
        constraint += int(constraint_ok)
        edge += int(edge_ok)
        exact += int(objective_ok and constraint_ok and edge_ok)
    n = len(rows)
    return {
        "n": n,
        "exact_semantic_accuracy": exact / n,
        "objective_accuracy": objective / n,
        "constraint_accuracy": constraint / n,
        "forbidden_edge_accuracy": edge / n,
    }


def method_records(rows, predictions, topk, *, ac_oracle=False):
    records = []
    for row in rows:
        if ac_oracle:
            action = row["desired_action"]
        else:
            action = select_from_semantics(
                row, predictions[row["instance_id"]], topk
            )
        regret = action_regret(row, action)
        target = semantic_target(row)
        records.append({
            "instance_id": row["instance_id"],
            "pair_id": row["pair_id"],
            "pair_side": row["pair_side"],
            "pair_type": row["pair_type"],
            "network_id": str(row["network_id"]),
            "selected_action": action,
            "desired_action": row["desired_action"],
            "normalised_regret": regret,
            "physics_optimal": regret <= 1e-12,
            "constraint_violation": action_touches(
                action, target["forbidden_edges"]
            ),
        })
    return records


def summarize_records(records):
    groups = defaultdict(dict)
    for record in records:
        groups[record["pair_id"]][record["pair_side"]] = record
    complete = [value for value in groups.values() if set(value) == {"left", "right"}]
    return {
        "n": len(records),
        "pairs": len(complete),
        "normalised_regret_mean": sum(x["normalised_regret"] for x in records) / len(records),
        "physics_optimal_rate": sum(x["physics_optimal"] for x in records) / len(records),
        "constraint_violation_rate": sum(x["constraint_violation"] for x in records) / len(records),
        "instruction_pair_flip_rate": (
            sum(
                value["left"]["selected_action"] != value["right"]["selected_action"]
                for value in complete
            ) / len(complete)
            if complete else None
        ),
        "pair_both_endpoints_optimal_rate": (
            sum(
                value["left"]["physics_optimal"] and value["right"]["physics_optimal"]
                for value in complete
            ) / len(complete)
            if complete else None
        ),
    }


def partition_identity(rows):
    return {
        "states": {
            (str(row["network_id"]), row["physical_state_sha256"])
            for row in rows
        },
        "loads": {
            (str(row["network_id"]), str(row["load_id"]))
            for row in rows
        },
        "templates": {row["template_id"] for row in rows},
    }


def pair_structure(rows):
    groups = defaultdict(list)
    for row in rows:
        groups[row["pair_id"]].append(row)
    return groups, all(
        {item["pair_side"] for item in values} == {"left", "right"}
        and len({item["desired_action"] for item in values}) == 2
        and len({item["physical_state_sha256"] for item in values}) == 1
        for values in groups.values()
    )


def evaluate_suite(rows, parsers, topk):
    output = {}
    for name, predictions in parsers.items():
        records = method_records(rows, predictions, topk)
        output[name] = {
            "summary": summarize_records(records),
            "semantic": semantic_accuracy(rows, predictions),
        }
    oracle_records = method_records(
        rows, oracle_predictions(rows), topk, ac_oracle=True
    )
    output["full_ac_oracle"] = {
        "summary": summarize_records(oracle_records),
        "semantic": semantic_accuracy(rows, oracle_predictions(rows)),
    }
    return output


def code_hashes():
    missing = [name for name in CODE_FILES if not (HERE / name).is_file()]
    if missing:
        raise FileNotFoundError(f"missing dynamic benchmark code: {missing}")
    return {name: file_sha256(HERE / name) for name in CODE_FILES}


def package_versions():
    from importlib.metadata import version
    return {
        name: version(name)
        for name in ("numpy", "scikit-learn")
    }


def create(args):
    output = Path(args.output)
    if output.exists():
        raise FileExistsError(f"refusing to overwrite preflight: {output}")
    pair_summary = json.load(open(args.pair_summary, encoding="utf-8"))
    train = load_rows(args.train_jsonl, "train")
    validation_all = load_rows(args.validation_jsonl, "validation")
    primary = sorted(
        [row for row in validation_all if int(row["paraphrase_index"]) == 0],
        key=lambda row: row["instance_id"],
    )
    replication = sorted(
        [row for row in validation_all if int(row["paraphrase_index"]) == 1],
        key=lambda row: row["instance_id"],
    )
    composition = [
        row for row in primary if row["pair_type"] == COMPOSITION_PAIR_TYPE
    ]

    full_model = fit_text_parser(train, args.seed)
    composition_train = [
        row for row in train if row["pair_type"] != COMPOSITION_PAIR_TYPE
    ]
    composition_model = fit_text_parser(composition_train, args.seed + 100)

    def common_parsers(rows):
        return {
            "fixed_loss_lindistflow": fixed_predictions(rows),
            "frozen_rule_parser_lindistflow": rule_predictions(rows),
            "tfidf_logreg_lindistflow": predict_text_parser(full_model, rows),
            "oracle_structured_lindistflow": oracle_predictions(rows),
        }

    suites = {
        "unseen_paraphrase_primary": evaluate_suite(
            primary, common_parsers(primary), args.topk
        ),
        "unseen_paraphrase_replication": evaluate_suite(
            replication, common_parsers(replication), args.topk
        ),
    }
    composition_parsers = common_parsers(composition)
    composition_parsers["tfidf_logreg_withheld_composition"] = (
        predict_text_parser(composition_model, composition)
    )
    suites["unseen_composition"] = evaluate_suite(
        composition, composition_parsers, args.topk
    )

    train_identity = partition_identity(train)
    validation_identity = partition_identity(validation_all)
    primary_groups, primary_pair_ok = pair_structure(primary)
    composition_groups, composition_pair_ok = pair_structure(composition)
    primary_methods = suites["unseen_paraphrase_primary"]
    oracle_regret = primary_methods["oracle_structured_lindistflow"]["summary"]["normalised_regret_mean"]
    nonoracle_names = (
        "fixed_loss_lindistflow",
        "frozen_rule_parser_lindistflow",
        "tfidf_logreg_lindistflow",
    )
    best_nonoracle_regret = min(
        primary_methods[name]["summary"]["normalised_regret_mean"]
        for name in nonoracle_names
    )
    composition_methods = suites["unseen_composition"]
    composition_oracle = composition_methods["oracle_structured_lindistflow"]["summary"]["normalised_regret_mean"]
    composition_best = min(
        composition_methods[name]["summary"]["normalised_regret_mean"]
        for name in (
            "fixed_loss_lindistflow",
            "frozen_rule_parser_lindistflow",
            "tfidf_logreg_withheld_composition",
        )
    )
    artifact_checks = {
        "train": pair_summary.get("artifacts", {}).get("train", {}).get("sha256") == file_sha256(args.train_jsonl),
        "validation": pair_summary.get("artifacts", {}).get("validation", {}).get("sha256") == file_sha256(args.validation_jsonl),
    }
    checks = {
        "pair_gate_pass": pair_summary.get("coverage_pass") is True,
        "pair_artifacts_current": all(artifact_checks.values()),
        "top1_primary_budget": args.topk == PRIMARY_TOPK,
        "primary_pairs_minimum": len(primary_groups) >= args.min_primary_pairs,
        "composition_pairs_minimum": len(composition_groups) >= args.min_composition_pairs,
        "primary_pair_structure": primary_pair_ok,
        "composition_pair_structure": composition_pair_ok,
        "both_networks_primary": {str(row["network_id"]) for row in primary} == {"33", "69"},
        "all_pair_types_primary": {row["pair_type"] for row in primary} == set(PAIR_TYPES),
        "train_validation_state_disjoint": not train_identity["states"].intersection(validation_identity["states"]),
        "train_validation_load_disjoint": not train_identity["loads"].intersection(validation_identity["loads"]),
        "train_validation_template_disjoint": not train_identity["templates"].intersection(validation_identity["templates"]),
        "full_text_parser_fit_train_only": full_model["fit_rows"] == len(train),
        "composition_parser_withholds_composite_type": len(composition_train) < len(train) and all(row["pair_type"] != COMPOSITION_PAIR_TYPE for row in composition_train),
        "oracle_structured_primary_near_ceiling": oracle_regret <= args.max_structured_oracle_regret,
        "fixed_policy_primary_material_regret": primary_methods["fixed_loss_lindistflow"]["summary"]["normalised_regret_mean"] >= args.min_fixed_regret,
        "primary_interface_headroom_material": best_nonoracle_regret - oracle_regret >= args.min_interface_headroom,
        "composition_interface_headroom_material": composition_best - composition_oracle >= args.min_interface_headroom,
        "development_reuse_disclosed": True,
        "fresh_final_test_required": True,
    }
    manifest = {
        "msg": "GridRank dynamic operator-language benchmark preflight",
        "schema": SCHEMA,
        "experiment_id": EXPERIMENT_ID,
        "preflight_pass": all(checks.values()),
        "decision": "authorize_dynamic_llm_seed42_preflight" if all(checks.values()) else "stop_dynamic_language_route",
        "llm_training_performed": False,
        "llm_loaded": False,
        "power_flow_calls": 0,
        "traditional_baseline_fit": True,
        "development_reuse_disclosed": True,
        "fresh_final_test_required_after_model_selection": True,
        "topk": args.topk,
        "seed": args.seed,
        "package_versions": package_versions(),
        "artifacts": {
            "train": {"path": str(Path(args.train_jsonl).resolve()), "sha256": file_sha256(args.train_jsonl)},
            "validation": {"path": str(Path(args.validation_jsonl).resolve()), "sha256": file_sha256(args.validation_jsonl)},
            "pair_summary": {"path": str(Path(args.pair_summary).resolve()), "sha256": file_sha256(args.pair_summary)},
        },
        "selection": {
            "primary": "validation paraphrase_index=0; all locked pair IDs",
            "replication": "validation paraphrase_index=1; all locked pair IDs",
            "composition": f"primary rows with pair_type={COMPOSITION_PAIR_TYPE}",
            "composition_training": f"all train rows except pair_type={COMPOSITION_PAIR_TYPE}",
            "composition_seen_control": "tfidf_logreg_lindistflow is reported only as a seen-composition positive control and is excluded from the composition-headroom gate",
            "no_model_result_used_for_row_selection": True,
        },
        "counts": {
            "train_rows": len(train),
            "composition_train_rows": len(composition_train),
            "validation_rows": len(validation_all),
            "primary_rows": len(primary),
            "primary_pairs": len(primary_groups),
            "replication_rows": len(replication),
            "composition_rows": len(composition),
            "composition_pairs": len(composition_groups),
        },
        "suites": suites,
        "headroom": {
            "primary_best_nonoracle_regret": best_nonoracle_regret,
            "primary_oracle_regret": oracle_regret,
            "primary_gap": best_nonoracle_regret - oracle_regret,
            "composition_best_nonoracle_regret": composition_best,
            "composition_oracle_regret": composition_oracle,
            "composition_gap": composition_best - composition_oracle,
        },
        "thresholds": {
            "min_fixed_regret": args.min_fixed_regret,
            "min_interface_headroom": args.min_interface_headroom,
            "max_structured_oracle_regret": args.max_structured_oracle_regret,
        },
        "checks": checks,
        "failed_checks": [name for name, value in checks.items() if not value],
        "code_sha256": code_hashes(),
    }
    output.write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps(manifest, ensure_ascii=False))
    if not manifest["preflight_pass"]:
        raise SystemExit(2)


def verify(args):
    manifest = json.load(open(args.output, encoding="utf-8"))
    artifacts = manifest.get("artifacts", {})
    artifact_checks = {
        name: Path(item["path"]).is_file() and file_sha256(item["path"]) == item["sha256"]
        for name, item in artifacts.items()
    }
    checks = {
        "schema": manifest.get("schema") == SCHEMA,
        "experiment_id": manifest.get("experiment_id") == EXPERIMENT_ID,
        "preflight_pass": manifest.get("preflight_pass") is True,
        "artifacts_current": bool(artifact_checks) and all(artifact_checks.values()),
        "code_current": manifest.get("code_sha256") == code_hashes(),
        "packages_current": manifest.get("package_versions") == package_versions(),
        "topk_current": manifest.get("topk") == args.topk,
        "development_reuse_disclosed": manifest.get("development_reuse_disclosed") is True,
        "fresh_final_test_required": manifest.get("fresh_final_test_required_after_model_selection") is True,
    }
    result = {
        "msg": "GridRank dynamic benchmark manifest verification",
        "checks": checks,
        "verification_pass": all(checks.values()),
    }
    print(json.dumps(result, ensure_ascii=False))
    if not result["verification_pass"]:
        raise SystemExit(2)


def main():
    args = parse_args()
    if args.verify_manifest:
        verify(args)
    elif Path(args.output).exists():
        verify(args)
    else:
        create(args)


if __name__ == "__main__":
    main()
