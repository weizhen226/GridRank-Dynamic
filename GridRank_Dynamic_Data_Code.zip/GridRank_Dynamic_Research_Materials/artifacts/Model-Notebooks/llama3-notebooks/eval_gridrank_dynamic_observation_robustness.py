"""Evaluate GridRank dynamic observation robustness."""

from __future__ import annotations

import argparse
import json
import math
from collections import defaultdict
from pathlib import Path

import gridrank_dynamic_observation_robustness as robust
import preflight_gridrank_dynamic_benchmark as benchmark
import preflight_gridrank_dynamic_observation_robustness as preflight


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--preflight_manifest", required=True)
    parser.add_argument("--output_dir", required=True)
    return parser.parse_args()


def target_status(labelled, action, target):
    item = (
        labelled["gate_anchor"]
        if action == robust.NOOP
        else next(
            value for value in labelled["candidates"]
            if value["action"] == action
        )
    )
    regret = float(item["normalised_regret"])
    return {
        "normalised_regret": regret,
        "physics_optimal": regret <= 1e-12,
        "true_feasible": bool(item.get("feedback_valid"))
        and bool(item.get("feasible")),
        "true_constraint_violation": benchmark.action_touches(
            action, target["forbidden_edges"]
        ),
        "no_op": action == robust.NOOP,
    }


def cache_match(row, anchor, outcomes):
    checks = {
        "anchor_feedback_valid": bool(anchor.get("feedback_valid"))
        == bool(row["gate_anchor"].get("feedback_valid")),
        "anchor_feasible": bool(anchor.get("feasible"))
        == bool(row["gate_anchor"].get("feasible")),
    }
    pairs = (
        ("loss_kw", "candidate_loss_kw"),
        ("min_vm_pu", "candidate_min_vm_pu"),
        ("max_vm_pu", "candidate_max_vm_pu"),
    )
    for live, cached in pairs:
        left = anchor.get(live)
        right = row["gate_anchor"].get(cached)
        checks[f"anchor_{live}"] = (
            left is None and right is None
            if left is None or right is None
            else abs(float(left) - float(right)) <= 1e-8
        )
    by_action = {item["action"]: item for item in row["candidates"]}
    for action, outcome in outcomes.items():
        cached = by_action[action]
        checks[f"{action}:feedback_valid"] = (
            bool(outcome.get("feedback_valid"))
            == bool(cached.get("feedback_valid"))
        )
        checks[f"{action}:feasible"] = (
            bool(outcome.get("feasible")) == bool(cached.get("feasible"))
        )
        for live, target in (
            ("candidate_loss_kw", "candidate_loss_kw"),
            ("candidate_min_vm_pu", "candidate_min_vm_pu"),
            ("candidate_max_vm_pu", "candidate_max_vm_pu"),
            ("reduction_pct", "reduction_pct"),
        ):
            left, right = outcome.get(live), cached.get(target)
            checks[f"{action}:{live}"] = (
                left is None and right is None
                if left is None or right is None
                else abs(float(left) - float(right)) <= 1e-8
            )
    return checks


def common_record(row, seed, metadata, load_bin, condition, axis,
                  action, top1, baseline, status, anchor_feasible,
                  observed_gate_rejected):
    return {
        "experiment_axis": axis,
        "condition": condition,
        "seed": int(seed),
        "instance_id": row["instance_id"],
        "pair_id": row["pair_id"],
        "pair_side": row["pair_side"],
        "pair_type": row["pair_type"],
        "physical_state_sha256": row["physical_state_sha256"],
        "network": metadata["network"],
        "network_size": int(metadata["n_bus"]),
        "simbench_code": metadata["simbench_code"],
        "state_index": int(metadata["state_index"]),
        "operating_regime": metadata["operating_regime"],
        "load_bin": load_bin,
        "normalised_load_level": metadata["normalised_load_level"],
        "der_active": metadata["der_active"],
        "deployed_action": action,
        "pre_gate_top1": top1,
        "baseline_action": baseline["safe_action"],
        "action_flip": action != baseline["safe_action"],
        "baseline_normalised_regret": float(
            baseline["normalised_regret"]
        ),
        "regret_degradation": (
            float(status["normalised_regret"])
            - float(baseline["normalised_regret"])
        ),
        "observed_anchor_feasible": bool(anchor_feasible),
        "observed_gate_rejected": bool(observed_gate_rejected),
        **status,
    }


def main():
    import gridrank_dynamic_cross_topology as grid

    args = parse_args()
    output_dir = Path(args.output_dir)
    if output_dir.exists():
        raise FileExistsError(f"refusing to overwrite output: {output_dir}")
    locked = preflight.verify_manifest(args.preflight_manifest)
    output_dir.mkdir()
    schedule = locked["schedule"]
    rows = robust.read_jsonl(locked["artifacts"]["pairs"]["path"])
    primary = [row for row in rows if row["pair_type"] == robust.PRIMARY]
    source = {row["instance_id"]: row for row in primary}
    records = robust.read_jsonl(
        locked["artifacts"]["cross_records"]["path"]
    )
    indexed = robust.record_index(records)
    methods = {
        seed: f"{robust.LLM_PREFIX}_s{seed}" for seed in robust.SEEDS
    }
    baselines = {
        (seed, instance): indexed[method][instance]
        for seed, method in methods.items()
        for instance in source
    }
    by_state = defaultdict(list)
    for row in primary:
        by_state[row["physical_state_sha256"]].append(row)
    if any(len(value) != 2 for value in by_state.values()):
        raise RuntimeError("primary state must contain exactly two pair sides")

    nets, metadata = {}, {}
    identity_checks = {}
    for state_sha, state_rows in sorted(by_state.items()):
        row = state_rows[0]
        state_index = robust.state_index(row)
        code = row["simbench_code"]
        net = grid.state_network(code, state_index, schedule["scenario_seed"])
        nets[state_sha] = net
        metadata[state_sha] = robust.state_operating_metadata(
            grid, code, net, state_index
        )
        identity_checks[state_sha] = (
            grid.state_identity(
                code, net, state_index, schedule["scenario_seed"]
            ) == state_sha
        )
    load_bins = robust.assign_load_bins(metadata)

    result_rows = []
    anchor_calls = candidate_calls = 0
    clean_checks = {}
    operational_cache = {}
    total_states = len(by_state)
    for state_number, (state_sha, state_rows) in enumerate(
        sorted(by_state.items()), start=1
    ):
        meta = metadata[state_sha]
        code = meta["simbench_code"]
        actions = [item["action"] for item in state_rows[0]["candidates"]]
        for condition in robust.operating_conditions():
            effective = condition["id"]
            if not meta["der_active"] and condition["der_scale"] != 1.0:
                effective = "clean"
            cache_key = (state_sha, effective)
            if cache_key not in operational_cache:
                net = robust.scale_operating_net(
                    nets[state_sha],
                    condition["load_scale"] if effective != "clean" else 1.0,
                    condition["der_scale"] if effective != "clean" else 1.0,
                )
                features = grid.candidate_feature_texts(code, net, actions)
                anchor, outcomes = robust.run_live_actions(
                    grid, code, net, actions, features
                )
                anchor_calls += 1
                candidate_calls += len(actions)
                operational_cache[cache_key] = (
                    features, anchor, outcomes
                )
            features, anchor, outcomes = operational_cache[cache_key]
            if len(outcomes) != len(actions):
                raise RuntimeError(
                    f"incomplete operating outcomes: {state_sha}:{effective}"
                )
            live = robust.live_state(
                state_rows[0], anchor, outcomes, features
            )
            for row in state_rows:
                target = benchmark.semantic_target(row)
                target_label = robust.labelled_state(live, target)
                for seed, method in methods.items():
                    baseline = baselines[(seed, row["instance_id"])]
                    semantic = robust.frozen_semantics(
                        row, indexed[method][row["instance_id"]]
                    )
                    action, top1 = robust.deploy_full_pool(
                        row, features, live, semantic, target
                    )
                    status = target_status(
                        target_label, action, target
                    )
                    value = common_record(
                        row, seed, meta, load_bins[state_sha],
                        condition["id"], "operating_shift",
                        action, top1, baseline, status,
                        anchor.get("feasible", False), action != top1,
                    )
                    value.update({
                        "load_scale": float(condition["load_scale"]),
                        "der_scale": float(condition["der_scale"]),
                        "effective_condition": effective,
                        "noise_sigma": 0.0,
                        "noise_replicate": None,
                    })
                    result_rows.append(value)
                    if condition["id"] == "clean":
                        key = f"{seed}:{row['instance_id']}"
                        current_checks = {
                            "action": action == baseline["safe_action"],
                            "regret": math.isclose(
                                status["normalised_regret"],
                                float(baseline["normalised_regret"]),
                                abs_tol=1e-10,
                                rel_tol=1e-10,
                            ),
                        }
                        clean_checks[key] = current_checks
            if condition["id"] == "clean":
                clean_checks[f"cache:{state_sha}"] = cache_match(
                    state_rows[0], anchor, outcomes
                )
        print(json.dumps({
            "msg": "GridRank robustness operating progress",
            "state": state_number,
            "states_total": total_states,
            "network": meta["network"],
        }, ensure_ascii=False), flush=True)

    for state_number, (state_sha, state_rows) in enumerate(
        sorted(by_state.items()), start=1
    ):
        meta = metadata[state_sha]
        code = meta["simbench_code"]
        actions = [item["action"] for item in state_rows[0]["candidates"]]
        for condition in robust.noise_conditions():
            observed = robust.noisy_observation(
                nets[state_sha],
                condition["sigma"],
                condition["replicate"],
                state_sha,
                schedule["perturbation_seed"],
            )
            features = grid.candidate_feature_texts(code, observed, actions)
            decisions = {}
            requested_actions = set()
            for row in state_rows:
                for seed, method in methods.items():
                    baseline = baselines[(seed, row["instance_id"])]
                    semantic = robust.frozen_semantics(
                        row, indexed[method][row["instance_id"]]
                    )
                    ranking = robust.proxy_order(row, features, semantic)
                    decisions[(row["instance_id"], seed)] = (
                        baseline, semantic, ranking
                    )
                    requested_actions.add(ranking[0])
            anchor, outcomes = robust.run_live_actions(
                grid, code, observed, sorted(requested_actions), features
            )
            anchor_calls += 1
            candidate_calls += len(requested_actions)
            for row in state_rows:
                for seed in robust.SEEDS:
                    baseline, semantic, ranking = decisions[(
                        row["instance_id"], seed
                    )]
                    action, top1, gate_reason = robust.observed_gate_action(
                        row, ranking, anchor, outcomes, semantic,
                        benchmark.semantic_target(row),
                    )
                    status = robust.clean_action_status(row, action)
                    value = common_record(
                        row, seed, meta, load_bins[state_sha],
                        condition["id"], "measurement_noise",
                        action, top1, baseline, status,
                        anchor.get("feasible", False), action != top1,
                    )
                    value.update({
                        "load_scale": 1.0,
                        "der_scale": 1.0,
                        "effective_condition": condition["id"],
                        "noise_sigma": float(condition["sigma"]),
                        "noise_replicate": int(condition["replicate"]),
                        "observed_gate_reason": gate_reason,
                    })
                    result_rows.append(value)
        print(json.dumps({
            "msg": "GridRank robustness noise progress",
            "state": state_number,
            "states_total": total_states,
            "network": meta["network"],
        }, ensure_ascii=False), flush=True)

    summaries = robust.summarize(
        result_rows,
        schedule["bootstrap_reps"],
        schedule["bootstrap_seed"],
    )
    clean_exact = all(
        all(values.values()) for values in clean_checks.values()
    )
    expected_rows = (
        len(by_state) * 2 * len(robust.SEEDS)
        * (
            len(robust.operating_conditions())
            + len(robust.noise_conditions())
        )
    )
    checks = {
        "evaluation_only": True,
        "training_not_performed": True,
        "model_not_loaded": True,
        "identity_exact": all(identity_checks.values()),
        "records_exact": len(result_rows) == expected_rows,
        "clean_replay_exact": clean_exact,
        "three_networks": len({
            value["network"] for value in metadata.values()
        }) == 3,
        "three_network_sizes": len({
            value["n_bus"] for value in metadata.values()
        }) == 3,
        "three_regimes": {
            value["operating_regime"] for value in metadata.values()
        } == set(robust.REGIMES),
        "three_load_bins": set(load_bins.values()) == set(robust.LOAD_BINS),
        "power_flow_call_accounting": (
            anchor_calls > 0 and candidate_calls > 0
        ),
    }
    records_path = output_dir / (
        "gridrank_dynamic_observation_robustness_records.jsonl"
    )
    robust.write_jsonl_exclusive(records_path, result_rows)
    gate = {
        "msg": "GridRank sealed dynamic observation robustness result",
        "schema": robust.SCHEMA,
        "experiment_id": robust.EXPERIMENT_ID,
        "preflight_sha256": robust.file_sha256(
            args.preflight_manifest
        ),
        "evaluation_only": True,
        "training_performed": False,
        "model_loaded": False,
        "frozen_language_outputs_reused": True,
        "certified_gate_semantics": (
            "the predicted policy card controls LinDistFlow ranking; the "
            "independently supplied operator objective and hard maintenance "
            "constraint control AC/no-op certification, matching the sealed "
            "cross-topology evaluator"
        ),
        "ground_truth_boundary": (
            "operating shifts are ranked/gated/audited on their shifted AC "
            "state; measurement noise is ranked/gated on the noisy observed "
            "state and audited on the unchanged sealed clean AC state"
        ),
        "records": {
            "path": str(records_path.resolve()),
            "sha256": robust.file_sha256(records_path),
            "rows": len(result_rows),
        },
        "state_metadata": metadata,
        "load_bins": load_bins,
        "summaries": summaries,
        "power_flow_calls": {
            "anchor_power_flows": anchor_calls,
            "candidate_power_flows": candidate_calls,
            "backend_power_flows": anchor_calls + candidate_calls,
            "full_pool_operating_conditions": (
                len(by_state) * len(robust.operating_conditions())
            ),
            "measurement_noise_conditions": (
                len(by_state) * len(robust.noise_conditions())
            ),
        },
        "clean_replay_checks": clean_checks,
        "checks": checks,
        "evaluation_pass": all(checks.values()),
        "robustness_gate_pass": summaries["robustness_gate_pass"],
        "failed_checks": [
            key for key, value in checks.items() if not value
        ],
        "failed_scientific_checks": [
            key for key, value in summaries["scientific_checks"].items()
            if not value
        ],
        "decision": (
            "robustness_evidence_pass"
            if summaries["robustness_gate_pass"]
            else "retain_results_and_report_robustness_boundary"
        ),
    }
    gate_path = output_dir / (
        "gridrank_dynamic_observation_robustness_gate.json"
    )
    gate_path.write_text(
        json.dumps(gate, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    print(json.dumps({
        "evaluation_pass": gate["evaluation_pass"],
        "robustness_gate_pass": gate["robustness_gate_pass"],
        "decision": gate["decision"],
        "records": gate["records"],
        "power_flow_calls": gate["power_flow_calls"],
        "failed_checks": gate["failed_checks"],
        "failed_scientific_checks": gate["failed_scientific_checks"],
    }, ensure_ascii=False))
    if not gate["evaluation_pass"]:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
