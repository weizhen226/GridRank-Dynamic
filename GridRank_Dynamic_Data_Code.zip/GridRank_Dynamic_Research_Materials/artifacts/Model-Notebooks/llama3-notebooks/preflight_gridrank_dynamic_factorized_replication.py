"""Check inputs for GridRank dynamic factorized replication."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import preflight_gridrank_dynamic_factorized as original
import preflight_gridrank_dynamic_policy as joint
import preflight_gridrank_feedback as runtime


HERE = Path(__file__).resolve().parent
SCHEMA = "gridrank-dynamic-factorized-seed-replication-preflight-v1"
EXPERIMENT_ID = "gridrank-factorized-dynamic-seed-replication-v1"
SUPPORTED_SEEDS = (123, 2025)
CODE_FILES = (
    "gridrank_dynamic_factorized_llm.py",
    "train_gridrank_dynamic_factorized.py",
    "verify_gridrank_dynamic_factorized.py",
    "preflight_gridrank_dynamic_factorized_replication.py",
    "train_gridrank_dynamic_factorized_replication.py",
    "verify_gridrank_dynamic_factorized_replication.py",
    "run_gridrank_dynamic_factorized_replication.sh",
    "../../docs/GRIDRANK_DYNAMIC_MULTISEED_PROTOCOL.md",
)

file_sha256 = original.file_sha256
schedule = original.schedule


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--train_jsonl", required=True)
    parser.add_argument("--validation_jsonl", required=True)
    parser.add_argument("--pair_summary", required=True)
    parser.add_argument("--benchmark_manifest", required=True)
    parser.add_argument("--joint_preflight", required=True)
    parser.add_argument("--joint_gate", required=True)
    parser.add_argument("--resume_adapter_path", required=True)
    parser.add_argument("--sft_adapter_path", required=True)
    parser.add_argument("--base_model", required=True)
    parser.add_argument("--reference_factorized_preflight", required=False)
    parser.add_argument("--reference_factorized_gate", required=False)
    parser.add_argument("--output", required=True)
    parser.add_argument("--max_length", type=int, required=True)
    parser.add_argument("--primitive_batch_size", type=int, required=True)
    parser.add_argument("--epochs", type=int, required=True)
    parser.add_argument("--learning_rate", type=float, required=True)
    parser.add_argument("--grad_accum", type=int, required=True)
    parser.add_argument("--max_grad_norm", type=float, required=True)
    parser.add_argument("--target_temperature", type=float, required=True)
    parser.add_argument("--lambda_objective", type=float, required=True)
    parser.add_argument("--lambda_constraint", type=float, required=True)
    parser.add_argument("--lambda_physics", type=float, required=True)
    parser.add_argument("--lambda_hard", type=float, required=True)
    parser.add_argument("--hard_margin", type=float, required=True)
    parser.add_argument("--beta_reference", type=float, required=True)
    parser.add_argument("--seed", type=int, required=True)
    parser.add_argument("--gradient_checkpointing", type=int, choices=(0, 1), required=True)
    parser.add_argument("--bootstrap_reps", type=int, required=True)
    return parser.parse_args()


def code_hashes():
    missing = [name for name in CODE_FILES if not (HERE / name).is_file()]
    if missing:
        raise FileNotFoundError(f"missing replication code: {missing}")
    return {name: file_sha256(HERE / name) for name in CODE_FILES}


def _current_artifacts(args):
    return {
        "train": args.train_jsonl,
        "validation": args.validation_jsonl,
        "pair_summary": args.pair_summary,
        "dynamic_benchmark": args.benchmark_manifest,
        "joint_preflight": args.joint_preflight,
        "joint_gate": args.joint_gate,
    }


def _without_seed(value):
    return {key: item for key, item in value.items() if key != "seed"}


def create(args):
    output = Path(args.output)
    if output.exists():
        raise FileExistsError(f"refusing to overwrite replication preflight: {output}")
    if not args.reference_factorized_preflight or not args.reference_factorized_gate:
        raise ValueError("reference seed-42 factorized preflight and gate are required")

    reference = json.load(open(args.reference_factorized_preflight, encoding="utf-8"))
    reference_gate = json.load(open(args.reference_factorized_gate, encoding="utf-8"))
    current_schedule = schedule(args)
    artifacts = _current_artifacts(args)
    reference_artifacts = reference.get("artifacts", {})
    gridrank_hash = joint.adapter_hash(args.resume_adapter_path)
    sft_hash = joint.adapter_hash(args.sft_adapter_path)

    checks = {
        "reference_preflight_schema": reference.get("schema") == original.SCHEMA,
        "reference_preflight_pass": reference.get("preflight_pass") is True,
        "reference_seed_42": reference.get("schedule", {}).get("seed") == 42,
        "reference_gate_bound": reference_gate.get("preflight_sha256")
        == file_sha256(args.reference_factorized_preflight),
        "reference_gate_structurally_verified": reference_gate.get("decision")
        in {"authorize_fresh_factorized_dynamic_confirmation", "stop_factorized_dynamic_route"},
        "supported_replication_seed": args.seed in SUPPORTED_SEEDS,
        "seed_is_only_schedule_change": _without_seed(current_schedule)
        == _without_seed(reference.get("schedule", {})),
        "source_artifact_hashes_match_seed42": all(
            name in reference_artifacts
            and Path(path).is_file()
            and file_sha256(path) == reference_artifacts[name].get("sha256")
            for name, path in artifacts.items()
        ),
        "gridrank_start_adapter_matches_seed42": gridrank_hash
        == reference.get("adapters", {}).get("gridrank", {}).get("sha256"),
        "sft_control_adapter_matches_seed42": sft_hash
        == reference.get("adapters", {}).get("sft", {}).get("sha256"),
        "base_model_matches_seed42": runtime.model_inventory(args.base_model)
        == reference.get("base_model_inventory"),
        "selection_exactly_reused": bool(reference.get("selection", {}).get("train_row_ids"))
        and bool(reference.get("selection", {}).get("validation_row_ids")),
        "withheld_composition_unchanged": reference.get("selection", {}).get(
            "joint_card_mix", {}
        ).get("voltage_maintenance", 0) == 0,
    }
    manifest = {
        "msg": "GridRank factorized dynamic seed-only replication preflight",
        "schema": SCHEMA,
        "experiment_id": EXPERIMENT_ID,
        "preflight_pass": all(checks.values()),
        "training_performed": False,
        "model_loaded": False,
        "power_flow_calls": 0,
        "replication_policy": (
            "post-confirmation robustness replication; seed is the only permitted "
            "training change; no confirmation outcome may tune the run"
        ),
        "reference_seed42": {
            "preflight": {
                "path": str(Path(args.reference_factorized_preflight).resolve()),
                "sha256": file_sha256(args.reference_factorized_preflight),
            },
            "gate": {
                "path": str(Path(args.reference_factorized_gate).resolve()),
                "sha256": file_sha256(args.reference_factorized_gate),
            },
        },
        "artifacts": {
            name: {"path": str(Path(path).resolve()), "sha256": file_sha256(path)}
            for name, path in artifacts.items()
        },
        "adapters": {
            "gridrank": {
                "path": str(Path(args.resume_adapter_path).resolve()),
                "sha256": gridrank_hash,
            },
            "sft": {
                "path": str(Path(args.sft_adapter_path).resolve()),
                "sha256": sft_hash,
            },
        },
        "base_model": str(Path(args.base_model).resolve()),
        "base_model_inventory": runtime.model_inventory(args.base_model),
        "training_runtime": runtime.training_runtime(),
        "schedule": current_schedule,
        "selection": reference["selection"],
        "prompt_audit": reference.get("prompt_audit"),
        "code_sha256": code_hashes(),
        "checks": checks,
        "failed_checks": [key for key, value in checks.items() if not value],
    }
    output.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(manifest, ensure_ascii=False))
    if not manifest["preflight_pass"]:
        raise SystemExit(2)


def verify(args):
    from gridrank_runtime_compat import runtime_compatibility

    manifest = json.load(open(args.output, encoding="utf-8"))
    artifact_checks = {
        name: Path(item["path"]).is_file() and file_sha256(item["path"]) == item["sha256"]
        for name, item in manifest.get("artifacts", {}).items()
    }
    adapter_checks = {
        name: joint.adapter_hash(item["path"]) == item["sha256"]
        for name, item in manifest.get("adapters", {}).items()
    }
    reference_checks = {
        name: Path(item["path"]).is_file() and file_sha256(item["path"]) == item["sha256"]
        for name, item in manifest.get("reference_seed42", {}).items()
    }
    checks = {
        "schema": manifest.get("schema") == SCHEMA,
        "experiment_id": manifest.get("experiment_id") == EXPERIMENT_ID,
        "preflight_pass": manifest.get("preflight_pass") is True,
        "supported_seed": manifest.get("schedule", {}).get("seed") in SUPPORTED_SEEDS,
        "schedule_current": manifest.get("schedule") == schedule(args),
        "artifacts_current": bool(artifact_checks) and all(artifact_checks.values()),
        "adapters_current": bool(adapter_checks) and all(adapter_checks.values()),
        "reference_seed42_current": bool(reference_checks) and all(reference_checks.values()),
        "base_model_current": manifest.get("base_model_inventory")
        == runtime.model_inventory(manifest.get("base_model")),
        "runtime_compatible": runtime_compatibility(
            manifest.get("training_runtime"), runtime.training_runtime()
        )["compatible"],
        "code_current": manifest.get("code_sha256") == code_hashes(),
    }
    result = {
        "msg": "GridRank factorized seed-replication runtime verification",
        "checks": checks,
        "verification_pass": all(checks.values()),
    }
    print(json.dumps(result, ensure_ascii=False))
    if not result["verification_pass"]:
        raise SystemExit(2)


def main():
    args = parse_args()
    if Path(args.output).exists():
        verify(args)
    else:
        create(args)


if __name__ == "__main__":
    main()
