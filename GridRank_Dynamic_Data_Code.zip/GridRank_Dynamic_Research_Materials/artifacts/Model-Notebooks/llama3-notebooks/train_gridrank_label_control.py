"""Train GridRank label control."""

from __future__ import annotations

import json
import os
from pathlib import Path

import train_gridrank_select as base
from gridrank_label_controls import VARIANTS, audit_control, transform_rows
from preflight_gridrank_label_controls import file_sha256, verify


GATE_SCHEMA = "gridrank-label-control-gate-v1"


def main():
    variant = os.environ.get("GRIDRANK_LABEL_CONTROL", "")
    suite_path = os.environ.get("GRIDRANK_LABEL_CONTROL_SUITE", "")
    if variant not in VARIANTS or not suite_path:
        raise RuntimeError("label-control variant/suite environment is missing")
    suite = verify(suite_path)
    args = base.parse_args()
    locked = suite["base_preflights"][variant]
    if file_sha256(args.preflight_manifest) != locked["sha256"]:
        raise RuntimeError("wrong base preflight for label control")
    if base.schedule_manifest(args) != suite["expected_schedule"]:
        raise RuntimeError("label-control schedule differs from full GridRank")

    original_load_rows = base.load_rows
    training_audit = None

    def controlled_load_rows(path, partition, topk):
        nonlocal training_audit
        rows = original_load_rows(path, partition, topk)
        if partition != "train":
            return rows
        controlled = transform_rows(
            rows, variant, label_seed=int(suite["label_seed"]),
            target_temperature=float(suite["target_temperature"]),
        )
        training_audit = audit_control(rows, controlled, variant)
        if training_audit != suite["control_audits"][variant]:
            raise RuntimeError("runtime label transformation differs from preflight")
        return controlled

    base.load_rows = controlled_load_rows
    exit_code = 0
    try:
        base.main()
    except SystemExit as error:
        exit_code = int(error.code or 0)
    finally:
        base.load_rows = original_load_rows

    gate_path = Path(args.output_dir) / "gridrank_select_gate.json"
    if not gate_path.is_file() or training_audit is None:
        raise RuntimeError("base trainer did not produce a complete control gate")
    gate = json.loads(gate_path.read_text(encoding="utf-8"))
    gate.update({
        "schema": GATE_SCHEMA,
        "experiment_id": suite["experiment_id"],
        "label_control_variant": variant,
        "label_control_suite_sha256": file_sha256(suite_path),
        "training_supervision_audit": training_audit,
        "base_trainer_exit_code": exit_code,
        "control_result_valid_even_if_efficacy_gate_fails": True,
        "control_training_complete": True,
    })
    gate_path.write_text(json.dumps(gate, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps({
        "msg": "GridRank matched label control complete",
        "variant": variant,
        "base_trainer_exit_code": exit_code,
        "engineering_gate_pass": gate.get("engineering_gate_pass"),
        "paper_gate_pass": gate.get("paper_gate_pass"),
        "summaries": gate.get("summaries"),
    }, ensure_ascii=False))


if __name__ == "__main__":
    main()
