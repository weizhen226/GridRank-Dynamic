"""Gridrank traditional baselines utilities."""

from __future__ import annotations

import math

import action_extract
import grpo_reward_limited as reward
from physics_graph_policy import graph_for_action


EPS = 1e-12
METHODS = (
    "resistance_exchange",
    "local_loss_sensitivity",
    "lindistflow_tree",
)
METHOD_DESCRIPTIONS = {
    "resistance_exchange": (
        "Resistance-only branch-exchange heuristic: prefer replacing a high-"
        "resistance in-service branch with a lower-resistance tie branch."
    ),
    "local_loss_sensitivity": (
        "Local branch-loss sensitivity: estimate the removed branch loss minus "
        "the newly closed branch loss while ignoring loss redistribution on "
        "unchanged branches."
    ),
    "lindistflow_tree": (
        "Whole-tree LinDistFlow-style resistive-loss proxy using candidate-tree "
        "downstream active and reactive power."
    ),
}


def _edge(edge):
    return tuple(sorted(int(value) for value in edge))


def _finite(value):
    return math.isfinite(float(value))


def _edge_loss_map(graph):
    

    nodes = graph["node_features"]
    edge_index = graph["edge_index"]
    edge_features = graph["edge_features"]
    if len(edge_index) % 2 or len(edge_index) != len(edge_features):
        raise ValueError("candidate graph has malformed directed edges")
    output = {}
    for offset in range(0, len(edge_index), 2):
        left, right = edge_index[offset]
        reverse = edge_index[offset + 1]
        if reverse != [right, left]:
            raise ValueError("candidate graph edge directions are not paired")
        left_depth = float(nodes[left][4])
        right_depth = float(nodes[right][4])
        if abs(left_depth - right_depth) <= EPS:
            raise ValueError("radial edge endpoints have equal depth")
        child = left if left_depth > right_depth else right
        downstream_p = float(nodes[child][2])
        downstream_q = float(nodes[child][3])
        resistance = abs(float(edge_features[offset][0]))
        key = _edge((left + 1, right + 1))
        if key in output:
            raise ValueError(f"duplicate active edge in candidate graph: {key}")
        output[key] = resistance * (
            downstream_p * downstream_p + downstream_q * downstream_q
        )
    return output


def _impedance_table(state_text):
    engine = reward.engine_from_prompt(state_text)
    if engine is None:
        raise ValueError("cannot parse network from state text")
    table = {
        engine._key(a, b): (float(resistance), float(reactance))
        for a, b, resistance, reactance in engine.ALL_BRANCHES
    }
    positive = sorted(abs(value[0]) for value in table.values() if value[0])
    scale = positive[len(positive) // 2] if positive else 1.0
    return table, max(scale, EPS)


def score_bundle(state_text, actions):
    

    actions = tuple(str(action) for action in actions)
    if not actions or len(actions) != len(set(actions)):
        raise ValueError("traditional baseline requires unique non-empty actions")
    if any(action == "Action: none" for action in actions):
        raise ValueError("no-op must remain outside the ranked exchange set")

    baseline_map = _edge_loss_map(graph_for_action(state_text, "Action: none"))
    baseline_total = sum(baseline_map.values())
    if not _finite(baseline_total) or baseline_total <= EPS:
        raise ValueError("invalid baseline loss proxy")
    impedance, resistance_scale = _impedance_table(state_text)
    output = {name: [] for name in METHODS}

    for action in actions:
        parsed = action_extract.extract_delta(action)
        if parsed is None or parsed == "none":
            raise ValueError(f"invalid exchange action: {action!r}")
        close_edge, open_edge = _edge(parsed[0]), _edge(parsed[1])
        if close_edge not in impedance or open_edge not in impedance:
            raise ValueError(f"unknown exchange edge: {action}")

        candidate_map = _edge_loss_map(graph_for_action(state_text, action))
        candidate_total = sum(candidate_map.values())
        if open_edge not in baseline_map:
            raise ValueError(f"opened edge is absent from baseline tree: {action}")
        if close_edge not in candidate_map:
            raise ValueError(f"closed edge is absent from candidate tree: {action}")

        close_r = float(impedance[close_edge][0])
        open_r = float(impedance[open_edge][0])
        output["resistance_exchange"].append(
            (open_r - close_r) / resistance_scale
        )
        output["local_loss_sensitivity"].append(
            (baseline_map[open_edge] - candidate_map[close_edge]) / baseline_total
        )
        output["lindistflow_tree"].append(
            (baseline_total - candidate_total) / baseline_total
        )

    if any(
        len(values) != len(actions) or any(not _finite(value) for value in values)
        for values in output.values()
    ):
        raise RuntimeError("traditional baseline produced invalid scores")
    return output


def score_method(state_text, actions, method):
    

    if method not in METHODS:
        raise ValueError(f"unknown traditional method: {method}")
    actions = tuple(str(action) for action in actions)
    if not actions or len(actions) != len(set(actions)):
        raise ValueError("traditional baseline requires unique non-empty actions")
    if any(action == "Action: none" for action in actions):
        raise ValueError("no-op must remain outside the ranked exchange set")
    impedance, resistance_scale = _impedance_table(state_text)

    if method == "resistance_exchange":
        output = []
        for action in actions:
            parsed = action_extract.extract_delta(action)
            if parsed is None or parsed == "none":
                raise ValueError(f"invalid exchange action: {action!r}")
            close_edge, open_edge = _edge(parsed[0]), _edge(parsed[1])
            if close_edge not in impedance or open_edge not in impedance:
                raise ValueError(f"unknown exchange edge: {action}")
            output.append(
                (float(impedance[open_edge][0]) - float(impedance[close_edge][0]))
                / resistance_scale
            )
        return output

    baseline_map = _edge_loss_map(graph_for_action(state_text, "Action: none"))
    baseline_total = sum(baseline_map.values())
    if not _finite(baseline_total) or baseline_total <= EPS:
        raise ValueError("invalid baseline loss proxy")
    output = []
    for action in actions:
        parsed = action_extract.extract_delta(action)
        if parsed is None or parsed == "none":
            raise ValueError(f"invalid exchange action: {action!r}")
        close_edge, open_edge = _edge(parsed[0]), _edge(parsed[1])
        candidate_map = _edge_loss_map(graph_for_action(state_text, action))
        if method == "local_loss_sensitivity":
            if open_edge not in baseline_map or close_edge not in candidate_map:
                raise ValueError(f"switched edge absent from expected tree: {action}")
            value = (
                baseline_map[open_edge] - candidate_map[close_edge]
            ) / baseline_total
        else:
            value = (baseline_total - sum(candidate_map.values())) / baseline_total
        output.append(value)
    if len(output) != len(actions) or any(not _finite(value) for value in output):
        raise RuntimeError(f"{method} produced invalid scores")
    return output


def scores_by_method(state_text, actions):
    

    return score_bundle(state_text, actions)
