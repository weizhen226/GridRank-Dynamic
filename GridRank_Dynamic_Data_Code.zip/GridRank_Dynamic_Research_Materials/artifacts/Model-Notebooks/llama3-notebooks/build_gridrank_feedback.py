"""Build GridRank feedback."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import random
import re
from collections import Counter, defaultdict
from pathlib import Path

import grpo_reward_limited as reward
from build_gridalign_instruction_feedback import INSTRUCTIONS, NOOP, utility
from gridalign_llm import PHYSICS_TEXT_SCHEMA_SHA256, candidate_physics_texts
from limited_protocol import DEADBAND_PCT
from structured_action_head import enumerate_radial_actions


STRICT_FIELDS = {"instance_id", "load_id", "prompt", "split"}
TARGET_TEMPERATURE = 0.20
ACCEPT_THRESHOLDS = {
    "loss": float(DEADBAND_PCT),
    "voltage": 0.01,
    "balanced": 0.05,
    "conservative": 0.0,
}
OPTIMAL_TOL = 1e-12

BUILD_CODE_FILES = (
    "build_gridrank_feedback.py",
    "build_gridalign_instruction_feedback.py",
    "limited_protocol.py",
    "gridalign_llm.py",
    "physics_graph_policy.py",
    "structured_action_head.py",
    "state_to_delta_csv.py",
    "action_extract.py",
    "grpo_reward_limited.py",
    "physics_env.py",
    "case33_authoritative.py",
    "case69_authoritative.py",
    "pandapower_backend.py",
    "subprocess_physics_backend.py",
    "physics_sim_worker.py",
)


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--train_source", action="append", required=True, help="NETWORK=STATE_ONLY")
    parser.add_argument("--validation_source", action="append", required=True, help="NETWORK=STATE_ONLY")
    parser.add_argument("--offline_loads_per_network", type=int, default=16)
    parser.add_argument("--online_loads_per_network", type=int, default=4)
    parser.add_argument("--test_loads_per_network", type=int, default=8)
    parser.add_argument("--candidate_pool_size", type=int, default=16,
                        help="0 means the complete topology-valid K=1 pool")
    parser.add_argument("--candidate_seed", type=int, default=20260721)
    parser.add_argument("--row_seed", type=int, default=42)
    parser.add_argument("--target_temperature", type=float, default=TARGET_TEMPERATURE)
    parser.add_argument("--physics_backend", choices=["pandapower-subprocess"],
                        default="pandapower-subprocess")
    parser.add_argument("--physics_python", required=True)
    parser.add_argument("--physics_timeout_s", type=float, default=60.0)
    parser.add_argument("--offline_out", required=True)
    parser.add_argument("--online_out", required=True)
    parser.add_argument("--test_out", required=True)
    parser.add_argument("--summary_out", required=True)
    return parser.parse_args()


def file_sha256(path):
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def read_state_only(path, expected_split):
    path = Path(path)
    if path.suffix.lower() == ".csv":
        with open(path, encoding="utf-8", newline="") as handle:
            reader = csv.DictReader(handle)
            if set(reader.fieldnames or []) != STRICT_FIELDS:
                raise ValueError(f"state-only CSV schema is not strict: {reader.fieldnames}")
            rows = list(reader)
    else:
        rows = [json.loads(line) for line in open(path, encoding="utf-8") if line.strip()]
        schemas = {frozenset(row) for row in rows}
        if schemas != {frozenset(STRICT_FIELDS)}:
            raise ValueError(f"state-only JSONL schema is not strict: {schemas}")
    if not rows or any(str(row["split"]) != expected_split for row in rows):
        raise ValueError(f"{path} must contain only split={expected_split}")
    if len({str(row["instance_id"]) for row in rows}) != len(rows):
        raise ValueError(f"duplicate instance_id in {path}")
    return rows


def canonical_state_text(prompt, network=None):
    

    text = str(prompt)
    patterns = {
        "network": r"\bBusses\s*=\s*(33|69)\b",
        "existing": r"Existing Open Lines\s*=",
        "load": r"System Load\s*=",
        "budget": r"N_branch_exchanges\s*<=\s*\d+",
    }
    for name, pattern in patterns.items():
        if len(re.findall(pattern, text, flags=re.I)) != 1:
            raise ValueError(f"prompt must contain exactly one {name} physical field")
    engine = reward.engine_from_prompt(text)
    existing = reward.parse_existing_open(text)
    load = reward.parse_load(text)
    budget = reward.parse_budget(text)
    if engine is None or existing is None or load is None or budget is None:
        raise ValueError("cannot parse canonical physical state")
    if network is not None and int(engine.N_BUS) != int(network):
        raise ValueError(f"network mismatch: spec={network}, prompt={engine.N_BUS}")
    if len(load) != int(engine.N_BUS):
        raise ValueError(
            f"load vector length mismatch: buses={engine.N_BUS}, loads={len(load)}"
        )
    branch_keys = {engine._key(a, b) for a, b, _, _ in engine.ALL_BRANCHES}
    existing_keys = {engine._key(*edge) for edge in existing}
    if not existing_keys or not existing_keys.issubset(branch_keys):
        raise ValueError("existing-open set contains an unknown branch")
    open_text = ",".join(f"({a},{b})" for a, b in sorted(existing_keys))
    load_text = ",".join(
        f"({float(value.real):.12g}{float(value.imag):+.12g}j)" for value in load
    )
    return (
        f"Power Distribution Network: Busses={int(engine.N_BUS)}, "
        f"Existing Open Lines=[{open_text}], System Load=[{load_text}]\n"
        f"Budget: N_branch_exchanges <= {int(budget)}\n"
        f"Voltage bounds: {float(reward.VMIN):.2f} <= Vm_pu <= {float(reward.VMAX):.2f}"
    )


def physical_state_sha256(prompt, network):
    

    engine = reward.engine_from_prompt(prompt)
    existing = reward.parse_existing_open(prompt)
    load = reward.parse_load(prompt)
    budget = reward.parse_budget(prompt)
    if engine is None or existing is None or load is None or budget is None:
        raise ValueError("cannot parse physical state")
    if int(engine.N_BUS) != int(network):
        raise ValueError(f"network mismatch: spec={network}, prompt={engine.N_BUS}")
    if len(load) != int(engine.N_BUS):
        raise ValueError(
            f"load vector length mismatch: buses={engine.N_BUS}, loads={len(load)}"
        )
    payload = {
        "network": int(network),
        "existing_open": [list(engine._key(*edge)) for edge in sorted(existing)],
        "load": [[round(float(value.real), 12), round(float(value.imag), 12)] for value in load],
        "exchange_budget": int(budget),
        "vmin": float(reward.VMIN),
        "vmax": float(reward.VMAX),
        "branches": [
            [int(a), int(b), round(float(r), 12), round(float(x), 12)]
            for a, b, r, x in engine.ALL_BRANCHES
        ],
    }
    encoded = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def complete_actions(prompt):
    engine = reward.engine_from_prompt(prompt)
    existing = reward.parse_existing_open(prompt)
    if engine is None or existing is None:
        raise ValueError("cannot enumerate candidate pool")
    actions = [NOOP, *[item["action"] for item in enumerate_radial_actions(engine, existing)]]
    if len(actions) != len(set(actions)):
        raise RuntimeError("topology enumerator returned duplicate actions")
    return actions


def select_action_pool(actions, state_sha, size, seed):
    if size < 0 or size == 1:
        raise ValueError("candidate_pool_size must be 0 or >=2")
    if size == 0 or len(actions) <= size:
        return list(actions)
    nonnoop = [action for action in actions if action != NOOP]
    ranked = sorted(
        nonnoop,
        key=lambda action: hashlib.sha256(
            f"{seed}|{state_sha}|{action}".encode("utf-8")
        ).digest(),
    )
    return [NOOP, *ranked[: size - 1]]


def _state_rows_by_load(rows, network, seed):
    grouped = defaultdict(list)
    for row in rows:
        grouped[str(row["load_id"])].append(row)
    load_ids = sorted(grouped)
    random.Random(seed + 1009 * int(network)).shuffle(load_ids)
    selected = []
    for load_id in load_ids:
        values = sorted(
            grouped[load_id],
            key=lambda row: hashlib.sha256(
                f"{seed}|{network}|{row['instance_id']}".encode("utf-8")
            ).digest(),
        )
        selected.append(values[0])
    return selected


def base_state(raw, network, pool_size, candidate_seed):
    text = canonical_state_text(raw["prompt"], network)
    state_sha = physical_state_sha256(text, network)
    full_actions = complete_actions(text)
    actions = select_action_pool(full_actions, state_sha, pool_size, candidate_seed)
    features = candidate_physics_texts(text, tuple(actions))
    candidates = [
        {"action": action, "candidate_feature_text": feature}
        for action, feature in zip(actions, features)
    ]
    return {
        "source_instance_id": str(raw["instance_id"]),
        "load_id": f"{network}:{raw['load_id']}",
        "network_id": str(network),
        "state_text": text,
        "physical_state_sha256": state_sha,
        "full_candidate_count": len(full_actions),
        "candidate_pool_sha256": hashlib.sha256("\n".join(actions).encode("utf-8")).hexdigest(),
        "candidates": candidates,
    }


def sanitize_feedback(candidate, scored):
    reduction, feasible, detail = scored
    output = dict(candidate)
    output.update({
        "feedback_revealed": True,
        "feedback_valid": bool(detail.get("feedback_valid")),
        "feasible": bool(feasible),
        "reason": detail.get("reason"),
        "reduction_pct": float(reduction) if reduction is not None else None,
        "anchor_loss_kw": detail.get("anchor_loss_kw"),
        "candidate_loss_kw": detail.get("candidate_loss_kw"),
        "anchor_min_vm_pu": detail.get("anchor_min_vm_pu"),
        "candidate_min_vm_pu": detail.get("min_vm_pu"),
        "candidate_max_vm_pu": detail.get("max_vm_pu"),
    })
    return output


def score_state(base, args, counters):
    actions = [candidate["action"] for candidate in base["candidates"]]
    scored = reward.score_completions(
        base["state_text"], actions, return_detail=True, action_mode="delta",
        physics_backend=args.physics_backend, physics_python=args.physics_python,
        physics_timeout_s=args.physics_timeout_s,
    )
    if len(scored) != len(actions):
        raise RuntimeError(
            f"physics backend returned {len(scored)} outcomes for {len(actions)} actions"
        )
    
    
    counters["anchor_power_flows"] += 1
    counters["candidate_power_flows"] += len(actions)
    counters["backend_power_flows"] += 1 + len(actions)
    candidates = [sanitize_feedback(candidate, value)
                  for candidate, value in zip(base["candidates"], scored)]
    if not all(candidate["feedback_valid"] for candidate in candidates):
        invalid = [candidate["action"] for candidate in candidates
                   if not candidate["feedback_valid"]]
        raise RuntimeError(f"invalid authoritative feedback for state {base['physical_state_sha256']}: {invalid}")
    output = dict(base)
    output["candidates"] = candidates
    return output


def noop_is_operational(candidates):
    noop = next(candidate for candidate in candidates if candidate["action"] == NOOP)
    return bool(noop.get("feedback_valid") and noop.get("feasible"))


def screen_online_anchor(base, args, counters):
    

    scored = reward.score_completions(
        base["state_text"], [NOOP], return_detail=True, action_mode="delta",
        physics_backend=args.physics_backend, physics_python=args.physics_python,
        physics_timeout_s=args.physics_timeout_s,
    )
    counters["anchor_screen_states"] += 1
    counters["anchor_power_flows"] += 1
    counters["candidate_power_flows"] += 1
    counters["backend_power_flows"] += 2
    if len(scored) != 1:
        raise RuntimeError(f"anchor screen returned {len(scored)} outcomes")
    candidate = sanitize_feedback(base["candidates"][0], scored[0])
    if not candidate["feedback_valid"]:
        raise RuntimeError(
            f"invalid anchor-screen feedback for state {base['physical_state_sha256']}"
        )
    return bool(candidate["feasible"])


def _normalised_regrets(safe_values, desired):
    finite = [float(value) for value in safe_values if value is not None]
    if not finite or safe_values[desired] is None:
        return [0.0 if index == desired else 1.0 for index in range(len(safe_values))]
    best = float(safe_values[desired])
    spread = max(finite) - min(finite) if len(finite) > 1 else abs(best)
    floor = min([0.0, *finite]) - max(1e-6, spread)
    scale = max(1e-6, best - floor)
    return [
        1.0 if value is None else min(1.0, max(0.0, (best - float(value)) / scale))
        for value in safe_values
    ]


def label_candidates(kind, candidates, temperature):
    noop = next(index for index, item in enumerate(candidates) if item["action"] == NOOP)
    anchor_min = candidates[noop]["anchor_min_vm_pu"]
    raw_values = [utility(kind, candidate, anchor_min) for candidate in candidates]
    threshold = ACCEPT_THRESHOLDS[kind]
    safe_values = []
    for index, value in enumerate(raw_values):
        if index == noop:
            safe_values.append(None if value is None else float(value))
        elif value is not None and float(value) > threshold:
            safe_values.append(float(value))
        else:
            safe_values.append(None)
    finite_indices = [index for index, value in enumerate(safe_values) if value is not None]
    if finite_indices:
        best_value = max(float(safe_values[index]) for index in finite_indices)
        optimal = {
            index for index in finite_indices
            if math.isclose(
                float(safe_values[index]), best_value,
                rel_tol=OPTIMAL_TOL, abs_tol=OPTIMAL_TOL,
            )
        }
        desired = max(
            optimal,
            key=lambda index: (
                candidates[index]["action"] == NOOP,
                candidates[index]["action"],
            ),
        )
    else:


        optimal = {noop}
        desired = noop
    regrets = _normalised_regrets(safe_values, desired)
    if not finite_indices or (desired == noop and len(optimal) == 1):
        probabilities = [float(index == noop) for index in range(len(candidates))]
    else:
        weights = [
            0.0 if value is None else math.exp(-regrets[index] / temperature)
            for index, value in enumerate(safe_values)
        ]
        total = sum(weights)
        probabilities = [value / total for value in weights]
    ranked = sorted(
        range(len(candidates)),
        key=lambda index: (
            safe_values[index] is None,
            -(safe_values[index] if safe_values[index] is not None else -math.inf),
            candidates[index]["action"] != NOOP,
            candidates[index]["action"],
        ),
    )
    ranks = {index: rank for rank, index in enumerate(ranked)}
    output = []
    for index, candidate in enumerate(candidates):
        item = dict(candidate)
        item.update({
            "instruction_utility": raw_values[index],
            "safe_utility": safe_values[index],
            "accepted_by_gate": safe_values[index] is not None,
            "is_physics_optimal": index in optimal,
            "fallback_candidate": index == noop,
            "normalised_regret": regrets[index],
            "physics_rank": ranks[index],
            "target_prob": probabilities[index],
        })
        output.append(item)
    return desired, output


def directive_rows(base, partition, style, temperature, labelled):
    rows = []
    for kind, directive in INSTRUCTIONS[style].items():
        row = {
            "instance_id": f"{partition}:{base['network_id']}:{base['source_instance_id']}:{kind}",
            "partition": partition,
            "source_split": "validation" if partition == "test" else "train",
            "instruction_id": kind,
            "instruction_style": style,
            "instruction_text": directive,
            **{key: value for key, value in base.items() if key != "candidates"},
        }
        if labelled:
            desired, candidates = label_candidates(kind, base["candidates"], temperature)
            optimal_indices = [
                index for index, candidate in enumerate(candidates)
                if candidate["is_physics_optimal"]
            ]
            row.update({
                "feedback_status": "authoritative-full-pool",
                "desired_index": desired,
                "desired_action": candidates[desired]["action"],
                "optimal_indices": optimal_indices,
                "optimal_actions": [candidates[index]["action"] for index in optimal_indices],
                "candidates": candidates,
            })
        else:
            candidates = []
            for candidate in base["candidates"]:
                item = dict(candidate)
                item["feedback_revealed"] = False
                candidates.append(item)
            row.update({"feedback_status": "unrevealed-online-stream", "candidates": candidates})
        rows.append(row)
    return rows


def _parse_sources(specs, expected_split):
    output = {}
    for spec in specs:
        network, path = spec.split("=", 1)
        if network in output:
            raise ValueError(f"duplicate source for network {network}")
        output[network] = {"path": path, "rows": read_state_only(path, expected_split)}
    if set(output) != {"33", "69"}:
        raise ValueError("GridRank gate requires exactly networks 33 and 69")
    return output


def _write_jsonl(path, rows):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as handle:
        for row in rows:
            handle.write(json.dumps(row, ensure_ascii=False) + "\n")


def main():
    args = parse_args()
    if min(args.offline_loads_per_network, args.online_loads_per_network,
           args.test_loads_per_network) <= 0:
        raise SystemExit("all per-network load counts must be positive")
    if args.target_temperature <= 0:
        raise SystemExit("target_temperature must be positive")
    train_sources = _parse_sources(args.train_source, "train")
    validation_sources = _parse_sources(args.validation_source, "validation")
    counters = Counter()
    offline_rows, online_rows, test_rows = [], [], []
    selected_loads = {"offline_train": {}, "online_stream": {}, "test": {}}
    selection_trace = {"offline_train": {}, "online_stream": {}, "test": {}}

    for network, source in sorted(train_sources.items()):
        states = _state_rows_by_load(source["rows"], network, args.row_seed)
        cursor = 0
        offline_bases = []
        offline_trace = []
        while len(offline_bases) < args.offline_loads_per_network and cursor < len(states):
            raw = states[cursor]
            cursor += 1
            base = score_state(
                base_state(raw, network, args.candidate_pool_size, args.candidate_seed),
                args, counters,
            )
            eligible = noop_is_operational(base["candidates"])
            offline_trace.append({
                "source_instance_id": str(raw["instance_id"]),
                "load_id": str(raw["load_id"]),
                "included": eligible,
                "reason": "operational_anchor" if eligible else "infeasible_anchor",
                "candidate_evaluations": len(base["candidates"]),
            })
            if eligible:
                offline_bases.append(base)
        if len(offline_bases) != args.offline_loads_per_network:
            raise RuntimeError(
                f"network {network}: insufficient operational offline states "
                f"({len(offline_bases)}/{args.offline_loads_per_network})"
            )
        online_bases = []
        online_trace = []
        while len(online_bases) < args.online_loads_per_network and cursor < len(states):
            raw = states[cursor]
            cursor += 1
            base = base_state(raw, network, args.candidate_pool_size, args.candidate_seed)
            eligible = screen_online_anchor(base, args, counters)
            online_trace.append({
                "source_instance_id": str(raw["instance_id"]),
                "load_id": str(raw["load_id"]),
                "included": eligible,
                "reason": "operational_anchor" if eligible else "infeasible_anchor",
                "candidate_evaluations": 1,
            })
            if eligible:
                online_bases.append(base)
        if len(online_bases) != args.online_loads_per_network:
            raise RuntimeError(
                f"network {network}: insufficient operational online states "
                f"({len(online_bases)}/{args.online_loads_per_network})"
            )
        selected_loads["offline_train"][network] = [
            base["load_id"].split(":", 1)[1] for base in offline_bases
        ]
        selected_loads["online_stream"][network] = [
            base["load_id"].split(":", 1)[1] for base in online_bases
        ]
        selection_trace["offline_train"][network] = offline_trace
        selection_trace["online_stream"][network] = online_trace
        for base in offline_bases:
            offline_rows.extend(directive_rows(
                base, "offline_train", "train", args.target_temperature, True
            ))
        for base in online_bases:
            online_rows.extend(directive_rows(
                base, "online_stream", "train", args.target_temperature, False
            ))

    for network, source in sorted(validation_sources.items()):
        states = _state_rows_by_load(source["rows"], network, args.row_seed + 4242)
        selected_bases = []
        trace = []
        for raw in states:
            base = score_state(
                base_state(raw, network, args.candidate_pool_size, args.candidate_seed),
                args, counters,
            )
            eligible = noop_is_operational(base["candidates"])
            trace.append({
                "source_instance_id": str(raw["instance_id"]),
                "load_id": str(raw["load_id"]),
                "included": eligible,
                "reason": "operational_anchor" if eligible else "infeasible_anchor",
                "candidate_evaluations": len(base["candidates"]),
            })
            if eligible:
                selected_bases.append(base)
            if len(selected_bases) == args.test_loads_per_network:
                break
        if len(selected_bases) < args.test_loads_per_network:
            raise RuntimeError(
                f"network {network}: insufficient operational validation states "
                f"({len(selected_bases)}/{args.test_loads_per_network})"
            )
        selected_loads["test"][network] = [
            base["load_id"].split(":", 1)[1] for base in selected_bases
        ]
        selection_trace["test"][network] = trace
        for base in selected_bases:
            test_rows.extend(directive_rows(
                base, "test", "test", args.target_temperature, True
            ))

    partitions = {"offline_train": offline_rows, "online_stream": online_rows, "test": test_rows}
    fingerprints = {
        name: {row["physical_state_sha256"] for row in rows}
        for name, rows in partitions.items()
    }
    if any(fingerprints[a].intersection(fingerprints[b])
           for offset, a in enumerate(fingerprints)
           for b in list(fingerprints)[offset + 1:]):
        raise RuntimeError("physical state leaked across GridRank partitions")
    load_sets = {
        name: set(row["load_id"] for row in rows)
        for name, rows in partitions.items()
    }
    if load_sets["offline_train"].intersection(load_sets["online_stream"]):
        raise RuntimeError("train load group leaked into online stream")

    _write_jsonl(args.offline_out, offline_rows)
    _write_jsonl(args.online_out, online_rows)
    _write_jsonl(args.test_out, test_rows)
    summary = {
        "msg": "GridRank physics-distillation data build",
        "schema": "gridrank-feedback-v1",
        "candidate_membership": "topology-only complete K=1 enumeration then fixed hash truncation",
        "state_serialization": "canonical parsed physical fields only; source text is never forwarded",
        "state_inclusion_rule": "existing topology must have valid, converged, voltage-feasible Pandapower feedback",
        "source_oracle_fields_visible": False,
        "online_feedback_revealed": False,
        "physics_backend": args.physics_backend,
        "physics_python": args.physics_python,
        "physics_text_schema_sha256": PHYSICS_TEXT_SCHEMA_SHA256,
        "candidate_pool_size": args.candidate_pool_size,
        "candidate_seed": args.candidate_seed,
        "row_seed": args.row_seed,
        "target_temperature": args.target_temperature,
        "partitions": {
            name: {
                "rows": len(rows),
                "base_states": len({row["physical_state_sha256"] for row in rows}),
                "loads": len({row["load_id"] for row in rows}),
                "network_mix": dict(Counter(row["network_id"] for row in rows)),
                "instruction_mix": dict(Counter(row["instruction_id"] for row in rows)),
                "desired_action_mix": (
                    dict(Counter("noop" if row["desired_action"] == NOOP else "exchange"
                                 for row in rows))
                    if name != "online_stream" else None
                ),
                "candidate_count_min": min(len(row["candidates"]) for row in rows),
                "candidate_count_max": max(len(row["candidates"]) for row in rows),
                "full_candidate_count_mean": sum(row["full_candidate_count"] for row in rows) / len(rows),
            }
            for name, rows in partitions.items()
        },
        "selected_load_ids": selected_loads,
        "selection_trace": selection_trace,
        "power_flow_calls": dict(counters),
        "build_code_sha256": {
            name: file_sha256(Path(__file__).resolve().parent / name)
            for name in BUILD_CODE_FILES
        },
        "sources": {
            "train": {network: {"path": value["path"], "sha256": file_sha256(value["path"])}
                      for network, value in train_sources.items()},
            "validation": {network: {"path": value["path"], "sha256": file_sha256(value["path"])}
                           for network, value in validation_sources.items()},
        },
        "artifacts": {
            "offline_train": {"path": args.offline_out, "sha256": file_sha256(args.offline_out)},
            "online_stream": {"path": args.online_out, "sha256": file_sha256(args.online_out)},
            "test": {"path": args.test_out, "sha256": file_sha256(args.test_out)},
        },
    }
    summary["coverage_pass"] = all(
        summary["partitions"][name]["network_mix"].get(network, 0) > 0
        for name in partitions for network in ("33", "69")
    )
    Path(args.summary_out).write_text(
        json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    print(json.dumps(summary, ensure_ascii=False))


if __name__ == "__main__":
    main()
