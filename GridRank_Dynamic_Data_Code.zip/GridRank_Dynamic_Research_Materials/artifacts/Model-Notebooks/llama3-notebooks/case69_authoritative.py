"""Case69 authoritative utilities."""

import argparse
import random

BASE_MVA = 10.0
BASE_KV = 12.66
ZBASE = BASE_KV ** 2 / BASE_MVA          


_RADIAL = [
    (1, 2, 0.0005, 0.0012), (2, 3, 0.0005, 0.0012), (3, 4, 0.0015, 0.0036),
    (4, 5, 0.0251, 0.0294), (5, 6, 0.366, 0.1864), (6, 7, 0.381, 0.1941),
    (7, 8, 0.0922, 0.047), (8, 9, 0.0493, 0.0251), (9, 10, 0.819, 0.2707),
    (10, 11, 0.1872, 0.0619), (11, 12, 0.7114, 0.2351), (12, 13, 1.03, 0.34),
    (13, 14, 1.044, 0.34), (14, 15, 1.058, 0.3496), (15, 16, 0.1966, 0.065),
    (16, 17, 0.3744, 0.1238), (17, 18, 0.0047, 0.0016), (18, 19, 0.3276, 0.1083),
    (19, 20, 0.2106, 0.069), (20, 21, 0.3416, 0.1129), (21, 22, 0.014, 0.0046),
    (22, 23, 0.1591, 0.0526), (23, 24, 0.3463, 0.1145), (24, 25, 0.7488, 0.2475),
    (25, 26, 0.3089, 0.1021), (26, 27, 0.1732, 0.0572), (3, 28, 0.0044, 0.0108),
    (28, 29, 0.064, 0.1565), (29, 30, 0.3978, 0.1315), (30, 31, 0.0702, 0.0232),
    (31, 32, 0.351, 0.116), (32, 33, 0.839, 0.2816), (33, 34, 1.708, 0.5646),
    (34, 35, 1.474, 0.4873), (3, 36, 0.0044, 0.0108), (36, 37, 0.064, 0.1565),
    (37, 38, 0.1053, 0.123), (38, 39, 0.0304, 0.0355), (39, 40, 0.0018, 0.0021),
    (40, 41, 0.7283, 0.8509), (41, 42, 0.31, 0.3623), (42, 43, 0.041, 0.0478),
    (43, 44, 0.0092, 0.0116), (44, 45, 0.1089, 0.1373), (45, 46, 0.0009, 0.0012),
    (4, 47, 0.0034, 0.0084), (47, 48, 0.0851, 0.2083), (48, 49, 0.2898, 0.7091),
    (49, 50, 0.0822, 0.2011), (8, 51, 0.0928, 0.0473), (51, 52, 0.3319, 0.114),
    (9, 53, 0.174, 0.0886), (53, 54, 0.203, 0.1034), (54, 55, 0.2842, 0.1447),
    (55, 56, 0.2813, 0.1433), (56, 57, 1.59, 0.5337), (57, 58, 0.7837, 0.263),
    (58, 59, 0.3042, 0.1006), (59, 60, 0.3861, 0.1172), (60, 61, 0.5075, 0.2585),
    (61, 62, 0.0974, 0.0496), (62, 63, 0.145, 0.0738), (63, 64, 0.7105, 0.3619),
    (64, 65, 1.041, 0.5302), (11, 66, 0.2012, 0.0611), (66, 67, 0.0047, 0.0014),
    (12, 68, 0.7394, 0.2444), (68, 69, 0.0047, 0.0016),
]


_TIES = [
    (11, 43, 0.5, 0.5), (13, 21, 0.5, 0.5), (15, 46, 1.0, 0.5),
    (50, 59, 2.0, 2.0), (27, 65, 1.0, 0.5),
]
ALL_BRANCHES = _RADIAL + _TIES
TIE_PAIRS = [(a, b) for a, b, _, _ in _TIES]
N_BUS = 69


_LOAD_MW = {
    6: (0.0026, 0.0022), 7: (0.0404, 0.03), 8: (0.075, 0.054), 9: (0.03, 0.022),
    10: (0.028, 0.019), 11: (0.145, 0.104), 12: (0.145, 0.104), 13: (0.008, 0.0055),
    14: (0.008, 0.0055), 16: (0.0455, 0.03), 17: (0.06, 0.035), 18: (0.06, 0.035),
    20: (0.001, 0.0006), 21: (0.114, 0.081), 22: (0.0053, 0.0035), 24: (0.028, 0.02),
    26: (0.014, 0.01), 27: (0.014, 0.01), 28: (0.026, 0.0186), 29: (0.026, 0.0186),
    33: (0.014, 0.01), 34: (0.0195, 0.014), 35: (0.006, 0.004), 36: (0.026, 0.0186),
    37: (0.026, 0.0186), 39: (0.024, 0.017), 40: (0.024, 0.017), 41: (0.0012, 0.001),
    43: (0.006, 0.0043), 45: (0.0392, 0.0263), 46: (0.0392, 0.0263), 48: (0.079, 0.0564),
    49: (0.3847, 0.2745), 50: (0.3847, 0.2745), 51: (0.0405, 0.0283), 52: (0.0036, 0.0027),
    53: (0.0043, 0.0035), 54: (0.0264, 0.019), 55: (0.024, 0.0172), 59: (0.1, 0.072),
    61: (1.244, 0.888), 62: (0.032, 0.023), 64: (0.227, 0.162), 65: (0.059, 0.042),
    66: (0.018, 0.013), 67: (0.018, 0.013), 68: (0.028, 0.02), 69: (0.028, 0.02),
}


def _key(a, b):
    return tuple(sorted((int(a), int(b))))


def load_vector_pu(scale=1.0):
    
    s = [0j] * N_BUS
    for b, (p, q) in _LOAD_MW.items():
        s[b - 1] = complex(p * scale, q * scale) / BASE_MVA
    return s


def bfs_powerflow(open_pairs, load_pu, z_unit="ohm"):
    
    open_set = {_key(*e) for e in (open_pairs or [])}
    zmap = {}
    for a, b, r, x in ALL_BRANCHES:
        k = _key(a, b)
        z = complex(r, x)
        zmap[k] = z / ZBASE if z_unit == "ohm" else z
    active = [(_key(a, b)) for a, b, _, _ in ALL_BRANCHES if _key(a, b) not in open_set]
    
    adj = {i: [] for i in range(1, N_BUS + 1)}
    for k in active:
        a, b = k
        adj[a].append((b, zmap[k]))
        adj[b].append((a, zmap[k]))
    parent = {1: None}; pz = {1: 0j}; order = [1]; seen = {1}; stack = [1]
    while stack:
        u = stack.pop(0)
        for v, z in adj[u]:
            if v not in seen:
                seen.add(v); parent[v] = u; pz[v] = z; order.append(v); stack.append(v)
    radial = (len(seen) == N_BUS) and (len(active) == N_BUS - 1)
    if not radial:
        return {"converged": False, "loss_kw": None, "min_vm_pu": None,
                "max_vm_pu": None, "radial": False}
    S = {i: load_pu[i - 1] for i in range(1, N_BUS + 1)}
    V = {i: 1.0 + 0j for i in range(1, N_BUS + 1)}
    Ibr = {i: 0j for i in range(1, N_BUS + 1)}
    converged = False
    for _ in range(500):
        Ibr = {i: 0j for i in range(1, N_BUS + 1)}
        for u in reversed(order):
            Ibr[u] += (S[u] / V[u]).conjugate()
            if parent[u] is not None:
                Ibr[parent[u]] += Ibr[u]
        md = 0.0
        for u in order[1:]:
            nv = V[parent[u]] - Ibr[u] * pz[u]
            md = max(md, abs(nv - V[u])); V[u] = nv
        if md < 1e-12:
            converged = True
            break
    loss_pu = sum((abs(Ibr[u]) ** 2) * pz[u].real for u in order[1:])
    vmags = [abs(V[i]) for i in range(1, N_BUS + 1)]
    return {"converged": converged, "loss_kw": loss_pu * BASE_MVA * 1000.0,
            "min_vm_pu": min(vmags), "max_vm_pu": max(vmags), "radial": True}


def _radial_ok(open_pairs):
    
    open_set = {_key(*e) for e in open_pairs}
    active = [_key(a, b) for a, b, _, _ in ALL_BRANCHES if _key(a, b) not in open_set]
    if len(active) != N_BUS - 1:
        return False
    adj = {i: [] for i in range(1, N_BUS + 1)}
    for a, b in active:
        adj[a].append(b); adj[b].append(a)
    seen, st = {1}, [1]
    while st:
        u = st.pop()
        for v in adj[u]:
            if v not in seen:
                seen.add(v); st.append(v)
    return len(seen) == N_BUS


def _random_radial_start(rng, base_open, n_swaps=6):
    
    cur = list(base_open)
    all_keys = [_key(a, b) for a, b, _, _ in ALL_BRANCHES]
    for _ in range(n_swaps):
        for _try in range(30):
            i = rng.randrange(len(cur))
            cand = rng.choice(all_keys)
            if cand in {_key(*e) for e in cur}:
                continue
            trial = list(cur); trial[i] = cand
            if _radial_ok(trial):
                cur = trial
                break
    return cur


def branch_exchange_search(load_pu, z_unit="ohm", vmin=0.90, vmax=1.10,
                           n_starts=8, seed=0, max_iters=300):
    
    rng = random.Random(seed)
    starts = [list(TIE_PAIRS)] + [_random_radial_start(rng, TIE_PAIRS) for _ in range(max(0, n_starts - 1))]
    all_keys = [_key(a, b) for a, b, _, _ in ALL_BRANCHES]

    def feasible(res):
        return (res["radial"] and res["converged"] and res["min_vm_pu"] is not None
                and res["min_vm_pu"] >= vmin and res["max_vm_pu"] <= vmax)

    best_open, best_loss, best_vm = None, float("inf"), None
    for start in starts:
        cur = start
        cur_res = bfs_powerflow(cur, load_pu, z_unit)
        cur_loss = cur_res["loss_kw"] if feasible(cur_res) else float("inf")
        for _ in range(max_iters):
            improved = False
            cur_set = {_key(*e) for e in cur}
            for oi in range(len(cur)):
                for cand in all_keys:
                    if cand in cur_set:
                        continue
                    trial = list(cur); trial[oi] = cand
                    res = bfs_powerflow(trial, load_pu, z_unit)
                    if feasible(res) and res["loss_kw"] < cur_loss - 1e-6:
                        cur, cur_loss, cur_set = trial, res["loss_kw"], {_key(*e) for e in trial}
                        improved = True
                        break
                if improved:
                    break
            if not improved:
                break
        if cur_loss < best_loss:
            r = bfs_powerflow(cur, load_pu, z_unit)
            best_open, best_loss, best_vm = cur, cur_loss, r["min_vm_pu"]
    return best_open, best_loss, best_vm


Z_UNIT = "ohm"
INIT_LOSS_KW_REF = 224.99      
OPT_LOSS_KW_REF = 99.6         

if __name__ == "__main__":
    ap = argparse.ArgumentParser(description="Authoritative case69 physics + published-benchmark check.")
    ap.add_argument("--search", action="store_true", help="run voltage-constrained multi-start branch-exchange")
    ap.add_argument("--vmin", type=float, default=0.90)
    ap.add_argument("--vmax", type=float, default=1.10)
    ap.add_argument("--n_starts", type=int, default=8)
    args = ap.parse_args()

    load = load_vector_pu(1.0)
    tot = sum(load) * BASE_MVA
    print(f"total load = {tot.real:.4f} MW + j{tot.imag:.4f} MVAr  (Savier-Das: 3.8019 MW + j2.6941 MVAr)")

    r0 = bfs_powerflow(TIE_PAIRS, load, Z_UNIT)
    print(f"\n[benchmark] z_unit={Z_UNIT} (fixed; MATPOWER declares ohm)")
    print(f"  INITIAL (5 ties open): loss={r0['loss_kw']:.4f} kW, min_vm={r0['min_vm_pu']:.4f} "
          f"(published ~225 kW)")
    
    assert abs(r0["loss_kw"] - INIT_LOSS_KW_REF) < 1.0, \
        f"initial loss {r0['loss_kw']:.2f} kW != published ~{INIT_LOSS_KW_REF} kW -- physics/units wrong"
    print("  ASSERT initial loss ~= 225 kW: PASS")

    if args.search:
        opt_open, opt_loss, opt_vm = branch_exchange_search(
            load, Z_UNIT, vmin=args.vmin, vmax=args.vmax, n_starts=args.n_starts)
        red = 100 * (r0["loss_kw"] - opt_loss) / r0["loss_kw"]
        print(f"\n[reference solution] voltage-constrained ({args.vmin}-{args.vmax} pu) "
              f"multi-start branch-exchange:")
        print(f"  loss={opt_loss:.4f} kW, min_vm={opt_vm:.4f}, reduction={red:.1f}% "
              f"(published ~{OPT_LOSS_KW_REF} kW / ~55.7%)")
        print(f"  open={sorted(opt_open)}")
        print("  NOTE: high-quality REFERENCE solution, NOT a proven global optimum "
              "(P2 adds optimality-gap verification).")
