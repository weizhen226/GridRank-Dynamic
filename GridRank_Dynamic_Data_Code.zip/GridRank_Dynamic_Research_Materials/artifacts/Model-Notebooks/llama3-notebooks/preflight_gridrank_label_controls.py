"""Check inputs for GridRank label controls."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import train_gridrank_select as base
from gridrank_label_controls import VARIANTS, audit_control, transform_rows


HERE = Path(__file__).resolve().parent
SCHEMA = "gridrank-label-controls-preflight-v1"
EXPERIMENT_ID = "gridrank-select-matched-label-controls-v1"
CODE_FILES = (
    "gridrank_label_controls.py",
    "preflight_gridrank_label_controls.py",
    "train_gridrank_label_control.py",
    "aggregate_gridrank_label_controls.py",
    "verify_gridrank_label_controls.py",
    "run_gridrank_label_controls.sh",
    "train_gridrank_select.py",
    "gridrank_select_llm.py",
    "gridrank_traditional_baselines.py",
    "../../docs/GRIDRANK_LABEL_CONTROLS_PROTOCOL.md",
)


def file_sha256(path) -> str:
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _json(path):
    return json.load(open(path, encoding="utf-8"))


def parse_mapping(values):
    output = {}
    for value in values:
        key, path = value.split("=", 1)
        if key in output:
            raise ValueError(f"duplicate mapping: {key}")
        output[key] = path
    return output


def create(args):
    mappings = parse_mapping(args.base_preflight)
    if set(mappings) != set(VARIANTS):
        raise ValueError(f"expected base preflights for {VARIANTS}")
    manifests = {name: _json(path) for name, path in mappings.items()}
    first = manifests[VARIANTS[0]]
    schedules = {name: value.get("training_schedule") for name, value in manifests.items()}
    artifacts = {name: value.get("artifact_sha256") for name, value in manifests.items()}
    adapters = {name: value.get("resume_adapter_sha256") for name, value in manifests.items()}
    full = _json(args.full_control_gate)
    rows = base.load_rows(args.train_jsonl, "train", 3)
    controls = {}
    for name in VARIANTS:
        transformed = transform_rows(
            rows, name, label_seed=args.label_seed,
            target_temperature=args.target_temperature,
        )
        controls[name] = audit_control(rows, transformed, name)
    code_sha256 = {
        relative: file_sha256(HERE / relative)
        for relative in CODE_FILES if (HERE / relative).is_file()
    }
    checks = {
        "base_preflights_pass": all(
            value.get("preflight_pass") is True for value in manifests.values()
        ),
        "same_training_schedule": len({json.dumps(value, sort_keys=True) for value in schedules.values()}) == 1,
        "same_locked_artifacts": len({json.dumps(value, sort_keys=True) for value in artifacts.values()}) == 1,
        "same_starting_adapter": len({json.dumps(value, sort_keys=True) for value in adapters.values()}) == 1,
        "full_control_seed42": full.get("schema") == "gridrank-select-confirm-seed-gate-v1"
            and full.get("confirmation_seed") == 42,
        "full_control_same_schedule": full.get("training_schedule") == schedules[VARIANTS[0]],
        "full_control_same_artifacts": full.get("locked_manifest", {}).get("artifact_sha256") == artifacts[VARIANTS[0]],
        "control_inputs_identical": all(
            value["model_visible_inputs_identical"] for value in controls.values()
        ),
        "control_supervision_changed": all(
            value["supervision_changed"] for value in controls.values()
        ),
        "control_both_classes": all(
            value["positive_labels"] > 0 and value["negative_labels"] > 0
            for value in controls.values()
        ),
        "code_complete": len(code_sha256) == len(CODE_FILES),
    }
    payload = {
        "schema": SCHEMA,
        "experiment_id": EXPERIMENT_ID,
        "preflight_pass": all(checks.values()),
        "training_claim": (
            "same Frozen GridIntent-SFT, canonical train/test rows, YES/NO scorer, "
            "four epochs, optimizer schedule, losses, and live gate; only training "
            "supervision source changes"
        ),
        "variants": list(VARIANTS),
        "label_seed": args.label_seed,
        "target_temperature": args.target_temperature,
        "base_preflights": {
            name: {"path": str(Path(path).resolve()), "sha256": file_sha256(path)}
            for name, path in mappings.items()
        },
        "full_control_gate": {
            "path": str(Path(args.full_control_gate).resolve()),
            "sha256": file_sha256(args.full_control_gate),
        },
        "train_jsonl": {
            "path": str(Path(args.train_jsonl).resolve()),
            "sha256": file_sha256(args.train_jsonl),
        },
        "expected_schedule": schedules[VARIANTS[0]],
        "artifact_sha256": artifacts[VARIANTS[0]],
        "resume_adapter_sha256": adapters[VARIANTS[0]],
        "control_audits": controls,
        "code_sha256": code_sha256,
        "checks": checks,
    }
    Path(args.output).write_text(
        json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    print(json.dumps({
        "msg": "GridRank matched label-controls preflight",
        "preflight_pass": payload["preflight_pass"],
        "control_audits": controls,
        "failed_checks": [key for key, value in checks.items() if not value],
    }, ensure_ascii=False))
    if not payload["preflight_pass"]:
        raise SystemExit(2)


def verify(path):
    payload = _json(path)
    checks = {
        "schema": payload.get("schema") == SCHEMA,
        "experiment_id": payload.get("experiment_id") == EXPERIMENT_ID,
        "preflight_pass": payload.get("preflight_pass") is True,
        "variants": payload.get("variants") == list(VARIANTS),
        "full_control_current": file_sha256(payload["full_control_gate"]["path"])
            == payload["full_control_gate"]["sha256"],
        "train_current": file_sha256(payload["train_jsonl"]["path"])
            == payload["train_jsonl"]["sha256"],
        "base_preflights_current": all(
            file_sha256(value["path"]) == value["sha256"]
            for value in payload.get("base_preflights", {}).values()
        ),
        "code_current": all(
            (HERE / relative).is_file()
            and file_sha256(HERE / relative) == expected
            for relative, expected in payload.get("code_sha256", {}).items()
        ) and len(payload.get("code_sha256", {})) == len(CODE_FILES),
    }
    result = {
        "msg": "GridRank matched label-controls preflight verification",
        "checks": checks,
        "verification_pass": all(checks.values()),
    }
    print(json.dumps(result, ensure_ascii=False))
    if not result["verification_pass"]:
        raise SystemExit(2)
    return payload


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", choices=("create", "verify"), required=True)
    parser.add_argument("--base_preflight", action="append", default=[])
    parser.add_argument("--full_control_gate")
    parser.add_argument("--train_jsonl")
    parser.add_argument("--label_seed", type=int, default=20260811)
    parser.add_argument("--target_temperature", type=float, default=0.2)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    if args.mode == "create":
        if not args.full_control_gate or not args.train_jsonl:
            raise SystemExit("create mode requires full control and train JSONL")
        create(args)
    else:
        verify(args.output)


if __name__ == "__main__":
    main()
