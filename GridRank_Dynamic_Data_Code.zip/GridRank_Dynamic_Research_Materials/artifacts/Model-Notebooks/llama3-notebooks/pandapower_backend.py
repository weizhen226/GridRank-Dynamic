"""Pandapower backend utilities."""

import math
import threading
from typing import Any, Dict, Iterable, Sequence

from physics_env import Edge, FlowResult, edge_key


class PandapowerBackend:
    

    solver_name = "pandapower_nr"

    def __init__(self, engine: Any):
        for name in ("N_BUS", "ALL_BRANCHES", "BASE_MVA", "BASE_KV"):
            if not hasattr(engine, name):
                raise TypeError(f"pandapower engine definition is missing {name}")
        try:
            import pandapower as pp
        except ImportError as exc:
            raise RuntimeError(
                "PandapowerBackend requires the optional 'pandapower' package"
            ) from exc

        self.pp = pp
        self.engine = engine
        self.network_id = int(engine.N_BUS)
        self.n_bus = int(engine.N_BUS)
        self.base_mva = float(engine.BASE_MVA)
        self.base_kv = float(engine.BASE_KV)
        self.zbase_ohm = self.base_kv ** 2 / self.base_mva
        self._branch_rows = tuple(
            (edge_key((a, b)), float(r), float(x))
            for a, b, r, x in engine.ALL_BRANCHES
        )
        self.branches = tuple(sorted({edge for edge, _, _ in self._branch_rows}))
        self.branch_set = set(self.branches)
        if len(self._branch_rows) != len(self.branch_set):
            raise ValueError("pandapower backend branch table contains duplicate edges")
        self._nets: Dict[str, Any] = {}
        
        
        self._lock = threading.RLock()

    @classmethod
    def for_network(cls, network_id: int) -> "PandapowerBackend":
        if int(network_id) == 33:
            import case33_authoritative as engine
        elif int(network_id) == 69:
            import case69_authoritative as engine
        else:
            raise ValueError(f"unsupported pandapower network: {network_id!r}")
        return cls(engine)

    def _build_net(self, z_unit: str):
        if z_unit not in {"ohm", "pu"}:
            raise ValueError("z_unit must be exactly 'ohm' or 'pu'")
        pp = self.pp
        net = pp.create_empty_network(sn_mva=self.base_mva)
        bus_index = {
            bus: pp.create_bus(net, vn_kv=self.base_kv, name=f"bus{bus}")
            for bus in range(1, self.n_bus + 1)
        }
        pp.create_ext_grid(net, bus=bus_index[1], vm_pu=1.0, name="slack")

        line_edges = []
        impedance_scale = 1.0 if z_unit == "ohm" else self.zbase_ohm
        for edge, resistance, reactance in self._branch_rows:
            a, b = edge
            pp.create_line_from_parameters(
                net,
                from_bus=bus_index[a],
                to_bus=bus_index[b],
                length_km=1.0,
                r_ohm_per_km=resistance * impedance_scale,
                x_ohm_per_km=reactance * impedance_scale,
                c_nf_per_km=0.0,
                max_i_ka=10.0,
                name=f"{a}-{b}",
            )
            line_edges.append(edge)

        load_rows = []
        for bus in range(1, self.n_bus + 1):
            load_rows.append(
                pp.create_load(
                    net,
                    bus=bus_index[bus],
                    p_mw=0.0,
                    q_mvar=0.0,
                    name=f"load{bus}",
                )
            )
        net._physics_line_edges = tuple(line_edges)
        net._physics_load_rows = tuple(load_rows)
        return net

    def _net(self, z_unit: str):
        if z_unit not in self._nets:
            self._nets[z_unit] = self._build_net(z_unit)
        return self._nets[z_unit]

    def _radial(self, open_set: set) -> bool:
        active = [edge for edge in self.branches if edge not in open_set]
        if len(active) != self.n_bus - 1:
            return False
        adjacency = {bus: [] for bus in range(1, self.n_bus + 1)}
        for a, b in active:
            adjacency[a].append(b)
            adjacency[b].append(a)
        seen = {1}
        stack = [1]
        while stack:
            bus = stack.pop()
            for neighbor in adjacency[bus]:
                if neighbor not in seen:
                    seen.add(neighbor)
                    stack.append(neighbor)
        return len(seen) == self.n_bus

    def run(
        self,
        open_lines: Iterable[Sequence[int]],
        load_pu: Sequence[complex],
        z_unit: str,
    ) -> FlowResult:
        try:
            if z_unit not in {"ohm", "pu"}:
                raise ValueError("z_unit must be exactly 'ohm' or 'pu'")
            if len(load_pu) != self.n_bus:
                raise ValueError(
                    f"load_pu must contain exactly {self.n_bus} values, got {len(load_pu)}"
                )
            normalized_load = []
            for index, value in enumerate(load_pu):
                parsed = complex(value)
                if not math.isfinite(parsed.real) or not math.isfinite(parsed.imag):
                    raise ValueError(f"load_pu[{index}] is non-finite")
                normalized_load.append(parsed)

            open_set = {edge_key(edge) for edge in open_lines}
            radial = self._radial(open_set)
            if not radial:
                return FlowResult(False, False, None, None, None)

            with self._lock:
                net = self._net(z_unit)
                net.line.loc[:, "in_service"] = [
                    edge not in open_set for edge in net._physics_line_edges
                ]
                for row, value in zip(net._physics_load_rows, normalized_load):
                    net.load.at[row, "p_mw"] = value.real * self.base_mva
                    net.load.at[row, "q_mvar"] = value.imag * self.base_mva

                try:
                    self.pp.runpp(
                        net,
                        algorithm="nr",
                        init="flat",
                        calculate_voltage_angles=False,
                        max_iteration=100,
                        
                        
                        tolerance_mva=1e-10,
                        check_connectivity=False,
                        numba=False,
                        lightsim2grid=False,
                    )
                except Exception as exc:
                    if type(exc).__name__ == "LoadflowNotConverged":
                        return FlowResult(True, False, None, None, None)
                    raise

                if not bool(net.converged):
                    return FlowResult(True, False, None, None, None)
                raw = {
                    "radial": True,
                    "converged": True,
                    "loss_kw": float(net.res_line["pl_mw"].sum()) * 1000.0,
                    "min_vm_pu": float(net.res_bus["vm_pu"].min()),
                    "max_vm_pu": float(net.res_bus["vm_pu"].max()),
                }
                return FlowResult.from_mapping(raw)
        except Exception as exc:
            return FlowResult(
                False,
                False,
                None,
                None,
                None,
                f"{type(exc).__name__}: {exc}",
            )
