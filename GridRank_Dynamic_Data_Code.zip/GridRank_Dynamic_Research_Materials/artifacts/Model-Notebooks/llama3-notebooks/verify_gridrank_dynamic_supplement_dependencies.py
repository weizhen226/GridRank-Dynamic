"""Validate GridRank dynamic supplement dependencies."""

from __future__ import annotations

import ast
import json
from pathlib import Path

import gridrank_dynamic_supplement as supplement


HERE = Path(__file__).resolve().parent


def imports(path):
    tree = ast.parse(path.read_text(encoding="utf-8"))
    return {
        node.names[0].name.split(".")[0]
        for node in ast.walk(tree)
        if isinstance(node, ast.Import)
    } | {
        (node.module or "").split(".")[0]
        for node in ast.walk(tree)
        if isinstance(node, ast.ImportFrom)
    }


def source(path):
    return path.read_text(encoding="utf-8")


def synthetic_row():
    base = {
        "feedback_valid": True,
        "feasible": True,
        "reason": "ok",
        "anchor_loss_kw": 100.0,
        "anchor_min_vm_pu": 0.94,
        "candidate_max_vm_pu": 1.01,
    }
    candidates = [
        {
            **base,
            "action": "Action: Replace (1, 2) with (8, 9)",
            "candidate_feature_text": (
                "loss_proxy_delta_pct=3.0; voltage_drop_proxy_max=0.010"
            ),
            "reduction_pct": 3.0,
            "candidate_loss_kw": 97.0,
            "candidate_min_vm_pu": 0.96,
            "safe_utility": None,
            "normalised_regret": 0.2,
        },
        {
            **base,
            "action": "Action: Replace (3, 4) with (9, 10)",
            "candidate_feature_text": (
                "loss_proxy_delta_pct=2.0; voltage_drop_proxy_max=0.020"
            ),
            "reduction_pct": 2.0,
            "candidate_loss_kw": 98.0,
            "candidate_min_vm_pu": 0.95,
            "safe_utility": 1.0,
            "normalised_regret": 0.0,
        },
        {
            **base,
            "action": "Action: Replace (5, 6) with (10, 11)",
            "candidate_feature_text": (
                "loss_proxy_delta_pct=1.0; voltage_drop_proxy_max=0.030"
            ),
            "reduction_pct": 1.0,
            "candidate_loss_kw": 99.0,
            "candidate_min_vm_pu": 0.945,
            "safe_utility": 0.5,
            "normalised_regret": 0.5,
        },
    ]
    return {
        "instance_id": "synthetic:right",
        "load_id": "simbench:test:1",
        "network_id": "simbench:test",
        "physical_state_sha256": "0" * 64,
        "pair_type": "maintenance_loss",
        "instruction_text": "Reduce loss, but do not operate branch (1, 2).",
        "candidates": candidates,
        "gate_anchor": {
            **base,
            "action": "Action: none",
            "candidate_feature_text": "",
            "reduction_pct": 0.0,
            "candidate_loss_kw": 100.0,
            "candidate_min_vm_pu": 0.94,
            "safe_utility": 0.0,
            "normalised_regret": 1.0,
        },
        "oracle_structured_instruction": {
            "objective": "loss",
            "hard_constraint": True,
            "forbidden_edges": [[1, 2]],
        },
    }


def full_cached_regression():
    rows, records = [], []
    methods = (
        "fixed_loss_lindistflow",
        "frozen_rule_parser_lindistflow",
        supplement.TFIDF,
        "oracle_structured_lindistflow",
        "full_ac_oracle",
        *(
            f"{supplement.LLM_PREFIX}_s{seed}"
            for seed in supplement.SEEDS
        ),
    )
    pair_types = ("objective", "maintenance_loss", "maintenance_voltage")
    for index in range(192):
        row = synthetic_row()
        row["instance_id"] = f"synthetic:{index}"
        row["load_id"] = f"simbench:synthetic:{index}"
        row["network_id"] = f"simbench:synthetic-{index % 3}"
        row["physical_state_sha256"] = f"{index:064x}"
        row["pair_type"] = pair_types[index % len(pair_types)]
        rows.append(row)
        for method in methods:
            value = {
                "method": method,
                "instance_id": row["instance_id"],
                "network": row["network_id"],
                "pair_type": row["pair_type"],
                "physical_state_sha256": row["physical_state_sha256"],
                "safe_action": row["candidates"][1]["action"],
                "normalised_regret": 0.0,
                "physics_optimal": True,
                "safe_feasible": True,
                "constraint_violation": False,
            }
            if method.startswith(supplement.LLM_PREFIX):
                value["selected_card"] = "loss_maintenance"
            records.append(value)
    result = supplement.cached_analysis(
        rows, records, bootstrap_reps=100, bootstrap_seed=20260908
    )
    return (
        result["analysis_pass"]
        and result["simbench_operating_regimes"]["unique_physical_states"]
        == 192
        and result["safety_and_maintenance_mask"]["pooled_three_seed"][
            "all"
        ]["deployed_feasible_rate"] == 1.0
    )


def main():
    cached_files = (
        HERE / "gridrank_dynamic_supplement.py",
        HERE / "eval_gridrank_dynamic_supplement_cached.py",
    )
    forbidden = {"torch", "transformers", "pandapower", "simbench"}
    cached_imports = set().union(*(imports(path) for path in cached_files))
    benchmark_text = source(HERE / "benchmark_gridrank_dynamic_supplement.py")
    runner_text = source(HERE / "run_gridrank_dynamic_supplement.sh")
    row = synthetic_row()
    unmasked = supplement.masked_proxy_order(row, "loss", [])
    masked = supplement.masked_proxy_order(row, "loss", [[1, 2]])
    random_result = supplement.exact_random_top1(row, masked)
    status = supplement.direct_action_status(
        row, unmasked[0], "loss", [[1, 2]]
    )
    checks = {
        "cached_analysis_has_no_heavy_imports": not forbidden.intersection(
            cached_imports
        ),
        "cached_analysis_has_no_power_flow": all(
            "score_state(" not in source(path) for path in cached_files
        ),
        "live_benchmark_has_no_gradient_or_llm_training": all(
            token not in benchmark_text
            for token in (
                ".backward(", "optimizer", "train_gridrank_dynamic_factorized",
                "loss.backward",
            )
        ),
        "runner_cpu_preflight_hides_cuda": (
            'CUDA_VISIBLE_DEVICES=""' in runner_text
        ),
        "runner_reverify_passes_required_upstream_inputs": (
            runner_text.count('--cross_preflight "$CROSS_PREFLIGHT"') >= 2
            and runner_text.count('--cross_gate "$CROSS_GATE"') >= 2
            and runner_text.count('--cross_records "$CROSS_RECORDS"') >= 2
        ),
        "mask_changes_forbidden_top1": (
            unmasked[0] != masked[0]
            and status["maintenance_violation"]
        ),
        "random_expectation_exact": (
            random_result["eligible_actions"] == len(masked)
            and random_result["normalised_regret"] is not None
        ),
        "regime_mapping_exact": [
            supplement.operating_regime({"load_id": f"x:{index}"})
            for index in range(3)
        ] == list(supplement.REGIMES),
        "state_index_recovers_from_canonical_load_id": (
            supplement.state_index({
                "load_id": "simbench:1-MV-rural--2-sw:37"
            }) == 37
            and supplement.state_index({
                "state_index": 12, "load_id": "ignored:99"
            }) == 12
        ),
        "live_benchmark_uses_scenario2_wrapper": (
            "import gridrank_dynamic_cross_topology as grid"
            in benchmark_text
            and "import gridrank_simbench as grid" not in benchmark_text
        ),
        "full_cached_pipeline_regression": full_cached_regression(),
    }
    result = {
        "msg": "GridRank dynamic supplement dependency-light verification",
        "checks": checks,
        "verification_pass": all(checks.values()),
        "synthetic": {
            "unmasked_top1": unmasked[0],
            "masked_top1": masked[0],
            "random_top1_exact": random_result,
        },
    }
    print(json.dumps(result, ensure_ascii=False))
    if not result["verification_pass"]:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
