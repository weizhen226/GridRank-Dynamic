"""Validate GridRank dynamic confirmation."""

from __future__ import annotations

import argparse
import json
from collections import defaultdict
from pathlib import Path
from types import SimpleNamespace

import preflight_gridrank_dynamic_confirmation as preflight
import train_gridrank_dynamic_policy as joint


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--gate", required=True)
    parser.add_argument("--preflight", required=True)
    return parser.parse_args()


def main():
    args = parse_args()
    gate = json.load(open(args.gate, encoding="utf-8"))
    manifest = json.load(open(args.preflight, encoding="utf-8"))
    records_path = Path(gate["records"]["path"])
    values = [
        json.loads(line) for line in open(records_path, encoding="utf-8") if line.strip()
    ]
    records = defaultdict(list)
    for row in values:
        method = row.pop("method")
        records[method].append(row)
    summaries = {name: joint.summarize(rows) for name, rows in records.items()}
    schedule = manifest["schedule"]
    seed, reps = schedule["seed"], schedule["bootstrap_reps"]
    aligned = records["physics_aligned_factorized_llm"]
    hidden = lambda rows: joint.subset(rows, "maintenance_voltage")
    paired = {
        "aligned_vs_fixed": joint.paired(records["fixed_loss_lindistflow"], aligned, reps, seed + 100),
        "aligned_vs_rule": joint.paired(records["frozen_rule_parser_lindistflow"], aligned, reps, seed + 200),
        "aligned_vs_full_tfidf_positive_control": joint.paired(
            records["tfidf_logreg_lindistflow_positive_control"], aligned, reps, seed + 300
        ),
        "correct_vs_removed": joint.paired(records["instruction_removed"], aligned, reps, seed + 400),
        "correct_vs_counterfactual": joint.paired(
            records["instruction_counterfactual"], aligned, reps, seed + 500
        ),
        "fresh_composition_aligned_vs_withheld_tfidf": joint.paired(
            hidden(records["tfidf_logreg_withheld_composition"]), hidden(aligned), reps, seed + 600
        ),
        "fresh_composition_aligned_vs_fixed": joint.paired(
            hidden(records["fixed_loss_lindistflow"]), hidden(aligned), reps, seed + 700
        ),
    }
    expected_pass = all(gate.get("checks", {}).values())
    expected_decision = (
        "authorize_dynamic_adaptation_paper_claim"
        if expected_pass else "retain_development_result_without_confirmatory_claim"
    )
    checks = {
        "schema": gate.get("schema") == "gridrank-dynamic-fresh-confirmation-gate-v1",
        "experiment_id": gate.get("experiment_id") == preflight.EXPERIMENT_ID,
        "preflight_schema": manifest.get("schema") == preflight.SCHEMA,
        "preflight_pass": manifest.get("preflight_pass") is True,
        "preflight_hash": gate.get("preflight_sha256") == preflight.file_sha256(args.preflight),
        "evaluation_only": gate.get("evaluation_only") is True,
        "training_not_performed": gate.get("training_performed") is False,
        "fresh_outcomes_not_fit": gate.get("fresh_outcomes_used_for_fit") is False,
        "records_hash": gate["records"]["sha256"] == preflight.file_sha256(records_path),
        "records_count": gate["records"]["rows"] == len(values),
        "method_set": gate["records"]["methods"] == sorted(records),
        "summaries_recomputed": gate.get("summaries") == summaries,
        "paired_recomputed": gate.get("paired") == paired,
        "adapter_current": (
            preflight.adapter_hash(manifest["factorized_adapter"]["path"])
            == manifest["factorized_adapter"]["sha256"]
        ),
        "gate_consistent": gate.get("confirmation_gate_pass") is expected_pass,
        "failed_checks_consistent": gate.get("failed_checks") == [
            key for key, value in gate.get("checks", {}).items() if not value
        ],
        "decision_consistent": gate.get("decision") == expected_decision,
        "interpretation_boundary_present": bool(gate.get("interpretation_boundary")),
    }
    result = {
        "msg": "GridRank fresh dynamic confirmation result verification",
        "checks": checks,
        "verification_pass": all(checks.values()),
        "confirmation_gate_pass": gate.get("confirmation_gate_pass"),
        "decision": gate.get("decision"),
        "failed_checks": gate.get("failed_checks"),
    }
    print(json.dumps(result, ensure_ascii=False))
    if not result["verification_pass"]:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
