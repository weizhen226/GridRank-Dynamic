"""Aggregate GridRank dynamic physics ablation."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import aggregate_gridrank_dynamic_multiseed as multi


HERE = Path(__file__).resolve().parent
SCHEMA = "gridrank-dynamic-physics-ablation-aggregate-v1"
EXPERIMENT_ID = "gridrank-dynamic-direct-ac-listwise-contribution-v1"
SEEDS = (42, 123, 2025)
ALIGNED = "physics_aligned_factorized_llm"
WITHHELD = "tfidf_logreg_withheld_composition"
PRIMARY_PAIR_TYPE = "maintenance_voltage"
CODE_FILES = (
    "aggregate_gridrank_dynamic_physics_ablation.py",
    "verify_gridrank_dynamic_physics_ablation.py",
    "run_gridrank_dynamic_physics_ablation.sh",
    "../../docs/GRIDRANK_DYNAMIC_PHYSICS_ABLATION_PROTOCOL.md",
)


def file_sha256(path):
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def code_hashes():
    missing = [name for name in CODE_FILES if not (HERE / name).is_file()]
    if missing:
        raise FileNotFoundError(f"missing physics-ablation aggregate code: {missing}")
    return {name: file_sha256(HERE / name) for name in CODE_FILES}


def parse_key_values(values, label):
    output = {}
    for value in values:
        if "=" not in value:
            raise ValueError(f"{label} must use SEED=PATH: {value}")
        raw_seed, path = value.split("=", 1)
        seed = int(raw_seed)
        if seed in output:
            raise ValueError(f"duplicate {label} seed {seed}")
        output[seed] = path
    if tuple(sorted(output)) != SEEDS:
        raise ValueError(f"{label} seeds must be exactly {SEEDS}, got {sorted(output)}")
    return output


def parse_args():
    parser = argparse.ArgumentParser()
    for name in (
        "full_gate", "full_records", "full_factor_preflight",
        "full_confirmation_preflight", "ablation_gate", "ablation_records",
        "ablation_factor_preflight", "ablation_confirmation_preflight",
    ):
        parser.add_argument(f"--{name}", action="append", required=True)
    parser.add_argument("--fresh_summary", required=True)
    parser.add_argument("--bootstrap_reps", type=int, default=10000)
    parser.add_argument("--bootstrap_seed", type=int, default=20260902)
    parser.add_argument("--output", required=True)
    return parser.parse_args()


def _without_physics(value):
    return {key: item for key, item in value.items() if key != "lambda_physics"}


def _method_rows(methods, pair_type=None):
    rows = methods[ALIGNED]
    if pair_type is not None:
        rows = [row for row in rows if row["pair_type"] == pair_type]
    return {row["instance_id"]: row for row in rows}


def cross_pair_effects(no_physics, full, pair_type=None):
    before = _method_rows(no_physics, pair_type)
    after = _method_rows(full, pair_type)
    if set(before) != set(after):
        raise ValueError("full/no-physics aligned instance IDs differ")
    grouped, networks = {}, {}
    values = {}
    for instance_id in sorted(before):
        pair_id = before[instance_id]["pair_id"]
        values.setdefault(pair_id, []).append(
            float(before[instance_id]["normalised_regret"])
            - float(after[instance_id]["normalised_regret"])
        )
        networks[pair_id] = str(before[instance_id]["network"])
    for pair_id, items in values.items():
        grouped[pair_id] = multi.mean(items)
    return grouped, networks


def baseline_signature(methods):
    return {
        row["instance_id"]: {
            "normalised_regret": row["normalised_regret"],
            "safe_action": row["safe_action"],
        }
        for row in methods[WITHHELD]
    }


def _input_item(path):
    return {"path": str(Path(path).resolve()), "sha256": file_sha256(path)}


def build(groups, fresh_summary, reps, bootstrap_seed):
    loaded = {}
    integrity = {}
    inputs = {"seeds": {}, "fresh_summary": _input_item(fresh_summary)}
    for seed in SEEDS:
        seed_values = {}
        seed_inputs = {}
        for name, paths in groups.items():
            path = paths[seed]
            seed_inputs[name] = _input_item(path)
            seed_values[name] = (
                multi.read_records(path) if name.endswith("records")
                else json.load(open(path, encoding="utf-8"))
            )
        inputs["seeds"][str(seed)] = seed_inputs
        loaded[seed] = seed_values

        full_gate = seed_values["full_gate"]
        ablation_gate = seed_values["ablation_gate"]
        full_factor = seed_values["full_factor_preflight"]
        ablation_factor = seed_values["ablation_factor_preflight"]
        full_confirm = seed_values["full_confirmation_preflight"]
        ablation_confirm = seed_values["ablation_confirmation_preflight"]
        full_records = seed_values["full_records"]
        ablation_records = seed_values["ablation_records"]

        integrity.update({
            f"seed_{seed}_full_records_hash": full_gate.get("records", {}).get("sha256")
            == file_sha256(groups["full_records"][seed]),
            f"seed_{seed}_ablation_records_hash": ablation_gate.get("records", {}).get("sha256")
            == file_sha256(groups["ablation_records"][seed]),
            f"seed_{seed}_full_confirmation_bound": full_gate.get("preflight_sha256")
            == file_sha256(groups["full_confirmation_preflight"][seed]),
            f"seed_{seed}_ablation_confirmation_bound": ablation_gate.get("preflight_sha256")
            == file_sha256(groups["ablation_confirmation_preflight"][seed]),
            f"seed_{seed}_full_factor_weight_one": full_factor.get("schedule", {}).get(
                "lambda_physics"
            ) == 1.0,
            f"seed_{seed}_ablation_factor_weight_zero": ablation_factor.get(
                "schedule", {}
            ).get("lambda_physics") == 0.0,
            f"seed_{seed}_matched_schedule_except_physics": _without_physics(
                full_factor.get("schedule", {})
            ) == _without_physics(ablation_factor.get("schedule", {})),
            f"seed_{seed}_matched_selection": full_factor.get("selection")
            == ablation_factor.get("selection"),
            f"seed_{seed}_same_method_set": set(full_records) == set(ablation_records),
            f"seed_{seed}_same_aligned_rows": set(_method_rows(full_records))
            == set(_method_rows(ablation_records)),
            f"seed_{seed}_baseline_replay_identical": baseline_signature(full_records)
            == baseline_signature(ablation_records),
            f"seed_{seed}_ablation_boundary_disclosed": bool(
                ablation_factor.get("interpretation_boundary")
            ),
            f"seed_{seed}_post_confirmation_disclosed": "not a fresh test"
            in str(ablation_confirm.get("freshness_status")),
            f"seed_{seed}_full_confirmation_preflight_pass": full_confirm.get(
                "preflight_pass"
            ) is True,
            f"seed_{seed}_ablation_confirmation_preflight_pass": ablation_confirm.get(
                "preflight_pass"
            ) is True,
        })

    pair_to_state, state_network, manifest = multi.physical_state_units(fresh_summary)
    integrity["fresh_summary_96_pairs"] = len(manifest) == 96
    integrity["fresh_summary_66_states"] = len(set(pair_to_state.values())) == 66

    overall_matrix, primary_matrix = {}, {}
    for seed in SEEDS:
        full = loaded[seed]["full_records"]
        no_physics = loaded[seed]["ablation_records"]
        overall_matrix[seed], _ = cross_pair_effects(no_physics, full)
        primary_matrix[seed], _ = cross_pair_effects(
            no_physics, full, PRIMARY_PAIR_TYPE
        )

    overall = multi.bootstrap_state_matrix(
        overall_matrix, pair_to_state, state_network, reps, bootstrap_seed + 100
    )
    primary = multi.bootstrap_state_matrix(
        primary_matrix, pair_to_state, state_network, reps, bootstrap_seed + 200
    )
    full_summary = {
        str(seed): multi.safety_summary(loaded[seed]["full_records"])
        for seed in SEEDS
    }
    ablation_summary = {
        str(seed): multi.safety_summary(loaded[seed]["ablation_records"])
        for seed in SEEDS
    }
    safety = {
        "full_all_seed_feasible_100pct": all(
            item["safe_feasible_rate"] == 1.0 for item in full_summary.values()
        ),
        "ablation_all_seed_feasible_100pct": all(
            item["safe_feasible_rate"] == 1.0 for item in ablation_summary.values()
        ),
        "full_all_seed_constraint_violation_zero": all(
            item["constraint_violation_rate"] == 0.0 for item in full_summary.values()
        ),
        "ablation_all_seed_constraint_violation_zero": all(
            item["constraint_violation_rate"] == 0.0
            for item in ablation_summary.values()
        ),
    }
    contribution = {
        "at_least_2_of_3_primary_seed_effects_positive": primary[
            "positive_seed_count"
        ] >= 2,
        "primary_physical_state_ci_lower_positive": primary[
            "physical_state_cluster_bootstrap_ci95"
        ][0] > 0,
        "primary_two_way_seed_state_ci_lower_positive": primary[
            "two_way_seed_state_bootstrap_ci95"
        ][0] > 0,
        "primary_both_networks_positive": all(
            primary["by_network"][network]["improvement_mean"] > 0
            for network in ("33", "69")
        ),
    }
    audit_pass = all(integrity.values())
    safety_pass = all(safety.values())
    contribution_pass = audit_pass and safety_pass and all(contribution.values())
    return {
        "msg": "GridRank dynamic direct-AC listwise loss ablation aggregate",
        "schema": SCHEMA,
        "experiment_id": EXPERIMENT_ID,
        "seeds": list(SEEDS),
        "bootstrap_reps": reps,
        "bootstrap_seed": bootstrap_seed,
        "training_performed": False,
        "model_loaded": False,
        "power_flow_calls": 0,
        "comparison_orientation": (
            "no_physics_listwise_regret minus full_loss_regret; positive favors full"
        ),
        "ablation_definition": (
            "lambda_physics=0 removes the direct AC-derived policy-card listwise "
            "term while retaining the physics-certified corpus and every other loss"
        ),
        "post_confirmation_supplement": True,
        "freshness_boundary": (
            "the already opened byte-locked confirmation is reused for a post-confirmation "
            "ablation and is not presented as an additional fresh test"
        ),
        "inputs": inputs,
        "overall_all_pair_types": overall,
        "primary_unseen_composition": primary,
        "per_seed_full_summary": full_summary,
        "per_seed_no_physics_summary": ablation_summary,
        "integrity_checks": integrity,
        "safety_checks": safety,
        "contribution_checks": contribution,
        "audit_pass": audit_pass,
        "safety_pass": safety_pass,
        "physics_loss_contribution_gate_pass": contribution_pass,
        "failed_integrity": [key for key, value in integrity.items() if not value],
        "failed_safety": [key for key, value in safety.items() if not value],
        "failed_contribution": [key for key, value in contribution.items() if not value],
        "decision": (
            "authorize_direct_ac_listwise_incremental_contribution_claim"
            if contribution_pass
            else "retain_physics_listwise_without_significant_incremental_claim"
        ),
        "interpretation_boundary": (
            "A failed contribution gate does not invalidate compositional language "
            "adaptation; it means this experiment does not isolate a significant "
            "incremental benefit from the direct AC-derived listwise term."
        ),
        "code_sha256": code_hashes(),
    }


def main():
    args = parse_args()
    output = Path(args.output)
    if output.exists():
        raise FileExistsError(f"refusing to overwrite physics-ablation aggregate: {output}")
    names = (
        "full_gate", "full_records", "full_factor_preflight",
        "full_confirmation_preflight", "ablation_gate", "ablation_records",
        "ablation_factor_preflight", "ablation_confirmation_preflight",
    )
    groups = {
        name: parse_key_values(getattr(args, name), name) for name in names
    }
    result = build(
        groups, args.fresh_summary, args.bootstrap_reps, args.bootstrap_seed
    )
    output.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(result, ensure_ascii=False))
    if not result["audit_pass"]:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
