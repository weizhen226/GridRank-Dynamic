#!/usr/bin/env bash
set -euo pipefail

CURRENT_STAGE="bootstrap"
on_exit() {
  local rc=$?
  trap - EXIT
  if (( rc != 0 )); then
    printf '{"msg":"GridRank joint-card seed-replication failure","stage":"%s","seed":%s,"exit_code":%d}\n' \
      "$CURRENT_STAGE" "${SEED:-null}" "$rc"
  fi
  exit "$rc"
}
trap on_exit EXIT

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"
export HF_HUB_OFFLINE=1
export TRANSFORMERS_OFFLINE=1
if [[ ! "${OMP_NUM_THREADS:-}" =~ ^[1-9][0-9]*$ ]]; then export OMP_NUM_THREADS=4; fi
export PYTORCH_CUDA_ALLOC_CONF="${PYTORCH_CUDA_ALLOC_CONF:-max_split_size_mb:64}"

PREFLIGHT_ONLY="${PREFLIGHT_ONLY:-1}"
case "$PREFLIGHT_ONLY" in 0|1) ;; *) echo "PREFLIGHT_ONLY must be 0 or 1" >&2; exit 2;; esac
if [[ "$PREFLIGHT_ONLY" == "1" ]]; then export CUDA_VISIBLE_DEVICES=""; fi

resolve_executable() {
  local requested="$1"
  if [[ "$requested" == */* ]]; then
    [[ -x "$requested" ]] && printf '%s\n' "$requested"
  else
    command -v -- "$requested"
  fi
}
TRAIN_PYTHON_BIN="$(resolve_executable "${TRAIN_PYTHON:-python}")" || exit 2

: "${SEED:?set SEED to 123 or 2025}"
case "$SEED" in 123|2025) ;; *) echo "SEED must be exactly 123 or 2025" >&2; exit 2;; esac

TAG="${TAG:-gridrank_dynamic_joint_replication_v1_s${SEED}_20260904}"
[[ "$TAG" =~ ^[A-Za-z0-9][A-Za-z0-9._-]*$ ]] || { echo "invalid TAG" >&2; exit 2; }
PAIR_TAG="${PAIR_TAG:-gridrank_instruction_pairs_v2_20260809}"
BENCHMARK_TAG="${BENCHMARK_TAG:-gridrank_dynamic_benchmark_v1_20260826_hotfix1}"
REFERENCE_JOINT_TAG="${REFERENCE_JOINT_TAG:-gridrank_dynamic_policy_v1_20260827_hotfix2}"
TRAIN_JSONL="${TRAIN_JSONL:-${PAIR_TAG}_train.jsonl}"
VALIDATION_JSONL="${VALIDATION_JSONL:-${PAIR_TAG}_validation.jsonl}"
PAIR_SUMMARY="${PAIR_SUMMARY:-${PAIR_TAG}_summary.json}"
BENCHMARK_MANIFEST="${BENCHMARK_MANIFEST:-${BENCHMARK_TAG}.preflight.json}"
REFERENCE_JOINT_PREFLIGHT="${REFERENCE_JOINT_PREFLIGHT:-${REFERENCE_JOINT_TAG}.preflight.json}"
REFERENCE_JOINT_GATE="${REFERENCE_JOINT_GATE:-output_${REFERENCE_JOINT_TAG}/gridrank_dynamic_policy_gate.json}"
RESUME_ADAPTER="${RESUME_ADAPTER:-output_gridrank_select_confirm_v1_20260725_s42/diagnostic_adapter}"
SFT_ADAPTER="${SFT_ADAPTER:-output_gridintent_gate_33_69_v2_20260717/sft_only}"
BASE_MODEL="${BASE_MODEL:-../../Meta-Llama-3.1-8B-Instruct}"
PREFLIGHT="${PREFLIGHT:-${TAG}.preflight.json}"
OUT="${OUT:-output_${TAG}}"
GATE="$OUT/gridrank_dynamic_policy_gate.json"

readonly MAX_LENGTH=512
readonly CARD_BATCH_SIZE=1
readonly EPOCHS=4
readonly LEARNING_RATE=5e-6
readonly GRAD_ACCUM=4
readonly MAX_GRAD_NORM=1.0
readonly TARGET_TEMPERATURE=0.10
readonly LAMBDA_SEMANTIC=1.0
readonly LAMBDA_PHYSICS=1.0
readonly LAMBDA_HARD=0.5
readonly HARD_MARGIN=0.5
readonly BETA_REFERENCE=0.01
readonly GRADIENT_CHECKPOINTING=1
readonly BOOTSTRAP_REPS=10000

for path in \
  "$TRAIN_JSONL" "$VALIDATION_JSONL" "$PAIR_SUMMARY" "$BENCHMARK_MANIFEST" \
  "$REFERENCE_JOINT_PREFLIGHT" "$REFERENCE_JOINT_GATE" \
  "$RESUME_ADAPTER/adapter_config.json" "$RESUME_ADAPTER/adapter_model.safetensors" \
  "$SFT_ADAPTER/adapter_config.json" "$SFT_ADAPTER/adapter_model.safetensors" \
  "$BASE_MODEL/config.json" "$BASE_MODEL/tokenizer_config.json" \
  gridrank_dynamic_llm.py train_gridrank_dynamic_policy.py \
  verify_gridrank_dynamic_policy.py \
  preflight_gridrank_dynamic_joint_replication.py \
  train_gridrank_dynamic_joint_replication.py \
  verify_gridrank_dynamic_joint_replication.py \
  verify_gridrank_dynamic_joint_replication_dependencies.py \
  ../../docs/GRIDRANK_DYNAMIC_FACTORIZATION_MULTISEED_PROTOCOL.md; do
  test -e "$path" || { echo "missing joint-card replication input: $path" >&2; exit 2; }
done

TRAIN_ARGS=(
  --train_jsonl "$TRAIN_JSONL"
  --validation_jsonl "$VALIDATION_JSONL"
  --pair_summary "$PAIR_SUMMARY"
  --benchmark_manifest "$BENCHMARK_MANIFEST"
  --resume_adapter_path "$RESUME_ADAPTER"
  --sft_adapter_path "$SFT_ADAPTER"
  --base_model "$BASE_MODEL"
  --max_length "$MAX_LENGTH"
  --card_batch_size "$CARD_BATCH_SIZE"
  --epochs "$EPOCHS"
  --learning_rate "$LEARNING_RATE"
  --grad_accum "$GRAD_ACCUM"
  --max_grad_norm "$MAX_GRAD_NORM"
  --target_temperature "$TARGET_TEMPERATURE"
  --lambda_semantic "$LAMBDA_SEMANTIC"
  --lambda_physics "$LAMBDA_PHYSICS"
  --lambda_hard "$LAMBDA_HARD"
  --hard_margin "$HARD_MARGIN"
  --beta_reference "$BETA_REFERENCE"
  --seed "$SEED"
  --gradient_checkpointing "$GRADIENT_CHECKPOINTING"
  --bootstrap_reps "$BOOTSTRAP_REPS"
)

CURRENT_STAGE="dependency_regressions"
echo "=== 1/4 VERIFY JOINT-CARD SEED-ONLY REPLICATION CONTRACT ==="
"$TRAIN_PYTHON_BIN" -B verify_gridrank_dynamic_joint_replication_dependencies.py

CURRENT_STAGE="locked_cpu_preflight"
echo "=== 2/4 LOCK JOINT-CARD SEED $SEED WITH ALL NON-SEED FIELDS MATCHED ==="
"$TRAIN_PYTHON_BIN" -B preflight_gridrank_dynamic_joint_replication.py \
  "${TRAIN_ARGS[@]}" \
  --reference_joint_preflight "$REFERENCE_JOINT_PREFLIGHT" \
  --reference_joint_gate "$REFERENCE_JOINT_GATE" \
  --output "$PREFLIGHT"

if [[ "$PREFLIGHT_ONLY" == "1" ]]; then
  echo "=== GRIDRANK JOINT-CARD SEED-$SEED PREFLIGHT COMPLETE; GPU NOT STARTED ==="
  exit 0
fi

test ! -e "$OUT" || { echo "refusing to overwrite output: $OUT" >&2; exit 2; }

CURRENT_STAGE="cuda_readiness"
echo "=== 3/4 CUDA + BITSANDBYTES NF4 READINESS ==="
"$TRAIN_PYTHON_BIN" -B - <<'PY'
import json
result = {"msg": "GridRank joint-card replication CUDA readiness"}
try:
    import bitsandbytes as bnb
    import torch
    from transformers import BitsAndBytesConfig
    checks = {"cuda_available": bool(torch.cuda.is_available()), "visible_device_count": torch.cuda.device_count() > 0}
    device = torch.device("cuda:0") if all(checks.values()) else None
    if device is not None:
        probe = torch.ones(1, device=device)
        checks["cuda_tensor_ok"] = float(probe.item()) == 1.0
        free, total = torch.cuda.mem_get_info(device)
        result.update({"device": torch.cuda.get_device_name(device), "free_memory_bytes": int(free), "total_memory_bytes": int(total)})
        config = BitsAndBytesConfig(load_in_4bit=True, bnb_4bit_quant_type="nf4", bnb_4bit_compute_dtype=torch.float16, bnb_4bit_use_double_quant=True)
        layer = bnb.nn.Linear4bit(64, 64, bias=False, compute_dtype=torch.float16, compress_statistics=True, quant_type="nf4").to(device)
        value = layer(torch.randn(2, 64, device=device, dtype=torch.float16))
        torch.cuda.synchronize(device)
        checks["bitsandbytes_nf4_cuda_kernel_ok"] = bool(value.is_cuda and torch.isfinite(value).all())
        checks["bitsandbytes_config_ok"] = bool(config.load_in_4bit and config.bnb_4bit_quant_type == "nf4")
    else:
        checks.update({"cuda_tensor_ok": False, "bitsandbytes_nf4_cuda_kernel_ok": False, "bitsandbytes_config_ok": False})
except Exception as exc:
    checks = locals().get("checks", {})
    checks["exception_free"] = False
    result["error"] = f"{type(exc).__name__}: {exc}"
result["checks"] = checks
result["readiness_pass"] = bool(checks) and all(checks.values())
print(json.dumps(result, ensure_ascii=False))
raise SystemExit(0 if result["readiness_pass"] else 2)
PY

CURRENT_STAGE="gpu_joint_replication"
echo "=== 4/4 UNCHANGED JOINT-CARD TRAINER; SEED $SEED ==="
set +e
"$TRAIN_PYTHON_BIN" -u train_gridrank_dynamic_joint_replication.py \
  "${TRAIN_ARGS[@]}" --preflight_manifest "$PREFLIGHT" --output_dir "$OUT"
TRAIN_RC=$?
set -e
if [[ ! -f "$GATE" ]]; then exit "$TRAIN_RC"; fi

CURRENT_STAGE="result_verification"
"$TRAIN_PYTHON_BIN" -B verify_gridrank_dynamic_joint_replication.py \
  --gate "$GATE" --preflight "$PREFLIGHT"
if (( TRAIN_RC != 0 && TRAIN_RC != 2 )); then exit "$TRAIN_RC"; fi
"$TRAIN_PYTHON_BIN" -B - "$GATE" "$SEED" <<'PY'
import json, sys
gate = json.load(open(sys.argv[1], encoding="utf-8"))
print(json.dumps({
    "msg": "GridRank joint-card control replication complete",
    "seed": int(sys.argv[2]),
    "structural_verification_pass": True,
    "control_development_gate_pass": gate.get("engineering_gate_pass"),
    "control_development_decision": gate.get("decision"),
    "interpretation": "development efficacy failure is retained, not converted into a main-method success",
}, ensure_ascii=False))
PY
echo "=== GRIDRANK JOINT-CARD SEED-$SEED REPLICATION COMPLETE ==="
