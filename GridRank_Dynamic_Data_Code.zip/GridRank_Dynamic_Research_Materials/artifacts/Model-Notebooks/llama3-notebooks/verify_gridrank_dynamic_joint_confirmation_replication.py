"""Validate GridRank dynamic joint confirmation replication."""

from __future__ import annotations

import json
import sys

import aggregate_gridrank_dynamic_multiseed as aggregate
import preflight_gridrank_dynamic_joint_confirmation_replication as replication


sys.modules["preflight_gridrank_dynamic_factorization_ablation"] = replication
import eval_gridrank_dynamic_factorization_ablation as evaluation  


def _argument(name):
    index = sys.argv.index(name)
    return sys.argv[index + 1]


def _seeded_comparison(
    methods, before, after, pair_to_state, state_network, reps, seed,
    pair_type=None,
):
    pair_values, _ = aggregate.pair_effects(
        methods, before, after, pair_type
    )
    state_result = aggregate.bootstrap_state_matrix(
        {_MODEL_SEED: pair_values}, pair_to_state, state_network, reps, seed
    )
    before_rows = methods[before]
    after_rows = methods[after]
    if pair_type is not None:
        before_rows = evaluation.joint.subset(before_rows, pair_type)
        after_rows = evaluation.joint.subset(after_rows, pair_type)
    return {
        "orientation": f"{before}_regret_minus_{after}_regret",
        "positive_favors": after,
        "pair_cluster_bootstrap": evaluation.joint.paired(
            before_rows, after_rows, reps, seed + 1
        ),
        "physical_state_statistics": state_result,
    }


def main():
    global _MODEL_SEED
    manifest = json.load(open(_argument("--preflight"), encoding="utf-8"))
    _MODEL_SEED = int(manifest["model_seed"])
    evaluation.comparison = _seeded_comparison
    sys.modules["eval_gridrank_dynamic_factorization_ablation"] = evaluation
    import verify_gridrank_dynamic_factorization_ablation as locked

    locked.main()
    gate = json.load(open(_argument("--gate"), encoding="utf-8"))
    checks = {
        "model_seed": gate.get("model_seed") == _MODEL_SEED,
        "replication_integrity_consistent": gate.get(
            "replication_evaluation_integrity_pass"
        )
        is (
            all(gate.get("integrity_checks", {}).values())
            and all(gate.get("safety_checks", {}).values())
        ),
        "replication_effect_consistent": gate.get(
            "replication_factorization_effect_pass"
        )
        is (
            all(gate.get("mechanism_checks", {}).values())
            and all(gate.get("efficacy_checks", {}).values())
        ),
    }
    result = {
        "msg": "GridRank matched joint-card seed result extension verification",
        "checks": checks,
        "verification_pass": all(checks.values()),
        "model_seed": _MODEL_SEED,
        "replication_evaluation_integrity_pass": gate.get(
            "replication_evaluation_integrity_pass"
        ),
        "replication_factorization_effect_pass": gate.get(
            "replication_factorization_effect_pass"
        ),
    }
    print(json.dumps(result, ensure_ascii=False))
    if not result["verification_pass"]:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
