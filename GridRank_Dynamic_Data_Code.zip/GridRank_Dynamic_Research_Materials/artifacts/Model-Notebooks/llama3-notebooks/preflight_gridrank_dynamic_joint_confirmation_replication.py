"""Check inputs for GridRank dynamic joint confirmation replication."""

from __future__ import annotations

import argparse
import hashlib
import json
from collections import Counter
from pathlib import Path

import preflight_gridrank_dynamic_confirmation_replication as confirm_rep
import preflight_gridrank_dynamic_factorized_replication as factor_rep
import preflight_gridrank_dynamic_joint_replication as joint_rep
import preflight_gridrank_feedback as runtime
from gridrank_dynamic_llm import CARDS, render_card_prompt
from gridrank_runtime_compat import runtime_compatibility


HERE = Path(__file__).resolve().parent
SCHEMA = "gridrank-dynamic-joint-confirmation-seed-replication-preflight-v1"
EXPERIMENT_ID = "gridrank-dynamic-factorized-vs-joint-card-matched-seed-v1"
PRIMARY_PAIR_TYPE = "maintenance_voltage"
SUPPORTED_SEEDS = (123, 2025)
CODE_FILES = (
    "preflight_gridrank_dynamic_joint_confirmation_replication.py",
    "eval_gridrank_dynamic_joint_confirmation_replication.py",
    "verify_gridrank_dynamic_joint_confirmation_replication.py",
    "verify_gridrank_dynamic_joint_confirmation_replication_dependencies.py",
    "run_gridrank_dynamic_joint_confirmation_replication.sh",
    "preflight_gridrank_dynamic_factorization_ablation.py",
    "eval_gridrank_dynamic_factorization_ablation.py",
    "verify_gridrank_dynamic_factorization_ablation.py",
    "aggregate_gridrank_dynamic_multiseed.py",
    "gridrank_dynamic_llm.py",
    "train_gridrank_dynamic_policy.py",
    "../../docs/GRIDRANK_DYNAMIC_FACTORIZATION_MULTISEED_PROTOCOL.md",
)


def file_sha256(path):
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def adapter_hash(path):
    root = Path(path)
    return {
        "adapter_config_json": file_sha256(root / "adapter_config.json"),
        "adapter_model_safetensors": file_sha256(
            root / "adapter_model.safetensors"
        ),
    }


def code_hashes():
    missing = [name for name in CODE_FILES if not (HERE / name).is_file()]
    if missing:
        raise FileNotFoundError(f"missing joint confirmation code: {missing}")
    return {name: file_sha256(HERE / name) for name in CODE_FILES}


def rows(path):
    return [
        json.loads(line) for line in open(path, encoding="utf-8") if line.strip()
    ]


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--fresh_pairs", required=True)
    parser.add_argument("--fresh_summary", required=True)
    parser.add_argument("--fresh_audit", required=True)
    parser.add_argument("--joint_preflight", required=True)
    parser.add_argument("--joint_gate", required=True)
    parser.add_argument("--joint_adapter", required=True)
    parser.add_argument("--factorized_preflight", required=True)
    parser.add_argument("--factorized_gate", required=True)
    parser.add_argument("--factorized_adapter", required=True)
    parser.add_argument("--factorized_confirmation_preflight", required=True)
    parser.add_argument("--factorized_confirmation_gate", required=True)
    parser.add_argument("--factorized_confirmation_records", required=True)
    parser.add_argument("--base_model", required=True)
    parser.add_argument("--model_seed", type=int, required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--max_length", type=int, required=True)
    parser.add_argument("--card_batch_size", type=int, required=True)
    parser.add_argument("--topk", type=int, required=True)
    parser.add_argument("--bootstrap_reps", type=int, required=True)
    parser.add_argument("--seed", type=int, required=True)
    parser.add_argument(
        "--gradient_checkpointing", type=int, choices=(0, 1), required=True
    )
    return parser.parse_args()


def schedule(args):
    return {
        "max_length": args.max_length,
        "card_batch_size": args.card_batch_size,
        "topk": args.topk,
        "bootstrap_reps": args.bootstrap_reps,
        "seed": args.seed,
        "gradient_checkpointing": args.gradient_checkpointing,
    }


def prompt_audit(values, base_model, max_length):
    from transformers import AutoTokenizer

    tokenizer = AutoTokenizer.from_pretrained(base_model, local_files_only=True)
    maximum = truncated = prompts = 0
    for row in values:
        for card in CARDS:
            length = len(
                tokenizer(
                    render_card_prompt(tokenizer, row, card),
                    add_special_tokens=False,
                )["input_ids"]
            )
            maximum = max(maximum, length)
            truncated += int(length > max_length)
            prompts += 1
    return {
        "prompts": prompts,
        "cards_per_row": len(CARDS),
        "max_tokens": maximum,
        "truncated_prompts": truncated,
        "prompt_length_pass": truncated == 0,
    }


def matched_training_contract(joint, factor, model_seed):
    js, fs = joint.get("schedule", {}), factor.get("schedule", {})
    scalar_fields = (
        "max_length",
        "epochs",
        "learning_rate",
        "grad_accum",
        "max_grad_norm",
        "target_temperature",
        "lambda_physics",
        "lambda_hard",
        "hard_margin",
        "beta_reference",
        "gradient_checkpointing",
        "bootstrap_reps",
    )
    field_matches = {name: js.get(name) == fs.get(name) for name in scalar_fields}
    jsel, fsel = joint.get("selection", {}), factor.get("selection", {})
    ja, fa = joint.get("adapters", {}), factor.get("adapters", {})
    joint_artifacts = joint.get("artifacts", {})
    factor_artifacts = factor.get("artifacts", {})
    source_fields = ("train", "validation", "pair_summary", "dynamic_benchmark")
    return {
        "same_model_seed": js.get("seed") == fs.get("seed") == model_seed,
        "same_training_row_ids": jsel.get("train_row_ids")
        == fsel.get("train_row_ids")
        and len(jsel.get("train_row_ids", [])) == 114,
        "same_validation_row_ids": jsel.get("validation_row_ids")
        == fsel.get("validation_row_ids"),
        "same_initial_gridrank_adapter": ja.get("gridrank", {}).get("sha256")
        == fa.get("gridrank", {}).get("sha256"),
        "same_sft_control_adapter": ja.get("sft", {}).get("sha256")
        == fa.get("sft", {}).get("sha256"),
        "same_base_model_inventory": joint.get("base_model_inventory")
        == factor.get("base_model_inventory"),
        "same_source_artifact_hashes": all(
            joint_artifacts.get(name, {}).get("sha256")
            == factor_artifacts.get(name, {}).get("sha256")
            for name in source_fields
        ),
        "same_scalar_training_schedule": all(field_matches.values()),
        "same_total_semantic_loss_weight": js.get("lambda_semantic")
        == fs.get("lambda_objective", 0) + fs.get("lambda_constraint", 0),
        "same_four_score_calls_per_row": True,
        "schedule_field_matches": field_matches,
    }


def create(args):
    output = Path(args.output)
    if output.exists():
        raise FileExistsError(f"refusing to overwrite preflight: {output}")
    if args.model_seed not in SUPPORTED_SEEDS:
        raise ValueError(f"model_seed must be one of {SUPPORTED_SEEDS}")
    fresh = rows(args.fresh_pairs)
    summary = json.load(open(args.fresh_summary, encoding="utf-8"))
    audit = json.load(open(args.fresh_audit, encoding="utf-8"))
    joint = json.load(open(args.joint_preflight, encoding="utf-8"))
    joint_gate = json.load(open(args.joint_gate, encoding="utf-8"))
    factor = json.load(open(args.factorized_preflight, encoding="utf-8"))
    factor_gate = json.load(open(args.factorized_gate, encoding="utf-8"))
    confirmation = json.load(
        open(args.factorized_confirmation_preflight, encoding="utf-8")
    )
    confirmation_gate = json.load(
        open(args.factorized_confirmation_gate, encoding="utf-8")
    )
    factor_records = rows(args.factorized_confirmation_records)
    methods = {row.get("method") for row in factor_records}
    pair_mix = Counter((str(row["network_id"]), row["pair_type"]) for row in fresh)
    prompt = prompt_audit(fresh, args.base_model, args.max_length)
    matched = matched_training_contract(joint, factor, args.model_seed)
    compatibility = runtime_compatibility(
        joint.get("training_runtime"), runtime.training_runtime()
    )
    checks = {
        "fresh_build_coverage_pass": summary.get("coverage_pass") is True,
        "fresh_audit_pass": audit.get("audit_pass") is True,
        "fresh_pairs_bound_to_summary": summary.get("artifacts", {})
        .get("pairs", {})
        .get("sha256")
        == file_sha256(args.fresh_pairs),
        "joint_replication_preflight_pass": joint.get("schema")
        == joint_rep.SCHEMA
        and joint.get("preflight_pass") is True,
        "factorized_replication_preflight_pass": factor.get("schema")
        == factor_rep.SCHEMA
        and factor.get("preflight_pass") is True,
        "joint_model_seed_matches": joint.get("schedule", {}).get("seed")
        == args.model_seed,
        "factorized_model_seed_matches": factor.get("schedule", {}).get("seed")
        == args.model_seed,
        "joint_gate_bound": joint_gate.get("preflight_sha256")
        == file_sha256(args.joint_preflight),
        "factorized_gate_bound": factor_gate.get("preflight_sha256")
        == file_sha256(args.factorized_preflight),
        "joint_adapter_valid": joint_gate.get("diagnostic_adapter", {}).get(
            "valid"
        )
        is True,
        "factorized_adapter_valid": factor_gate.get("diagnostic_adapter", {}).get(
            "valid"
        )
        is True,
        "joint_adapter_current": adapter_hash(args.joint_adapter)
        == joint_gate.get("diagnostic_adapter", {}).get("sha256"),
        "factorized_adapter_current": adapter_hash(args.factorized_adapter)
        == factor_gate.get("diagnostic_adapter", {}).get("sha256"),
        "matched_training_contract": all(
            value
            for key, value in matched.items()
            if key != "schedule_field_matches"
        )
        and all(matched["schedule_field_matches"].values()),
        "factorized_confirmation_schema": confirmation.get("schema")
        == confirm_rep.SCHEMA,
        "factorized_confirmation_model_seed": confirmation.get("model_seed")
        == args.model_seed,
        "factorized_confirmation_gate_bound": confirmation_gate.get(
            "preflight_sha256"
        )
        == file_sha256(args.factorized_confirmation_preflight),
        "factorized_confirmation_records_current": confirmation_gate.get(
            "records", {}
        ).get("sha256")
        == file_sha256(args.factorized_confirmation_records),
        "factorized_confirmation_method_present": (
            "physics_aligned_factorized_llm" in methods
        ),
        "fresh_bytes_match_factorized_confirmation": confirmation.get(
            "artifacts", {}
        ).get("fresh_pairs", {}).get("sha256")
        == file_sha256(args.fresh_pairs),
        "fresh_rows_192": len(fresh) == 192,
        "fresh_pair_clusters_96": len({row["pair_id"] for row in fresh}) == 96,
        "fresh_physical_states_66": len(
            {row["physical_state_sha256"] for row in fresh}
        )
        == 66,
        "primary_rows_96": sum(
            row["pair_type"] == PRIMARY_PAIR_TYPE for row in fresh
        )
        == 96,
        "primary_48_rows_each_network": all(
            pair_mix[(network, PRIMARY_PAIR_TYPE)] == 48
            for network in ("33", "69")
        ),
        "prompt_length": prompt["prompt_length_pass"],
        "topk_one": args.topk == 1,
        "bootstrap_10000_or_more": args.bootstrap_reps >= 10000,
        "fixed_evaluation_seed": args.seed == 20260904,
        "runtime_compatible": compatibility["compatible"],
    }
    artifacts = {
        "fresh_pairs": args.fresh_pairs,
        "fresh_summary": args.fresh_summary,
        "fresh_audit": args.fresh_audit,
        "joint_preflight": args.joint_preflight,
        "joint_gate": args.joint_gate,
        "factorized_preflight": args.factorized_preflight,
        "factorized_gate": args.factorized_gate,
        "factorized_confirmation_preflight": args.factorized_confirmation_preflight,
        "factorized_confirmation_gate": args.factorized_confirmation_gate,
        "factorized_confirmation_records": args.factorized_confirmation_records,
    }
    manifest = {
        "msg": "GridRank matched joint-card confirmation replication preflight",
        "schema": SCHEMA,
        "experiment_id": EXPERIMENT_ID,
        "preflight_pass": all(checks.values()),
        "evaluation_only": True,
        "training_performed": False,
        "model_loaded": False,
        "power_flow_calls": 0,
        "model_seed": args.model_seed,
        "confirmation_reuse_disclosed": True,
        "freshness_boundary": (
            "The seed-42 run retains the fresh-confirmation claim; this matched "
            "seed replication reuses identical locked bytes only for robustness."
        ),
        "matched_training_contract": matched,
        "artifacts": {
            name: {"path": str(Path(path).resolve()), "sha256": file_sha256(path)}
            for name, path in artifacts.items()
        },
        "adapters": {
            "joint_card": {
                "path": str(Path(args.joint_adapter).resolve()),
                "sha256": adapter_hash(args.joint_adapter),
            },
            "factorized": {
                "path": str(Path(args.factorized_adapter).resolve()),
                "sha256": adapter_hash(args.factorized_adapter),
            },
        },
        "base_model": str(Path(args.base_model).resolve()),
        "base_model_inventory": runtime.model_inventory(args.base_model),
        "locked_training_runtime": joint.get("training_runtime"),
        "runtime_compatibility": compatibility,
        "schedule": schedule(args),
        "fresh_partition": {
            "rows": len(fresh),
            "pair_clusters": len({row["pair_id"] for row in fresh}),
            "physical_states": len(
                {row["physical_state_sha256"] for row in fresh}
            ),
            "primary_rows": sum(
                row["pair_type"] == PRIMARY_PAIR_TYPE for row in fresh
            ),
        },
        "prompt_audit": prompt,
        "code_sha256": code_hashes(),
        "checks": checks,
        "failed_checks": [key for key, value in checks.items() if not value],
    }
    output.write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps(manifest, ensure_ascii=False))
    if not manifest["preflight_pass"]:
        raise SystemExit(2)


def verify(args):
    manifest = json.load(open(args.output, encoding="utf-8"))
    current_model_seed = getattr(args, "model_seed", manifest.get("model_seed"))
    checks = {
        "schema": manifest.get("schema") == SCHEMA,
        "experiment_id": manifest.get("experiment_id") == EXPERIMENT_ID,
        "preflight_pass": manifest.get("preflight_pass") is True,
        "model_seed": manifest.get("model_seed") == current_model_seed,
        "artifacts_current": all(
            Path(item["path"]).is_file()
            and file_sha256(item["path"]) == item["sha256"]
            for item in manifest.get("artifacts", {}).values()
        ),
        "adapters_current": all(
            adapter_hash(item["path"]) == item["sha256"]
            for item in manifest.get("adapters", {}).values()
        ),
        "base_model_current": runtime.model_inventory(manifest["base_model"])
        == manifest["base_model_inventory"],
        "runtime_compatible": runtime_compatibility(
            manifest.get("locked_training_runtime"), runtime.training_runtime()
        )["compatible"],
        "schedule_current": manifest.get("schedule") == schedule(args),
        "code_current": manifest.get("code_sha256") == code_hashes(),
    }
    result = {
        "msg": "GridRank matched joint-card confirmation runtime verification",
        "checks": checks,
        "verification_pass": all(checks.values()),
    }
    print(json.dumps(result, ensure_ascii=False))
    if not result["verification_pass"]:
        raise SystemExit(2)


def main():
    args = parse_args()
    if Path(args.output).exists():
        verify(args)
    else:
        create(args)


if __name__ == "__main__":
    main()
