#!/usr/bin/env bash
set -euo pipefail

CURRENT_STAGE="bootstrap"
on_exit() {
  local rc=$?
  trap - EXIT
  if (( rc != 0 )); then
    printf '{"msg":"GridRank confirmation seed-replication failure","stage":"%s","model_seed":%s,"exit_code":%d}\n' \
      "$CURRENT_STAGE" "${MODEL_SEED:-null}" "$rc"
  fi
  exit "$rc"
}
trap on_exit EXIT

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"
export HF_HUB_OFFLINE=1
export TRANSFORMERS_OFFLINE=1
if [[ ! "${OMP_NUM_THREADS:-}" =~ ^[1-9][0-9]*$ ]]; then export OMP_NUM_THREADS=4; fi
export PYTORCH_CUDA_ALLOC_CONF="${PYTORCH_CUDA_ALLOC_CONF:-max_split_size_mb:64}"

PREFLIGHT_ONLY="${PREFLIGHT_ONLY:-1}"
case "$PREFLIGHT_ONLY" in 0|1) ;; *) echo "PREFLIGHT_ONLY must be 0 or 1" >&2; exit 2;; esac
if [[ "$PREFLIGHT_ONLY" == "1" ]]; then export CUDA_VISIBLE_DEVICES=""; fi

resolve_executable() {
  local requested="$1"
  if [[ "$requested" == */* ]]; then [[ -x "$requested" ]] && printf '%s\n' "$requested"; else command -v -- "$requested"; fi
}
TRAIN_PYTHON_BIN="$(resolve_executable "${TRAIN_PYTHON:-python}")" || exit 2

: "${MODEL_SEED:?set MODEL_SEED to 123 or 2025}"
case "$MODEL_SEED" in 123|2025) ;; *) echo "MODEL_SEED must be exactly 123 or 2025" >&2; exit 2;; esac

TAG="${TAG:-gridrank_dynamic_confirmation_replication_v1_s${MODEL_SEED}_20260831}"
[[ "$TAG" =~ ^[A-Za-z0-9][A-Za-z0-9._-]*$ ]] || { echo "invalid TAG" >&2; exit 2; }
PAIR_TAG="${PAIR_TAG:-gridrank_instruction_pairs_v2_20260809}"
FROZEN_CONFIRM_TAG="${FROZEN_CONFIRM_TAG:-gridrank_dynamic_confirmation_v1_20260829_hotfix1}"
FACTOR_TAG="${FACTOR_TAG:-gridrank_dynamic_factorized_replication_v1_s${MODEL_SEED}_20260830}"
FRESH_PAIRS="${FRESH_PAIRS:-${FROZEN_CONFIRM_TAG}_pairs.jsonl}"
FRESH_SUMMARY="${FRESH_SUMMARY:-${FROZEN_CONFIRM_TAG}_summary.json}"
FRESH_AUDIT="${FRESH_AUDIT:-${FROZEN_CONFIRM_TAG}_audit.json}"
ORIGINAL_TRAIN="${ORIGINAL_TRAIN:-${PAIR_TAG}_train.jsonl}"
ORIGINAL_VALIDATION="${ORIGINAL_VALIDATION:-${PAIR_TAG}_validation.jsonl}"
REFERENCE_CONFIRM_PREFLIGHT="${REFERENCE_CONFIRM_PREFLIGHT:-${FROZEN_CONFIRM_TAG}.preflight.json}"
REFERENCE_CONFIRM_GATE="${REFERENCE_CONFIRM_GATE:-output_${FROZEN_CONFIRM_TAG}/gridrank_dynamic_confirmation_gate.json}"
FACTOR_PREFLIGHT="${FACTOR_PREFLIGHT:-${FACTOR_TAG}.preflight.json}"
FACTOR_GATE="${FACTOR_GATE:-output_${FACTOR_TAG}/gridrank_dynamic_factorized_gate.json}"
FACTOR_ADAPTER="${FACTOR_ADAPTER:-output_${FACTOR_TAG}/diagnostic_adapter}"
BASE_MODEL="${BASE_MODEL:-../../Meta-Llama-3.1-8B-Instruct}"
PREFLIGHT="${PREFLIGHT:-${TAG}.preflight.json}"
OUT="${OUT:-output_${TAG}}"
GATE="$OUT/gridrank_dynamic_confirmation_gate.json"

readonly MAX_LENGTH=512
readonly PRIMITIVE_BATCH_SIZE=4
readonly TOPK=1
readonly BOOTSTRAP_REPS=10000
readonly EVALUATION_SEED=20260829
readonly GRADIENT_CHECKPOINTING=0

for path in \
  "$FRESH_PAIRS" "$FRESH_SUMMARY" "$FRESH_AUDIT" \
  "$ORIGINAL_TRAIN" "$ORIGINAL_VALIDATION" \
  "$REFERENCE_CONFIRM_PREFLIGHT" "$REFERENCE_CONFIRM_GATE" \
  "$FACTOR_PREFLIGHT" "$FACTOR_GATE" \
  "$FACTOR_ADAPTER/adapter_config.json" "$FACTOR_ADAPTER/adapter_model.safetensors" \
  "$BASE_MODEL/config.json" "$BASE_MODEL/tokenizer_config.json" \
  eval_gridrank_dynamic_confirmation.py verify_gridrank_dynamic_confirmation.py \
  preflight_gridrank_dynamic_confirmation_replication.py \
  eval_gridrank_dynamic_confirmation_replication.py \
  verify_gridrank_dynamic_confirmation_replication.py \
  ../../docs/GRIDRANK_DYNAMIC_MULTISEED_PROTOCOL.md; do
  test -e "$path" || { echo "missing confirmation replication input: $path" >&2; exit 2; }
done

PREFLIGHT_ARGS=(
  --fresh_pairs "$FRESH_PAIRS"
  --fresh_summary "$FRESH_SUMMARY"
  --fresh_audit "$FRESH_AUDIT"
  --original_train "$ORIGINAL_TRAIN"
  --original_validation "$ORIGINAL_VALIDATION"
  --factorized_preflight "$FACTOR_PREFLIGHT"
  --factorized_gate "$FACTOR_GATE"
  --factorized_adapter "$FACTOR_ADAPTER"
  --base_model "$BASE_MODEL"
  --max_length "$MAX_LENGTH"
  --primitive_batch_size "$PRIMITIVE_BATCH_SIZE"
  --topk "$TOPK"
  --bootstrap_reps "$BOOTSTRAP_REPS"
  --seed "$EVALUATION_SEED"
  --gradient_checkpointing "$GRADIENT_CHECKPOINTING"
)

CURRENT_STAGE="locked_cpu_preflight"
echo "=== 1/3 LOCK BYTE-IDENTICAL CONFIRMATION FOR MODEL SEED $MODEL_SEED ==="
"$TRAIN_PYTHON_BIN" -B preflight_gridrank_dynamic_confirmation_replication.py \
  "${PREFLIGHT_ARGS[@]}" \
  --reference_confirmation_preflight "$REFERENCE_CONFIRM_PREFLIGHT" \
  --reference_confirmation_gate "$REFERENCE_CONFIRM_GATE" \
  --model_seed "$MODEL_SEED" --output "$PREFLIGHT"

if [[ "$PREFLIGHT_ONLY" == "1" ]]; then
  echo "=== GRIDRANK CONFIRMATION SEED-$MODEL_SEED REPLICATION PREFLIGHT COMPLETE; GPU NOT STARTED ==="
  exit 0
fi
test ! -e "$OUT" || { echo "refusing to overwrite output: $OUT" >&2; exit 2; }

CURRENT_STAGE="cuda_readiness"
echo "=== 2/3 CUDA + NF4 READINESS ==="
"$TRAIN_PYTHON_BIN" -B - <<'PY'
import json
try:
    import bitsandbytes as bnb
    import torch
    checks = {"cuda_available": torch.cuda.is_available(), "visible_device_count": torch.cuda.device_count() > 0}
    device = torch.device("cuda:0") if all(checks.values()) else None
    if device is not None:
        layer = bnb.nn.Linear4bit(64, 64, bias=False, compute_dtype=torch.float16, compress_statistics=True, quant_type="nf4").to(device)
        value = layer(torch.randn(2, 64, device=device, dtype=torch.float16))
        torch.cuda.synchronize(device)
        checks["nf4_kernel"] = bool(value.is_cuda and torch.isfinite(value).all())
    else:
        checks["nf4_kernel"] = False
except Exception as exc:
    checks = {"exception_free": False}
    error = f"{type(exc).__name__}: {exc}"
else:
    error = None
result = {"msg": "GridRank confirmation replication CUDA readiness", "checks": checks, "error": error, "readiness_pass": bool(checks) and all(checks.values())}
print(json.dumps(result, ensure_ascii=False))
raise SystemExit(0 if result["readiness_pass"] else 2)
PY

CURRENT_STAGE="frozen_replication_evaluation"
echo "=== 3/3 EVALUATE FROZEN SEED-$MODEL_SEED ADAPTER; NO FIT OR POWER FLOW ==="
set +e
"$TRAIN_PYTHON_BIN" -u eval_gridrank_dynamic_confirmation_replication.py \
  --fresh_pairs "$FRESH_PAIRS" --original_train "$ORIGINAL_TRAIN" \
  --preflight_manifest "$PREFLIGHT" --factorized_adapter "$FACTOR_ADAPTER" \
  --base_model "$BASE_MODEL" --output_dir "$OUT" \
  --max_length "$MAX_LENGTH" --primitive_batch_size "$PRIMITIVE_BATCH_SIZE" \
  --topk "$TOPK" --bootstrap_reps "$BOOTSTRAP_REPS" --seed "$EVALUATION_SEED" \
  --gradient_checkpointing "$GRADIENT_CHECKPOINTING"
EVAL_RC=$?
set -e
if [[ ! -f "$GATE" ]]; then exit "$EVAL_RC"; fi
CURRENT_STAGE="result_verification"
"$TRAIN_PYTHON_BIN" -B verify_gridrank_dynamic_confirmation_replication.py \
  --gate "$GATE" --preflight "$PREFLIGHT"
if (( EVAL_RC != 0 )); then exit "$EVAL_RC"; fi
echo "=== GRIDRANK CONFIRMATION SEED-$MODEL_SEED REPLICATION COMPLETE ==="
