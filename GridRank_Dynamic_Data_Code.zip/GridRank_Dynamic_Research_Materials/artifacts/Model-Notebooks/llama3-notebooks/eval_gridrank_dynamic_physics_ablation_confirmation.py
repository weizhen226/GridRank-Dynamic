"""Evaluate GridRank dynamic physics ablation confirmation."""

from __future__ import annotations

import sys
from pathlib import Path

import preflight_gridrank_dynamic_physics_ablation as factor_preflight


sys.modules["preflight_gridrank_dynamic_factorized"] = factor_preflight
import train_gridrank_dynamic_factorized as factor_trainer  

sys.modules["train_gridrank_dynamic_factorized"] = factor_trainer

import preflight_gridrank_dynamic_physics_ablation_confirmation as confirm_preflight  

sys.modules["preflight_gridrank_dynamic_confirmation"] = confirm_preflight
import eval_gridrank_dynamic_confirmation as locked_evaluator  


def _argument(name):
    index = sys.argv.index(name)
    return sys.argv[index + 1]


if __name__ == "__main__":
    try:
        locked_evaluator.main()
    except SystemExit as exc:
        output = Path(_argument("--output_dir"))
        complete = (
            (output / "gridrank_dynamic_confirmation_gate.json").is_file()
            and (output / "gridrank_dynamic_confirmation_records.jsonl").is_file()
        )
        if exc.code == 2 and complete:
            print(
                '{"msg":"no-physics confirmation artifact complete",'
                '"original_claim_gate_exit_accepted":true}'
            )
        else:
            raise
