"""Check inputs for GridRank dynamic confirmation."""

from __future__ import annotations

import argparse
import hashlib
import json
from collections import Counter
from pathlib import Path

import preflight_gridrank_feedback as runtime
from gridrank_dynamic_factorized_llm import PRIMITIVES, render_primitive_prompt
from gridrank_runtime_compat import runtime_compatibility


HERE = Path(__file__).resolve().parent
SCHEMA = "gridrank-dynamic-fresh-confirmation-preflight-v1"
EXPERIMENT_ID = "gridrank-factorized-dynamic-fresh-confirmation-v1"
CODE_FILES = (
    "build_gridrank_dynamic_confirmation.py",
    "audit_gridrank_dynamic_confirmation.py",
    "preflight_gridrank_dynamic_confirmation.py",
    "eval_gridrank_dynamic_confirmation.py",
    "verify_gridrank_dynamic_confirmation.py",
    "verify_gridrank_dynamic_confirmation_dependencies.py",
    "run_gridrank_dynamic_confirmation.sh",
    "gridrank_dynamic_factorized_llm.py",
    "train_gridrank_dynamic_factorized.py",
    "train_gridrank_dynamic_policy.py",
    "preflight_gridrank_dynamic_benchmark.py",
    "make_gridrank_dynamic_confirmation_state_view.py",
    "../../docs/GRIDRANK_DYNAMIC_CONFIRMATION_PROTOCOL.md",
)


def file_sha256(path):
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def adapter_hash(path):
    root = Path(path)
    return {
        "adapter_config_json": file_sha256(root / "adapter_config.json"),
        "adapter_model_safetensors": file_sha256(root / "adapter_model.safetensors"),
    }


def code_hashes():
    missing = [name for name in CODE_FILES if not (HERE / name).is_file()]
    if missing:
        raise FileNotFoundError(f"missing fresh-confirmation code: {missing}")
    return {name: file_sha256(HERE / name) for name in CODE_FILES}


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--fresh_pairs", required=True)
    parser.add_argument("--fresh_summary", required=True)
    parser.add_argument("--fresh_audit", required=True)
    parser.add_argument("--original_train", required=True)
    parser.add_argument("--original_validation", required=True)
    parser.add_argument("--factorized_preflight", required=True)
    parser.add_argument("--factorized_gate", required=True)
    parser.add_argument("--factorized_adapter", required=True)
    parser.add_argument("--base_model", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--max_length", type=int, required=True)
    parser.add_argument("--primitive_batch_size", type=int, required=True)
    parser.add_argument("--topk", type=int, required=True)
    parser.add_argument("--bootstrap_reps", type=int, required=True)
    parser.add_argument("--seed", type=int, required=True)
    parser.add_argument("--gradient_checkpointing", type=int, choices=(0, 1), required=True)
    return parser.parse_args()


def schedule(args):
    return {
        "max_length": args.max_length,
        "primitive_batch_size": args.primitive_batch_size,
        "topk": args.topk,
        "bootstrap_reps": args.bootstrap_reps,
        "seed": args.seed,
        "gradient_checkpointing": args.gradient_checkpointing,
    }


def rows(path):
    return [json.loads(line) for line in open(path, encoding="utf-8") if line.strip()]


def prompt_audit(values, base_model, max_length):
    from transformers import AutoTokenizer

    tokenizer = AutoTokenizer.from_pretrained(base_model, local_files_only=True)
    maximum = truncated = prompts = 0
    for row in values:
        for primitive in PRIMITIVES:
            text = render_primitive_prompt(tokenizer, row, primitive)
            length = len(tokenizer(text, add_special_tokens=False)["input_ids"])
            maximum = max(maximum, length)
            truncated += int(length > max_length)
            prompts += 1
    return {
        "prompts": prompts,
        "max_tokens": maximum,
        "truncated_prompts": truncated,
        "prompt_length_pass": truncated == 0,
    }


def create(args):
    output = Path(args.output)
    if output.exists():
        raise FileExistsError(f"refusing to overwrite preflight: {output}")
    fresh_summary = json.load(open(args.fresh_summary, encoding="utf-8"))
    fresh_audit = json.load(open(args.fresh_audit, encoding="utf-8"))
    factor_preflight = json.load(open(args.factorized_preflight, encoding="utf-8"))
    factor_gate = json.load(open(args.factorized_gate, encoding="utf-8"))
    fresh = rows(args.fresh_pairs)
    original_train = rows(args.original_train)
    original_validation = rows(args.original_validation)
    fresh_states = {(str(x["network_id"]), x["physical_state_sha256"]) for x in fresh}
    fresh_loads = {(str(x["network_id"]), str(x["load_id"])) for x in fresh}
    prior = [*original_train, *original_validation]
    prior_states = {(str(x["network_id"]), x["physical_state_sha256"]) for x in prior}
    prior_loads = {(str(x["network_id"]), str(x["load_id"])) for x in prior}
    pair_mix = Counter((str(x["network_id"]), x["pair_type"]) for x in fresh)
    prompt = prompt_audit(fresh, args.base_model, args.max_length)
    expected_adapter = factor_gate.get("diagnostic_adapter", {}).get("sha256")
    compatibility = runtime_compatibility(
        factor_preflight.get("training_runtime"), runtime.training_runtime()
    )
    checks = {
        "fresh_build_coverage_pass": fresh_summary.get("coverage_pass") is True,
        "fresh_audit_pass": fresh_audit.get("audit_pass") is True,
        "fresh_pairs_hash_bound": (
            fresh_summary["artifacts"]["pairs"]["sha256"] == file_sha256(args.fresh_pairs)
        ),
        "factorized_preflight_pass": factor_preflight.get("preflight_pass") is True,
        "factorized_gate_engineering_pass": factor_gate.get("engineering_gate_pass") is True,
        "factorized_gate_authorized_fresh_confirmation": (
            factor_gate.get("decision") == "authorize_fresh_factorized_dynamic_confirmation"
        ),
        "factorized_gate_bound_to_preflight": (
            factor_gate.get("preflight_sha256") == file_sha256(args.factorized_preflight)
        ),
        "factorized_adapter_current": adapter_hash(args.factorized_adapter) == expected_adapter,
        "training_runtime_compatible": compatibility["compatible"],
        "fresh_state_disjoint_original_train_and_validation": not fresh_states.intersection(prior_states),
        "fresh_load_disjoint_original_train_and_validation": not fresh_loads.intersection(prior_loads),
        "primary_pairs_24_each_network": all(
            pair_mix[(network, "maintenance_voltage")] == 48
            for network in ("33", "69")
        ),
        "seen_pairs_12_each_network_type": all(
            pair_mix[(network, pair_type)] == 24
            for network in ("33", "69")
            for pair_type in ("objective", "maintenance_loss")
        ),
        "one_row_per_pair_endpoint": len({x["instance_id"] for x in fresh}) == len(fresh),
        "prompt_length": prompt["prompt_length_pass"],
        "topk_one": args.topk == 1,
        "bootstrap_10000_or_more": args.bootstrap_reps >= 10000,
        "fresh_evaluation_seed": args.seed == 20260829,
    }
    manifest = {
        "msg": "GridRank factorized fresh dynamic confirmation preflight",
        "schema": SCHEMA,
        "experiment_id": EXPERIMENT_ID,
        "preflight_pass": all(checks.values()),
        "evaluation_only": True,
        "training_performed": False,
        "model_loaded": False,
        "fresh_outcomes_used_for_fit": False,
        "primary_hypothesis": (
            "On fresh maintenance+voltage pairs, frozen factorized GridRank has "
            "lower pair-cluster mean normalized regret than the TFIDF parser "
            "trained without maintenance_voltage labels."
        ),
        "artifacts": {
            name: {"path": str(Path(path).resolve()), "sha256": file_sha256(path)}
            for name, path in {
                "fresh_pairs": args.fresh_pairs,
                "fresh_summary": args.fresh_summary,
                "fresh_audit": args.fresh_audit,
                "original_train": args.original_train,
                "original_validation": args.original_validation,
                "factorized_preflight": args.factorized_preflight,
                "factorized_gate": args.factorized_gate,
            }.items()
        },
        "factorized_adapter": {
            "path": str(Path(args.factorized_adapter).resolve()),
            "sha256": adapter_hash(args.factorized_adapter),
        },
        "base_model": str(Path(args.base_model).resolve()),
        "base_model_inventory": runtime.model_inventory(args.base_model),
        "locked_training_runtime": factor_preflight.get("training_runtime"),
        "current_runtime_compatibility": compatibility,
        "schedule": schedule(args),
        "fresh_partition": {
            "rows": len(fresh),
            "pair_clusters": len({x["pair_id"] for x in fresh}),
            "states": len(fresh_states),
            "loads": len(fresh_loads),
            "row_mix_by_network_type": {
                f"{network}:{pair_type}": pair_mix[(network, pair_type)]
                for network in ("33", "69")
                for pair_type in ("objective", "maintenance_loss", "maintenance_voltage")
            },
        },
        "prompt_audit": prompt,
        "code_sha256": code_hashes(),
        "checks": checks,
        "failed_checks": [key for key, value in checks.items() if not value],
    }
    output.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(manifest, ensure_ascii=False))
    if not manifest["preflight_pass"]:
        raise SystemExit(2)


def verify(args):
    manifest = json.load(open(args.output, encoding="utf-8"))
    factor_preflight = json.load(open(args.factorized_preflight, encoding="utf-8"))
    checks = {
        "schema": manifest.get("schema") == SCHEMA,
        "experiment_id": manifest.get("experiment_id") == EXPERIMENT_ID,
        "preflight_pass": manifest.get("preflight_pass") is True,
        "artifacts_current": all(
            Path(item["path"]).is_file() and file_sha256(item["path"]) == item["sha256"]
            for item in manifest.get("artifacts", {}).values()
        ),
        "adapter_current": (
            adapter_hash(manifest["factorized_adapter"]["path"])
            == manifest["factorized_adapter"]["sha256"]
        ),
        "base_model_current": (
            runtime.model_inventory(manifest["base_model"])
            == manifest["base_model_inventory"]
        ),
        "runtime_compatible": runtime_compatibility(
            factor_preflight.get("training_runtime"), runtime.training_runtime()
        )["compatible"],
        "schedule_current": manifest.get("schedule") == schedule(args),
        "code_current": manifest.get("code_sha256") == code_hashes(),
    }
    result = {
        "msg": "GridRank fresh dynamic confirmation runtime verification",
        "checks": checks,
        "verification_pass": all(checks.values()),
    }
    print(json.dumps(result, ensure_ascii=False))
    if not result["verification_pass"]:
        raise SystemExit(2)


def main():
    args = parse_args()
    if Path(args.output).exists():
        verify(args)
    else:
        create(args)


if __name__ == "__main__":
    main()
