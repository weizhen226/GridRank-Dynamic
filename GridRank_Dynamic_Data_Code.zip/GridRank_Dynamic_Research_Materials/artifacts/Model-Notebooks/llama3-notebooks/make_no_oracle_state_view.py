"""Make no oracle state view utilities."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
from collections import Counter
from pathlib import Path

from build_gridrank_feedback import canonical_state_text


KEEP = ("instance_id", "load_id", "prompt", "split")
FORBIDDEN = {
    "output", "chosen", "chosen_index", "candidates", "headroom_pct", "bucket",
    "target_loss_kw", "label_open", "best_reduction_pct", "true_noop", "should_act",
}


def file_sha256(path: str | Path) -> str:
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _source_rows(path: Path):
    if path.suffix.lower() == ".csv":
        with open(path, encoding="utf-8", newline="") as handle:
            reader = csv.DictReader(handle)
            fields = set(reader.fieldnames or [])
            missing = set(KEEP) - fields
            if missing:
                raise ValueError(f"source CSV missing fields: {sorted(missing)}")
            for row in reader:
                yield row
        return
    if path.suffix.lower() in {".jsonl", ".json"}:
        with open(path, encoding="utf-8") as handle:
            for line in handle:
                if line.strip():
                    row = json.loads(line)
                    missing = set(KEEP) - set(row)
                    if missing:
                        raise ValueError(f"source JSONL row missing fields: {sorted(missing)}")
                    yield row
        return
    raise ValueError(f"unsupported source format: {path}")


def build_view(input_path, output_jsonl, manifest_json, split):
    source = Path(input_path).resolve()
    output = Path(output_jsonl).resolve()
    manifest = Path(manifest_json).resolve()
    if source == output:
        raise ValueError("input and output paths must differ")
    rows = []
    for row in _source_rows(source):
        if str(row.get("split", "train")) != split:
            continue
        item = {name: str(row.get(name, "")) for name in KEEP}
        item["prompt"] = canonical_state_text(item["prompt"])
        rows.append(item)
    if not rows:
        raise ValueError(f"source contains no rows for split={split!r}")
    ids = [row["instance_id"] for row in rows]
    if any(not value for value in ids) or len(ids) != len(set(ids)):
        raise ValueError("instance_id must be nonempty and unique")
    if any(not row["prompt"] for row in rows):
        raise ValueError("every state-only row requires a prompt")

    output.parent.mkdir(parents=True, exist_ok=True)
    tmp = output.with_name(output.name + ".tmp")
    with open(tmp, "w", encoding="utf-8") as handle:
        for row in rows:
            handle.write(json.dumps(row, ensure_ascii=False) + "\n")
    os.replace(tmp, output)

    
    emitted = [json.loads(line) for line in open(output, encoding="utf-8") if line.strip()]
    schemas = {tuple(sorted(row)) for row in emitted}
    if schemas != {tuple(sorted(KEEP))}:
        raise RuntimeError(f"strict state schema verification failed: {schemas}")
    if any(FORBIDDEN.intersection(row) for row in emitted):
        raise RuntimeError("forbidden oracle field leaked into state-only view")

    result = {
        "msg": "strict no-oracle state view",
        "schema": "gridrank-state-only-v1",
        "source_path": str(source),
        "source_sha256": file_sha256(source),
        "output_path": str(output),
        "output_sha256": file_sha256(output),
        "columns": list(KEEP),
        "forbidden_columns_absent": sorted(FORBIDDEN),
        "prompt_canonicalized": True,
        "source_text_forwarded": False,
        "selected_split": split,
        "rows": len(emitted),
        "split_counts": dict(Counter(row["split"] for row in emitted)),
    }
    manifest.parent.mkdir(parents=True, exist_ok=True)
    tmp_manifest = manifest.with_name(manifest.name + ".tmp")
    tmp_manifest.write_text(json.dumps(result, indent=2, ensure_ascii=False), encoding="utf-8")
    os.replace(tmp_manifest, manifest)
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True)
    parser.add_argument("--output_jsonl", required=True)
    parser.add_argument("--manifest_json", required=True)
    parser.add_argument("--split", required=True)
    args = parser.parse_args()
    print(json.dumps(build_view(
        args.input, args.output_jsonl, args.manifest_json, args.split
    ), ensure_ascii=False))


if __name__ == "__main__":
    main()
