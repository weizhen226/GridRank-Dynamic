"""Validate GridRank dynamic policy dependencies."""

from __future__ import annotations

import ast
import inspect
import json
from pathlib import Path

import gridrank_dynamic_llm as dynamic


HERE = Path(__file__).resolve().parent


def calls(path):
    tree = ast.parse((HERE / path).read_text(encoding="utf-8"))
    return {
        node.func.id
        for node in ast.walk(tree)
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Name)
    }


def main():
    row = {
        "instruction_text": (
            "Improve the weakest-bus voltage while branch (7, 8) is unavailable."
        ),
        "oracle_structured_instruction": {
            "objective": "voltage", "hard_constraint": True,
            "forbidden_edges": [[7, 8]],
        },
    }
    rendered = dynamic.card_question(row, dynamic.CARDS[3])
    scorer_source = (HERE / "gridrank_dynamic_llm.py").read_text(encoding="utf-8")
    prompt_source = inspect.getsource(dynamic.card_question) + inspect.getsource(dynamic.render_card_prompt)
    trainer_source = (HERE / "train_gridrank_dynamic_policy.py").read_text(encoding="utf-8")
    preflight_source = (HERE / "preflight_gridrank_dynamic_policy.py").read_text(encoding="utf-8")
    checks = {
        "four_compositional_cards": dynamic.card_ids() == [
            "loss_unconstrained", "voltage_unconstrained",
            "loss_maintenance", "voltage_maintenance",
        ],
        "native_instruction_prompt": row["instruction_text"] in rendered,
        "oracle_not_rendered": "oracle_structured_instruction" not in prompt_source,
        "cached_physics_not_rendered": all(
            token not in scorer_source
            for token in ("normalised_regret]", "target_prob]", "safe_utility]")
        ),
        "composition_withheld": "maintenance_voltage" in trainer_source,
        "physics_card_loss_present": "physics_listwise" in trainer_source,
        "causal_controls_present": all(
            token in trainer_source
            for token in ("instruction_removed", "instruction_counterfactual")
        ),
        "unpaired_correct_cache_supported": (
            'if condition == "instruction_counterfactual" else {}' in trainer_source
        ),
        "reference_adapter_present": "reference" in trainer_source,
        "canonical_fresh_test_field_supported": (
            "fresh_final_test_required_after_model_selection" in preflight_source
        ),
        "no_live_power_flow_calls": not {
            "runpp", "run_power_flow", "simulate", "evaluate_action"
        }.intersection(calls("train_gridrank_dynamic_policy.py")),
    }
    result = {
        "msg": "GridRank dynamic-policy dependency-light verification",
        "checks": checks,
        "verification_pass": all(checks.values()),
        "training_performed": False,
        "model_loaded": False,
        "power_flow_calls": 0,
    }
    print(json.dumps(result, ensure_ascii=False))
    if not result["verification_pass"]:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
