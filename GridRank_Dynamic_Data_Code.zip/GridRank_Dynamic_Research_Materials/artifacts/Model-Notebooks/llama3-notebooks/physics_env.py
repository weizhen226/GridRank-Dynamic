"""Physics env utilities."""

from dataclasses import asdict, dataclass, replace
import hashlib
from itertools import count
import math
from numbers import Integral
from typing import Any, Dict, Iterable, List, Optional, Protocol, Sequence, Tuple, Union
import uuid

import case33_authoritative as case33
import case69_authoritative as case69
from limited_protocol import DEADBAND_PCT


Edge = Tuple[int, int]
OpenLines = Tuple[Edge, ...]


def _strict_int(value: Any, name: str) -> int:
    if isinstance(value, bool) or not isinstance(value, Integral):
        raise ValueError(f"{name} must be an integer, got {value!r}")
    return int(value)


def _strict_bool(value: Any, name: str) -> bool:
    if not isinstance(value, bool):
        raise ValueError(f"{name} must be bool, got {value!r}")
    return value


def _finite_float(value: Any) -> Optional[float]:
    if isinstance(value, (bool, complex)):
        return None
    try:
        parsed = float(value)
    except (TypeError, ValueError, OverflowError):
        return None
    return parsed if math.isfinite(parsed) else None


def edge_key(edge: Sequence[int]) -> Edge:
    
    if len(edge) != 2:
        raise ValueError(f"an edge must contain exactly two endpoints: {edge!r}")
    a = _strict_int(edge[0], "edge endpoint")
    b = _strict_int(edge[1], "edge endpoint")
    return (a, b) if a <= b else (b, a)


def canonical_open_lines(
    open_lines: Iterable[Sequence[int]], deduplicate: bool = True
) -> OpenLines:
    
    values = [edge_key(edge) for edge in open_lines]
    return tuple(sorted(set(values) if deduplicate else values))


def branch_exchange_distance(
    candidate: Iterable[Sequence[int]], anchor: Iterable[Sequence[int]]
) -> int:
    
    candidate_set = set(canonical_open_lines(candidate))
    anchor_set = set(canonical_open_lines(anchor))
    return len(candidate_set - anchor_set)


@dataclass(frozen=True)
class FlowResult:
    radial: bool
    converged: bool
    loss_kw: Optional[float]
    min_vm_pu: Optional[float]
    max_vm_pu: Optional[float]
    backend_error: Optional[str] = None

    @classmethod
    def from_mapping(
        cls, raw: Dict[str, Any], backend_error: Optional[str] = None
    ) -> "FlowResult":
        
        if not isinstance(raw, dict):
            raise ValueError(f"backend result must be a dict, got {type(raw).__name__}")
        required = {"radial", "converged", "loss_kw", "min_vm_pu", "max_vm_pu"}
        missing = sorted(required - set(raw))
        radial = _strict_bool(raw.get("radial", False), "radial")
        converged = _strict_bool(raw.get("converged", False), "converged")
        loss_kw = _finite_float(raw.get("loss_kw"))
        min_vm_pu = _finite_float(raw.get("min_vm_pu"))
        max_vm_pu = _finite_float(raw.get("max_vm_pu"))

        errors: List[str] = []
        if backend_error:
            errors.append(backend_error)
        if missing:
            errors.append(f"missing keys {missing}")
        if raw.get("backend_error"):
            errors.append(f"reported error: {raw['backend_error']}")
        if radial and converged:
            if loss_kw is None:
                errors.append("converged result has missing/non-finite loss_kw")
            if min_vm_pu is None or max_vm_pu is None:
                errors.append("converged result has missing/non-finite voltage")
            elif min_vm_pu > max_vm_pu:
                errors.append("converged result has min_vm_pu > max_vm_pu")
        normalized_error = (
            "invalid_backend_result: " + "; ".join(errors) if errors else None
        )
        return cls(
            radial=radial,
            converged=converged,
            loss_kw=loss_kw,
            min_vm_pu=min_vm_pu,
            max_vm_pu=max_vm_pu,
            backend_error=normalized_error,
        )


@dataclass(frozen=True)
class Scenario:
    network_id: int
    load_pu: Tuple[complex, ...]
    initial_open: OpenLines
    exchange_budget: int = 1
    decision_horizon: int = 1
    vmin: float = 0.90
    vmax: float = 1.10
    z_unit: str = "ohm"


@dataclass(frozen=True)
class NoOp:
    

    def __str__(self) -> str:
        return "Action: none"


@dataclass(frozen=True)
class Exchange:
    

    close_edge: Edge
    open_edge: Edge

    def __post_init__(self) -> None:
        object.__setattr__(self, "close_edge", edge_key(self.close_edge))
        object.__setattr__(self, "open_edge", edge_key(self.open_edge))

    def __str__(self) -> str:
        a, b = self.close_edge
        c, d = self.open_edge
        return f"Action: Replace ({a}, {b}) with ({c}, {d})"


PhysicsAction = Union[NoOp, Exchange]
NOOP = NoOp()


@dataclass(frozen=True)
class PhysicsState:
    environment_id: str
    network_id: int
    episode_id: int
    revision: int
    anchor_open: OpenLines
    current_open: OpenLines
    anchor_flow: FlowResult
    current_flow: FlowResult
    exchanges_used: int
    decisions_used: int
    done: bool


@dataclass(frozen=True)
class Evaluation:
    environment_id: str
    network_id: int
    episode_id: int
    state_revision: int
    state_fingerprint: str
    attempted_action: Optional[PhysicsAction]
    action_valid: bool
    candidate_open: Optional[OpenLines]
    distance_from_anchor: Optional[int]
    projected_exchanges: Optional[int]
    within_budget: Optional[bool]
    anchor_flow: FlowResult
    current_flow: FlowResult
    candidate_flow: Optional[FlowResult]
    reduction_anchor_pct: Optional[float]
    reduction_step_pct: Optional[float]
    voltage_ok: Optional[bool]
    feedback_valid: bool
    feasible: bool
    reason: str

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class Transition:
    attempted_action: PhysicsAction
    executed_action: PhysicsAction
    evaluation: Evaluation
    next_state: PhysicsState
    applied: bool
    fallback_used: bool
    terminated: bool


@dataclass(frozen=True)
class CandidateEvaluation:
    action: PhysicsAction
    evaluation: Evaluation


@dataclass(frozen=True)
class Enumeration:
    candidates: Tuple[CandidateEvaluation, ...]
    complete: bool
    truncated: bool
    n_evaluated: int


@dataclass(frozen=True)
class DeliveryDecision:
    open_lines: OpenLines
    delivered_reduction_pct: float
    selected_candidate: bool
    reason: str


@dataclass(frozen=True)
class SafeStepResult:
    attempted_action: PhysicsAction
    attempted_evaluation: Evaluation
    delivery: DeliveryDecision
    transition: Transition


class PhysicsBackend(Protocol):
    network_id: int
    n_bus: int
    branches: Tuple[Edge, ...]
    branch_set: set

    def run(
        self,
        open_lines: Iterable[Sequence[int]],
        load_pu: Sequence[complex],
        z_unit: str,
    ) -> FlowResult: ...


class AuthoritativeBFSBackend:
    

    def __init__(self, engine: Any):
        for name in ("N_BUS", "ALL_BRANCHES", "bfs_powerflow"):
            if not hasattr(engine, name):
                raise TypeError(f"physics backend is missing {name}")
        self.engine = engine
        self.network_id = _strict_int(engine.N_BUS, "backend N_BUS")
        self.n_bus = self.network_id
        self.branches = tuple(
            sorted({edge_key((a, b)) for a, b, _, _ in engine.ALL_BRANCHES})
        )
        self.branch_set = set(self.branches)

    def run(
        self,
        open_lines: Iterable[Sequence[int]],
        load_pu: Sequence[complex],
        z_unit: str,
    ) -> FlowResult:
        try:
            raw = self.engine.bfs_powerflow(list(open_lines), list(load_pu), z_unit)
            return FlowResult.from_mapping(raw)
        except Exception as exc:
            return FlowResult(
                False,
                False,
                None,
                None,
                None,
                f"{type(exc).__name__}: {exc}",
            )


class PhysicsEnv:
    

    _ENGINES = {33: case33, 69: case69}
    _EPISODE_IDS = count(1)

    def __init__(self, backend: PhysicsBackend):
        for name in ("network_id", "n_bus", "branches", "branch_set", "run"):
            if not hasattr(backend, name):
                raise TypeError(f"physics backend is missing {name}")
        self.backend = backend
        self._environment_id = uuid.uuid4().hex
        self.scenario: Optional[Scenario] = None
        self._state: Optional[PhysicsState] = None

    @classmethod
    def for_network(
        cls,
        network_id: int,
        backend: str = "authoritative",
        physics_python: Optional[str] = None,
        backend_timeout_s: float = 60.0,
    ) -> "PhysicsEnv":
        network_id = _strict_int(network_id, "network_id")
        if not isinstance(backend, str):
            raise ValueError(f"backend must be a string, got {backend!r}")
        backend_name = backend.strip().lower()
        if backend_name == "pandapower":
            from pandapower_backend import PandapowerBackend

            return cls(PandapowerBackend.for_network(network_id))
        if backend_name in {"pandapower-subprocess", "pandapower_subprocess"}:
            from subprocess_physics_backend import SubprocessPhysicsBackend

            return cls(SubprocessPhysicsBackend.for_network(
                network_id,
                physics_python=physics_python,
                timeout_s=backend_timeout_s,
            ))
        if backend_name not in {"authoritative", "bfs"}:
            raise ValueError(f"unsupported physics backend: {backend!r}")
        try:
            engine = cls._ENGINES[network_id]
        except KeyError:
            raise ValueError(f"unsupported network: {network_id!r}")
        return cls(AuthoritativeBFSBackend(engine))

    def _independent_snapshot(self) -> "PhysicsEnv":
        clone = type(self)(self.backend)
        if self._state is not None:
            clone.scenario = self.scenario
            clone._state = replace(
                self._state,
                environment_id=clone._environment_id,
                episode_id=next(self._EPISODE_IDS),
            )
        return clone

    def __copy__(self) -> "PhysicsEnv":
        return self._independent_snapshot()

    def __deepcopy__(self, memo: Dict[int, Any]) -> "PhysicsEnv":
        clone = self._independent_snapshot()
        memo[id(self)] = clone
        return clone

    def __getstate__(self) -> Dict[str, Any]:
        return dict(self.__dict__)

    def __setstate__(self, values: Dict[str, Any]) -> None:
        self.__dict__.update(values)
        self._environment_id = uuid.uuid4().hex
        if self._state is not None:
            self._state = replace(
                self._state,
                environment_id=self._environment_id,
                episode_id=next(self._EPISODE_IDS),
            )

    @property
    def state(self) -> PhysicsState:
        if self._state is None:
            raise RuntimeError("reset() must be called before using the environment")
        if self._state.environment_id != self._environment_id:
            raise RuntimeError("environment contains a foreign physical state")
        return self._state

    @property
    def branch_set(self) -> set:
        return self.backend.branch_set

    def _state_fingerprint(self, state: Optional[PhysicsState] = None) -> str:
        state = self.state if state is None else state
        scenario = self.scenario
        payload = repr(
            (
                self._environment_id,
                state.network_id,
                state.episode_id,
                state.revision,
                scenario.load_pu,
                scenario.initial_open,
                scenario.exchange_budget,
                scenario.decision_horizon,
                scenario.vmin,
                scenario.vmax,
                scenario.z_unit,
                state.anchor_open,
                state.current_open,
                state.anchor_flow,
                state.current_flow,
                state.exchanges_used,
                state.decisions_used,
                state.done,
            )
        ).encode("utf-8")
        return hashlib.sha256(payload).hexdigest()

    def reset(
        self,
        scenario: Scenario,
        require_feasible_initial: bool = True,
        require_known_initial_edges: bool = True,
    ) -> PhysicsState:
        require_feasible_initial = _strict_bool(
            require_feasible_initial, "require_feasible_initial"
        )
        require_known_initial_edges = _strict_bool(
            require_known_initial_edges, "require_known_initial_edges"
        )
        network_id = _strict_int(scenario.network_id, "network_id")
        exchange_budget = _strict_int(scenario.exchange_budget, "exchange_budget")
        decision_horizon = _strict_int(scenario.decision_horizon, "decision_horizon")
        if network_id != self.backend.network_id:
            raise ValueError(
                f"scenario network {scenario.network_id} does not match backend "
                f"{self.backend.network_id}"
            )
        if exchange_budget < 0:
            raise ValueError("exchange_budget must be non-negative")
        if decision_horizon < 1:
            raise ValueError("decision_horizon must be at least one")
        vmin = _finite_float(scenario.vmin)
        vmax = _finite_float(scenario.vmax)
        if vmin is None or vmax is None:
            raise ValueError("vmin and vmax must be finite numbers")
        if not vmin < vmax:
            raise ValueError("vmin must be smaller than vmax")
        if scenario.z_unit not in {"ohm", "pu"}:
            raise ValueError("z_unit must be exactly 'ohm' or 'pu'")

        raw_initial = [edge_key(edge) for edge in scenario.initial_open]
        if len(raw_initial) != len(set(raw_initial)):
            raise ValueError("initial_open contains duplicate edges")
        initial_open = tuple(sorted(raw_initial))
        unknown = sorted(set(initial_open) - self.branch_set)
        if unknown and require_known_initial_edges:
            raise ValueError(f"initial_open contains unknown branches: {unknown}")

        if len(scenario.load_pu) != self.backend.n_bus:
            raise ValueError(
                f"load_pu must contain exactly {self.backend.n_bus} values, "
                f"got {len(scenario.load_pu)}"
            )
        load: List[complex] = []
        for index, value in enumerate(scenario.load_pu):
            try:
                parsed = complex(value)
            except (TypeError, ValueError, OverflowError):
                raise ValueError(
                    f"load_pu[{index}] is not a complex-compatible number: {value!r}"
                )
            if not math.isfinite(parsed.real) or not math.isfinite(parsed.imag):
                raise ValueError(f"load_pu[{index}] must be finite, got {value!r}")
            load.append(parsed)

        normalized = replace(
            scenario,
            network_id=self.backend.network_id,
            load_pu=tuple(load),
            initial_open=initial_open,
            exchange_budget=exchange_budget,
            decision_horizon=decision_horizon,
            vmin=vmin,
            vmax=vmax,
        )
        initial_flow = self.backend.run(initial_open, normalized.load_pu, normalized.z_unit)
        if require_feasible_initial and not self._base_ok(initial_flow):
            raise ValueError(
                f"initial configuration is not a valid power-flow state: {initial_flow}"
            )

        self.scenario = normalized
        self._state = PhysicsState(
            environment_id=self._environment_id,
            network_id=self.backend.network_id,
            episode_id=next(self._EPISODE_IDS),
            revision=0,
            anchor_open=initial_open,
            current_open=initial_open,
            anchor_flow=initial_flow,
            current_flow=initial_flow,
            exchanges_used=0,
            decisions_used=0,
            done=False,
        )
        return self._state

    @staticmethod
    def _base_ok(flow: FlowResult) -> bool:
        
        return bool(
            flow.backend_error is None
            and flow.radial
            and flow.converged
            and flow.loss_kw
        )

    def _voltage_ok(self, flow: FlowResult) -> Optional[bool]:
        if flow.backend_error is not None or not flow.radial or not flow.converged:
            return None
        if flow.min_vm_pu is None or flow.max_vm_pu is None:
            return False
        return bool(
            self.scenario.vmin <= flow.min_vm_pu
            and flow.max_vm_pu <= self.scenario.vmax
        )

    @staticmethod
    def _reduction(base: FlowResult, candidate: FlowResult) -> Optional[float]:
        if (
            not PhysicsEnv._base_ok(base)
            or candidate.backend_error is not None
            or not candidate.radial
            or not candidate.converged
            or candidate.loss_kw is None
        ):
            return None
        return (
            (float(base.loss_kw) - float(candidate.loss_kw))
            / float(base.loss_kw)
            * 100.0
        )

    def _invalid_evaluation(
        self, action: Optional[PhysicsAction], reason: str
    ) -> Evaluation:
        state = self.state
        feedback_valid = state.anchor_flow.backend_error is None
        return Evaluation(
            environment_id=self._environment_id,
            network_id=state.network_id,
            episode_id=state.episode_id,
            state_revision=state.revision,
            state_fingerprint=self._state_fingerprint(state),
            attempted_action=action,
            action_valid=False,
            candidate_open=None,
            distance_from_anchor=None,
            projected_exchanges=None,
            within_budget=None,
            anchor_flow=state.anchor_flow,
            current_flow=state.current_flow,
            candidate_flow=None,
            reduction_anchor_pct=None,
            reduction_step_pct=None,
            voltage_ok=None,
            feedback_valid=feedback_valid,
            feasible=False,
            reason=reason if feedback_valid else "simulator_error",
        )

    def evaluate_open_set(
        self,
        candidate_open: Iterable[Sequence[int]],
        attempted_action: Optional[PhysicsAction] = None,
        projected_exchanges: Optional[int] = None,
        strict: bool = True,
    ) -> Evaluation:
        
        state = self.state
        strict = _strict_bool(strict, "strict")
        candidate = canonical_open_lines(candidate_open, deduplicate=False)
        if strict:
            if len(candidate) != len(set(candidate)):
                return self._invalid_evaluation(attempted_action, "duplicate_open_lines")
            if any(edge not in self.branch_set for edge in candidate):
                return self._invalid_evaluation(attempted_action, "unknown_branch")
            if len(candidate) != len(state.current_open):
                return self._invalid_evaluation(attempted_action, "wrong_open_count")

        distance = branch_exchange_distance(candidate, state.anchor_open)
        if projected_exchanges is None:
            budget_cost = distance
        else:
            projected_exchanges = _strict_int(
                projected_exchanges, "projected_exchanges"
            )
            if projected_exchanges < 0:
                raise ValueError("projected_exchanges must be non-negative")
            budget_cost = max(distance, projected_exchanges)
        within_budget = budget_cost <= self.scenario.exchange_budget

        flow = self.backend.run(
            candidate, self.scenario.load_pu, self.scenario.z_unit
        )
        voltage_ok = self._voltage_ok(flow)
        anchor_ok = self._base_ok(state.anchor_flow)
        candidate_loss_ok = flow.loss_kw is not None
        reduction_anchor = self._reduction(state.anchor_flow, flow)
        reduction_step = self._reduction(state.current_flow, flow)
        feedback_valid = bool(
            state.anchor_flow.backend_error is None and flow.backend_error is None
        )
        feasible = bool(
            feedback_valid
            and within_budget
            and flow.radial
            and flow.converged
            and voltage_ok
            and anchor_ok
            and candidate_loss_ok
        )
        reason = (
            "ok"
            if feasible
            else "simulator_error"
            if not feedback_valid
            else "over_budget"
            if not within_budget
            else "nonradial"
            if not flow.radial
            else "nonconverged"
            if not flow.converged
            else "invalid_existing"
            if not anchor_ok
            else "voltage_violation"
            if not voltage_ok
            else "invalid_loss"
        )
        return Evaluation(
            environment_id=self._environment_id,
            network_id=state.network_id,
            episode_id=state.episode_id,
            state_revision=state.revision,
            state_fingerprint=self._state_fingerprint(state),
            attempted_action=attempted_action,
            action_valid=True,
            candidate_open=candidate,
            distance_from_anchor=distance,
            projected_exchanges=budget_cost,
            within_budget=within_budget,
            anchor_flow=state.anchor_flow,
            current_flow=state.current_flow,
            candidate_flow=flow,
            reduction_anchor_pct=reduction_anchor,
            reduction_step_pct=reduction_step,
            voltage_ok=voltage_ok,
            feedback_valid=feedback_valid,
            feasible=feasible,
            reason=reason,
        )

    def evaluate(self, action: PhysicsAction) -> Evaluation:
        
        state = self.state
        if state.done:
            return self._invalid_evaluation(action, "episode_done")
        if isinstance(action, NoOp):
            return self.evaluate_open_set(
                state.current_open,
                attempted_action=action,
                projected_exchanges=state.exchanges_used,
            )
        if not isinstance(action, Exchange):
            return self._invalid_evaluation(None, "invalid_action_type")

        current_set = set(state.current_open)
        close_edge = edge_key(action.close_edge)
        open_edge = edge_key(action.open_edge)
        if close_edge not in current_set:
            return self._invalid_evaluation(action, "remove_not_open")
        if open_edge in current_set:
            return self._invalid_evaluation(action, "add_already_open")
        if open_edge not in self.branch_set:
            return self._invalid_evaluation(action, "add_invalid_branch")
        candidate = tuple(sorted((current_set - {close_edge}) | {open_edge}))
        return self.evaluate_open_set(
            candidate,
            attempted_action=action,
            projected_exchanges=state.exchanges_used + 1,
        )

    def step(self, action: PhysicsAction) -> Transition:
        
        evaluation = self.evaluate(action)
        return self._commit(action, evaluation)

    def _commit(
        self,
        action: PhysicsAction,
        evaluation: Evaluation,
        force_safe_noop: bool = False,
    ) -> Transition:
        old = self.state
        if (
            evaluation.environment_id != self._environment_id
            or evaluation.network_id != old.network_id
            or evaluation.episode_id != old.episode_id
            or evaluation.state_revision != old.revision
            or evaluation.state_fingerprint != self._state_fingerprint(old)
        ):
            raise ValueError("foreign_or_stale_evaluation")
        if old.done:
            return Transition(action, NOOP, evaluation, old, False, True, True)

        decisions_used = old.decisions_used + 1
        applied = False
        fallback = False
        executed: PhysicsAction = NOOP
        current_open = old.current_open
        current_flow = old.current_flow
        exchanges_used = old.exchanges_used

        if force_safe_noop:
            fallback = True
        elif isinstance(action, NoOp):
            applied = bool(evaluation.feasible)
        elif evaluation.feasible:
            applied = True
            executed = action
            current_open = evaluation.candidate_open
            current_flow = evaluation.candidate_flow
            exchanges_used += 1
        else:
            fallback = True

        terminated = bool(
            force_safe_noop
            or isinstance(action, NoOp)
            or decisions_used >= self.scenario.decision_horizon
            or exchanges_used >= self.scenario.exchange_budget
        )
        next_state = PhysicsState(
            environment_id=old.environment_id,
            network_id=old.network_id,
            episode_id=old.episode_id,
            revision=old.revision + 1,
            anchor_open=old.anchor_open,
            current_open=current_open,
            anchor_flow=old.anchor_flow,
            current_flow=current_flow,
            exchanges_used=exchanges_used,
            decisions_used=decisions_used,
            done=terminated,
        )
        self._state = next_state
        return Transition(
            action, executed, evaluation, next_state, applied, fallback, terminated
        )

    def enumerate_actions(
        self,
        include_noop: bool = True,
        include_infeasible: bool = True,
        cap: Optional[int] = None,
    ) -> Enumeration:
        
        include_noop = _strict_bool(include_noop, "include_noop")
        include_infeasible = _strict_bool(
            include_infeasible, "include_infeasible"
        )
        if cap is not None:
            cap = _strict_int(cap, "cap")
            if cap < 1:
                raise ValueError("cap must be positive when provided")
        state = self.state
        current_set = set(state.current_open)
        energized = sorted(self.branch_set - current_set)
        actions: List[PhysicsAction] = []
        if include_noop:
            actions.append(NOOP)
        actions.extend(
            Exchange(close_edge, open_edge)
            for close_edge in sorted(current_set)
            for open_edge in energized
        )

        output: List[CandidateEvaluation] = []
        evaluated = 0
        truncated = False
        for action in actions:
            if cap is not None and evaluated >= cap:
                truncated = True
                break
            evaluation = self.evaluate(action)
            evaluated += 1
            if include_infeasible or evaluation.feasible:
                output.append(CandidateEvaluation(action, evaluation))
        return Enumeration(tuple(output), not truncated, truncated, evaluated)

    def safe_delivery(
        self, evaluation: Evaluation, deadband_pct: float = DEADBAND_PCT
    ) -> DeliveryDecision:
        
        if not isinstance(evaluation, Evaluation):
            raise TypeError("evaluation must be an Evaluation")
        state = self.state
        if (
            evaluation.environment_id != self._environment_id
            or evaluation.network_id != state.network_id
            or evaluation.episode_id != state.episode_id
            or evaluation.state_revision != state.revision
            or evaluation.state_fingerprint != self._state_fingerprint(state)
        ):
            raise ValueError("foreign_or_stale_evaluation")
        deadband = _finite_float(deadband_pct)
        if deadband is None or deadband < 0.0:
            raise ValueError("deadband_pct must be a finite non-negative number")
        if (
            evaluation.feedback_valid
            and evaluation.feasible
            and evaluation.candidate_open is not None
            and evaluation.reduction_step_pct is not None
            and evaluation.reduction_step_pct > deadband
        ):
            return DeliveryDecision(
                evaluation.candidate_open,
                float(evaluation.reduction_anchor_pct),
                True,
                "selected_improvement",
            )
        reason = (
            "feedback_invalid" if not evaluation.feedback_valid else "fallback_existing"
        )
        current_reduction = self._reduction(state.anchor_flow, state.current_flow)
        return DeliveryDecision(
            state.current_open,
            float(current_reduction) if current_reduction is not None else 0.0,
            False,
            reason,
        )

    def safe_step(
        self, action: PhysicsAction, deadband_pct: float = DEADBAND_PCT
    ) -> SafeStepResult:
        
        attempted = self.evaluate(action)
        delivery = self.safe_delivery(attempted, deadband_pct)
        transition = self._commit(
            action,
            attempted,
            force_safe_noop=(
                not delivery.selected_candidate and not isinstance(action, NoOp)
            ),
        )
        return SafeStepResult(action, attempted, delivery, transition)


def scenario_for_network(
    network_id: int,
    initial_open: Iterable[Sequence[int]],
    load_pu: Sequence[complex],
    exchange_budget: int = 1,
    decision_horizon: int = 1,
    vmin: float = 0.90,
    vmax: float = 1.10,
    z_unit: str = "ohm",
) -> Scenario:
    
    return Scenario(
        network_id=_strict_int(network_id, "network_id"),
        load_pu=tuple(complex(value) for value in load_pu),
        initial_open=canonical_open_lines(initial_open),
        exchange_budget=_strict_int(exchange_budget, "exchange_budget"),
        decision_horizon=_strict_int(decision_horizon, "decision_horizon"),
        vmin=float(vmin),
        vmax=float(vmax),
        z_unit=z_unit,
    )
