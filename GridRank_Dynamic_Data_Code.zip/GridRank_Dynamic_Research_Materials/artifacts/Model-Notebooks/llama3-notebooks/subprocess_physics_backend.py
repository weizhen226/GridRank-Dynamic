"""Subprocess physics backend utilities."""

from collections import deque
import json
import os
from pathlib import Path
import queue
import subprocess
import sys
import threading
from typing import Iterable, Optional, Sequence

from physics_env import Edge, FlowResult, edge_key


HERE = Path(__file__).resolve().parent


class SubprocessPhysicsBackend:
    

    solver_name = "pandapower_subprocess"

    def __init__(
        self,
        engine,
        physics_python: Optional[str] = None,
        timeout_s: float = 60.0,
        startup_timeout_s: float = 90.0,
        worker_path: Optional[str] = None,
    ):
        for name in ("N_BUS", "ALL_BRANCHES"):
            if not hasattr(engine, name):
                raise TypeError(f"subprocess backend engine definition is missing {name}")
        self.engine = engine
        self.network_id = int(engine.N_BUS)
        self.n_bus = int(engine.N_BUS)
        self.branches = tuple(
            sorted({edge_key((a, b)) for a, b, _, _ in engine.ALL_BRANCHES})
        )
        self.branch_set = set(self.branches)
        self.timeout_s = float(timeout_s)
        if self.timeout_s <= 0:
            raise ValueError("timeout_s must be positive")
        self.physics_python = str(
            physics_python or os.environ.get("PHYSICS_SIM_PYTHON") or sys.executable
        )
        self.worker_path = str(worker_path or (HERE / "physics_sim_worker.py"))
        self._lock = threading.RLock()
        self._responses = queue.Queue()
        self._stderr = deque(maxlen=40)
        self._request_id = 0
        self._closed = False

        creationflags = 0
        if os.name == "nt" and hasattr(subprocess, "CREATE_NO_WINDOW"):
            creationflags = subprocess.CREATE_NO_WINDOW
        command = [
            self.physics_python,
            "-u",
            self.worker_path,
            "--network",
            str(self.network_id),
            "--backend",
            "pandapower",
        ]
        try:
            self._process = subprocess.Popen(
                command,
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                encoding="utf-8",
                bufsize=1,
                cwd=str(HERE),
                creationflags=creationflags,
            )
        except Exception as exc:
            raise RuntimeError(
                f"failed to start physics worker with {self.physics_python!r}: {exc}"
            ) from exc
        threading.Thread(target=self._read_stdout, daemon=True).start()
        threading.Thread(target=self._read_stderr, daemon=True).start()
        try:
            line = self._responses.get(timeout=float(startup_timeout_s))
        except queue.Empty as exc:
            self._terminate()
            raise RuntimeError(
                f"physics worker startup timed out; stderr={list(self._stderr)!r}"
            ) from exc
        try:
            ready = json.loads(line)
        except json.JSONDecodeError as exc:
            self._terminate()
            raise RuntimeError(f"invalid physics worker handshake: {line!r}") from exc
        if not ready.get("ready") or int(ready.get("network_id", -1)) != self.network_id:
            self._terminate()
            raise RuntimeError(
                f"physics worker failed to initialize: {ready}; stderr={list(self._stderr)!r}"
            )

    @classmethod
    def for_network(
        cls,
        network_id: int,
        physics_python: Optional[str] = None,
        timeout_s: float = 60.0,
    ) -> "SubprocessPhysicsBackend":
        if int(network_id) == 33:
            import case33_authoritative as engine
        elif int(network_id) == 69:
            import case69_authoritative as engine
        else:
            raise ValueError(f"unsupported subprocess network: {network_id!r}")
        return cls(engine, physics_python=physics_python, timeout_s=timeout_s)

    def _read_stdout(self):
        try:
            for line in self._process.stdout:
                if line.strip():
                    self._responses.put(line.strip())
        finally:
            self._responses.put(json.dumps({
                "worker_eof": True,
                "returncode": self._process.poll(),
            }))

    def _read_stderr(self):
        for line in self._process.stderr:
            if line.strip():
                self._stderr.append(line.strip())

    def _terminate(self):
        process = getattr(self, "_process", None)
        if process is not None and process.poll() is None:
            process.terminate()
            try:
                process.wait(timeout=3)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait(timeout=3)
        self._closed = True

    def close(self):
        with self._lock:
            if self._closed:
                return
            try:
                self._request_id += 1
                self._process.stdin.write(json.dumps({
                    "id": self._request_id,
                    "command": "close",
                }) + "\n")
                self._process.stdin.flush()
                self._process.wait(timeout=3)
            except Exception:
                self._terminate()
            finally:
                self._closed = True

    @property
    def healthy(self):
        return not self._closed and self._process.poll() is None

    @property
    def pid(self):
        return self._process.pid

    @property
    def request_count(self):
        return self._request_id

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, traceback):
        self.close()

    def __del__(self):
        try:
            self.close()
        except Exception:
            pass

    def run(
        self,
        open_lines: Iterable[Sequence[int]],
        load_pu: Sequence[complex],
        z_unit: str,
    ) -> FlowResult:
        with self._lock:
            try:
                if self._closed or self._process.poll() is not None:
                    raise RuntimeError(
                        f"physics worker is not running; stderr={list(self._stderr)!r}"
                    )
                self._request_id += 1
                request_id = self._request_id
                request = {
                    "id": request_id,
                    "open_lines": [list(edge_key(edge)) for edge in open_lines],
                    "load_pu": [
                        [float(complex(value).real), float(complex(value).imag)]
                        for value in load_pu
                    ],
                    "z_unit": z_unit,
                }
                self._process.stdin.write(json.dumps(request) + "\n")
                self._process.stdin.flush()
                try:
                    line = self._responses.get(timeout=self.timeout_s)
                except queue.Empty as exc:
                    self._terminate()
                    raise TimeoutError(
                        f"physics worker exceeded {self.timeout_s}s"
                    ) from exc
                response = json.loads(line)
                if response.get("worker_eof"):
                    raise RuntimeError(
                        f"physics worker exited unexpectedly: {response}; "
                        f"stderr={list(self._stderr)!r}"
                    )
                if response.get("id") != request_id or "result" not in response:
                    raise RuntimeError(
                        f"physics worker protocol mismatch: request={request_id}, response={response}"
                    )
                return FlowResult.from_mapping(response["result"])
            except Exception as exc:
                return FlowResult(
                    False,
                    False,
                    None,
                    None,
                    None,
                    f"{type(exc).__name__}: {exc}",
                )
