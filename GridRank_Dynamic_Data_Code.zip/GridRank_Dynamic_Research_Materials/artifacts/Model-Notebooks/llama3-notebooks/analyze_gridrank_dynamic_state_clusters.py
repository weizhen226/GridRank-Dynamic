"""Analyze gridrank dynamic state clusters utilities."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import aggregate_gridrank_dynamic_multiseed as aggregate


SCHEMA = "gridrank-dynamic-state-cluster-sensitivity-v1"
ALIGNED = aggregate.ALIGNED
WITHHELD = aggregate.WITHHELD
REMOVED = aggregate.REMOVED
COUNTERFACTUAL = aggregate.COUNTERFACTUAL
PRIMARY = aggregate.PRIMARY_PAIR_TYPE


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--fresh_summary", required=True)
    parser.add_argument("--confirmation_gate", required=True)
    parser.add_argument("--confirmation_records", required=True)
    parser.add_argument("--factorized_tfidf_audit", required=True)
    parser.add_argument("--bootstrap_reps", type=int, default=10000)
    parser.add_argument("--bootstrap_seed", type=int, default=20260901)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    output = Path(args.output)
    if output.exists():
        raise FileExistsError(f"refusing to overwrite state-cluster result: {output}")

    gate = json.load(open(args.confirmation_gate, encoding="utf-8"))
    tfidf_audit = json.load(open(args.factorized_tfidf_audit, encoding="utf-8"))
    methods = aggregate.read_records(args.confirmation_records)
    pair_to_state, state_network, manifest = aggregate.physical_state_units(
        args.fresh_summary
    )

    primary, _ = aggregate.pair_effects(methods, WITHHELD, ALIGNED, PRIMARY)
    removed, _ = aggregate.pair_effects(methods, REMOVED, ALIGNED)
    counterfactual, _ = aggregate.pair_effects(
        methods, COUNTERFACTUAL, ALIGNED
    )
    primary_result = aggregate.bootstrap_state_matrix(
        {42: primary}, pair_to_state, state_network,
        args.bootstrap_reps, args.bootstrap_seed + 100,
    )
    removed_result = aggregate.bootstrap_state_matrix(
        {42: removed}, pair_to_state, state_network,
        args.bootstrap_reps, args.bootstrap_seed + 200,
    )
    counterfactual_result = aggregate.bootstrap_state_matrix(
        {42: counterfactual}, pair_to_state, state_network,
        args.bootstrap_reps, args.bootstrap_seed + 300,
    )

    integrity = {
        "confirmation_gate_pass": gate.get("confirmation_gate_pass") is True,
        "evaluation_only": gate.get("evaluation_only") is True
            and gate.get("training_performed") is False,
        "records_hash_matches_gate": gate.get("records", {}).get("sha256")
            == aggregate.file_sha256(args.confirmation_records),
        "factorized_tfidf_audit_pass": tfidf_audit.get("audit_pass") is True,
        "fresh_manifest_96_pairs": len(pair_to_state) == 96,
        "fresh_manifest_66_states": len(state_network) == 66,
        "primary_48_pairs_are_48_states": (
            primary_result["pair_clusters"]
            == primary_result["physical_state_clusters"]
            == 48
            and primary_result["states_with_multiple_pairs"] == 0
        ),
        "all_pair_ids_mapped": set(removed) == set(pair_to_state)
            and set(counterfactual) == set(pair_to_state),
    }
    sensitivity = {
        "primary_physical_state_ci_lower_positive":
            primary_result["physical_state_cluster_bootstrap_ci95"][0] > 0,
        "correct_vs_removed_state_ci_lower_positive":
            removed_result["physical_state_cluster_bootstrap_ci95"][0] > 0,
        "correct_vs_counterfactual_state_ci_lower_positive":
            counterfactual_result["physical_state_cluster_bootstrap_ci95"][0] > 0,
        "correct_vs_removed_hierarchical_ci_lower_positive":
            removed_result["hierarchical_seed_state_pair_bootstrap_ci95"][0] > 0,
        "correct_vs_counterfactual_hierarchical_ci_lower_positive":
            counterfactual_result[
                "hierarchical_seed_state_pair_bootstrap_ci95"
            ][0] > 0,
    }
    result = {
        "msg": "GridRank seed-42 physical-state cluster sensitivity analysis",
        "schema": SCHEMA,
        "training_performed": False,
        "model_loaded": False,
        "power_flow_calls": 0,
        "bootstrap_reps": args.bootstrap_reps,
        "bootstrap_seed": args.bootstrap_seed,
        "independence_finding": (
            "The primary 48 maintenance-voltage pairs are one-to-one with 48 "
            "physical states, hence the published pair-cluster primary interval "
            "is numerically identical to a physical-state-cluster interval. The "
            "96 all-type pairs reuse 66 states, so causal controls are reanalysed "
            "with state and nested state/pair resampling."
        ),
        "manifest_counts": {
            "pair_clusters": len(pair_to_state),
            "physical_state_clusters": len(state_network),
            "manifest_rows": len(manifest),
        },
        "primary_factorized_tfidf_vs_factorized_llm": primary_result,
        "causal_controls": {
            "correct_vs_removed": removed_result,
            "correct_vs_counterfactual": counterfactual_result,
        },
        "inputs": {
            "fresh_summary": {
                "path": str(Path(args.fresh_summary).resolve()),
                "sha256": aggregate.file_sha256(args.fresh_summary),
            },
            "confirmation_gate": {
                "path": str(Path(args.confirmation_gate).resolve()),
                "sha256": aggregate.file_sha256(args.confirmation_gate),
            },
            "confirmation_records": {
                "path": str(Path(args.confirmation_records).resolve()),
                "sha256": aggregate.file_sha256(args.confirmation_records),
            },
            "factorized_tfidf_audit": {
                "path": str(Path(args.factorized_tfidf_audit).resolve()),
                "sha256": aggregate.file_sha256(args.factorized_tfidf_audit),
            },
        },
        "integrity_checks": integrity,
        "sensitivity_checks": sensitivity,
        "audit_pass": all(integrity.values()),
        "state_cluster_sensitivity_pass": all(sensitivity.values()),
        "failed_integrity": [key for key, value in integrity.items() if not value],
        "failed_sensitivity": [key for key, value in sensitivity.items() if not value],
    }
    output.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(result, ensure_ascii=False))
    if not result["audit_pass"]:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
