"""Validate GridRank dynamic factorized."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import preflight_gridrank_dynamic_factorized as preflight


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--gate", required=True)
    parser.add_argument("--preflight", required=True)
    return parser.parse_args()


def main():
    args = parse_args()
    gate = json.load(open(args.gate, encoding="utf-8"))
    manifest = json.load(open(args.preflight, encoding="utf-8"))
    mechanism = gate.get("mechanism_checks", {})
    engineering = gate.get("engineering_checks", {})
    safety = gate.get("safety_checks", {})
    paper = gate.get("paper_checks", {})
    expected_engineering = bool(
        mechanism and engineering and safety
        and all({**mechanism, **engineering, **safety}.values())
    )
    expected_paper = bool(paper and all(paper.values()))
    expected_decision = (
        "authorize_fresh_factorized_dynamic_confirmation"
        if expected_engineering else "stop_factorized_dynamic_route"
    )
    adapter = gate.get("diagnostic_adapter", {})
    adapter_path = Path(args.gate).parent / "diagnostic_adapter"
    summaries = gate.get("summaries", {})
    required_methods = (
        "fixed_loss_lindistflow", "frozen_rule_parser_lindistflow",
        "tfidf_logreg_lindistflow", "tfidf_logreg_withheld_composition",
        "oracle_structured_lindistflow", "sft_factorized_interface",
        "frozen_gridrank_factorized_interface",
        "physics_aligned_factorized_llm", "instruction_removed",
        "instruction_counterfactual", "full_ac_oracle",
    )
    checks = {
        "preflight_schema": manifest.get("schema") == preflight.SCHEMA,
        "preflight_pass": manifest.get("preflight_pass") is True,
        "preflight_hash": (
            gate.get("preflight_sha256") == preflight.file_sha256(args.preflight)
        ),
        "schedule_bound": gate.get("schedule") == manifest.get("schedule"),
        "factorized_architecture_present": all(
            token in str(gate.get("architecture", ""))
            for token in ("loss/voltage", "none/maintenance", "additive composition")
        ),
        "withheld_composition": gate.get("withheld_composition") == "maintenance_voltage",
        "development_reuse_disclosed": gate.get("development_reuse_disclosed") is True,
        "fresh_final_test_required": gate.get("fresh_final_test_required") is True,
        "all_method_interfaces": all(name in summaries for name in required_methods),
        "axis_metrics_present": all(
            name in gate.get("axis_metrics", {})
            for name in ("sft", "frozen_gridrank", "physics_aligned", "physics_aligned_composition")
        ),
        "joint_card_ablation_locked": (
            gate.get("joint_card_ablation", {}).get("engineering_gate_pass") is False
        ),
        "positive_control_boundary_present": bool(gate.get("interpretation_boundary")),
        "mechanism_checks_nonempty": bool(mechanism),
        "engineering_checks_nonempty": bool(engineering),
        "safety_checks_nonempty": bool(safety),
        "paper_checks_nonempty": bool(paper),
        "engineering_decision_consistent": (
            gate.get("engineering_gate_pass") is expected_engineering
        ),
        "paper_decision_consistent": gate.get("paper_gate_pass") is expected_paper,
        "decision_consistent": gate.get("decision") == expected_decision,
        "adapter_valid": adapter.get("valid") is True,
        "adapter_files_present": (
            (adapter_path / "adapter_config.json").is_file()
            and (adapter_path / "adapter_model.safetensors").is_file()
        ),
    }
    result = {
        "msg": "GridRank factorized dynamic-policy result verification",
        "checks": checks,
        "verification_pass": all(checks.values()),
        "engineering_gate_pass": gate.get("engineering_gate_pass"),
        "paper_gate_pass": gate.get("paper_gate_pass"),
        "decision": gate.get("decision"),
        "failed_mechanism": [key for key, value in mechanism.items() if not value],
        "failed_engineering": [key for key, value in engineering.items() if not value],
        "failed_safety": [key for key, value in safety.items() if not value],
        "failed_paper": [key for key, value in paper.items() if not value],
    }
    print(json.dumps(result, ensure_ascii=False))
    if not result["verification_pass"]:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
