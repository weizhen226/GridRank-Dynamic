"""Validate GridRank dynamic multiseed."""

from __future__ import annotations

import argparse
import json

import aggregate_gridrank_dynamic_multiseed as aggregate


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--aggregate", required=True)
    args = parser.parse_args()
    locked = json.load(open(args.aggregate, encoding="utf-8"))
    gates = {
        int(seed): item["gate"]["path"]
        for seed, item in locked["inputs"]["seeds"].items()
    }
    records = {
        int(seed): item["records"]["path"]
        for seed, item in locked["inputs"]["seeds"].items()
    }
    recomputed = aggregate.build(
        gates,
        records,
        locked["inputs"]["fresh_summary"]["path"],
        locked["inputs"]["factorized_tfidf_audit"]["path"],
        locked["bootstrap_reps"],
        locked["bootstrap_seed"],
    )
    checks = {
        "schema": locked.get("schema") == aggregate.SCHEMA,
        "experiment_id": locked.get("experiment_id") == aggregate.EXPERIMENT_ID,
        "exact_recomputation": locked == recomputed,
        "audit_consistent": locked.get("audit_pass")
        == all(locked.get("integrity_checks", {}).values()),
        "decision_consistent": locked.get("decision") == (
            "authorize_three_seed_dynamic_adaptation_claim"
            if locked.get("robustness_gate_pass")
            else "retain_single_seed_confirmatory_claim_and_report_seed_variance"
        ),
    }
    result = {
        "msg": "GridRank dynamic multiseed aggregate verification",
        "checks": checks,
        "verification_pass": all(checks.values()),
        "audit_pass": locked.get("audit_pass"),
        "robustness_gate_pass": locked.get("robustness_gate_pass"),
        "decision": locked.get("decision"),
        "failed_robustness": locked.get("failed_robustness"),
    }
    print(json.dumps(result, ensure_ascii=False))
    if not result["verification_pass"]:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
