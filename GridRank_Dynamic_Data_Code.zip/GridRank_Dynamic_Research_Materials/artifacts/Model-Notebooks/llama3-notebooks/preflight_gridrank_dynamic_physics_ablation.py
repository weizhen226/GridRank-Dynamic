"""Check inputs for GridRank dynamic physics ablation."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import preflight_gridrank_dynamic_factorized as original
import preflight_gridrank_dynamic_factorized_replication as replication
import preflight_gridrank_dynamic_policy as joint
import preflight_gridrank_feedback as runtime


HERE = Path(__file__).resolve().parent
SCHEMA = "gridrank-dynamic-factorized-no-physics-preflight-v1"
EXPERIMENT_ID = "gridrank-factorized-dynamic-no-physics-listwise-ablation-v1"
SUPPORTED_SEEDS = (42, 123, 2025)
CODE_FILES = (
    "gridrank_dynamic_factorized_llm.py",
    "train_gridrank_dynamic_factorized.py",
    "verify_gridrank_dynamic_factorized.py",
    "preflight_gridrank_dynamic_physics_ablation.py",
    "train_gridrank_dynamic_physics_ablation.py",
    "verify_gridrank_dynamic_physics_ablation_model.py",
    "preflight_gridrank_dynamic_physics_ablation_confirmation.py",
    "eval_gridrank_dynamic_physics_ablation_confirmation.py",
    "verify_gridrank_dynamic_physics_ablation_confirmation.py",
    "aggregate_gridrank_dynamic_physics_ablation.py",
    "verify_gridrank_dynamic_physics_ablation.py",
    "run_gridrank_dynamic_physics_ablation.sh",
    "../../docs/GRIDRANK_DYNAMIC_PHYSICS_ABLATION_PROTOCOL.md",
)

file_sha256 = original.file_sha256
schedule = original.schedule


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--train_jsonl", required=True)
    parser.add_argument("--validation_jsonl", required=True)
    parser.add_argument("--pair_summary", required=True)
    parser.add_argument("--benchmark_manifest", required=True)
    parser.add_argument("--joint_preflight", required=True)
    parser.add_argument("--joint_gate", required=True)
    parser.add_argument("--resume_adapter_path", required=True)
    parser.add_argument("--sft_adapter_path", required=True)
    parser.add_argument("--base_model", required=True)
    parser.add_argument("--reference_full_preflight", required=False)
    parser.add_argument("--reference_full_gate", required=False)
    parser.add_argument("--output", required=True)
    parser.add_argument("--max_length", type=int, required=True)
    parser.add_argument("--primitive_batch_size", type=int, required=True)
    parser.add_argument("--epochs", type=int, required=True)
    parser.add_argument("--learning_rate", type=float, required=True)
    parser.add_argument("--grad_accum", type=int, required=True)
    parser.add_argument("--max_grad_norm", type=float, required=True)
    parser.add_argument("--target_temperature", type=float, required=True)
    parser.add_argument("--lambda_objective", type=float, required=True)
    parser.add_argument("--lambda_constraint", type=float, required=True)
    parser.add_argument("--lambda_physics", type=float, required=True)
    parser.add_argument("--lambda_hard", type=float, required=True)
    parser.add_argument("--hard_margin", type=float, required=True)
    parser.add_argument("--beta_reference", type=float, required=True)
    parser.add_argument("--seed", type=int, required=True)
    parser.add_argument("--gradient_checkpointing", type=int, choices=(0, 1), required=True)
    parser.add_argument("--bootstrap_reps", type=int, required=True)
    return parser.parse_args()


def code_hashes():
    missing = [name for name in CODE_FILES if not (HERE / name).is_file()]
    if missing:
        raise FileNotFoundError(f"missing physics-ablation code: {missing}")
    return {name: file_sha256(HERE / name) for name in CODE_FILES}


def _artifacts(args):
    return {
        "train": args.train_jsonl,
        "validation": args.validation_jsonl,
        "pair_summary": args.pair_summary,
        "dynamic_benchmark": args.benchmark_manifest,
        "joint_preflight": args.joint_preflight,
        "joint_gate": args.joint_gate,
    }


def _without_physics(value):
    return {key: item for key, item in value.items() if key != "lambda_physics"}


def create(args):
    output = Path(args.output)
    if output.exists():
        raise FileExistsError(f"refusing to overwrite physics-ablation preflight: {output}")
    if not args.reference_full_preflight or not args.reference_full_gate:
        raise ValueError("matched full-loss preflight and gate are required")

    reference = json.load(open(args.reference_full_preflight, encoding="utf-8"))
    reference_gate = json.load(open(args.reference_full_gate, encoding="utf-8"))
    current_schedule = schedule(args)
    reference_schedule = reference.get("schedule", {})
    artifacts = _artifacts(args)
    reference_artifacts = reference.get("artifacts", {})
    gridrank_hash = joint.adapter_hash(args.resume_adapter_path)
    sft_hash = joint.adapter_hash(args.sft_adapter_path)
    reference_schema_valid = reference.get("schema") in {
        original.SCHEMA, replication.SCHEMA,
    }

    checks = {
        "reference_schema_supported": reference_schema_valid,
        "reference_preflight_pass": reference.get("preflight_pass") is True,
        "reference_seed_matches": reference_schedule.get("seed") == args.seed,
        "supported_ablation_seed": args.seed in SUPPORTED_SEEDS,
        "reference_full_physics_weight_one": reference_schedule.get("lambda_physics") == 1.0,
        "ablation_physics_weight_zero": args.lambda_physics == 0.0,
        "physics_weight_is_only_schedule_change": (
            _without_physics(current_schedule) == _without_physics(reference_schedule)
        ),
        "reference_gate_bound": reference_gate.get("preflight_sha256")
        == file_sha256(args.reference_full_preflight),
        "reference_adapter_valid": reference_gate.get("diagnostic_adapter", {}).get("valid") is True,
        "source_artifact_hashes_match_full": all(
            name in reference_artifacts
            and Path(path).is_file()
            and file_sha256(path) == reference_artifacts[name].get("sha256")
            for name, path in artifacts.items()
        ),
        "gridrank_start_adapter_matches_full": gridrank_hash
        == reference.get("adapters", {}).get("gridrank", {}).get("sha256"),
        "sft_control_adapter_matches_full": sft_hash
        == reference.get("adapters", {}).get("sft", {}).get("sha256"),
        "base_model_matches_full": runtime.model_inventory(args.base_model)
        == reference.get("base_model_inventory"),
        "selection_exactly_reused": bool(reference.get("selection", {}).get("train_row_ids"))
        and bool(reference.get("selection", {}).get("validation_row_ids")),
        "withheld_composition_unchanged": reference.get("selection", {}).get(
            "joint_card_mix", {}
        ).get("voltage_maintenance", 0) == 0,
        "remaining_loss_weights_positive": all(
            value > 0
            for value in (
                args.lambda_objective,
                args.lambda_constraint,
                args.lambda_hard,
                args.beta_reference,
            )
        ),
    }
    manifest = {
        "msg": "GridRank factorized dynamic no-physics-listwise ablation preflight",
        "schema": SCHEMA,
        "experiment_id": EXPERIMENT_ID,
        "preflight_pass": all(checks.values()),
        "training_performed": False,
        "model_loaded": False,
        "power_flow_calls": 0,
        "ablation_definition": (
            "lambda_physics changes from 1.0 to 0.0; physics-certified data "
            "selection, semantic CE, axis margin, reference KL, start adapter, "
            "optimizer schedule and model seed remain matched"
        ),
        "interpretation_boundary": (
            "This removes the direct AC-derived policy-card listwise term, not "
            "all physics information from the already physics-certified corpus."
        ),
        "post_confirmation_supplement": True,
        "reference_full": {
            "preflight": {
                "path": str(Path(args.reference_full_preflight).resolve()),
                "sha256": file_sha256(args.reference_full_preflight),
            },
            "gate": {
                "path": str(Path(args.reference_full_gate).resolve()),
                "sha256": file_sha256(args.reference_full_gate),
            },
        },
        "artifacts": {
            name: {"path": str(Path(path).resolve()), "sha256": file_sha256(path)}
            for name, path in artifacts.items()
        },
        "adapters": {
            "gridrank": {
                "path": str(Path(args.resume_adapter_path).resolve()),
                "sha256": gridrank_hash,
            },
            "sft": {
                "path": str(Path(args.sft_adapter_path).resolve()),
                "sha256": sft_hash,
            },
        },
        "base_model": str(Path(args.base_model).resolve()),
        "base_model_inventory": runtime.model_inventory(args.base_model),
        "training_runtime": runtime.training_runtime(),
        "schedule": current_schedule,
        "selection": reference["selection"],
        "prompt_audit": reference.get("prompt_audit"),
        "code_sha256": code_hashes(),
        "checks": checks,
        "failed_checks": [key for key, value in checks.items() if not value],
    }
    output.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(manifest, ensure_ascii=False))
    if not manifest["preflight_pass"]:
        raise SystemExit(2)


def verify(args):
    from gridrank_runtime_compat import runtime_compatibility

    manifest = json.load(open(args.output, encoding="utf-8"))
    artifact_checks = {
        name: Path(item["path"]).is_file() and file_sha256(item["path"]) == item["sha256"]
        for name, item in manifest.get("artifacts", {}).items()
    }
    adapter_checks = {
        name: joint.adapter_hash(item["path"]) == item["sha256"]
        for name, item in manifest.get("adapters", {}).items()
    }
    reference_checks = {
        name: Path(item["path"]).is_file() and file_sha256(item["path"]) == item["sha256"]
        for name, item in manifest.get("reference_full", {}).items()
    }
    checks = {
        "schema": manifest.get("schema") == SCHEMA,
        "experiment_id": manifest.get("experiment_id") == EXPERIMENT_ID,
        "preflight_pass": manifest.get("preflight_pass") is True,
        "supported_seed": manifest.get("schedule", {}).get("seed") in SUPPORTED_SEEDS,
        "physics_weight_zero": manifest.get("schedule", {}).get("lambda_physics") == 0.0,
        "schedule_current": manifest.get("schedule") == schedule(args),
        "artifacts_current": bool(artifact_checks) and all(artifact_checks.values()),
        "adapters_current": bool(adapter_checks) and all(adapter_checks.values()),
        "reference_full_current": bool(reference_checks) and all(reference_checks.values()),
        "base_model_current": manifest.get("base_model_inventory")
        == runtime.model_inventory(manifest.get("base_model")),
        "runtime_compatible": runtime_compatibility(
            manifest.get("training_runtime"), runtime.training_runtime()
        )["compatible"],
        "code_current": manifest.get("code_sha256") == code_hashes(),
        "boundary_present": bool(manifest.get("interpretation_boundary")),
    }
    result = {
        "msg": "GridRank no-physics-listwise ablation runtime verification",
        "checks": checks,
        "verification_pass": all(checks.values()),
    }
    print(json.dumps(result, ensure_ascii=False))
    if not result["verification_pass"]:
        raise SystemExit(2)


def main():
    args = parse_args()
    if Path(args.output).exists():
        verify(args)
    else:
        create(args)


if __name__ == "__main__":
    main()
