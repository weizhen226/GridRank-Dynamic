#!/usr/bin/env bash
set -euo pipefail
export HF_HUB_OFFLINE=1

PREFLIGHT_ONLY="${PREFLIGHT_ONLY:-1}"
[[ "$PREFLIGHT_ONLY" == "0" || "$PREFLIGHT_ONLY" == "1" ]] || {
  echo "PREFLIGHT_ONLY must be 0 or 1" >&2; exit 2;
}

resolve_executable () {
  local requested="$1"
  if [[ "$requested" == */* ]]; then
    test -x "$requested" && printf '%s\n' "$requested"
  else
    command -v -- "$requested"
  fi
}
TRAIN_PYTHON_BIN="$(resolve_executable "${TRAIN_PYTHON:-python}")" || {
  echo "TRAIN_PYTHON is not executable" >&2; exit 2;
}
PHYSICS_PYTHON_BIN="$(resolve_executable "${PHYSICS_PYTHON:-$TRAIN_PYTHON_BIN}")" || {
  echo "PHYSICS_PYTHON is not executable" >&2; exit 2;
}

BASE_MODEL="${BASE_MODEL:-../../Meta-Llama-3.1-8B-Instruct}"
SFT="${SFT:-output_gridintent_gate_33_69_v2_20260717/sft_only}"
SOURCE_TAG="${SOURCE_TAG:-gridrank_select_confirm_v1_20260725}"
UPSTREAM_SUMMARY="${UPSTREAM_SUMMARY:-${SOURCE_TAG}_feedback_summary.json}"
UPSTREAM_AUDIT="${UPSTREAM_AUDIT:-${SOURCE_TAG}_feedback_audit.json}"
UPSTREAM_OFFLINE="${UPSTREAM_OFFLINE:-${SOURCE_TAG}_offline_train.jsonl}"
UPSTREAM_TEST="${UPSTREAM_TEST:-${SOURCE_TAG}_locked_test.jsonl}"
TRAIN_JSONL="${TRAIN_JSONL:-${SOURCE_TAG}_train.jsonl}"
TEST_JSONL="${TEST_JSONL:-${SOURCE_TAG}_test.jsonl}"
DATA_SUMMARY="${DATA_SUMMARY:-${SOURCE_TAG}_data_summary.json}"
DATA_AUDIT="${DATA_AUDIT:-${SOURCE_TAG}_data_audit.json}"
FULL_CONTROL_GATE="${FULL_CONTROL_GATE:-output_${SOURCE_TAG}_s42/gridrank_select_gate.json}"

TAG="${TAG:-gridrank_label_controls_v1_20260811}"
[[ "$TAG" =~ ^[A-Za-z0-9][A-Za-z0-9._-]*$ ]] || {
  echo "invalid TAG" >&2; exit 2;
}
SUITE_PREFLIGHT="${SUITE_PREFLIGHT:-${TAG}.preflight.json}"
AGGREGATE="${AGGREGATE:-${TAG}_aggregate.json}"

readonly MAX_LENGTH=1024
readonly CANDIDATE_BATCH_SIZE=4
readonly EPOCHS=4
readonly TOPK=3
readonly LEARNING_RATE=2e-6
readonly GRAD_ACCUM=4
readonly MAX_GRAD_NORM=1.0
readonly LIST_TEMPERATURE=1.0
readonly LAMBDA_BCE=1.0
readonly LAMBDA_LISTWISE=0.5
readonly LAMBDA_HARD=1.0
readonly HARD_MARGIN=0.5
readonly BETA_REFERENCE=0.02
readonly TRAIN_SEED=42
readonly LABEL_SEED=20260811
readonly TARGET_TEMPERATURE=0.2
readonly GRADIENT_CHECKPOINTING=1
readonly PHYSICS_TIMEOUT_S="${PHYSICS_TIMEOUT_S:-60.0}"
readonly BOOTSTRAP_REPS="${BOOTSTRAP_REPS:-10000}"
readonly BOOTSTRAP_SEED="${BOOTSTRAP_SEED:-20260811}"
readonly VARIANTS=(shuffled_labels lindistflow_labels)

for path in "$UPSTREAM_SUMMARY" "$UPSTREAM_AUDIT" "$UPSTREAM_OFFLINE" \
  "$UPSTREAM_TEST" "$TRAIN_JSONL" "$TEST_JSONL" "$DATA_SUMMARY" \
  "$DATA_AUDIT" "$FULL_CONTROL_GATE" \
  "$SFT/adapter_config.json" "$SFT/adapter_model.safetensors" \
  "$BASE_MODEL/config.json" "$BASE_MODEL/tokenizer_config.json"; do
  test -e "$path" || { echo "missing locked label-control input: $path" >&2; exit 2; }
done

create_base_preflight () {
  local variant="$1"
  local output="${TAG}_${variant}.base.preflight.json"
  "$TRAIN_PYTHON_BIN" -u preflight_gridrank_select.py \
    --upstream_summary "$UPSTREAM_SUMMARY" --upstream_audit "$UPSTREAM_AUDIT" \
    --offline_jsonl "$UPSTREAM_OFFLINE" --upstream_test_jsonl "$UPSTREAM_TEST" \
    --train_jsonl "$TRAIN_JSONL" --test_jsonl "$TEST_JSONL" \
    --data_summary "$DATA_SUMMARY" --data_audit "$DATA_AUDIT" \
    --resume_adapter_path "$SFT" --base_model "$BASE_MODEL" \
    --physics_python "$PHYSICS_PYTHON_BIN" --physics_timeout_s "$PHYSICS_TIMEOUT_S" \
    --output "$output" --max_length "$MAX_LENGTH" \
    --candidate_batch_size "$CANDIDATE_BATCH_SIZE" --epochs "$EPOCHS" \
    --topk "$TOPK" --learning_rate "$LEARNING_RATE" --grad_accum "$GRAD_ACCUM" \
    --max_grad_norm "$MAX_GRAD_NORM" --list_temperature "$LIST_TEMPERATURE" \
    --lambda_bce "$LAMBDA_BCE" --lambda_listwise "$LAMBDA_LISTWISE" \
    --lambda_hard "$LAMBDA_HARD" --hard_margin "$HARD_MARGIN" \
    --beta_reference "$BETA_REFERENCE" --seed "$TRAIN_SEED" \
    --gradient_checkpointing "$GRADIENT_CHECKPOINTING" \
    --bootstrap_reps "$BOOTSTRAP_REPS"
}

if [[ "$PREFLIGHT_ONLY" == "1" ]]; then
  echo "=== 1/3 DEPENDENCY-LIGHT MATCHED LABEL-CONTROL REGRESSIONS ==="
  "$TRAIN_PYTHON_BIN" -B verify_gridrank_label_controls.py

  echo "=== 2/3 CREATE TWO IDENTICAL FULL-LOSS BASE PREFLIGHTS ==="
  existing=0
  for variant in "${VARIANTS[@]}"; do
    test -e "${TAG}_${variant}.base.preflight.json" && existing=$((existing + 1))
  done
  if [[ "$existing" != "0" && "$existing" != "2" ]]; then
    echo "partial base-preflight set; use a new TAG" >&2; exit 2
  fi
  if [[ "$existing" == "0" ]]; then
    for variant in "${VARIANTS[@]}"; do create_base_preflight "$variant"; done
  fi

  echo "=== 3/3 LOCK INPUT IDENTITY, LABEL TRANSFORMS, SCHEDULE, AND CODE ==="
  if [[ ! -e "$SUITE_PREFLIGHT" ]]; then
    "$TRAIN_PYTHON_BIN" -u preflight_gridrank_label_controls.py --mode create \
      --base_preflight "shuffled_labels=${TAG}_shuffled_labels.base.preflight.json" \
      --base_preflight "lindistflow_labels=${TAG}_lindistflow_labels.base.preflight.json" \
      --full_control_gate "$FULL_CONTROL_GATE" --train_jsonl "$TRAIN_JSONL" \
      --label_seed "$LABEL_SEED" --target_temperature "$TARGET_TEMPERATURE" \
      --output "$SUITE_PREFLIGHT"
  fi
  "$TRAIN_PYTHON_BIN" -B preflight_gridrank_label_controls.py \
    --mode verify --output "$SUITE_PREFLIGHT"
  echo "=== GRIDRANK MATCHED LABEL CONTROLS CPU PREFLIGHT COMPLETE; GPU NOT STARTED ==="
  exit 0
fi

"$TRAIN_PYTHON_BIN" -B preflight_gridrank_label_controls.py \
  --mode verify --output "$SUITE_PREFLIGHT"
for variant in "${VARIANTS[@]}"; do
  out="output_${TAG}_${variant}"
  test ! -e "$out" || { echo "refusing to reuse output: $out" >&2; exit 2; }
  test ! -e "${out}.log" || { echo "refusing to overwrite log: ${out}.log" >&2; exit 2; }
done
test ! -e "$AGGREGATE" || { echo "refusing to overwrite aggregate: $AGGREGATE" >&2; exit 2; }

echo "=== 1/4 CUDA + NF4 READINESS ==="
"$TRAIN_PYTHON_BIN" -B - <<'PY'
import json, torch
from transformers import BitsAndBytesConfig
checks = {"cuda": bool(torch.cuda.is_available()), "device_count": torch.cuda.device_count() > 0}
config = BitsAndBytesConfig(load_in_4bit=True, bnb_4bit_quant_type="nf4",
    bnb_4bit_compute_dtype=torch.float16, bnb_4bit_use_double_quant=True)
checks["nf4"] = bool(config.load_in_4bit and config.bnb_4bit_quant_type == "nf4")
result = {"msg":"GridRank label-controls CUDA readiness", "checks":checks,
          "readiness_pass":all(checks.values())}
if checks["cuda"]: result["device"] = torch.cuda.get_device_name(0)
print(json.dumps(result, ensure_ascii=False))
raise SystemExit(0 if result["readiness_pass"] else 2)
PY

stage=1
for variant in "${VARIANTS[@]}"; do
  stage=$((stage + 1))
  echo "=== ${stage}/4 TRAIN MATCHED CONTROL: ${variant} ==="
  manifest="${TAG}_${variant}.base.preflight.json"
  out="output_${TAG}_${variant}"
  "$TRAIN_PYTHON_BIN" -B preflight_gridrank_select.py \
    --verify_runtime_manifest "$manifest" --base_model "$BASE_MODEL" \
    --physics_python "$PHYSICS_PYTHON_BIN" --physics_timeout_s "$PHYSICS_TIMEOUT_S" \
    --bootstrap_reps "$BOOTSTRAP_REPS"
  GRIDRANK_LABEL_CONTROL="$variant" \
  GRIDRANK_LABEL_CONTROL_SUITE="$SUITE_PREFLIGHT" \
  "$TRAIN_PYTHON_BIN" -u train_gridrank_label_control.py \
    --train_jsonl "$TRAIN_JSONL" --test_jsonl "$TEST_JSONL" \
    --data_summary "$DATA_SUMMARY" --data_audit "$DATA_AUDIT" \
    --preflight_manifest "$manifest" --resume_adapter_path "$SFT" \
    --output_dir "$out" --base_model "$BASE_MODEL" \
    --physics_python "$PHYSICS_PYTHON_BIN" --physics_timeout_s "$PHYSICS_TIMEOUT_S" \
    --max_length "$MAX_LENGTH" --candidate_batch_size "$CANDIDATE_BATCH_SIZE" \
    --epochs "$EPOCHS" --topk "$TOPK" --learning_rate "$LEARNING_RATE" \
    --grad_accum "$GRAD_ACCUM" --max_grad_norm "$MAX_GRAD_NORM" \
    --list_temperature "$LIST_TEMPERATURE" --lambda_bce "$LAMBDA_BCE" \
    --lambda_listwise "$LAMBDA_LISTWISE" --lambda_hard "$LAMBDA_HARD" \
    --hard_margin "$HARD_MARGIN" --beta_reference "$BETA_REFERENCE" \
    --seed "$TRAIN_SEED" --gradient_checkpointing "$GRADIENT_CHECKPOINTING" \
    --bootstrap_reps "$BOOTSTRAP_REPS" 2>&1 | tee "${out}.log"
  "$TRAIN_PYTHON_BIN" -B verify_gridrank_label_controls.py \
    --gate "$out/gridrank_select_gate.json" --variant "$variant" \
    --suite_preflight "$SUITE_PREFLIGHT"
done

echo "=== 4/4 AGGREGATE FULL GRIDRANK VS MATCHED LABEL CONTROLS ==="
"$TRAIN_PYTHON_BIN" -u aggregate_gridrank_label_controls.py \
  --suite_preflight "$SUITE_PREFLIGHT" \
  --gate "shuffled_labels=output_${TAG}_shuffled_labels/gridrank_select_gate.json" \
  --gate "lindistflow_labels=output_${TAG}_lindistflow_labels/gridrank_select_gate.json" \
  --bootstrap_reps "$BOOTSTRAP_REPS" --bootstrap_seed "$BOOTSTRAP_SEED" \
  --output "$AGGREGATE"
"$TRAIN_PYTHON_BIN" -B verify_gridrank_label_controls.py \
  --aggregate "$AGGREGATE" --suite_preflight "$SUITE_PREFLIGHT"
echo "=== GRIDRANK MATCHED LABEL CONTROLS COMPLETE ==="
