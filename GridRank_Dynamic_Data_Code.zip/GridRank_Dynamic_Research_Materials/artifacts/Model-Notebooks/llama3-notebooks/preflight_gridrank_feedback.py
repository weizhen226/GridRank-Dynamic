"""Check inputs for GridRank feedback."""

from __future__ import annotations

import argparse
import hashlib
import importlib.metadata
import json
import math
import platform
import subprocess
import sys
from pathlib import Path

from audit_gridrank_feedback import CODE_FILES as AUDIT_CODE_FILES
from gridrank_llm import render_candidate_prompt, resolve_preference_token_ids


HERE = Path(__file__).resolve().parent


CODE_FILES = tuple(AUDIT_CODE_FILES)

TRAINING_DISTRIBUTIONS = (
    "torch", "transformers", "tokenizers", "peft", "accelerate", "bitsandbytes",
    "safetensors", "huggingface-hub",
)
PHYSICS_DISTRIBUTIONS = (
    "pandapower", "numpy", "pandas", "scipy", "networkx",
)
AUDIT_CHECK_KEYS = {
    "strict_source_schema", "topology_membership_rebuilt", "derived_targets_recomputed",
    "online_feedback_sealed", "state_partitions_disjoint", "load_partitions_disjoint",
    "artifact_hashes_match_summary", "summary_counts_match",
    "source_hashes_match_summary", "selected_load_ids_match",
    "deterministic_selection_trace_matches", "power_flow_call_counts_match_trace",
    "build_code_matches_summary", "both_target_types_in_offline",
    "both_target_types_in_test", "locked_code_files_present",
    "labelled_noop_operational", "pandapower_replay_count_exact",
    "pandapower_replay_exact", "selection_anchor_replay_exact",
}


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--train_source", action="append", required=True,
                        help="NETWORK=state-only train source")
    parser.add_argument("--validation_source", action="append", required=True,
                        help="NETWORK=validation state-only view")
    parser.add_argument("--validation_raw", action="append", required=True,
                        help="NETWORK=raw validation source used to build the view")
    parser.add_argument("--validation_view_manifest", action="append", required=True,
                        help="NETWORK=make_no_oracle_state_view manifest")
    parser.add_argument("--offline_jsonl", required=True)
    parser.add_argument("--online_jsonl", required=True)
    parser.add_argument("--test_jsonl", required=True)
    parser.add_argument("--data_summary", required=True)
    parser.add_argument("--data_audit", required=True)
    parser.add_argument("--resume_adapter_path", required=True)
    parser.add_argument("--base_model", required=True)
    parser.add_argument("--physics_python", required=True)
    parser.add_argument("--physics_timeout_s", type=float, required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--max_length", type=int, required=True)
    parser.add_argument("--candidate_batch_size", type=int, required=True)
    parser.add_argument("--offline_epochs", type=int, required=True)
    parser.add_argument("--online_rounds", type=int, required=True)
    parser.add_argument("--online_query_budget", type=int, required=True)
    parser.add_argument("--topk", type=int, required=True)
    parser.add_argument("--learning_rate", type=float, required=True)
    parser.add_argument("--grad_accum", type=int, required=True)
    parser.add_argument("--max_grad_norm", type=float, required=True)
    parser.add_argument("--list_temperature", type=float, required=True)
    parser.add_argument("--lambda_margin", type=float, required=True)
    parser.add_argument("--offline_margin", type=float, required=True)
    parser.add_argument("--beta_reference", type=float, required=True)
    parser.add_argument("--online_margin", type=float, required=True)
    parser.add_argument("--online_offline_kl", type=float, required=True)
    parser.add_argument("--online_replay_mass", type=float, required=True)
    parser.add_argument("--seed", type=int, required=True)
    parser.add_argument("--gradient_checkpointing", type=int, required=True)
    parser.add_argument("--bootstrap_reps", type=int, required=True)
    return parser.parse_args()


def file_sha256(path):
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def schedule(args):
    
    keys = (
        "max_length", "candidate_batch_size", "offline_epochs", "online_rounds",
        "online_query_budget", "topk", "learning_rate", "grad_accum",
        "max_grad_norm", "list_temperature", "lambda_margin", "offline_margin",
        "beta_reference", "online_margin", "online_offline_kl",
        "online_replay_mass", "seed", "gradient_checkpointing",
        "physics_timeout_s", "bootstrap_reps",
    )
    return {key: getattr(args, key) for key in keys}


def execution_schedule(args):
    
    return schedule(args)


def _distribution_versions(names):
    versions = {}
    for name in names:
        try:
            versions[name] = importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError:
            versions[name] = None
    return versions


def training_runtime():
    
    return {
        "executable": str(Path(sys.executable).resolve()),
        "python": sys.version,
        "implementation": platform.python_implementation(),
        "platform": platform.platform(),
        "distributions": _distribution_versions(TRAINING_DISTRIBUTIONS),
    }


def _python_json(python, code, timeout_s=60.0):
    completed = subprocess.run(
        [python, "-B", "-c", code], check=True, text=True,
        stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=timeout_s,
    )
    return json.loads(completed.stdout.strip().splitlines()[-1])


def _model_files(path):
    root = Path(path)
    required = [root / "config.json", root / "tokenizer_config.json"]
    if not all(item.exists() for item in required):
        raise FileNotFoundError("base model config/tokenizer config is missing")
    files = [*required]
    indexes = [
        item for item in (
            root / "model.safetensors.index.json",
            root / "pytorch_model.bin.index.json",
        )
        if item.exists()
    ]
    if indexes:
        index = indexes[0]
        files.append(index)
        data = json.loads(index.read_text(encoding="utf-8"))
        shard_names = sorted(set(data.get("weight_map", {}).values()))
        if not shard_names:
            raise FileNotFoundError("base model index contains no weight shards")
        shard_paths = [Path(name) for name in shard_names]
        if any(item.is_absolute() or ".." in item.parts for item in shard_paths):
            raise ValueError("base model index contains an unsafe shard path")
        weight_files = [root / name for name in shard_paths]
    else:
        weight_files = sorted(root.glob("model*.safetensors"))
        if not weight_files:
            weight_files = sorted(root.glob("pytorch_model*.bin"))
    if not weight_files:
        raise FileNotFoundError("base model has no weight shards")
    files.extend(weight_files)


    tokenizer_files = {
        item
        for item in root.iterdir()
        if item.is_file() and (
            item.name.startswith("tokenizer")
            or item.name in {
                "special_tokens_map.json", "added_tokens.json", "vocab.json",
                "vocab.txt", "merges.txt", "spiece.model",
                "sentencepiece.bpe.model", "chat_template.json",
                "chat_template.jinja", "generation_config.json",
            }
            or "chat_template" in item.name
        )
    }
    chat_templates = root / "chat_templates"
    if chat_templates.is_dir():
        tokenizer_files.update(item for item in chat_templates.rglob("*") if item.is_file())
    tokenizer_files = sorted(tokenizer_files)
    core_tokenizer = {
        "tokenizer.json", "tokenizer.model", "spiece.model", "vocab.json",
        "vocab.txt", "sentencepiece.bpe.model",
    }
    if not any(item.parent == root and item.name in core_tokenizer for item in tokenizer_files):
        raise FileNotFoundError("base model has no tokenizer vocabulary/model artifact")
    files.extend(tokenizer_files)
    files = sorted(set(files))
    if any(not item.is_file() or item.stat().st_size <= 0 for item in files):
        raise FileNotFoundError("base model shard manifest is incomplete")
    return root, files


def model_manifest(path):
    root, files = _model_files(path)
    return {
        str(item.relative_to(root)): {"bytes": item.stat().st_size, "sha256": file_sha256(item)}
        for item in files
    }


def model_inventory(path):
    
    root, files = _model_files(path)
    return {str(item.relative_to(root)): item.stat().st_size for item in files}


def prompt_length_audit(base_model, partitions, max_length):
    
    if int(max_length) <= 0:
        raise ValueError("max_length must be positive")
    from transformers import AutoTokenizer

    tokenizer = AutoTokenizer.from_pretrained(base_model, local_files_only=True)
    positive_id, negative_id = resolve_preference_token_ids(tokenizer)
    partition_results = {}
    total_rows = 0
    total_candidates = 0
    truncated_candidates = 0
    global_max = 0
    longest = None
    for partition, raw_path in partitions.items():
        path = Path(raw_path).resolve()
        stats = {
            "path": str(path),
            "rows": 0,
            "candidates": 0,
            "max_tokens": 0,
            "truncated_candidates": 0,
            "by_network": {},
        }
        with open(path, encoding="utf-8") as handle:
            for line_number, line in enumerate(handle, start=1):
                if not line.strip():
                    continue
                row = json.loads(line)
                candidates = row.get("candidates")
                if not isinstance(candidates, list) or not candidates:
                    raise ValueError(
                        f"{partition} row {line_number} has no candidate list"
                    )
                texts = [
                    render_candidate_prompt(tokenizer, row, candidate)
                    for candidate in candidates
                ]
                encoded = tokenizer(
                    texts,
                    add_special_tokens=False,
                    truncation=False,
                    padding=False,
                    return_attention_mask=False,
                    return_token_type_ids=False,
                )
                lengths = [len(token_ids) for token_ids in encoded["input_ids"]]
                if len(lengths) != len(candidates) or any(length <= 0 for length in lengths):
                    raise RuntimeError(f"invalid prompt token counts in {partition}")
                network = str(row.get("network_id"))
                network_stats = stats["by_network"].setdefault(network, {
                    "rows": 0, "candidates": 0, "max_tokens": 0,
                    "truncated_candidates": 0,
                })
                row_truncated = sum(length > max_length for length in lengths)
                row_max = max(lengths)
                stats["rows"] += 1
                stats["candidates"] += len(lengths)
                stats["max_tokens"] = max(stats["max_tokens"], row_max)
                stats["truncated_candidates"] += row_truncated
                network_stats["rows"] += 1
                network_stats["candidates"] += len(lengths)
                network_stats["max_tokens"] = max(network_stats["max_tokens"], row_max)
                network_stats["truncated_candidates"] += row_truncated
                total_rows += 1
                total_candidates += len(lengths)
                truncated_candidates += row_truncated
                if row_max > global_max:
                    index = lengths.index(row_max)
                    global_max = row_max
                    longest = {
                        "partition": partition,
                        "instance_id": row.get("instance_id"),
                        "network": network,
                        "candidate_action": candidates[index].get("action"),
                        "tokens": row_max,
                    }
        if stats["rows"] <= 0:
            raise ValueError(f"empty prompt-audit partition: {partition}")
        partition_results[partition] = stats
    result = {
        "msg": "GridRank exact candidate-prompt token-length audit",
        "tokenizer_class": type(tokenizer).__name__,
        "chat_template_used": bool(getattr(tokenizer, "chat_template", None)),
        "preference_token_ids": {"YES": positive_id, "NO": negative_id},
        "max_length": int(max_length),
        "rows": total_rows,
        "candidates": total_candidates,
        "max_tokens": global_max,
        "truncated_candidates": truncated_candidates,
        "longest_prompt": longest,
        "partitions": partition_results,
    }
    result["prompt_length_pass"] = (
        total_candidates > 0
        and global_max <= int(max_length)
        and truncated_candidates == 0
    )
    return result


def physics_runtime(python):
    
    code = f"""
import importlib.metadata as metadata
import json
import platform
import sys
from pathlib import Path

versions = {{}}
for name in {list(PHYSICS_DISTRIBUTIONS)!r}:
    try:
        versions[name] = metadata.version(name)
    except metadata.PackageNotFoundError:
        versions[name] = None
print(json.dumps({{
    "executable": str(Path(sys.executable).resolve()),
    "python": sys.version,
    "implementation": platform.python_implementation(),
    "platform": platform.platform(),
    "distributions": versions,
}}))
"""
    return _python_json(python, code)


def _parse_specs(specs, label):
    output = {}
    for spec in specs:
        if "=" not in spec:
            raise ValueError(f"{label} must use NETWORK=PATH: {spec!r}")
        network, raw_path = spec.split("=", 1)
        if network in output:
            raise ValueError(f"duplicate {label} network: {network}")
        path = Path(raw_path).resolve()
        if not path.is_file():
            raise FileNotFoundError(f"missing {label} path: {path}")
        output[network] = path
    if set(output) != {"33", "69"}:
        raise ValueError(f"{label} must contain exactly networks 33 and 69")
    return output


def _require_exact_keys(mapping, expected, label):
    if not isinstance(mapping, dict) or set(mapping) != set(expected):
        actual = sorted(mapping) if isinstance(mapping, dict) else type(mapping).__name__
        raise ValueError(f"{label} keys mismatch: expected={sorted(expected)}, actual={actual}")


def validation_view_locks(raw_specs, view_specs, manifest_specs):
    raw = _parse_specs(raw_specs, "validation_raw")
    views = _parse_specs(view_specs, "validation_source")
    manifests = _parse_specs(manifest_specs, "validation_view_manifest")
    required = {
        "schema", "source_path", "source_sha256", "output_path", "output_sha256",
        "columns", "forbidden_columns_absent", "selected_split", "rows", "split_counts",
        "prompt_canonicalized", "source_text_forwarded", "msg",
    }
    expected_columns = ["instance_id", "load_id", "prompt", "split"]
    expected_forbidden = sorted({
        "output", "chosen", "chosen_index", "candidates", "headroom_pct", "bucket",
        "target_loss_kw", "label_open", "best_reduction_pct", "true_noop", "should_act",
    })
    output = {}
    for network in ("33", "69"):
        payload = json.loads(manifests[network].read_text(encoding="utf-8"))
        missing = sorted(required - set(payload))
        if missing:
            raise ValueError(f"validation view manifest {network} missing fields: {missing}")
        with open(views[network], encoding="utf-8") as handle:
            emitted = [json.loads(line) for line in handle if line.strip()]
        declared_rows = payload["rows"]
        row_schema_ok = bool(emitted) and all(
            isinstance(row, dict)
            and list(row) == expected_columns
            and all(isinstance(row[column], str) for column in expected_columns)
            and row["split"] == "validation"
            for row in emitted
        )
        checks = {
            "msg": payload["msg"] == "strict no-oracle state view",
            "schema": payload["schema"] == "gridrank-state-only-v1",
            "split": payload["selected_split"] == "validation",
            "source_path": Path(payload["source_path"]).resolve() == raw[network],
            "output_path": Path(payload["output_path"]).resolve() == views[network],
            "source_sha256": payload["source_sha256"] == file_sha256(raw[network]),
            "output_sha256": payload["output_sha256"] == file_sha256(views[network]),
            "columns": payload["columns"] == expected_columns,
            "forbidden_columns": payload["forbidden_columns_absent"] == expected_forbidden,
            "prompt_canonicalized": payload["prompt_canonicalized"] is True,
            "source_text_not_forwarded": payload["source_text_forwarded"] is False,
            "rows": isinstance(declared_rows, int) and not isinstance(declared_rows, bool)
                and declared_rows > 0 and declared_rows == len(emitted),
            "split_counts": payload["split_counts"] == {"validation": len(emitted)},
            "emitted_schema": row_schema_ok,
        }
        if not all(checks.values()):
            raise ValueError(f"validation view manifest {network} is stale: {checks}")
        output[network] = {
            "raw_path": str(raw[network]),
            "view_path": str(views[network]),
            "manifest_path": str(manifests[network]),
            "raw_sha256": file_sha256(raw[network]),
            "view_sha256": file_sha256(views[network]),
            "manifest_sha256": file_sha256(manifests[network]),
        }
    return output


def verify_runtime_lock(
    manifest_path, base_model, physics_python, physics_timeout_s, bootstrap_reps,
):
    
    if not math.isfinite(float(physics_timeout_s)) or float(physics_timeout_s) <= 0:
        raise ValueError("physics_timeout_s must be finite and positive")
    if int(bootstrap_reps) <= 0:
        raise ValueError("bootstrap_reps must be positive")
    manifest = json.loads(Path(manifest_path).read_text(encoding="utf-8"))
    current_training = training_runtime()
    current_physics = physics_runtime(physics_python)
    execution = manifest.get("execution_schedule")
    locked_model = manifest.get("base_model_manifest")
    locked_inventory = {
        name: int(value["bytes"])
        for name, value in locked_model.items()
    } if isinstance(locked_model, dict) else None
    checks = {
        "preflight_pass": manifest.get("preflight_pass") is True,
        "training_runtime_match": manifest.get("training_runtime") == current_training,
        "physics_runtime_match": manifest.get("physics_runtime") == current_physics,
        "base_model_inventory_match": locked_inventory == model_inventory(base_model),
        "physics_timeout_match": isinstance(execution, dict)
            and execution.get("physics_timeout_s") == float(physics_timeout_s),
        "bootstrap_reps_match": isinstance(execution, dict)
            and execution.get("bootstrap_reps") == int(bootstrap_reps),
    }
    return {
        "msg": "GridRank locked runtime verification",
        "checks": checks,
        "runtime_pass": all(checks.values()),
        "training_runtime": current_training,
        "physics_runtime": current_physics,
    }


def main():
    args = parse_args()
    if not math.isfinite(args.physics_timeout_s) or args.physics_timeout_s <= 0:
        raise ValueError("physics_timeout_s must be finite and positive")
    if args.bootstrap_reps <= 0:
        raise ValueError("bootstrap_reps must be positive")
    output = Path(args.output)
    if output.exists():
        raise FileExistsError(f"refusing to overwrite preflight manifest: {output}")
    audit = json.load(open(args.data_audit, encoding="utf-8"))
    summary = json.load(open(args.data_summary, encoding="utf-8"))
    train_sources = _parse_specs(args.train_source, "train_source")
    validation_sources = _parse_specs(args.validation_source, "validation_source")
    source_hash = {
        "train": {network: file_sha256(path) for network, path in train_sources.items()},
        "validation": {
            network: file_sha256(path) for network, path in validation_sources.items()
        },
    }
    view_locks = validation_view_locks(
        args.validation_raw, args.validation_source, args.validation_view_manifest
    )
    adapter = Path(args.resume_adapter_path)
    resume_hash = {
        "adapter_config_json": file_sha256(adapter / "adapter_config.json"),
        "adapter_model_safetensors": file_sha256(adapter / "adapter_model.safetensors"),
    }
    artifact_hash = {
        "offline_train": file_sha256(args.offline_jsonl),
        "online_stream": file_sha256(args.online_jsonl),
        "test": file_sha256(args.test_jsonl),
        "summary": file_sha256(args.data_summary),
        "audit": file_sha256(args.data_audit),
    }
    missing_code = [name for name in CODE_FILES if not (HERE / name).exists()]
    code_hash = {
        name: file_sha256(HERE / name) for name in CODE_FILES if (HERE / name).exists()
    }
    _require_exact_keys(audit, {
        "msg", "summary_sha256", "artifact_sha256", "source_sha256", "code_sha256",
        "missing_code_files", "partition_audits", "physics_replay",
        "selection_anchor_replay", "checks", "audit_pass",
    }, "data audit")
    _require_exact_keys(audit["artifact_sha256"], {
        "offline_train", "online_stream", "test",
    }, "audit artifact_sha256")
    _require_exact_keys(audit["source_sha256"], {"train", "validation"},
                        "audit source_sha256")
    for split in ("train", "validation"):
        _require_exact_keys(audit["source_sha256"][split], {"33", "69"},
                            f"audit source_sha256.{split}")
    _require_exact_keys(audit["code_sha256"], AUDIT_CODE_FILES, "audit code_sha256")
    _require_exact_keys(audit["checks"], AUDIT_CHECK_KEYS, "audit checks")
    audit_artifacts_match = audit["artifact_sha256"] == {
        key: artifact_hash[key] for key in ("offline_train", "online_stream", "test")
    }
    audit_summary_matches = audit["summary_sha256"] == artifact_hash["summary"]
    audit_sources_match = audit["source_sha256"] == source_hash
    audit_code_matches = audit["code_sha256"] == {
        name: file_sha256(HERE / name) for name in AUDIT_CODE_FILES
    }
    audit_checks_all_true = (
        isinstance(audit["checks"], dict)
        and bool(audit["checks"])
        and all(value is True for value in audit["checks"].values())
    )
    prompt_audit = prompt_length_audit(
        args.base_model,
        {
            "offline_train": args.offline_jsonl,
            "online_stream": args.online_jsonl,
            "test": args.test_jsonl,
        },
        args.max_length,
    )
    base_manifest = model_manifest(args.base_model)
    current_training_runtime = training_runtime()
    current_physics_runtime = physics_runtime(args.physics_python)
    checks = {
        "data_audit_pass": audit["audit_pass"] is True,
        "data_audit_checks_all_true": audit_checks_all_true,
        "data_audit_missing_code_files_empty": audit["missing_code_files"] == [],
        "audit_artifacts_match_current": audit_artifacts_match,
        "audit_summary_matches_current": audit_summary_matches,
        "audit_sources_match_current": audit_sources_match,
        "data_coverage_pass": summary.get("coverage_pass") is True,
        "online_feedback_sealed": summary.get("online_feedback_revealed") is False,
        "source_oracle_fields_hidden": summary.get("source_oracle_fields_visible") is False,
        "all_code_files_present": not missing_code,
        "audit_was_built_by_current_code": audit_code_matches,
        "candidate_prompts_untruncated": prompt_audit["prompt_length_pass"] is True,
        "resume_adapter_present": all((adapter / name).exists() for name in (
            "adapter_config.json", "adapter_model.safetensors"
        )),
        "training_runtime_complete": all(
            current_training_runtime["distributions"].get(name) is not None
            for name in TRAINING_DISTRIBUTIONS
        ),
        "physics_runtime_complete": all(
            current_physics_runtime["distributions"].get(name) is not None
            for name in PHYSICS_DISTRIBUTIONS
        ),
    }
    result = {
        "msg": "GridRank locked CPU preflight",
        "artifact_sha256": artifact_hash,
        "source_sha256": source_hash,
        "validation_view_locks": view_locks,
        "resume_adapter_sha256": resume_hash,
        "base_model_manifest": base_manifest,
        "prompt_length_audit": prompt_audit,
        "code_sha256": code_hash,
        "missing_code_files": missing_code,
        "training_schedule": schedule(args),
        "execution_schedule": execution_schedule(args),
        "training_runtime": current_training_runtime,
        "physics_runtime": current_physics_runtime,
        "preflight_python": {"executable": str(Path(sys.executable).resolve()),
                             "version": sys.version},
        "checks": checks,
        "preflight_pass": all(checks.values()),
    }
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(result, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps(result, ensure_ascii=False))
    if not result["preflight_pass"]:
        raise SystemExit(2)


def runtime_verification_main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--verify_runtime_manifest", required=True)
    parser.add_argument("--base_model", required=True)
    parser.add_argument("--physics_python", required=True)
    parser.add_argument("--physics_timeout_s", type=float, required=True)
    parser.add_argument("--bootstrap_reps", type=int, required=True)
    args = parser.parse_args()
    result = verify_runtime_lock(
        args.verify_runtime_manifest, args.base_model, args.physics_python,
        args.physics_timeout_s, args.bootstrap_reps,
    )
    print(json.dumps(result, ensure_ascii=False))
    if not result["runtime_pass"]:
        raise SystemExit(2)


if __name__ == "__main__":
    if "--verify_runtime_manifest" in sys.argv:
        runtime_verification_main()
    else:
        main()
