"""Audit GridRank dynamic confirmation."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from types import SimpleNamespace

import build_gridrank_dynamic_confirmation as build
from build_gridrank_instruction_pairs import candidate_pairs


SCHEMA = "gridrank-dynamic-fresh-confirmation-audit-v1"


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", choices=("build", "verify"), default="build")
    parser.add_argument("--cache", required=True)
    parser.add_argument("--pairs", required=True)
    parser.add_argument("--summary", required=True)
    parser.add_argument("--audit_out", required=True)
    return parser.parse_args()


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def main():
    args = parse_args()
    output = Path(args.audit_out)
    if args.mode == "build" and output.exists():
        raise FileExistsError(f"refusing to overwrite audit: {output}")
    if args.mode == "verify" and not output.is_file():
        raise FileNotFoundError(output)
    summary = json.load(open(args.summary, encoding="utf-8"))
    cache = build.jsonl(args.cache)
    rows = build.jsonl(args.pairs)
    settings = SimpleNamespace(**summary["settings"])
    p_args = build.pair_args(settings)
    pool = []
    for state in cache:
        pool.extend(candidate_pairs(state, "validation", p_args))
    selected = build.selected_pairs(pool, settings)
    expected_rows, expected_manifest = build.emit(selected)
    excluded_states, excluded_loads, expected_exclusions = build.exclusion_identities(
        settings.exclude_jsonl
    )
    evaluation_states, expected_state_only_exclusions = build.exclusion_states(
        settings.exclude_state_jsonl
    )
    actual_states = {
        (str(row["network_id"]), str(row["physical_state_sha256"])) for row in rows
    }
    actual_loads = {
        (str(row["network_id"]), str(row["load_id"])) for row in rows
    }
    pair_groups = {}
    for row in rows:
        pair_groups.setdefault(row["pair_id"], []).append(row)
    checks = {
        "summary_schema": summary.get("schema") == build.SCHEMA,
        "summary_coverage_pass": summary.get("coverage_pass") is True,
        "cache_hash": summary["artifacts"]["cache"]["sha256"] == build.file_sha256(args.cache),
        "pairs_hash": summary["artifacts"]["pairs"]["sha256"] == build.file_sha256(args.pairs),
        "source_hashes_current": all(
            item["sha256"] == build.file_sha256(item["path"])
            for item in summary["sources"].values()
        ),
        "exclusion_hashes_current": all(
            item["sha256"] == build.file_sha256(item["path"])
            for item in summary["exclusions"]
        ),
        "exclusion_manifest_exact": summary["exclusions"] == expected_exclusions,
        "state_only_exclusion_manifest_exact": (
            summary["state_only_exclusions"] == expected_state_only_exclusions
        ),
        "state_disjoint": not actual_states.intersection(
            excluded_states.union(evaluation_states)
        ),
        "load_disjoint": not actual_loads.intersection(excluded_loads),
        "deterministic_selected_manifest": (
            summary["pairs"]["manifest"] == expected_manifest
        ),
        "deterministic_pair_rows": (
            [canonical(row) for row in rows]
            == [canonical(row) for row in expected_rows]
        ),
        "pair_endpoints_exact": all(
            len(values) == 2
            and {row["pair_side"] for row in values} == {"left", "right"}
            for values in pair_groups.values()
        ),
        "one_language_template_per_endpoint": all(
            row["instruction_style"] == "fresh_confirmation"
            and row["template_id"].startswith("fresh:")
            for row in rows
        ),
        "oracle_never_in_native_state_or_instruction": all(
            "oracle_structured_instruction" not in row["state_text"]
            and "desired_action" not in row["instruction_text"]
            for row in rows
        ),
        "no_training_or_model_selection": (
            summary.get("training_performed") is False
            and summary.get("model_loaded") is False
            and summary.get("model_scores_used") is False
        ),
    }
    result = {
        "msg": "GridRank fresh dynamic confirmation cached audit",
        "schema": SCHEMA,
        "audit_pass": all(checks.values()),
        "checks": checks,
        "summary_sha256": build.file_sha256(args.summary),
        "artifact_sha256": {
            "cache": build.file_sha256(args.cache),
            "pairs": build.file_sha256(args.pairs),
        },
        "recomputed_pair_clusters": len(expected_manifest),
        "recomputed_primary_pair_clusters": sum(
            item["pair_type"] == build.PRIMARY_PAIR_TYPE for item in expected_manifest
        ),
    }
    if args.mode == "build":
        with open(output, "x", encoding="utf-8", newline="\n") as handle:
            json.dump(result, handle, ensure_ascii=False, indent=2, sort_keys=True)
            handle.write("\n")
    else:
        stored = json.load(open(output, encoding="utf-8"))
        if stored != result:
            raise RuntimeError("stored fresh-confirmation audit no longer recomputes exactly")
    print(json.dumps(result, ensure_ascii=False))
    if not result["audit_pass"]:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
