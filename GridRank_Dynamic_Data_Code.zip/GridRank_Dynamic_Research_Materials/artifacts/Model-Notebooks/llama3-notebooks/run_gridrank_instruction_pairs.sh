#!/usr/bin/env bash
set -euo pipefail

CURRENT_STAGE="bootstrap"
on_exit() {
  local rc=$?
  trap - EXIT
  if (( rc != 0 )); then
    printf '{"msg":"GridRank strong instruction-pair runner failure","stage":"%s","coverage_pass":false,"exit_code":%d}\n' \
      "$CURRENT_STAGE" "$rc"
  fi
  exit "$rc"
}
trap on_exit EXIT

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"
export CUDA_VISIBLE_DEVICES=""
export HF_HUB_OFFLINE=1
export TRANSFORMERS_OFFLINE=1
export OMP_NUM_THREADS=4

resolve_executable() {
  local requested="$1"
  if [[ "$requested" == */* ]]; then
    [[ -x "$requested" ]] && printf '%s\n' "$requested"
  else
    command -v -- "$requested"
  fi
}
PYTHON_BIN="$(resolve_executable "${TRAIN_PYTHON:-python}")" || exit 2

TAG="${TAG:-gridrank_instruction_pairs_v2_20260809}"
[[ "$TAG" =~ ^[A-Za-z0-9][A-Za-z0-9._-]*$ ]] || {
  echo "invalid TAG" >&2; exit 2;
}
TRAIN_CACHE="${TRAIN_CACHE:-gridrank_select_confirm_v1_20260725_offline_train.jsonl}"
VALIDATION_CACHE_A="${VALIDATION_CACHE_A:-gridrank_select_extension_v2_20260726_offline_lock.jsonl}"
VALIDATION_CACHE_B="${VALIDATION_CACHE_B:-gridrank_feedback_gate_v1_final_20260721_offline_train.jsonl}"
TRAIN_OUT="${TRAIN_OUT:-${TAG}_train.jsonl}"
VALIDATION_OUT="${VALIDATION_OUT:-${TAG}_validation.jsonl}"
SUMMARY_OUT="${SUMMARY_OUT:-${TAG}_summary.json}"

for path in \
  build_gridrank_instruction_pairs.py \
  verify_gridrank_instruction_pairs.py \
  ../../docs/GRIDRANK_STRONG_INSTRUCTION_PAIRS_PROTOCOL.md \
  "$TRAIN_CACHE" "$VALIDATION_CACHE_A" "$VALIDATION_CACHE_B"; do
  test -f "$path" || { echo "missing instruction-pair input: $path" >&2; exit 2; }
done

CURRENT_STAGE="dependency_regressions"
echo "=== 1/3 DEPENDENCY-LIGHT STRONG-PAIR REGRESSIONS ==="
"$PYTHON_BIN" -B verify_gridrank_instruction_pairs.py

CURRENT_STAGE="cached_pair_build"
echo "=== 2/3 BUILD OUTCOME-INFORMED COUNTERFACTUAL PAIRS FROM CACHED AC PHYSICS ==="
existing=0
for path in "$TRAIN_OUT" "$VALIDATION_OUT" "$SUMMARY_OUT"; do
  [[ -e "$path" ]] && existing=$((existing + 1))
done
if (( existing == 0 )); then
  "$PYTHON_BIN" -B build_gridrank_instruction_pairs.py \
    --train_cache "$TRAIN_CACHE" \
    --validation_cache "$VALIDATION_CACHE_A" "$VALIDATION_CACHE_B" \
    --train_out "$TRAIN_OUT" \
    --validation_out "$VALIDATION_OUT" \
    --summary_out "$SUMMARY_OUT"
elif (( existing != 3 )); then
  echo "partial instruction-pair outputs exist; refusing ambiguous reuse" >&2
  exit 2
else
  echo "all locked instruction-pair outputs exist; verifying without rebuilding"
fi

CURRENT_STAGE="artifact_audit"
echo "=== 3/3 VERIFY PAIR STRENGTH, SPLIT ISOLATION, AND CACHED BASELINES ==="
"$PYTHON_BIN" -B verify_gridrank_instruction_pairs.py --summary "$SUMMARY_OUT"

echo "=== GRIDRANK STRONG INSTRUCTION-PAIR CPU GATE PASS; GPU NOT STARTED ==="
