"""Gridrank dynamic llm utilities."""

from __future__ import annotations

from typing import Iterable, Sequence


POSITIVE_TOKEN = "YES"
NEGATIVE_TOKEN = "NO"

CARDS = (
    {
        "card_id": "loss_unconstrained",
        "objective": "loss",
        "hard_constraint": False,
        "description": "Prioritize active-power loss reduction; no named branch restriction applies.",
    },
    {
        "card_id": "voltage_unconstrained",
        "objective": "voltage",
        "hard_constraint": False,
        "description": "Prioritize weakest-bus voltage improvement; no named branch restriction applies.",
    },
    {
        "card_id": "loss_maintenance",
        "objective": "loss",
        "hard_constraint": True,
        "description": "Prioritize active-power loss reduction and obey every explicitly named unavailable-branch restriction.",
    },
    {
        "card_id": "voltage_maintenance",
        "objective": "voltage",
        "hard_constraint": True,
        "description": "Prioritize weakest-bus voltage improvement and obey every explicitly named unavailable-branch restriction.",
    },
)


def card_ids() -> list[str]:
    return [card["card_id"] for card in CARDS]


def card_index(card_id: str) -> int:
    values = card_ids()
    if card_id not in values:
        raise ValueError(f"unknown semantic card: {card_id}")
    return values.index(card_id)


def oracle_card_id(row: dict) -> str:
    

    value = row["oracle_structured_instruction"]
    objective = str(value["objective"])
    constrained = bool(value["hard_constraint"])
    suffix = "maintenance" if constrained else "unconstrained"
    return f"{objective}_{suffix}"


def card_question(row: dict, card: dict) -> str:
    instruction = str(row.get("instruction_text", "")).strip()
    if not instruction:
        raise ValueError("instruction_text is required")
    if card.get("card_id") not in card_ids():
        raise ValueError("invalid semantic card")
    return (
        "You are interpreting a distribution-grid operator directive.\n\n"
        "Operator directive:\n"
        f"{instruction}\n\n"
        "Candidate interpretation:\n"
        f"{card['description']}\n\n"
        "Does the candidate interpretation faithfully match the directive? "
        f"Answer {POSITIVE_TOKEN} or {NEGATIVE_TOKEN}."
    )


def render_card_prompt(tokenizer, row: dict, card: dict) -> str:
    question = card_question(row, card)
    if getattr(tokenizer, "chat_template", None):
        return tokenizer.apply_chat_template(
            [{"role": "user", "content": question}],
            tokenize=False,
            add_generation_prompt=True,
        )
    return f"<|user|>\n{question}</s>\n<|assistant|>\n"


def resolve_preference_token_ids(tokenizer) -> tuple[int, int]:
    values = []
    for surface in (POSITIVE_TOKEN, NEGATIVE_TOKEN):
        encoded = tokenizer.encode(surface, add_special_tokens=False)
        if len(encoded) != 1:
            raise RuntimeError(
                f"readout token must be one tokenizer token: {surface!r} -> {encoded}"
            )
        values.append(int(encoded[0]))
    if values[0] == values[1]:
        raise RuntimeError("YES/NO token IDs are identical")
    return values[0], values[1]


def _chunks(values: Sequence, size: int) -> Iterable[Sequence]:
    if size <= 0:
        raise ValueError("card_batch_size must be positive")
    for offset in range(0, len(values), size):
        yield values[offset : offset + size]


def card_scores(
    model,
    tokenizer,
    row: dict,
    *,
    max_length: int,
    card_batch_size: int,
    require_grad: bool,
    cards: Sequence[dict] = CARDS,
):
    

    import torch

    requested = [card["card_id"] for card in cards]
    canonical = card_ids()
    if (
        not requested
        or len(requested) != len(set(requested))
        or any(value not in canonical for value in requested)
        or requested != sorted(requested, key=canonical.index)
    ):
        raise ValueError("semantic-card order must be a canonical nonempty subset")
    positive_id, negative_id = resolve_preference_token_ids(tokenizer)
    device = next(model.parameters()).device
    old_truncation = tokenizer.truncation_side
    old_padding = tokenizer.padding_side
    tokenizer.truncation_side = "left"
    tokenizer.padding_side = "right"
    output = []
    try:
        for chunk in _chunks(list(cards), card_batch_size):
            texts = [render_card_prompt(tokenizer, row, card) for card in chunk]
            encoded = tokenizer(
                texts,
                return_tensors="pt",
                padding=True,
                truncation=True,
                max_length=max_length,
                add_special_tokens=False,
            )
            encoded = {key: value.to(device) for key, value in encoded.items()}
            context = torch.enable_grad() if require_grad else torch.no_grad()
            with context:
                kwargs = {"use_cache": False, "return_dict": True}
                if len(chunk) == 1:
                    kwargs["num_logits_to_keep"] = 1
                result = model(**encoded, **kwargs)
                if len(chunk) == 1:
                    logits = result.logits[:, 0].float()
                else:
                    last = encoded["attention_mask"].sum(dim=1).long() - 1
                    batch = torch.arange(last.shape[0], device=device)
                    logits = result.logits[batch, last].float()
                output.append(logits[:, positive_id] - logits[:, negative_id])
    finally:
        tokenizer.truncation_side = old_truncation
        tokenizer.padding_side = old_padding
    scores = torch.cat(output, dim=0)
    if scores.shape != (len(cards),) or not bool(torch.isfinite(scores).all()):
        raise FloatingPointError("semantic-card scorer produced invalid scores")
    return scores


def selected_card_id(scores) -> str:
    values = [float(value) for value in scores]
    if len(values) != len(CARDS):
        raise ValueError("card score count mismatch")
    index = min(range(len(values)), key=lambda i: (-values[i], CARDS[i]["card_id"]))
    return CARDS[index]["card_id"]


def card_semantics(row: dict, card_id: str, edge_extractor) -> dict:
    card = CARDS[card_index(card_id)]
    constrained = bool(card["hard_constraint"])
    return {
        "objective": card["objective"],
        "hard_constraint": constrained,
        "forbidden_edges": edge_extractor(row["instruction_text"]) if constrained else [],
    }
