"""Audit GridRank dynamic cross topology."""

from __future__ import annotations

import argparse
import json
import math
from collections import Counter
from pathlib import Path

import gridrank_dynamic_cross_topology as grid
from build_gridrank_dynamic_cross_topology import (
    NETWORKS, PAIR_SCHEMA, SCHEMA, file_sha256,
)


AUDIT_SCHEMA = "gridrank-dynamic-cross-topology-audit-v1"


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--cache", required=True)
    parser.add_argument("--pairs", required=True)
    parser.add_argument("--summary", required=True)
    parser.add_argument("--output", required=True)
    return parser.parse_args()


def read_jsonl(path):
    return [json.loads(line) for line in open(path, encoding="utf-8") if line.strip()]


def close(a, b, tolerance=1e-8):
    if a is None or b is None:
        return a is b
    return math.isclose(float(a), float(b), rel_tol=tolerance, abs_tol=tolerance)


def replay_state(state, scenario_seed):
    actions = [item["action"] for item in state["candidates"] if item["action"] != grid.NOOP]
    anchor, outcomes = grid.score_state(
        state["simbench_code"], int(state["state_index"]), scenario_seed, actions
    )
    cached = {item["action"]: item for item in state["candidates"]}
    actual = {item["action"]: item for item in outcomes}
    mismatches = []
    for action in actions:
        left, right = cached[action], actual[action]
        checks = {
            "feedback_valid": bool(left["feedback_valid"]) == bool(right["feedback_valid"]),
            "feasible": bool(left["feasible"]) == bool(right["feasible"]),
            "reduction_pct": close(left["reduction_pct"], right["reduction_pct"]),
            "candidate_loss_kw": close(left["candidate_loss_kw"], right["loss_kw"]),
            "candidate_min_vm_pu": close(left["candidate_min_vm_pu"], right["min_vm_pu"]),
            "candidate_max_vm_pu": close(left["candidate_max_vm_pu"], right["max_vm_pu"]),
        }
        if not all(checks.values()):
            mismatches.append({"action": action, "failed": [key for key, value in checks.items() if not value]})
    noop = cached[grid.NOOP]
    anchor_checks = {
        "feedback_valid": bool(noop["feedback_valid"]) == bool(anchor["feedback_valid"]),
        "feasible": bool(noop["feasible"]) == bool(anchor["feasible"]),
        "anchor_loss_kw": close(noop["anchor_loss_kw"], anchor["loss_kw"]),
        "anchor_min_vm_pu": close(noop["anchor_min_vm_pu"], anchor["min_vm_pu"]),
    }
    return {
        "network": state["network_id"],
        "physical_state_sha256": state["physical_state_sha256"],
        "candidate_count": len(actions),
        "anchor_checks": anchor_checks,
        "mismatches": mismatches,
        "pass": all(anchor_checks.values()) and not mismatches,
        "power_flow_calls": len(actions) + 1,
    }


def main():
    args = parse_args()
    output = Path(args.output)
    if output.exists():
        raise FileExistsError(f"refusing to overwrite audit: {output}")
    summary = json.load(open(args.summary, encoding="utf-8"))
    cache, pairs = read_jsonl(args.cache), read_jsonl(args.pairs)
    manifest = summary.get("pairs", {}).get("manifest", [])
    pair_counts = Counter(row["pair_id"] for row in pairs)
    selected_states = {item["physical_state_sha256"] for item in manifest}
    cache_index = {row["physical_state_sha256"]: row for row in cache}
    scenario_seed = int(summary["settings"]["scenario_seed"])
    expected_anchor_calls = sum(len(value) for value in summary["scan_trace"].values())
    expected_candidate_calls = len(cache) * int(summary["settings"]["nonnoop_candidates"])
    replays = []
    for network in NETWORKS:
        candidates = sorted(
            (row for row in cache if row["network_id"] == network and row["physical_state_sha256"] in selected_states),
            key=lambda row: row["physical_state_sha256"],
        )
        if candidates:
            replays.append(replay_state(candidates[0], scenario_seed))
    checks = {
        "summary_schema": summary.get("schema") == SCHEMA,
        "summary_coverage_pass": summary.get("coverage_pass") is True,
        "artifact_cache_hash": summary.get("artifacts", {}).get("cache", {}).get("sha256") == file_sha256(args.cache),
        "artifact_pairs_hash": summary.get("artifacts", {}).get("pairs", {}).get("sha256") == file_sha256(args.pairs),
        "pair_schema_strict": bool(pairs) and all(row.get("schema") == PAIR_SCHEMA for row in pairs),
        "exactly_two_rows_per_pair": bool(pair_counts) and set(pair_counts.values()) == {2},
        "manifest_pair_ids_exact": set(pair_counts) == {item["pair_id"] for item in manifest},
        "selected_states_in_cache": selected_states.issubset(cache_index),
        "sealed_partition_only": all(row.get("partition") == "sealed_cross_topology" for row in pairs),
        "network_set_exact": {str(row["network_id"]) for row in pairs} == set(NETWORKS),
        "no_33_69_rows": all(str(row["network_id"]) not in {"33", "69"} for row in pairs),
        "model_blind_construction": summary.get("model_scores_used") is False and summary.get("model_loaded") is False,
        "power_flow_call_counts_exact": summary.get("power_flow_calls") == {
            "anchor_power_flows": expected_anchor_calls,
            "candidate_power_flows": expected_candidate_calls,
            "backend_power_flows": expected_anchor_calls + expected_candidate_calls,
        },
        "oracle_metadata_not_in_instruction": all(
            "desired_action" not in row["instruction_text"] and "safe_utility" not in row["instruction_text"]
            for row in pairs
        ),
        "live_replay_one_per_network": len(replays) == len(NETWORKS),
        "live_replay_exact": bool(replays) and all(item["pass"] for item in replays),
    }
    result = {
        "msg": "GridRank sealed dynamic cross-topology provenance and live-AC audit",
        "schema": AUDIT_SCHEMA,
        "audit_pass": all(checks.values()),
        "artifacts": {
            "cache": {"path": str(Path(args.cache).resolve()), "sha256": file_sha256(args.cache)},
            "pairs": {"path": str(Path(args.pairs).resolve()), "sha256": file_sha256(args.pairs)},
            "summary": {"path": str(Path(args.summary).resolve()), "sha256": file_sha256(args.summary)},
        },
        "partition": {
            "rows": len(pairs), "pairs": len(pair_counts),
            "states": len(selected_states), "networks": sorted({row["network_id"] for row in pairs}),
        },
        "live_replay": replays,
        "checks": checks,
        "failed_checks": [key for key, value in checks.items() if not value],
    }
    output.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(result, ensure_ascii=False))
    if not result["audit_pass"]:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
