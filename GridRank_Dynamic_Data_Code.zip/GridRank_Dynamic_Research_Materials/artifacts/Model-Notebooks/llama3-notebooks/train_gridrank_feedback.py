"""Train GridRank feedback."""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import random
from collections import Counter, defaultdict
from pathlib import Path

import grpo_reward_limited as reward
from build_gridrank_feedback import NOOP, label_candidates, sanitize_feedback
from gridrank_llm import candidate_scores, rank_candidate_indices, reordered_row


DEFAULT_BASE = str(Path(__file__).resolve().parents[2] / "Meta-Llama-3.1-8B-Instruct")


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--offline_jsonl", required=True)
    parser.add_argument("--online_jsonl", required=True)
    parser.add_argument("--test_jsonl", required=True)
    parser.add_argument("--data_summary", required=True)
    parser.add_argument("--data_audit", required=True)
    parser.add_argument("--preflight_manifest", required=True)
    parser.add_argument("--resume_adapter_path", required=True)
    parser.add_argument("--output_dir", required=True)
    parser.add_argument("--base_model", default=DEFAULT_BASE)
    parser.add_argument("--physics_python", required=True)
    parser.add_argument("--physics_timeout_s", type=float, default=60.0)
    parser.add_argument("--max_length", type=int, default=1024)
    parser.add_argument("--candidate_batch_size", type=int, default=4)
    parser.add_argument("--offline_epochs", type=int, default=2)
    parser.add_argument("--online_rounds", type=int, default=2)
    parser.add_argument("--online_query_budget", type=int, default=4)
    parser.add_argument("--topk", type=int, default=4)
    parser.add_argument("--learning_rate", type=float, default=2e-6)
    parser.add_argument("--grad_accum", type=int, default=4)
    parser.add_argument("--max_grad_norm", type=float, default=1.0)
    parser.add_argument("--list_temperature", type=float, default=1.0)
    parser.add_argument("--lambda_margin", type=float, default=1.0)
    parser.add_argument("--offline_margin", type=float, default=0.5)
    parser.add_argument("--beta_reference", type=float, default=0.04)
    parser.add_argument("--online_margin", type=float, default=0.5)
    parser.add_argument("--online_offline_kl", type=float, default=0.10)
    parser.add_argument("--online_replay_mass", type=float, default=0.50)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--gradient_checkpointing", type=int, choices=[0, 1], default=1)
    parser.add_argument("--bootstrap_reps", type=int, default=2000)
    return parser.parse_args()


def file_sha256(path):
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def validate_saved_adapter(path):
    path = Path(path)
    config = path / "adapter_config.json"
    weights = path / "adapter_model.safetensors"
    result = {"path": str(path), "valid": False, "sha256": {}}
    try:
        if not config.is_file() or not weights.is_file() or weights.stat().st_size <= 0:
            result["error"] = "adapter config/weights missing or empty"
            return result
        json.loads(config.read_text(encoding="utf-8"))
        from safetensors import safe_open
        with safe_open(str(weights), framework="pt", device="cpu") as handle:
            keys = list(handle.keys())
        if not keys:
            result["error"] = "adapter safetensors contains no tensors"
            return result
        result.update({
            "valid": True,
            "tensor_count": len(keys),
            "sha256": {
                "adapter_config_json": file_sha256(config),
                "adapter_model_safetensors": file_sha256(weights),
            },
        })
    except Exception as exc:
        result["error"] = f"{type(exc).__name__}: {exc}"
    return result


def load_rows(path, partition, labelled):
    rows = [json.loads(line) for line in open(path, encoding="utf-8") if line.strip()]
    if not rows:
        raise ValueError(f"empty partition: {path}")
    seen = set()
    for row in rows:
        if row.get("partition") != partition or row["instance_id"] in seen:
            raise ValueError(f"partition/instance violation: {row.get('instance_id')}")
        seen.add(row["instance_id"])
        if labelled:
            target = [float(candidate["target_prob"]) for candidate in row["candidates"]]
            if abs(sum(target) - 1.0) > 1e-8:
                raise ValueError(f"invalid target distribution: {row['instance_id']}")
            if row["candidates"][int(row["desired_index"])]["action"] != row["desired_action"]:
                raise ValueError(f"desired candidate mismatch: {row['instance_id']}")
            optimal = [
                index for index, candidate in enumerate(row["candidates"])
                if candidate.get("is_physics_optimal") is True
            ]
            if not optimal or row.get("optimal_indices") != optimal:
                raise ValueError(f"invalid physics-optimal set: {row['instance_id']}")
        else:
            forbidden = {
                "desired_action", "desired_index", "optimal_indices", "optimal_actions",
                "instruction_utility", "safe_utility", "accepted_by_gate",
                "is_physics_optimal", "normalised_regret", "physics_rank", "target_prob",
                "reduction_pct", "feasible", "feedback_valid", "reason",
                "anchor_loss_kw", "candidate_loss_kw", "anchor_min_vm_pu",
                "candidate_min_vm_pu", "candidate_max_vm_pu",
            }
            if forbidden.intersection(row) or any(
                forbidden.intersection(candidate)
                or set(candidate) != {"action", "candidate_feature_text", "feedback_revealed"}
                or candidate.get("feedback_revealed") is not False
                for candidate in row["candidates"]
            ):
                raise ValueError(f"online stream leaked a target: {row['instance_id']}")
    return rows


def schedule_manifest(args):
    return {
        "max_length": args.max_length,
        "candidate_batch_size": args.candidate_batch_size,
        "offline_epochs": args.offline_epochs,
        "online_rounds": args.online_rounds,
        "online_query_budget": args.online_query_budget,
        "topk": args.topk,
        "learning_rate": args.learning_rate,
        "grad_accum": args.grad_accum,
        "max_grad_norm": args.max_grad_norm,
        "list_temperature": args.list_temperature,
        "lambda_margin": args.lambda_margin,
        "offline_margin": args.offline_margin,
        "beta_reference": args.beta_reference,
        "online_margin": args.online_margin,
        "online_offline_kl": args.online_offline_kl,
        "online_replay_mass": args.online_replay_mass,
        "seed": args.seed,
        "gradient_checkpointing": args.gradient_checkpointing,
        "physics_timeout_s": args.physics_timeout_s,
        "bootstrap_reps": args.bootstrap_reps,
    }


def verify_preflight(args):
    import preflight_gridrank_feedback as preflight

    manifest = json.load(open(args.preflight_manifest, encoding="utf-8"))
    audit = json.load(open(args.data_audit, encoding="utf-8"))
    if not manifest.get("preflight_pass") or not audit.get("audit_pass"):
        raise RuntimeError("CPU preflight/data audit did not pass")
    expected = {
        "offline_train": file_sha256(args.offline_jsonl),
        "online_stream": file_sha256(args.online_jsonl),
        "test": file_sha256(args.test_jsonl),
        "summary": file_sha256(args.data_summary),
        "audit": file_sha256(args.data_audit),
    }
    if manifest.get("artifact_sha256") != expected:
        raise RuntimeError("preflight artifact hashes no longer match")
    if manifest.get("training_schedule") != schedule_manifest(args):
        raise RuntimeError("training schedule differs from locked CPU preflight")
    if manifest.get("training_runtime") != preflight.training_runtime():
        raise RuntimeError("training runtime differs from locked CPU preflight")
    if manifest.get("physics_runtime") != preflight.physics_runtime(args.physics_python):
        raise RuntimeError("physics runtime differs from locked CPU preflight")
    adapter = Path(args.resume_adapter_path)
    current_adapter = {
        "adapter_config_json": file_sha256(adapter / "adapter_config.json"),
        "adapter_model_safetensors": file_sha256(adapter / "adapter_model.safetensors"),
    }
    if manifest.get("resume_adapter_sha256") != current_adapter:
        raise RuntimeError("resume adapter differs from locked CPU preflight")
    here = Path(__file__).resolve().parent
    for name, expected_hash in manifest.get("code_sha256", {}).items():
        path = here / name
        if not path.exists() or file_sha256(path) != expected_hash:
            raise RuntimeError(f"locked source changed after preflight: {name}")
    base = Path(args.base_model)
    for relative, expected in manifest.get("base_model_manifest", {}).items():
        path = base / relative
        if (not path.exists() or path.stat().st_size != int(expected["bytes"])
                or file_sha256(path) != expected["sha256"]):
            raise RuntimeError(f"base model changed after preflight: {relative}")
    return manifest


def parameter_copy(named):
    return {name: parameter.detach().float().cpu().clone() for name, parameter in named}


def restore(named, state):
    import torch
    with torch.no_grad():
        for name, parameter in named:
            parameter.copy_(state[name].to(parameter.device, dtype=parameter.dtype))


def parameter_delta(named, before):
    changed = 0
    squared = 0.0
    maximum = 0.0
    for name, parameter in named:
        delta = parameter.detach().float().cpu() - before[name]
        changed += int(bool((delta != 0).any()))
        squared += float((delta * delta).sum())
        maximum = max(maximum, float(delta.abs().max()))
    return {"changed_tensors": changed, "l2": math.sqrt(squared), "max_abs": maximum}


def adapter_initial_equality(default_lora, reference_lora):
    def canonical(name, adapter):
        return name.replace(f".{adapter}.", ".ADAPTER.")

    left = {canonical(name, "default"): parameter.detach().float().cpu()
            for name, parameter in default_lora}
    right = {canonical(name, "reference"): parameter.detach().float().cpu()
             for name, parameter in reference_lora}
    if set(left) != set(right):
        return {"same_tensor_set": False, "changed_tensors": None, "max_abs": None}
    deltas = [(left[name] - right[name]).abs() for name in left]
    return {
        "same_tensor_set": True,
        "changed_tensors": sum(bool((delta != 0).any()) for delta in deltas),
        "max_abs": max((float(delta.max()) for delta in deltas), default=0.0),
    }


def gradient_audit(default_lora, reference_lora):
    import torch
    gradients = [parameter.grad for _, parameter in default_lora if parameter.grad is not None]
    return {
        "gradient_tensors": len(gradients),
        "nonzero_gradient_tensors": sum(bool(torch.any(value != 0)) for value in gradients),
        "finite": all(bool(torch.isfinite(value).all()) for value in gradients),
        "reference_gradient_tensors": sum(parameter.grad is not None for _, parameter in reference_lora),
    }


def add_row_weights(rows):
    flags = [row["desired_action"] != NOOP for row in rows]
    counts = {flag: sum(value == flag for value in flags) for flag in (False, True)}
    weights = {
        flag: (len(rows) / (2.0 * counts[flag]) if counts[flag] else 1.0)
        for flag in (False, True)
    }
    output = []
    for row, flag in zip(rows, flags):
        item = dict(row)
        item["_row_weight"] = weights[flag]
        output.append(item)
    return output


def score_row(model, tokenizer, row, args, require_grad, adapter="default"):
    model.set_adapter(adapter)
    return candidate_scores(
        model, tokenizer, row, max_length=args.max_length,
        candidate_batch_size=args.candidate_batch_size, require_grad=require_grad,
    )


def reference_score_cache(model, tokenizer, rows, args):
    cache = {}
    for row in rows:
        cache[row["instance_id"]] = score_row(
            model, tokenizer, row, args, False, adapter="reference"
        ).detach().float().cpu()
    model.set_adapter("default")
    return cache


def policy_score_cache(model, tokenizer, rows, args):
    cache = {}
    for row in rows:
        cache[row["instance_id"]] = score_row(
            model, tokenizer, row, args, False, adapter="default"
        ).detach().float().cpu()
    return cache


def offline_objective(scores, row, reference_scores, args):
    import torch
    import torch.nn.functional as functional

    target = torch.tensor(
        [float(candidate["target_prob"]) for candidate in row["candidates"]],
        device=scores.device, dtype=torch.float32,
    )
    scaled = scores.float() / float(args.list_temperature)
    log_policy = torch.log_softmax(scaled, dim=-1)
    listwise = -(target * log_policy).sum()
    optimal = [int(index) for index in row["optimal_indices"]]
    negatives = [index for index in range(len(scores)) if index not in set(optimal)]
    positive_score = torch.stack([scores[index].float() for index in optimal]).max()
    if negatives:
        negative_score = torch.stack([scores[index].float() for index in negatives]).max()
        gap = positive_score - negative_score
        margin = functional.softplus(float(args.offline_margin) - gap)
    else:
        gap = positive_score.new_zeros(())
        margin = positive_score.new_zeros(())
    reference_log = torch.log_softmax(
        reference_scores.to(scores.device).float() / float(args.list_temperature), dim=-1
    )
    reference_policy = reference_log.exp()
    kl = (reference_policy * (reference_log - log_policy)).sum()
    supervised = float(row.get("_row_weight", 1.0)) * (
        listwise + float(args.lambda_margin) * margin
    )
    total = supervised + float(args.beta_reference) * kl
    if not bool(torch.isfinite(total)):
        raise FloatingPointError(f"non-finite offline objective: {row['instance_id']}")
    return {"total": total, "listwise": listwise, "margin": margin, "kl": kl, "gap": gap}


def optimizer_step(optimizer, parameters, max_norm):
    import torch
    norm = torch.nn.utils.clip_grad_norm_(parameters, max_norm, error_if_nonfinite=True)
    optimizer.step()
    optimizer.zero_grad(set_to_none=True)
    return float(norm)


def train_offline(model, tokenizer, rows, references, default_lora, reference_lora, args):
    import torch

    parameters = [parameter for _, parameter in default_lora]
    optimizer = torch.optim.AdamW(parameters, lr=args.learning_rate, weight_decay=0.0)
    rng = random.Random(args.seed + 101)
    history = []
    first_gradient = None
    optimizer_steps = 0
    for epoch in range(1, args.offline_epochs + 1):
        schedule = list(rows)
        rng.shuffle(schedule)
        optimizer.zero_grad(set_to_none=True)
        records = []
        for micro, row in enumerate(schedule, start=1):
            scores = score_row(model, tokenizer, row, args, True)
            terms = offline_objective(scores, row, references[row["instance_id"]], args)
            (terms["total"] / args.grad_accum).backward()
            if first_gradient is None:
                first_gradient = gradient_audit(default_lora, reference_lora)
                if (
                    first_gradient["nonzero_gradient_tensors"] <= 0
                    or not first_gradient["finite"]
                    or first_gradient["reference_gradient_tensors"] != 0
                ):
                    raise RuntimeError(f"offline first-gradient audit failed: {first_gradient}")
            records.append({key: float(value.detach()) for key, value in terms.items()})
            if micro % args.grad_accum == 0:
                optimizer_step(optimizer, parameters, args.max_grad_norm)
                optimizer_steps += 1
        remainder = len(schedule) % args.grad_accum
        if remainder:
            scale = args.grad_accum / remainder
            for parameter in parameters:
                if parameter.grad is not None:
                    parameter.grad.mul_(scale)
            optimizer_step(optimizer, parameters, args.max_grad_norm)
            optimizer_steps += 1
        history.append({
            "epoch": epoch,
            **{key: sum(record[key] for record in records) / len(records)
               for key in ("total", "listwise", "margin", "kl", "gap")},
        })
    return {"history": history, "first_gradient": first_gradient, "optimizer_steps": optimizer_steps}


def _safe_key(candidate):
    value = candidate.get("safe_utility")
    return (
        -math.inf if value is None else float(value),
        candidate["action"] == NOOP,
        candidate["action"],
    )


def _gate_eligible(candidate):
    return bool(candidate.get("accepted_by_gate")) and candidate.get("safe_utility") is not None


def record_from_scores(row, scores, topk):
    values = [float(value) for value in scores]
    order = rank_candidate_indices(values, row)
    selected = order[0]
    noop = next(index for index, candidate in enumerate(row["candidates"]) if candidate["action"] == NOOP)
    raw_topk = order[:topk]
    queried = list(dict.fromkeys([*raw_topk, noop]))
    accepted = [index for index in queried if _gate_eligible(row["candidates"][index])]
    safe = max(accepted, key=lambda index: _safe_key(row["candidates"][index])) if accepted else noop
    optimal = set(int(index) for index in row["optimal_indices"])
    safe_candidate = row["candidates"][safe]
    candidate_backend_queries = sum(index != noop for index in queried)
    backend_power_flow_requests = 1 + candidate_backend_queries
    return {
        "instance_id": row["instance_id"],
        "network": str(row["network_id"]),
        "load_id": row["load_id"],
        "physical_state_sha256": row["physical_state_sha256"],
        "instruction_id": row["instruction_id"],
        "candidate_count": len(values),
        "top1_index": selected,
        "top1_action": row["candidates"][selected]["action"],
        "top1_correct": selected in optimal,
        "top1_feasible": bool(row["candidates"][selected].get("feasible")),
        "top1_regret": float(row["candidates"][selected]["normalised_regret"]),
        "topk_indices": raw_topk,
        "gate_query_indices": queried,
        "topk_oracle_recall": bool(optimal.intersection(raw_topk)),
        "gate_shortlist_oracle_recall": bool(optimal.intersection(queried)),
        "safe_index": safe,
        "safe_action": safe_candidate["action"],
        "safe_oracle": safe in optimal,
        "safe_regret": float(safe_candidate["normalised_regret"]),
        "safe_feasible": bool(safe_candidate.get("feasible")),
        "safe_accepted": bool(safe_candidate.get("accepted_by_gate")),
        "safe_reduction_pct": (
            0.0 if safe_candidate["action"] == NOOP
            else float(safe_candidate.get("reduction_pct") or 0.0)
        ),
        "logical_simulator_queries": len(queried),
        "candidate_backend_queries": candidate_backend_queries,
        "backend_power_flow_requests": backend_power_flow_requests,
        "full_pool_backend_power_flows": 1 + len(values),
        "call_reduction_rate": 1.0 - backend_power_flow_requests / (1 + len(values)),
        "scores": values,
    }


def evaluate(model, tokenizer, rows, args):
    records = []
    for row in rows:
        scores = score_row(model, tokenizer, row, args, False).detach().float().cpu().tolist()
        records.append(record_from_scores(row, scores, args.topk))
    return records


def live_gate_replay(rows, records, args):
    

    if [row["instance_id"] for row in rows] != [row["instance_id"] for row in records]:
        raise RuntimeError("live-gate row order mismatch")
    output = []
    for row, record in zip(rows, records):
        noop_index = next(
            index for index, candidate in enumerate(row["candidates"])
            if candidate["action"] == NOOP
        )
        topk = list(record["topk_indices"])
        candidate_indices = [index for index in topk if index != noop_index]
        backend_actions = [row["candidates"][index]["action"] for index in candidate_indices]
        if not backend_actions:
            backend_actions = [NOOP]
        error = None
        try:
            evaluated = reward.score_completions(
                row["state_text"], backend_actions, return_detail=True,
                action_mode="delta", physics_backend="pandapower-subprocess",
                physics_python=args.physics_python,
                physics_timeout_s=args.physics_timeout_s,
            )
        except Exception as exc:
            evaluated = []
            error = f"{type(exc).__name__}: {exc}"
        if len(evaluated) != len(backend_actions):
            error = error or f"outcome count {len(evaluated)} != {len(backend_actions)}"
        selected = None
        local_candidates = []
        if error is None:
            detail = evaluated[0][2]
            noop_candidate = _noop_feedback(row, detail)
            probed = [
                sanitize_feedback(row["candidates"][index], result)
                for index, result in zip(candidate_indices, evaluated)
            ] if candidate_indices else []
            if (
                not noop_candidate["feedback_valid"]
                or not noop_candidate["feasible"]
                or not all(candidate["feedback_valid"] for candidate in probed)
            ):
                error = "invalid or non-operational live gate feedback"
            else:
                _, local_candidates = label_candidates(
                    row["instruction_id"], [noop_candidate, *probed], 0.20
                )
                accepted = [candidate for candidate in local_candidates if _gate_eligible(candidate)]
                selected = max(accepted, key=_safe_key) if accepted else noop_candidate
        if selected is None:
            selected = _noop_feedback(row, evaluated[0][2]) if evaluated else {
                "action": NOOP, "feasible": False, "accepted_by_gate": False,
                "reduction_pct": None,
            }
        output.append({
            "instance_id": row["instance_id"],
            "network": str(row["network_id"]),
            "instruction_id": row["instruction_id"],
            "topk_indices": topk,
            "candidate_backend_actions": backend_actions,
            "anchor_power_flows": 1,
            "candidate_power_flows": len(backend_actions),
            "backend_power_flows": 1 + len(backend_actions),
            "feedback_valid": error is None,
            "fail_closed": error is not None,
            "error": error,
            "selected_action": selected["action"],
            "selected_feasible": bool(selected.get("feasible")),
            "selected_accepted": bool(selected.get("accepted_by_gate")),
            "selected_reduction_pct": (
                0.0 if selected["action"] == NOOP
                else float(selected.get("reduction_pct") or 0.0)
            ),
            "cached_action": record["safe_action"],
            "matches_cached_gate": error is None and selected["action"] == record["safe_action"],
        })
    return {
        "rows": output,
        "summary": {
            "n": len(output),
            "valid_rate": sum(item["feedback_valid"] for item in output) / len(output),
            "fail_closed_rows": sum(item["fail_closed"] for item in output),
            "matches_cached_rate": sum(item["matches_cached_gate"] for item in output) / len(output),
            "selected_feasible_rate": sum(item["selected_feasible"] for item in output) / len(output),
            "anchor_power_flows": sum(item["anchor_power_flows"] for item in output),
            "candidate_power_flows": sum(item["candidate_power_flows"] for item in output),
            "backend_power_flows": sum(item["backend_power_flows"] for item in output),
        },
    }


def summarise(records):
    n = len(records)
    return {
        "n": n,
        "base_states": len({row["physical_state_sha256"] for row in records}),
        "loads": len({row["load_id"] for row in records}),
        "top1_accuracy": sum(row["top1_correct"] for row in records) / n,
        "top1_feasible_rate": sum(row["top1_feasible"] for row in records) / n,
        "top1_regret_mean": sum(row["top1_regret"] for row in records) / n,
        "topk_oracle_recall": sum(row["topk_oracle_recall"] for row in records) / n,
        "gate_shortlist_oracle_recall": sum(
            row["gate_shortlist_oracle_recall"] for row in records
        ) / n,
        "safe_oracle_rate": sum(row["safe_oracle"] for row in records) / n,
        "safe_regret_mean": sum(row["safe_regret"] for row in records) / n,
        "safe_feasible_rate": sum(row["safe_feasible"] for row in records) / n,
        "safe_accept_rate": sum(row["safe_action"] != NOOP for row in records) / n,
        "safe_reduction_pct_mean": sum(row["safe_reduction_pct"] for row in records) / n,
        "logical_simulator_queries_mean": sum(row["logical_simulator_queries"] for row in records) / n,
        "candidate_backend_queries_mean": sum(row["candidate_backend_queries"] for row in records) / n,
        "backend_power_flow_requests_mean": sum(
            row["backend_power_flow_requests"] for row in records
        ) / n,
        "call_reduction_rate_mean": sum(row["call_reduction_rate"] for row in records) / n,
    }


def breakdown(records, key):
    return {
        value: summarise([row for row in records if row[key] == value])
        for value in sorted({row[key] for row in records})
    }


def paired_improvement(before, after, reps, seed):
    if [row["instance_id"] for row in before] != [row["instance_id"] for row in after]:
        raise RuntimeError("paired evaluation row order changed")
    deltas = [old["safe_regret"] - new["safe_regret"] for old, new in zip(before, after)]
    groups = defaultdict(list)
    for delta, row in zip(deltas, before):
        groups[(row["network"], row["physical_state_sha256"])].append(delta)
    cluster_values = [sum(values) / len(values) for values in groups.values()]
    rng = random.Random(seed)
    samples = []
    for _ in range(reps):
        draw = [cluster_values[rng.randrange(len(cluster_values))] for _ in cluster_values]
        samples.append(sum(draw) / len(draw))
    samples.sort()
    lower = samples[int(0.025 * (len(samples) - 1))]
    upper = samples[int(0.975 * (len(samples) - 1))]
    return {
        "n_rows": len(deltas),
        "n_state_clusters": len(cluster_values),
        "safe_regret_improvement_mean": sum(deltas) / len(deltas),
        "state_cluster_improvement_mean": sum(cluster_values) / len(cluster_values),
        "state_cluster_bootstrap_ci95": [lower, upper],
        "rows_better": sum(value > 1e-12 for value in deltas),
        "rows_worse": sum(value < -1e-12 for value in deltas),
        "rows_tied": sum(abs(value) <= 1e-12 for value in deltas),
    }


def online_query_indices(scores, row, budget, seed):
    values = [float(value) for value in scores]
    noop = next(index for index, candidate in enumerate(row["candidates"]) if candidate["action"] == NOOP)
    eligible = [index for index in range(len(values)) if index != noop]
    if not eligible:
        return []
    order = rank_candidate_indices(values, row)
    selected = [index for index in order if index != noop][:2]
    remaining = [index for index in eligible if index not in selected]
    if remaining:
        uncertainty = min(
            remaining,
            key=lambda index: (
                abs(values[index] - values[noop]), row["candidates"][index]["action"]
            ),
        )
        selected.append(uncertainty)
    remaining = [index for index in eligible if index not in selected]
    if remaining:
        explore = min(
            remaining,
            key=lambda index: hashlib.sha256(
                f"{seed}|{row['instance_id']}|{row['candidates'][index]['action']}".encode("utf-8")
            ).digest(),
        )
        selected.append(explore)
    if len(selected) < min(budget, len(eligible)):
        for index in sorted(eligible, key=lambda value: row["candidates"][value]["action"]):
            if index not in selected:
                selected.append(index)
            if len(selected) >= min(budget, len(eligible)):
                break
    return selected[:budget]


def _noop_feedback(row, detail):
    noop = next(candidate for candidate in row["candidates"] if candidate["action"] == NOOP)
    output = dict(noop)
    minimum = detail.get("anchor_min_vm_pu")
    maximum = detail.get("anchor_max_vm_pu")
    valid = (
        bool(detail.get("feedback_valid"))
        and detail.get("anchor_loss_kw") is not None
        and minimum is not None and maximum is not None
        and all(math.isfinite(float(value)) for value in (
            detail.get("anchor_loss_kw"), minimum, maximum
        ))
    )
    output.update({
        "feedback_revealed": True,
        "feedback_valid": bool(valid),
        "feasible": bool(valid and reward.VMIN <= float(minimum) <= reward.VMAX
                         and reward.VMIN <= float(maximum) <= reward.VMAX),
        "reason": "ok" if valid else "invalid_anchor",
        "reduction_pct": 0.0 if valid else None,
        "anchor_loss_kw": detail.get("anchor_loss_kw"),
        "candidate_loss_kw": detail.get("anchor_loss_kw"),
        "anchor_min_vm_pu": minimum,
        "candidate_min_vm_pu": minimum,
        "candidate_max_vm_pu": maximum,
    })
    return output


def collect_online_feedback(
    model, tokenizer, rows, frozen_offline_scores, args, round_index,
):
    feedback, pairs = [], []
    counters = Counter()
    for row in rows:
        scores = score_row(model, tokenizer, row, args, False).detach().float().cpu()
        queried = online_query_indices(
            scores, row, args.online_query_budget,
            args.seed + 10000 * round_index,
        )
        expected_budget = min(
            args.online_query_budget,
            sum(candidate["action"] != NOOP for candidate in row["candidates"]),
        )
        if len(queried) != expected_budget:
            raise RuntimeError(f"online query budget mismatch: {row['instance_id']}")
        actions = [row["candidates"][index]["action"] for index in queried]
        counters["attempted_rows"] += 1
        counters["attempted_logical_queries"] += len(actions)
        counters["attempted_anchor_power_flows"] += 1
        counters["attempted_candidate_power_flows"] += len(actions)
        try:
            evaluated = reward.score_completions(
                row["state_text"], actions, return_detail=True, action_mode="delta",
                physics_backend="pandapower-subprocess", physics_python=args.physics_python,
                physics_timeout_s=args.physics_timeout_s,
            )
        except Exception as exc:
            counters["backend_exception_rows"] += 1
            feedback.append({
                "round": round_index, "instance_id": row["instance_id"],
                "queried_indices": queried, "queried_actions": actions,
                "scores": scores.tolist(), "invalid_feedback": True,
                "error": f"{type(exc).__name__}: {exc}",
            })
            continue
        if len(evaluated) != len(actions):
            counters["outcome_count_mismatch_rows"] += 1
            feedback.append({
                "round": round_index, "instance_id": row["instance_id"],
                "queried_indices": queried, "queried_actions": actions,
                "scores": scores.tolist(), "invalid_feedback": True,
                "error": f"outcome count {len(evaluated)} != {len(actions)}",
            })
            continue
        counters["successful_rows"] += 1
        counters["successful_logical_queries"] += len(evaluated)
        counters["successful_anchor_power_flows"] += 1
        counters["successful_candidate_power_flows"] += len(evaluated)
        probed = [sanitize_feedback(row["candidates"][index], result)
                  for index, result in zip(queried, evaluated)]
        if not all(candidate["feedback_valid"] for candidate in probed):
            counters["invalid_feedback_rows"] += 1
            feedback.append({
                "round": round_index, "instance_id": row["instance_id"],
                "queried_indices": queried, "scores": scores.tolist(),
                "invalid_feedback": True,
            })
            continue
        noop_candidate = _noop_feedback(row, evaluated[0][2])
        if not noop_candidate["feedback_valid"] or not noop_candidate["feasible"]:
            counters["invalid_anchor_rows"] += 1
            feedback.append({
                "round": round_index, "instance_id": row["instance_id"],
                "queried_indices": queried, "queried_actions": actions,
                "scores": scores.tolist(), "invalid_feedback": True,
                "error": "online no-op anchor is not operational",
            })
            continue
        local_candidates = [noop_candidate, *probed]
        _, labelled = label_candidates(row["instruction_id"], local_candidates, 0.20)
        by_action = {candidate["action"]: candidate for candidate in labelled}
        global_top = rank_candidate_indices(scores, row)[0]
        top_action = row["candidates"][global_top]["action"]
        local_top = by_action.get(top_action)
        safe = [candidate for candidate in labelled if _gate_eligible(candidate)]
        best = max(safe, key=_safe_key) if safe else None
        pair = None
        if local_top is not None and not _gate_eligible(local_top) and best is not None:
            pair = (best["action"], top_action, "safe_over_unsafe_or_nonpositive")
        elif (
            local_top is not None and best is not None
            and float(best["safe_utility"]) > float(local_top["safe_utility"]) + 1e-9
        ):
            pair = (best["action"], top_action, "strictly_better_probe_over_policy_top")
        feedback_row = {
            "round": round_index,
            "instance_id": row["instance_id"],
            "network": row["network_id"],
            "load_id": row["load_id"],
            "physical_state_sha256": row["physical_state_sha256"],
            "instruction_id": row["instruction_id"],
            "queried_indices": queried,
            "queried_actions": actions,
            "policy_scores": scores.tolist(),
            "policy_top_action": top_action,
            "probed_candidates": labelled,
            "pair": pair,
            "invalid_feedback": False,
        }
        feedback.append(feedback_row)
        if pair is not None:
            better_action, worse_action, pair_type = pair
            better_index = next(index for index, candidate in enumerate(row["candidates"])
                                if candidate["action"] == better_action)
            worse_index = next(index for index, candidate in enumerate(row["candidates"])
                               if candidate["action"] == worse_action)
            pairs.append({
                "row": row,
                "better_index": better_index,
                "worse_index": worse_index,
                "pair_type": pair_type,
                "offline_pair_scores": [
                    float(frozen_offline_scores[row["instance_id"]][better_index]),
                    float(frozen_offline_scores[row["instance_id"]][worse_index]),
                ],
            })
            counters[f"pair_{pair_type}"] += 1
            counters[f"pair_network_{row['network_id']}"] += 1
        counters[f"valid_network_{row['network_id']}"] += 1
        counters[f"valid_instruction_{row['instruction_id']}"] += 1
    return feedback, pairs, dict(counters)


def pair_objective(model, tokenizer, pair, args):
    import torch
    import torch.nn.functional as functional

    row = pair["row"]
    pair_row = dict(row)
    pair_row["candidates"] = [
        row["candidates"][pair["better_index"]],
        row["candidates"][pair["worse_index"]],
    ]
    scores = score_row(model, tokenizer, pair_row, args, True)
    gap = scores[0].float() - scores[1].float()
    hinge = functional.relu(float(args.online_margin) - gap)
    reference_log = torch.log_softmax(torch.tensor(
        pair["offline_pair_scores"], device=scores.device, dtype=torch.float32
    ), dim=-1)
    policy_log = torch.log_softmax(scores.float(), dim=-1)
    kl = (reference_log.exp() * (reference_log - policy_log)).sum()
    total = hinge + float(args.online_offline_kl) * kl
    if not bool(torch.isfinite(total)):
        raise FloatingPointError(f"non-finite online pair objective: {row['instance_id']}")
    return {"total": total,
            "hinge": hinge, "kl": kl, "gap": gap}


def replay_match(rows, pair, offset):
    network = str(pair["row"]["network_id"])
    instruction = pair["row"]["instruction_id"]
    matched = [row for row in rows if str(row["network_id"]) == network
               and row["instruction_id"] == instruction]
    if not matched:
        matched = rows
    return matched[offset % len(matched)]


def train_online_round(
    model, tokenizer, pairs, offline_rows, references,
    default_lora, reference_lora, args, round_index,
):
    import torch

    if not pairs:
        return {"pairs": 0, "optimizer_steps": 0, "first_gradient": None, "loss": None}
    parameters = [parameter for _, parameter in default_lora]
    optimizer = torch.optim.AdamW(parameters, lr=args.learning_rate, weight_decay=0.0)
    schedule = list(pairs)
    random.Random(args.seed + 30000 + round_index).shuffle(schedule)
    optimizer.zero_grad(set_to_none=True)
    records = []
    first_gradient = None
    optimizer_steps = 0
    for micro, pair in enumerate(schedule, start=1):
        pair_terms = pair_objective(model, tokenizer, pair, args)
        replay_row = replay_match(offline_rows, pair, micro + 1000 * round_index)
        replay_scores = score_row(model, tokenizer, replay_row, args, True)
        replay_terms = offline_objective(
            replay_scores, replay_row, references[replay_row["instance_id"]], args
        )
        total = pair_terms["total"] + float(args.online_replay_mass) * replay_terms["total"]
        (total / args.grad_accum).backward()
        if first_gradient is None:
            first_gradient = gradient_audit(default_lora, reference_lora)
            if (
                first_gradient["nonzero_gradient_tensors"] <= 0
                or not first_gradient["finite"]
                or first_gradient["reference_gradient_tensors"] != 0
            ):
                raise RuntimeError(f"online first-gradient audit failed: {first_gradient}")
        records.append({
            "total": float(total.detach()),
            "hinge": float(pair_terms["hinge"].detach()),
            "pair_kl": float(pair_terms["kl"].detach()),
            "pair_gap": float(pair_terms["gap"].detach()),
            "replay": float(replay_terms["total"].detach()),
        })
        if micro % args.grad_accum == 0:
            optimizer_step(optimizer, parameters, args.max_grad_norm)
            optimizer_steps += 1
    remainder = len(schedule) % args.grad_accum
    if remainder:
        scale = args.grad_accum / remainder
        for parameter in parameters:
            if parameter.grad is not None:
                parameter.grad.mul_(scale)
        optimizer_step(optimizer, parameters, args.max_grad_norm)
        optimizer_steps += 1
    return {
        "pairs": len(pairs),
        "pair_type_mix": dict(Counter(pair["pair_type"] for pair in pairs)),
        "optimizer_steps": optimizer_steps,
        "first_gradient": first_gradient,
        **{key: sum(record[key] for record in records) / len(records)
           for key in ("total", "hinge", "pair_kl", "pair_gap", "replay")},
    }


def pair_margin_summary(model, tokenizer, pairs, args):
    if not pairs:
        return {"n": 0, "gap_mean": None, "margin_satisfied_rate": None}
    gaps = []
    for pair in pairs:
        row = pair["row"]
        pair_row = dict(row)
        pair_row["candidates"] = [
            row["candidates"][pair["better_index"]], row["candidates"][pair["worse_index"]]
        ]
        scores = score_row(model, tokenizer, pair_row, args, False).detach().float().cpu()
        gaps.append(float(scores[0] - scores[1]))
    return {
        "n": len(gaps),
        "gap_mean": sum(gaps) / len(gaps),
        "margin_satisfied_rate": sum(value >= args.online_margin for value in gaps) / len(gaps),
    }


def shuffled_instruction_rows(rows):
    groups = defaultdict(list)
    for row in rows:
        groups[row["physical_state_sha256"]].append(row)
    output = []
    for values in groups.values():
        values = sorted(values, key=lambda row: row["instruction_id"])
        texts = [row["instruction_text"] for row in values]
        rotated = texts[1:] + texts[:1]
        for row, text in zip(values, rotated):
            item = dict(row)
            item["instruction_text"] = text
            output.append(item)
    by_id = {row["instance_id"]: row for row in output}
    return [by_id[row["instance_id"]] for row in rows]


def main():
    import torch
    import grpo_train as training

    args = parse_args()
    if args.topk <= 0 or args.online_query_budget <= 0 or args.grad_accum <= 0:
        raise SystemExit("topk/query budget/grad_accum must be positive")
    if args.offline_epochs <= 0 or args.online_rounds <= 0:
        raise SystemExit("offline_epochs and online_rounds must be positive")
    if (
        args.max_length <= 0 or args.candidate_batch_size <= 0
        or args.learning_rate <= 0 or args.max_grad_norm <= 0
        or args.list_temperature <= 0 or args.physics_timeout_s <= 0
        or args.bootstrap_reps <= 0
    ):
        raise SystemExit("length/batch/lr/norm/temperature/timeout/bootstrap must be positive")
    manifest = verify_preflight(args)
    if not torch.cuda.is_available():
        raise RuntimeError("GridRank GPU stage requires CUDA; refusing CPU/device_map fallback")
    random.seed(args.seed)
    torch.manual_seed(args.seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(args.seed)

    offline_rows = add_row_weights(load_rows(args.offline_jsonl, "offline_train", True))
    online_rows = load_rows(args.online_jsonl, "online_stream", False)
    test_rows = load_rows(args.test_jsonl, "test", True)
    if {row["physical_state_sha256"] for row in offline_rows}.intersection(
        {row["physical_state_sha256"] for row in test_rows}
    ):
        raise RuntimeError("training state leaked into held-out test")

    model, tokenizer = training.build_model_and_tokenizer(args)
    tokenizer.pad_token = tokenizer.eos_token
    model.config.pad_token_id = tokenizer.pad_token_id
    default_lora = [(name, parameter) for name, parameter in model.named_parameters()
                    if "lora_" in name and ".default." in name]
    reference_lora = [(name, parameter) for name, parameter in model.named_parameters()
                      if "lora_" in name and ".reference." in name]
    if not default_lora or not reference_lora:
        raise RuntimeError("policy/reference LoRA adapters are required")
    for _, parameter in default_lora:
        parameter.requires_grad_(True)
    for _, parameter in reference_lora:
        parameter.requires_grad_(False)

    initial_adapter_match = adapter_initial_equality(default_lora, reference_lora)
    if (
        not initial_adapter_match["same_tensor_set"]
        or initial_adapter_match["changed_tensors"] != 0
    ):
        raise RuntimeError(f"default/reference adapters differ at initialization: {initial_adapter_match}")

    initial_parameters = parameter_copy(default_lora)
    initial_reference = parameter_copy(reference_lora)
    references = reference_score_cache(model, tokenizer, offline_rows, args)
    sft_records = evaluate(model, tokenizer, test_rows, args)
    offline_train_result = train_offline(
        model, tokenizer, offline_rows, references, default_lora, reference_lora, args
    )
    offline_parameters = parameter_copy(default_lora)
    offline_delta_from_sft = parameter_delta(default_lora, initial_parameters)
    offline_records = evaluate(model, tokenizer, test_rows, args)
    frozen_offline_online_scores = policy_score_cache(model, tokenizer, online_rows, args)

    online_round_history = []
    feedback_all = []
    for round_index in range(1, args.online_rounds + 1):
        feedback, pairs, query_counts = collect_online_feedback(
            model, tokenizer, online_rows, frozen_offline_online_scores, args, round_index
        )
        before_margin = pair_margin_summary(model, tokenizer, pairs, args)
        training_result = train_online_round(
            model, tokenizer, pairs, offline_rows, references,
            default_lora, reference_lora, args, round_index,
        )
        after_margin = pair_margin_summary(model, tokenizer, pairs, args)
        feedback_all.extend(feedback)
        online_round_history.append({
            "round": round_index,
            "query_counts": query_counts,
            "feedback_rows": len(feedback),
            "pair_margin_before": before_margin,
            "training": training_result,
            "pair_margin_after": after_margin,
        })
    final_records = evaluate(model, tokenizer, test_rows, args)
    shuffled_records = evaluate(model, tokenizer, shuffled_instruction_rows(test_rows), args)
    live_gate = live_gate_replay(test_rows, final_records, args)


    permutation_rows = test_rows[: min(8, len(test_rows))]
    permutation_consistent = 0
    permutation_score_max_abs_delta = 0.0
    for row in permutation_rows:
        original = score_row(model, tokenizer, row, args, False).detach().float().cpu()
        order = list(reversed(range(len(row["candidates"]))))
        reversed_scores = score_row(
            model, tokenizer, reordered_row(row, order), args, False
        ).detach().float().cpu()
        remapped = [0.0] * len(order)
        for new_index, old_index in enumerate(order):
            remapped[old_index] = float(reversed_scores[new_index])
        permutation_score_max_abs_delta = max(
            permutation_score_max_abs_delta,
            max(abs(float(a) - float(b)) for a, b in zip(original, remapped)),
        )
        permutation_consistent += int(
            rank_candidate_indices(original, row) == rank_candidate_indices(remapped, row)
        )
    permutation_rate = permutation_consistent / len(permutation_rows)

    summaries = {
        "sft": summarise(sft_records),
        "offline": summarise(offline_records),
        "online": summarise(final_records),
        "instruction_shuffled": summarise(shuffled_records),
    }
    by_network = {
        name: breakdown(records, "network")
        for name, records in {
            "sft": sft_records, "offline": offline_records,
            "online": final_records, "instruction_shuffled": shuffled_records,
        }.items()
    }
    by_instruction = {
        name: breakdown(records, "instruction_id")
        for name, records in {
            "sft": sft_records, "offline": offline_records, "online": final_records,
        }.items()
    }
    paired = {
        "offline_vs_sft": paired_improvement(
            sft_records, offline_records, args.bootstrap_reps, args.seed + 500
        ),
        "online_vs_sft": paired_improvement(
            sft_records, final_records, args.bootstrap_reps, args.seed + 501
        ),
        "online_vs_offline": paired_improvement(
            offline_records, final_records, args.bootstrap_reps, args.seed + 502
        ),
    }
    final_delta_from_sft = parameter_delta(default_lora, initial_parameters)
    online_delta = parameter_delta(default_lora, offline_parameters)
    reference_delta = parameter_delta(reference_lora, initial_reference)
    top1_changes = sum(
        old["top1_action"] != new["top1_action"] for old, new in zip(sft_records, final_records)
    )
    any_pairs = any(round_row["training"]["pairs"] > 0 for round_row in online_round_history)
    any_pair_improvement = any(
        row["pair_margin_before"]["n"] > 0
        and row["pair_margin_after"]["gap_mean"] > row["pair_margin_before"]["gap_mean"]
        for row in online_round_history
    )
    expected_online_queries = len(online_rows) * args.online_query_budget
    online_budget_valid = all(
        row["query_counts"].get("attempted_rows", 0) == len(online_rows)
        and row["query_counts"].get("attempted_logical_queries", 0) == expected_online_queries
        and row["query_counts"].get("successful_rows", 0) == len(online_rows)
        and row["query_counts"].get("successful_logical_queries", 0) == expected_online_queries
        and row["query_counts"].get("invalid_feedback_rows", 0) == 0
        and row["query_counts"].get("invalid_anchor_rows", 0) == 0
        and row["query_counts"].get("backend_exception_rows", 0) == 0
        and row["query_counts"].get("outcome_count_mismatch_rows", 0) == 0
        for row in online_round_history
    )
    online_pair_network_coverage = all(
        sum(row["query_counts"].get(f"pair_network_{network}", 0)
            for row in online_round_history) > 0
        for network in ("33", "69")
    )
    engineering_checks = {
        "offline_lora_gradient_nonzero": bool(
            offline_train_result["first_gradient"]
            and offline_train_result["first_gradient"]["nonzero_gradient_tensors"] > 0
            and offline_train_result["first_gradient"]["finite"]
        ),
        "reference_adapter_frozen": reference_delta["changed_tensors"] == 0,
        "reference_equals_policy_at_start": initial_adapter_match["changed_tensors"] == 0,
        "lora_parameters_changed": offline_delta_from_sft["changed_tensors"] > 0,
        "heldout_ranking_changed": top1_changes > 0,
        "offline_safe_regret_improved": summaries["offline"]["safe_regret_mean"]
            < summaries["sft"]["safe_regret_mean"],
        "offline_each_network_nonnegative": all(
            by_network["offline"][network]["safe_regret_mean"]
            <= by_network["sft"][network]["safe_regret_mean"] + 1e-12
            for network in ("33", "69")
        ),
        "online_verified_pairs_exist": any_pairs,
        "online_verified_pairs_cover_both_networks": online_pair_network_coverage,
        "online_fixed_budget_all_feedback_valid": online_budget_valid,
        "online_pair_margin_improved": any_pair_improvement,
        "online_test_not_worse_than_offline": summaries["online"]["safe_regret_mean"]
            <= summaries["offline"]["safe_regret_mean"] + 1e-12,
        "online_each_network_not_worse_than_offline": all(
            by_network["online"][network]["safe_regret_mean"]
            <= by_network["offline"][network]["safe_regret_mean"] + 1e-12
            for network in ("33", "69")
        ),
        "online_each_network_not_worse_than_sft": all(
            by_network["online"][network]["safe_regret_mean"]
            <= by_network["sft"][network]["safe_regret_mean"] + 1e-12
            for network in ("33", "69")
        ),
        "online_topk_recall_each_network_nonnegative": all(
            by_network["online"][network]["topk_oracle_recall"]
            >= by_network["sft"][network]["topk_oracle_recall"] - 1e-12
            for network in ("33", "69")
        ),
        "uses_instruction_text": summaries["online"]["safe_regret_mean"]
            < summaries["instruction_shuffled"]["safe_regret_mean"],
        "safe_gate_feasible": summaries["online"]["safe_feasible_rate"] == 1.0,
        "live_topk_gate_valid": live_gate["summary"]["valid_rate"] == 1.0,
        "live_topk_gate_matches_cached": live_gate["summary"]["matches_cached_rate"] == 1.0,
        "live_topk_gate_feasible": live_gate["summary"]["selected_feasible_rate"] == 1.0,
        "candidate_order_invariant": permutation_rate == 1.0,
    }
    paper_checks = {
        "engineering_gate_pass": all(engineering_checks.values()),
        "online_strictly_improves_heldout_over_offline": summaries["online"]["safe_regret_mean"]
            < summaries["offline"]["safe_regret_mean"],
        "online_vs_offline_each_network_nonnegative": all(
            by_network["online"][network]["safe_regret_mean"]
            <= by_network["offline"][network]["safe_regret_mean"] + 1e-12
            for network in ("33", "69")
        ),
        "online_vs_sft_cluster_ci_lower_positive": paired["online_vs_sft"][
            "state_cluster_bootstrap_ci95"
        ][0] > 0.0,
        "online_vs_offline_cluster_ci_lower_positive": paired["online_vs_offline"][
            "state_cluster_bootstrap_ci95"
        ][0] > 0.0,
    }
    result = {
        "msg": "GridRank physics-distillation and online counterexample gate",
        "architecture": (
            "state + directive + candidate + deterministic non-AC features -> "
            "shared LLM YES/NO logit score; no scalar head or graph-score bypass"
        ),
        "decision_protocol": "LLM Top-k + no-op -> authoritative physics safety gate",
        "online_protocol": (
            "sealed stream; policy top2 + uncertainty1 + seeded explore1; "
            "verified pairwise counterexamples only"
        ),
        "preflight_sha256": file_sha256(args.preflight_manifest),
        "locked_manifest": manifest,
        "training_schedule": schedule_manifest(args),
        "offline_training": offline_train_result,
        "online_rounds": online_round_history,
        "parameter_delta": {
            "offline_from_sft": offline_delta_from_sft,
            "online_from_offline": online_delta,
            "final_from_sft": final_delta_from_sft,
        },
        "reference_parameter_delta": reference_delta,
        "initial_adapter_equality": initial_adapter_match,
        "heldout_top1_changed_rows": top1_changes,
        "candidate_permutation_probe_rate": permutation_rate,
        "candidate_permutation_score_max_abs_delta": permutation_score_max_abs_delta,
        "summaries": summaries,
        "by_network": by_network,
        "by_instruction": by_instruction,
        "paired": paired,
        "live_topk_gate": live_gate,
        "engineering_checks": engineering_checks,
        "paper_checks": paper_checks,
        "engineering_gate_pass": all(engineering_checks.values()),
        "paper_gate_pass": all(paper_checks.values()),
    }
    output = Path(args.output_dir)
    output.mkdir(parents=True, exist_ok=False)
    with open(output / "gridrank_online_feedback.jsonl", "w", encoding="utf-8") as handle:
        for row in feedback_all:
            handle.write(json.dumps(row, ensure_ascii=False) + "\n")
    preliminary_pass = result["engineering_gate_pass"]
    adapter_save = {"attempted": preliminary_pass, "valid": False}
    if preliminary_pass:
        try:
            save_returned = bool(training.save_policy_adapter(
                model, output / "adapter", args.online_rounds
            ))
            adapter_save = validate_saved_adapter(output / "adapter")
            adapter_save["attempted"] = True
            adapter_save["save_function_returned"] = save_returned
            adapter_save["valid"] = bool(adapter_save["valid"] and save_returned)
        except Exception as exc:
            adapter_save = {
                "attempted": True, "valid": False,
                "error": f"{type(exc).__name__}: {exc}",
            }
    engineering_checks["adapter_saved_and_hashed"] = bool(adapter_save["valid"])
    paper_checks["adapter_saved_and_hashed"] = bool(adapter_save["valid"])
    result["adapter_save"] = adapter_save
    result["engineering_checks"] = engineering_checks
    result["paper_checks"] = paper_checks
    result["engineering_gate_pass"] = all(engineering_checks.values())
    result["paper_gate_pass"] = all(paper_checks.values())
    (output / "gridrank_gate.json").write_text(
        json.dumps(result, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    print(json.dumps(result, ensure_ascii=False))
    if not result["engineering_gate_pass"]:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
