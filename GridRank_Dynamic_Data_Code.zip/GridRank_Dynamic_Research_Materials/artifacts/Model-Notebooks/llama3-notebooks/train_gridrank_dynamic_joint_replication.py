"""Train GridRank dynamic joint replication."""

from __future__ import annotations

import sys

import preflight_gridrank_dynamic_joint_replication as replication_preflight


sys.modules["preflight_gridrank_dynamic_policy"] = replication_preflight
import train_gridrank_dynamic_policy as locked_trainer  


if __name__ == "__main__":
    locked_trainer.main()

