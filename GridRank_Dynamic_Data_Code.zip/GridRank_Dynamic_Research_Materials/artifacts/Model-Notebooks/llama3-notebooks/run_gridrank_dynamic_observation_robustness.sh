#!/usr/bin/env bash
set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$HERE"

TAG="${TAG:-gridrank_dynamic_observation_robustness_v1_20260909}"
CROSS_TAG="${CROSS_TAG:-gridrank_dynamic_cross_topology_v1_20260907}"
PREFLIGHT_ONLY="${PREFLIGHT_ONLY:-1}"
TRAIN_PYTHON="${TRAIN_PYTHON:-$(command -v python)}"

PREFLIGHT="${TAG}.preflight.json"
OUTPUT_DIR="output_${TAG}"
GATE="${OUTPUT_DIR}/gridrank_dynamic_observation_robustness_gate.json"
CROSS_PREFLIGHT="${CROSS_TAG}.preflight.json"
CROSS_GATE="output_${CROSS_TAG}/gridrank_dynamic_cross_topology_gate.json"
CROSS_RECORDS="output_${CROSS_TAG}/gridrank_dynamic_cross_topology_records.jsonl"

stage="bootstrap"
failure() {
  code=$?
  printf '{"msg":"GridRank dynamic observation robustness failure","stage":"%s","evaluation_pass":false,"exit_code":%d}\n' "$stage" "$code"
  exit "$code"
}
trap failure ERR

required=(
  gridrank_dynamic_observation_robustness.py
  preflight_gridrank_dynamic_observation_robustness.py
  eval_gridrank_dynamic_observation_robustness.py
  verify_gridrank_dynamic_observation_robustness.py
  verify_gridrank_dynamic_observation_robustness_dependencies.py
  ../../docs/GRIDRANK_DYNAMIC_OBSERVATION_ROBUSTNESS_PROTOCOL.md
  "$CROSS_PREFLIGHT"
  "$CROSS_GATE"
  "$CROSS_RECORDS"
)
for path in "${required[@]}"; do
  if [[ ! -e "$path" ]]; then
    echo "missing robustness input: $path" >&2
    exit 2
  fi
done

stage="dependency_regressions"
echo "=== 1/4 DEPENDENCY-LIGHT ROBUSTNESS REGRESSIONS ==="
CUDA_VISIBLE_DEVICES="" "$TRAIN_PYTHON" -B \
  verify_gridrank_dynamic_observation_robustness_dependencies.py

stage="locked_preflight"
echo "=== 2/4 LOCK SEALED CROSS-TOPOLOGY STATES, OUTPUTS AND PERTURBATIONS ==="
if [[ ! -e "$PREFLIGHT" ]]; then
  if [[ -e "$OUTPUT_DIR" ]]; then
    echo "output exists without preflight: $OUTPUT_DIR" >&2
    exit 2
  fi
  CUDA_VISIBLE_DEVICES="" "$TRAIN_PYTHON" -B \
    preflight_gridrank_dynamic_observation_robustness.py \
    --cross_preflight "$CROSS_PREFLIGHT" \
    --cross_gate "$CROSS_GATE" \
    --cross_records "$CROSS_RECORDS" \
    --output "$PREFLIGHT" \
    --bootstrap_reps 10000 \
    --bootstrap_seed 20260909
else
  CUDA_VISIBLE_DEVICES="" "$TRAIN_PYTHON" -B \
    preflight_gridrank_dynamic_observation_robustness.py \
    --cross_preflight "$CROSS_PREFLIGHT" \
    --cross_gate "$CROSS_GATE" \
    --cross_records "$CROSS_RECORDS" \
    --output "$PREFLIGHT" --verify
fi

if [[ "$PREFLIGHT_ONLY" == "1" ]]; then
  echo "=== GRIDRANK DYNAMIC ROBUSTNESS CPU PREFLIGHT COMPLETE; AC PERTURBATION EVALUATION NOT STARTED ==="
  exit 0
fi
if [[ "$PREFLIGHT_ONLY" != "0" ]]; then
  echo "PREFLIGHT_ONLY must be 0 or 1" >&2
  exit 2
fi
if [[ -e "$OUTPUT_DIR" ]]; then
  echo "refusing to overwrite robustness output: $OUTPUT_DIR" >&2
  exit 2
fi

stage="sealed_ac_evaluation"
echo "=== 3/4 SEALED LOAD/DER SHIFTS + MEASUREMENT-NOISE AC EVALUATION ==="
CUDA_VISIBLE_DEVICES="" "$TRAIN_PYTHON" -u \
  eval_gridrank_dynamic_observation_robustness.py \
  --preflight_manifest "$PREFLIGHT" \
  --output_dir "$OUTPUT_DIR"

stage="result_verify"
echo "=== 4/4 VERIFY RECORDS, CLEAN REPLAY AND EXACT STATISTICS ==="
CUDA_VISIBLE_DEVICES="" "$TRAIN_PYTHON" -B \
  verify_gridrank_dynamic_observation_robustness.py \
  --preflight_manifest "$PREFLIGHT" \
  --gate "$GATE"

echo "=== GRIDRANK DYNAMIC OPERATING/OBSERVATION ROBUSTNESS COMPLETE ==="

