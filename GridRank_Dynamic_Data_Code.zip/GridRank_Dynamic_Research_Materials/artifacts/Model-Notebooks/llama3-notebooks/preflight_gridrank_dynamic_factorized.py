"""Check inputs for GridRank dynamic factorized."""

from __future__ import annotations

import argparse
import hashlib
import json
from collections import Counter
from pathlib import Path

import preflight_gridrank_feedback as runtime
import preflight_gridrank_dynamic_benchmark as benchmark
import preflight_gridrank_dynamic_policy as joint_preflight
from gridrank_dynamic_factorized_llm import PRIMITIVES, render_primitive_prompt
from gridrank_dynamic_llm import oracle_card_id


HERE = Path(__file__).resolve().parent
SCHEMA = "gridrank-dynamic-factorized-preflight-v1"
EXPERIMENT_ID = "gridrank-physics-certified-factorized-dynamic-policy-v1"
CODE_FILES = (
    "build_gridrank_instruction_pairs.py",
    "preflight_gridrank_dynamic_benchmark.py",
    "gridrank_dynamic_llm.py",
    "preflight_gridrank_dynamic_policy.py",
    "train_gridrank_dynamic_policy.py",
    "gridrank_dynamic_factorized_llm.py",
    "preflight_gridrank_dynamic_factorized.py",
    "train_gridrank_dynamic_factorized.py",
    "verify_gridrank_dynamic_factorized.py",
    "verify_gridrank_dynamic_factorized_dependencies.py",
    "run_gridrank_dynamic_factorized.sh",
    "grpo_train.py",
    "../../docs/GRIDRANK_DYNAMIC_FACTORIZED_PROTOCOL.md",
)


def file_sha256(path):
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--train_jsonl", required=True)
    parser.add_argument("--validation_jsonl", required=True)
    parser.add_argument("--pair_summary", required=True)
    parser.add_argument("--benchmark_manifest", required=True)
    parser.add_argument("--joint_preflight", required=True)
    parser.add_argument("--joint_gate", required=True)
    parser.add_argument("--resume_adapter_path", required=True)
    parser.add_argument("--sft_adapter_path", required=True)
    parser.add_argument("--base_model", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--max_length", type=int, required=True)
    parser.add_argument("--primitive_batch_size", type=int, required=True)
    parser.add_argument("--epochs", type=int, required=True)
    parser.add_argument("--learning_rate", type=float, required=True)
    parser.add_argument("--grad_accum", type=int, required=True)
    parser.add_argument("--max_grad_norm", type=float, required=True)
    parser.add_argument("--target_temperature", type=float, required=True)
    parser.add_argument("--lambda_objective", type=float, required=True)
    parser.add_argument("--lambda_constraint", type=float, required=True)
    parser.add_argument("--lambda_physics", type=float, required=True)
    parser.add_argument("--lambda_hard", type=float, required=True)
    parser.add_argument("--hard_margin", type=float, required=True)
    parser.add_argument("--beta_reference", type=float, required=True)
    parser.add_argument("--seed", type=int, required=True)
    parser.add_argument("--gradient_checkpointing", type=int, choices=(0, 1), required=True)
    parser.add_argument("--bootstrap_reps", type=int, required=True)
    return parser.parse_args()


def schedule(args):
    keys = (
        "max_length", "primitive_batch_size", "epochs", "learning_rate",
        "grad_accum", "max_grad_norm", "target_temperature",
        "lambda_objective", "lambda_constraint", "lambda_physics",
        "lambda_hard", "hard_margin", "beta_reference", "seed",
        "gradient_checkpointing", "bootstrap_reps",
    )
    return {key: getattr(args, key) for key in keys}


def code_hashes():
    missing = [name for name in CODE_FILES if not (HERE / name).is_file()]
    if missing:
        raise FileNotFoundError(f"missing factorized dynamic-policy code: {missing}")
    return {name: file_sha256(HERE / name) for name in CODE_FILES}


def prompt_audit(rows, base_model, max_length):
    from transformers import AutoTokenizer

    tokenizer = AutoTokenizer.from_pretrained(base_model, local_files_only=True)
    maximum = count = truncated = 0
    for row in rows:
        for primitive in PRIMITIVES:
            text = render_primitive_prompt(tokenizer, row, primitive)
            length = len(tokenizer(text, add_special_tokens=False)["input_ids"])
            maximum = max(maximum, length)
            count += 1
            truncated += int(length > max_length)
    return {
        "prompts": count, "max_tokens": maximum,
        "truncated_prompts": truncated,
        "prompt_length_pass": truncated == 0,
    }


def create(args):
    output = Path(args.output)
    if output.exists():
        raise FileExistsError(f"refusing to overwrite preflight: {output}")
    upstream = json.load(open(args.joint_preflight, encoding="utf-8"))
    joint_gate = json.load(open(args.joint_gate, encoding="utf-8"))
    benchmark_manifest = json.load(open(args.benchmark_manifest, encoding="utf-8"))
    pair_summary = json.load(open(args.pair_summary, encoding="utf-8"))
    train_all = benchmark.load_rows(args.train_jsonl, "train")
    validation_all = benchmark.load_rows(args.validation_jsonl, "validation")
    train_by_id = {row["instance_id"]: row for row in train_all}
    validation_by_id = {row["instance_id"]: row for row in validation_all}
    selected_ids = list(upstream.get("selection", {}).get("train_row_ids", []))
    validation_ids = list(upstream.get("selection", {}).get("validation_row_ids", []))
    missing_train = sorted(set(selected_ids).difference(train_by_id))
    missing_validation = sorted(set(validation_ids).difference(validation_by_id))
    if missing_train or missing_validation:
        raise RuntimeError(
            f"upstream selection missing train={missing_train[:3]} validation={missing_validation[:3]}"
        )
    train = [train_by_id[value] for value in selected_ids]
    validation = [validation_by_id[value] for value in validation_ids]
    composition = [row for row in validation if row["pair_type"] == "maintenance_voltage"]
    prompt = prompt_audit(train + validation, args.base_model, args.max_length)
    objective_mix = Counter(
        row["oracle_structured_instruction"]["objective"] for row in train
    )
    constraint_mix = Counter(
        bool(row["oracle_structured_instruction"]["hard_constraint"]) for row in train
    )
    card_mix = Counter(oracle_card_id(row) for row in train)
    expected_artifacts = {
        "train": args.train_jsonl,
        "validation": args.validation_jsonl,
        "pair_summary": args.pair_summary,
        "dynamic_benchmark": args.benchmark_manifest,
    }
    upstream_artifacts = upstream.get("artifacts", {})
    benchmark_requires_fresh_final = bool(
        benchmark_manifest.get("fresh_final_test_required_after_model_selection") is True
        or benchmark_manifest.get("fresh_final_test_required") is True
    )
    checks = {
        "upstream_joint_preflight_pass": upstream.get("preflight_pass") is True,
        "upstream_joint_method_failed_as_locked_ablation": joint_gate.get("engineering_gate_pass") is False,
        "upstream_joint_gate_bound": joint_gate.get("preflight_sha256") == file_sha256(args.joint_preflight),
        "upstream_artifacts_current": all(
            upstream_artifacts.get(name, {}).get("sha256") == file_sha256(path)
            for name, path in expected_artifacts.items()
        ),
        "dynamic_benchmark_pass": benchmark_manifest.get("preflight_pass") is True,
        "dynamic_benchmark_authorized": (
            benchmark_manifest.get("decision") == "authorize_dynamic_llm_seed42_preflight"
        ),
        "instruction_pair_gate_pass": pair_summary.get("coverage_pass") is True,
        "same_locked_training_rows_114": len(train) == 114,
        "same_locked_validation_rows_96": len(validation) == 96,
        "withheld_composition_rows_32": len(composition) == 32,
        "maintenance_voltage_absent_from_training": all(
            row["pair_type"] != "maintenance_voltage" for row in train
        ),
        "voltage_maintenance_joint_card_absent": card_mix["voltage_maintenance"] == 0,
        "both_objective_values_seen": objective_mix["loss"] > 0 and objective_mix["voltage"] > 0,
        "both_constraint_values_seen": constraint_mix[False] > 0 and constraint_mix[True] > 0,
        "three_seen_joint_cards": all(
            card_mix[name] > 0
            for name in ("loss_unconstrained", "voltage_unconstrained", "loss_maintenance")
        ),
        "factorization_seed_42": args.seed == 42,
        "positive_schedule": all(
            isinstance(value, (int, float)) and value > 0
            for value in schedule(args).values()
        ),
        "prompt_length": prompt["prompt_length_pass"],
        "fresh_final_test_required": benchmark_requires_fresh_final,
    }
    manifest = {
        "msg": "GridRank factorized dynamic semantic-policy preflight",
        "schema": SCHEMA, "experiment_id": EXPERIMENT_ID,
        "preflight_pass": all(checks.values()),
        "training_performed": False, "model_loaded": False,
        "power_flow_calls": 0,
        "development_reuse_disclosed": True,
        "fresh_final_test_required": True,
        "artifacts": {
            name: {"path": str(Path(path).resolve()), "sha256": file_sha256(path)}
            for name, path in {
                **expected_artifacts,
                "joint_preflight": args.joint_preflight,
                "joint_gate": args.joint_gate,
            }.items()
        },
        "adapters": {
            "gridrank": {
                "path": str(Path(args.resume_adapter_path).resolve()),
                "sha256": joint_preflight.adapter_hash(args.resume_adapter_path),
            },
            "sft": {
                "path": str(Path(args.sft_adapter_path).resolve()),
                "sha256": joint_preflight.adapter_hash(args.sft_adapter_path),
            },
        },
        "base_model": str(Path(args.base_model).resolve()),
        "base_model_inventory": runtime.model_inventory(args.base_model),
        "training_runtime": runtime.training_runtime(),
        "schedule": schedule(args),
        "selection": {
            "rule": (
                "exact 114-row physics-certified selection from locked joint-card preflight; "
                "maintenance_voltage remains absent"
            ),
            "train_row_ids": selected_ids,
            "validation_row_ids": validation_ids,
            "composition_row_ids": [row["instance_id"] for row in composition],
            "objective_mix": dict(objective_mix),
            "constraint_mix": {str(key): value for key, value in constraint_mix.items()},
            "joint_card_mix": dict(card_mix),
        },
        "prompt_audit": prompt,
        "code_sha256": code_hashes(),
        "checks": checks,
        "failed_checks": [key for key, value in checks.items() if not value],
    }
    output.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(manifest, ensure_ascii=False))
    if not manifest["preflight_pass"]:
        raise SystemExit(2)


def verify(args):
    from gridrank_runtime_compat import runtime_compatibility

    manifest = json.load(open(args.output, encoding="utf-8"))
    artifact_checks = {
        name: Path(item["path"]).is_file() and file_sha256(item["path"]) == item["sha256"]
        for name, item in manifest.get("artifacts", {}).items()
    }
    adapter_checks = {
        name: joint_preflight.adapter_hash(item["path"]) == item["sha256"]
        for name, item in manifest.get("adapters", {}).items()
    }
    checks = {
        "schema": manifest.get("schema") == SCHEMA,
        "experiment_id": manifest.get("experiment_id") == EXPERIMENT_ID,
        "preflight_pass": manifest.get("preflight_pass") is True,
        "artifacts_current": bool(artifact_checks) and all(artifact_checks.values()),
        "adapters_current": bool(adapter_checks) and all(adapter_checks.values()),
        "base_model_current": manifest.get("base_model_inventory") == runtime.model_inventory(manifest.get("base_model")),
        "runtime_compatible": runtime_compatibility(
            manifest.get("training_runtime"), runtime.training_runtime()
        )["compatible"],
        "schedule_current": manifest.get("schedule") == schedule(args),
        "code_current": manifest.get("code_sha256") == code_hashes(),
    }
    result = {
        "msg": "GridRank factorized dynamic-policy runtime verification",
        "checks": checks, "verification_pass": all(checks.values()),
    }
    print(json.dumps(result, ensure_ascii=False))
    if not result["verification_pass"]:
        raise SystemExit(2)


def main():
    args = parse_args()
    if Path(args.output).exists():
        verify(args)
    else:
        create(args)


if __name__ == "__main__":
    main()
