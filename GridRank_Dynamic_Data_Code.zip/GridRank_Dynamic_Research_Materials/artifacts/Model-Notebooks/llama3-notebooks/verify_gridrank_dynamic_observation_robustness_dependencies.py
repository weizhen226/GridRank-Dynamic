"""Validate GridRank dynamic observation robustness dependencies."""

from __future__ import annotations

import ast
import json
from pathlib import Path

import gridrank_dynamic_observation_robustness as robust


HERE = Path(__file__).resolve().parent


def imported_roots(path):
    tree = ast.parse(path.read_text(encoding="utf-8"))
    return {
        node.names[0].name.split(".")[0]
        for node in ast.walk(tree)
        if isinstance(node, ast.Import)
    } | {
        (node.module or "").split(".")[0]
        for node in ast.walk(tree)
        if isinstance(node, ast.ImportFrom)
    }


def synthetic_records():
    records = []
    networks = ("rural", "semiurb", "urban")
    regimes = robust.REGIMES
    bins = robust.LOAD_BINS
    for state in range(6):
        for seed in robust.SEEDS:
            for side in ("left", "right"):
                baseline = 0.10
                records.append({
                    "experiment_axis": "operating_shift",
                    "condition": "clean",
                    "seed": seed,
                    "instance_id": f"{state}:{side}",
                    "pair_id": str(state),
                    "pair_side": side,
                    "pair_type": robust.PRIMARY,
                    "physical_state_sha256": f"{state:064x}",
                    "network": networks[state % 3],
                    "network_size": (70, 100, 180)[state % 3],
                    "operating_regime": regimes[state % 3],
                    "load_bin": bins[state % 3],
                    "normalised_load_level": 1.0,
                    "der_active": state % 3 != 0,
                    "normalised_regret": baseline,
                    "regret_degradation": 0.0,
                    "physics_optimal": False,
                    "action_flip": False,
                    "true_feasible": True,
                    "true_constraint_violation": False,
                    "no_op": False,
                    "observed_anchor_feasible": True,
                    "observed_gate_rejected": False,
                })
    
    clean = list(records)
    for condition in robust.operating_conditions()[1:]:
        for row in clean:
            value = dict(row)
            value["condition"] = condition["id"]
            records.append(value)
    for condition in robust.noise_conditions():
        for row in clean:
            value = dict(row)
            value.update({
                "experiment_axis": "measurement_noise",
                "condition": condition["id"],
                "noise_sigma": condition["sigma"],
                "noise_replicate": condition["replicate"],
            })
            records.append(value)
    return records


def main():
    eval_path = HERE / "eval_gridrank_dynamic_observation_robustness.py"
    runner_path = HERE / "run_gridrank_dynamic_observation_robustness.sh"
    eval_text = eval_path.read_text(encoding="utf-8")
    runner_text = runner_path.read_text(encoding="utf-8")
    summary = robust.summarize(
        synthetic_records(), bootstrap_reps=100, bootstrap_seed=20260909
    )
    normal = robust.hash_normal("state", 1, "load")
    checks = {
        "five_operating_conditions": len(
            robust.operating_conditions()
        ) == 5,
        "nine_noise_conditions": len(robust.noise_conditions()) == 9,
        "three_noise_levels": {
            item["sigma"] for item in robust.noise_conditions()
        } == set(robust.NOISE_SIGMAS),
        "three_noise_replicates": {
            item["replicate"] for item in robust.noise_conditions()
        } == set(robust.NOISE_REPLICATES),
        "deterministic_noise": normal
        == robust.hash_normal("state", 1, "load"),
        "noise_changes_with_identity": normal
        != robust.hash_normal("state", 2, "load"),
        "canonical_state_index_fallback": (
            robust.state_index({
                "instance_id": "fallback",
                "load_id": "simbench:1-MV-rural--2-sw:37",
            }) == 37
            and robust.state_index({
                "state_index": 12,
                "load_id": "simbench:ignored:99",
            }) == 12
        ),
        "summary_regression": summary["robustness_gate_pass"],
        "evaluation_has_no_training_or_model_imports": not {
            "torch", "transformers", "grpo_train",
        }.intersection(imported_roots(eval_path)),
        "evaluation_has_no_optimizer_or_backward": all(
            token not in eval_text
            for token in ("optimizer", ".backward(", "loss.backward")
        ),
        "runner_cpu_only": "CUDA_VISIBLE_DEVICES=\"\"" in runner_text,
        "runner_does_not_require_gpu": all(
            token not in runner_text for token in ("nvidia-smi", "CUDA readiness")
        ),
        "clean_true_boundary_present": (
            "unchanged sealed clean AC state" in eval_text
            and "ground_truth_boundary" in eval_text
        ),
        "ranking_and_certified_gate_semantics_separate": (
            "semantic, target" in eval_text
            and "semantic,\n                        benchmark.semantic_target(row)"
            in eval_text
            and "certified_gate_semantics" in eval_text
        ),
        "full_pool_operating_replay_present": (
            "run_live_actions" in eval_text
            and "operating_conditions" in eval_text
        ),
    }
    result = {
        "msg": "GridRank dynamic observation robustness dependency verification",
        "checks": checks,
        "verification_pass": all(checks.values()),
        "synthetic_robustness_gate_pass": summary["robustness_gate_pass"],
    }
    print(json.dumps(result, ensure_ascii=False))
    if not result["verification_pass"]:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
