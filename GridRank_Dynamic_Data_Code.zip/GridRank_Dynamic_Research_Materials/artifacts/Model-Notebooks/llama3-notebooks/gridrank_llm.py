"""Gridrank llm utilities."""

from __future__ import annotations

from typing import Iterable, Sequence


POSITIVE_TOKEN = "YES"
NEGATIVE_TOKEN = "NO"


def resolve_preference_token_ids(tokenizer) -> tuple[int, int]:
    

    values = []
    for surface in (POSITIVE_TOKEN, NEGATIVE_TOKEN):
        encoded = tokenizer.encode(surface, add_special_tokens=False)
        if len(encoded) != 1:
            raise RuntimeError(
                f"candidate readout token must be one tokenizer token: "
                f"{surface!r} -> {encoded}"
            )
        values.append(int(encoded[0]))
    if values[0] == values[1]:
        raise RuntimeError("YES/NO candidate readout token IDs are identical")
    return values[0], values[1]


def candidate_question(row: dict, candidate: dict) -> str:
    

    feature_text = candidate.get("candidate_feature_text")
    if not feature_text:
        raise ValueError("candidate_feature_text is required; AC outcomes must not be substituted")
    return (
        "Physical distribution-network state:\n"
        f"{row['state_text']}\n\n"
        "Operator directive:\n"
        f"{row['instruction_text']}\n\n"
        "Candidate switching action:\n"
        f"{candidate['action']}\n\n"
        "Deterministic candidate-local features (no AC power-flow result):\n"
        f"{feature_text}\n\n"
        "Should this candidate be preferred under the directive and physical constraints? "
        f"Answer exactly {POSITIVE_TOKEN} or {NEGATIVE_TOKEN}."
    )


def render_candidate_prompt(tokenizer, row: dict, candidate: dict) -> str:
    

    question = candidate_question(row, candidate)
    if getattr(tokenizer, "chat_template", None):
        return tokenizer.apply_chat_template(
            [{"role": "user", "content": question}],
            tokenize=False,
            add_generation_prompt=True,
        )
    return f"<|user|>\n{question}</s>\n<|assistant|>\n"


def _chunks(values: Sequence, size: int) -> Iterable[Sequence]:
    if size <= 0:
        raise ValueError("candidate_batch_size must be positive")
    for offset in range(0, len(values), size):
        yield values[offset : offset + size]


def candidate_scores(
    model,
    tokenizer,
    row: dict,
    *,
    max_length: int,
    candidate_batch_size: int,
    require_grad: bool,
):
    

    import torch

    candidates = list(row.get("candidates") or [])
    if len(candidates) < 2:
        raise ValueError("GridRank requires at least two candidates")
    positive_id, negative_id = resolve_preference_token_ids(tokenizer)
    device = next(model.parameters()).device
    old_truncation = tokenizer.truncation_side
    old_padding = tokenizer.padding_side
    tokenizer.truncation_side = "left"
    tokenizer.padding_side = "right"
    outputs = []
    try:
        for chunk in _chunks(candidates, candidate_batch_size):
            texts = [render_candidate_prompt(tokenizer, row, candidate) for candidate in chunk]
            encoded = tokenizer(
                texts,
                return_tensors="pt",
                padding=True,
                truncation=True,
                max_length=max_length,
                add_special_tokens=False,
            )
            encoded = {key: value.to(device) for key, value in encoded.items()}
            context = torch.enable_grad() if require_grad else torch.no_grad()
            with context:
                result = model(**encoded, use_cache=False, return_dict=True)
                last_index = encoded["attention_mask"].sum(dim=1).long() - 1
                batch_index = torch.arange(last_index.shape[0], device=device)
                logits = result.logits[batch_index, last_index].float()
                outputs.append(logits[:, positive_id] - logits[:, negative_id])
    finally:
        tokenizer.truncation_side = old_truncation
        tokenizer.padding_side = old_padding
    scores = torch.cat(outputs, dim=0)
    if scores.shape != (len(candidates),):
        raise RuntimeError("candidate score shape mismatch")
    if not bool(torch.isfinite(scores).all()):
        raise FloatingPointError("candidate scorer produced NaN/Inf")
    return scores


def rank_candidate_indices(scores, row: dict) -> list[int]:
    

    values = [float(value) for value in scores]
    if len(values) != len(row["candidates"]):
        raise ValueError("score/candidate length mismatch")
    return sorted(
        range(len(values)),
        key=lambda index: (-values[index], row["candidates"][index]["action"]),
    )


def reordered_row(row: dict, order: Sequence[int]) -> dict:
    

    candidates = list(row["candidates"])
    if sorted(order) != list(range(len(candidates))):
        raise ValueError("order must be a candidate permutation")
    output = dict(row)
    output["candidates"] = [candidates[index] for index in order]
    desired_action = row["desired_action"]
    output["desired_index"] = next(
        index for index, candidate in enumerate(output["candidates"])
        if candidate["action"] == desired_action
    )
    if "optimal_actions" in row:
        optimal_actions = set(row["optimal_actions"])
        output["optimal_indices"] = [
            index for index, candidate in enumerate(output["candidates"])
            if candidate["action"] in optimal_actions
        ]
        output["optimal_actions"] = [
            output["candidates"][index]["action"] for index in output["optimal_indices"]
        ]
    return output
