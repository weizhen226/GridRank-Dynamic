"""Validate GridRank dynamic physics ablation model."""

from __future__ import annotations

import sys

import preflight_gridrank_dynamic_physics_ablation as ablation_preflight


sys.modules["preflight_gridrank_dynamic_factorized"] = ablation_preflight

import verify_gridrank_dynamic_factorized as locked_verifier  


if __name__ == "__main__":
    locked_verifier.main()
