"""Audit GridRank dynamic factorized tfidf."""

from __future__ import annotations

import argparse
import hashlib
import json
from collections import defaultdict
from pathlib import Path

import preflight_gridrank_dynamic_benchmark as benchmark
import train_gridrank_dynamic_policy as joint


SCHEMA = "gridrank-factorized-tfidf-audit-v1"
METHOD = "tfidf_logreg_withheld_composition"
WITHHELD = "maintenance_voltage"


def file_sha256(path):
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def rows(path):
    return [json.loads(line) for line in open(path, encoding="utf-8") if line.strip()]


def stored_method(path):
    output = []
    for value in rows(path):
        if value.pop("method") == METHOD:
            output.append(value)
    return output


def canonical(values):
    return {
        row["instance_id"]: json.dumps(row, sort_keys=True, ensure_ascii=False)
        for row in values
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--original_train", required=True)
    parser.add_argument("--fresh_pairs", required=True)
    parser.add_argument("--confirmation_records", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    output = Path(args.output)
    if output.exists():
        raise FileExistsError(f"refusing to overwrite factorized TF-IDF audit: {output}")

    train = rows(args.original_train)
    fresh = rows(args.fresh_pairs)
    fit_rows = [row for row in train if row["pair_type"] != WITHHELD]
    model = benchmark.fit_text_parser(fit_rows, 20260926)
    predictions = benchmark.predict_text_parser(model, fresh)
    replay = joint.records_from_predictions(fresh, predictions, METHOD)
    stored = stored_method(args.confirmation_records)
    objective_targets = {
        benchmark.semantic_target(row)["objective"] for row in fit_rows
    }
    constraint_targets = {
        bool(benchmark.semantic_target(row)["hard_constraint"]) for row in fit_rows
    }
    checks = {
        "shared_tfidf_representation": "features" in model,
        "separate_objective_head": set(map(str, model["objective"].classes_))
        == objective_targets,
        "separate_constraint_head": set(map(int, model["constraint"].classes_))
        == {int(value) for value in constraint_targets},
        "no_joint_card_classifier": set(model) == {
            "features", "objective", "constraint", "fit_rows"
        },
        "withheld_composition_absent_from_fit": all(
            row["pair_type"] != WITHHELD for row in fit_rows
        ),
        "both_objectives_seen_separately": objective_targets == {"loss", "voltage"},
        "both_constraints_seen_separately": constraint_targets == {False, True},
        "fit_row_count_locked": model["fit_rows"] == len(fit_rows),
        "fresh_predictions_complete": len(predictions) == len(fresh),
        "stored_method_present": len(stored) == len(fresh),
        "replay_exactly_matches_locked_records": canonical(replay) == canonical(stored),
    }
    result = {
        "msg": "GridRank factorized TF-IDF baseline audit",
        "schema": SCHEMA,
        "audit_pass": all(checks.values()),
        "historical_method_name": METHOD,
        "paper_method_name": "Factorized TF-IDF + two-head Logistic Regression",
        "architecture": (
            "shared word+character TF-IDF; independent objective and constraint "
            "logistic heads; deterministic axis composition; regex edge extraction; "
            "same LinDistFlow action ranking and AC-safe execution interface"
        ),
        "withheld_joint_composition": WITHHELD,
        "fit_rows": len(fit_rows),
        "fresh_rows": len(fresh),
        "objective_classes": sorted(objective_targets),
        "constraint_classes": sorted(constraint_targets),
        "summary": joint.summarize(replay),
        "artifacts": {
            "original_train": {"path": str(Path(args.original_train).resolve()), "sha256": file_sha256(args.original_train)},
            "fresh_pairs": {"path": str(Path(args.fresh_pairs).resolve()), "sha256": file_sha256(args.fresh_pairs)},
            "confirmation_records": {"path": str(Path(args.confirmation_records).resolve()), "sha256": file_sha256(args.confirmation_records)},
        },
        "checks": checks,
        "failed_checks": [key for key, value in checks.items() if not value],
    }
    output.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(result, ensure_ascii=False))
    if not result["audit_pass"]:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
