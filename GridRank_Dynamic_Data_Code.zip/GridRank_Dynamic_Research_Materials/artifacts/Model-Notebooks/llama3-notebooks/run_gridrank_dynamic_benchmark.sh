#!/usr/bin/env bash
set -euo pipefail

CURRENT_STAGE="bootstrap"
on_exit() {
  local rc=$?
  trap - EXIT
  if (( rc != 0 )); then
    printf '{"msg":"GridRank dynamic benchmark runner failure","stage":"%s","preflight_pass":false,"exit_code":%d}\n' \
      "$CURRENT_STAGE" "$rc"
  fi
  exit "$rc"
}
trap on_exit EXIT

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"
export CUDA_VISIBLE_DEVICES=""
export HF_HUB_OFFLINE=1
export TRANSFORMERS_OFFLINE=1
export OMP_NUM_THREADS="${OMP_NUM_THREADS:-4}"

resolve_executable() {
  local requested="$1"
  if [[ "$requested" == */* ]]; then
    [[ -x "$requested" ]] && printf '%s\n' "$requested"
  else
    command -v -- "$requested"
  fi
}
PYTHON_BIN="$(resolve_executable "${TRAIN_PYTHON:-python}")" || exit 2

TAG="${TAG:-gridrank_dynamic_benchmark_v1_20260826}"
[[ "$TAG" =~ ^[A-Za-z0-9][A-Za-z0-9._-]*$ ]] || {
  echo "invalid TAG" >&2; exit 2;
}
PAIR_TAG="${PAIR_TAG:-gridrank_instruction_pairs_v2_20260809}"
TRAIN_JSONL="${TRAIN_JSONL:-${PAIR_TAG}_train.jsonl}"
VALIDATION_JSONL="${VALIDATION_JSONL:-${PAIR_TAG}_validation.jsonl}"
PAIR_SUMMARY="${PAIR_SUMMARY:-${PAIR_TAG}_summary.json}"
OUT="${OUT:-${TAG}.preflight.json}"

for path in \
  "$TRAIN_JSONL" "$VALIDATION_JSONL" "$PAIR_SUMMARY" \
  build_gridrank_instruction_pairs.py \
  preflight_gridrank_dynamic_benchmark.py \
  verify_gridrank_dynamic_benchmark.py \
  ../../docs/GRIDRANK_DYNAMIC_BENCHMARK_PROTOCOL.md; do
  test -f "$path" || {
    echo "missing dynamic benchmark input: $path" >&2; exit 2;
  }
done

CURRENT_STAGE="dependency_regressions"
echo "=== 1/4 DEPENDENCY-LIGHT DYNAMIC-BENCHMARK REGRESSIONS ==="
"$PYTHON_BIN" -B verify_gridrank_dynamic_benchmark.py

CURRENT_STAGE="library_readiness"
echo "=== 2/4 CPU TEXT-BASELINE LIBRARY READINESS ==="
"$PYTHON_BIN" -B - <<'PY'
import json
from importlib.metadata import version

result = {"msg": "GridRank dynamic benchmark CPU library readiness"}
try:
    import sklearn
    versions = {
        "numpy": version("numpy"),
        "scikit-learn": version("scikit-learn"),
    }
    checks = {
        "sklearn_import": bool(sklearn.__version__),
        "versions_nonempty": all(versions.values()),
    }
except Exception as exc:
    versions = {}
    checks = {"sklearn_import": False, "versions_nonempty": False}
    result["error"] = f"{type(exc).__name__}: {exc}"
result["versions"] = versions
result["checks"] = checks
result["readiness_pass"] = all(checks.values())
print(json.dumps(result, ensure_ascii=False))
raise SystemExit(0 if result["readiness_pass"] else 2)
PY

CURRENT_STAGE="benchmark_qualification"
echo "=== 3/4 FIT TRAIN-ONLY TRADITIONAL TEXT BASELINES + QUALIFY TRACKS ==="
if [[ -e "$OUT" ]]; then
  "$PYTHON_BIN" -B preflight_gridrank_dynamic_benchmark.py \
    --train_jsonl "$TRAIN_JSONL" \
    --validation_jsonl "$VALIDATION_JSONL" \
    --pair_summary "$PAIR_SUMMARY" \
    --output "$OUT" \
    --verify_manifest
else
  "$PYTHON_BIN" -B preflight_gridrank_dynamic_benchmark.py \
    --train_jsonl "$TRAIN_JSONL" \
    --validation_jsonl "$VALIDATION_JSONL" \
    --pair_summary "$PAIR_SUMMARY" \
    --output "$OUT"
fi

CURRENT_STAGE="result_verification"
echo "=== 4/4 VERIFY LOCKED DYNAMIC-BENCHMARK DECISION ==="
"$PYTHON_BIN" -B verify_gridrank_dynamic_benchmark.py --manifest "$OUT"

"$PYTHON_BIN" -B - "$OUT" <<'PY'
import json
import sys

d = json.load(open(sys.argv[1], encoding="utf-8"))
result = {
    "preflight_pass": d["preflight_pass"],
    "decision": d["decision"],
    "counts": d["counts"],
    "headroom": d["headroom"],
    "primary_methods": {
        name: value["summary"]
        for name, value in d["suites"]["unseen_paraphrase_primary"].items()
    },
    "composition_methods": {
        name: value["summary"]
        for name, value in d["suites"]["unseen_composition"].items()
    },
    "failed_checks": d["failed_checks"],
    "llm_training_performed": d["llm_training_performed"],
    "fresh_final_test_required": d["fresh_final_test_required_after_model_selection"],
}
print(json.dumps(result, ensure_ascii=False, indent=2))
PY

echo "=== GRIDRANK DYNAMIC OPERATOR-LANGUAGE CPU QUALIFICATION COMPLETE; GPU NOT STARTED ==="
