"""Train GridRank select."""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import random
from collections import defaultdict
from pathlib import Path

import grpo_reward_limited as reward
from build_gridrank_feedback import label_candidates, sanitize_feedback
from gridrank_select_llm import (
    NOOP,
    exchange_scores,
    rank_exchange_indices,
    reordered_exchange_row,
    topk_exchange_indices,
    validate_exchange_only_row,
)


DEFAULT_BASE = str(Path(__file__).resolve().parents[2] / "Meta-Llama-3.1-8B-Instruct")
ROW_FIELDS = {
    "schema", "instance_id", "partition", "upstream_instance_id", "source_split",
    "source_instance_id", "load_id", "network_id", "state_text",
    "physical_state_sha256", "full_candidate_count", "upstream_candidate_pool_sha256",
    "instruction_id", "instruction_style", "instruction_text", "feedback_status",
    "desired_index", "desired_action", "optimal_indices", "optimal_actions",
    "candidates", "gate_anchor",
}
CANDIDATE_FIELDS = {
    "action", "candidate_feature_text", "feedback_revealed", "feedback_valid",
    "feasible", "reason", "reduction_pct", "anchor_loss_kw", "candidate_loss_kw",
    "anchor_min_vm_pu", "candidate_min_vm_pu", "candidate_max_vm_pu",
    "instruction_utility", "safe_utility", "accepted_by_gate", "ranking_utility",
    "ranking_eligible", "is_ranking_optimal", "ranking_regret", "ranking_rank",
    "target_prob",
}
ANCHOR_FIELDS = {
    "role", "action", "candidate_feature_text", "feedback_revealed", "feedback_valid",
    "feasible", "reason", "reduction_pct", "anchor_loss_kw", "candidate_loss_kw",
    "anchor_min_vm_pu", "candidate_min_vm_pu", "candidate_max_vm_pu",
    "instruction_utility", "safe_utility", "accepted_by_gate",
}


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--train_jsonl", required=True)
    parser.add_argument("--test_jsonl", required=True)
    parser.add_argument("--data_summary", required=True)
    parser.add_argument("--data_audit", required=True)
    parser.add_argument("--preflight_manifest", required=True)
    parser.add_argument("--resume_adapter_path", required=True)
    parser.add_argument("--output_dir", required=True)
    parser.add_argument("--base_model", default=DEFAULT_BASE)
    parser.add_argument("--physics_python", required=True)
    parser.add_argument("--physics_timeout_s", type=float, default=60.0)
    parser.add_argument("--max_length", type=int, default=1024)
    parser.add_argument("--candidate_batch_size", type=int, default=4)
    parser.add_argument("--epochs", type=int, default=4)
    parser.add_argument("--topk", type=int, default=3)
    parser.add_argument("--learning_rate", type=float, default=2e-6)
    parser.add_argument("--grad_accum", type=int, default=4)
    parser.add_argument("--max_grad_norm", type=float, default=1.0)
    parser.add_argument("--list_temperature", type=float, default=1.0)
    parser.add_argument("--lambda_bce", type=float, default=1.0)
    parser.add_argument("--lambda_listwise", type=float, default=0.5)
    parser.add_argument("--lambda_hard", type=float, default=1.0)
    parser.add_argument("--hard_margin", type=float, default=0.5)
    parser.add_argument("--beta_reference", type=float, default=0.02)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--gradient_checkpointing", type=int, choices=[0, 1], default=1)
    parser.add_argument("--bootstrap_reps", type=int, default=2000)
    return parser.parse_args()


def file_sha256(path):
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def schedule_manifest(args):
    return {
        "max_length": args.max_length,
        "candidate_batch_size": args.candidate_batch_size,
        "epochs": args.epochs,
        "topk": args.topk,
        "learning_rate": args.learning_rate,
        "grad_accum": args.grad_accum,
        "max_grad_norm": args.max_grad_norm,
        "list_temperature": args.list_temperature,
        "lambda_bce": args.lambda_bce,
        "lambda_listwise": args.lambda_listwise,
        "lambda_hard": args.lambda_hard,
        "hard_margin": args.hard_margin,
        "beta_reference": args.beta_reference,
        "seed": args.seed,
        "gradient_checkpointing": args.gradient_checkpointing,
        "physics_timeout_s": args.physics_timeout_s,
        "bootstrap_reps": args.bootstrap_reps,
    }


def verify_preflight(args):
    

    import preflight_gridrank_feedback as runtime

    manifest = json.load(open(args.preflight_manifest, encoding="utf-8"))
    summary = json.load(open(args.data_summary, encoding="utf-8"))
    audit = json.load(open(args.data_audit, encoding="utf-8"))
    if not manifest.get("preflight_pass") or not audit.get("audit_pass"):
        raise RuntimeError("GridRank-Select CPU preflight/data audit did not pass")
    if summary.get("schema") != "gridrank-select-summary-v1":
        raise RuntimeError("unexpected GridRank-Select summary schema")
    expected_artifacts = {
        "train": file_sha256(args.train_jsonl),
        "test": file_sha256(args.test_jsonl),
        "summary": file_sha256(args.data_summary),
        "audit": file_sha256(args.data_audit),
    }
    if manifest.get("artifact_sha256") != expected_artifacts:
        raise RuntimeError("derived GridRank-Select artifact hashes changed")
    if manifest.get("training_schedule") != schedule_manifest(args):
        raise RuntimeError("GPU schedule differs from locked CPU preflight")
    if manifest.get("training_runtime") != runtime.training_runtime():
        raise RuntimeError("training runtime differs from locked CPU preflight")
    if manifest.get("physics_runtime") != runtime.physics_runtime(args.physics_python):
        raise RuntimeError("physics runtime differs from locked CPU preflight")
    adapter = Path(args.resume_adapter_path)
    current_adapter = {
        "adapter_config_json": file_sha256(adapter / "adapter_config.json"),
        "adapter_model_safetensors": file_sha256(adapter / "adapter_model.safetensors"),
    }
    if manifest.get("resume_adapter_sha256") != current_adapter:
        raise RuntimeError("SFT adapter differs from locked CPU preflight")
    here = Path(__file__).resolve().parent
    code_sha256 = manifest.get("code_sha256")
    if not isinstance(code_sha256, dict) or not code_sha256:
        raise RuntimeError("preflight did not lock the source dependency chain")
    required_code = {"gridrank_select_llm.py", "train_gridrank_select.py"}
    if not required_code.issubset(code_sha256):
        raise RuntimeError("preflight omitted the GPU scorer/trainer source")
    for relative, expected_hash in code_sha256.items():
        path = here / relative
        if not path.is_file() or file_sha256(path) != expected_hash:
            raise RuntimeError(f"locked source changed: {relative}")
    base = Path(args.base_model)
    base_manifest = manifest.get("base_model_manifest")
    if not isinstance(base_manifest, dict) or not base_manifest:
        raise RuntimeError("preflight did not lock the base model")
    for relative, expected in base_manifest.items():
        path = base / relative
        if (
            not path.is_file()
            or path.stat().st_size != int(expected["bytes"])
            or file_sha256(path) != expected["sha256"]
        ):
            raise RuntimeError(f"base model changed: {relative}")
    return manifest


def _finite(value):
    return value is not None and math.isfinite(float(value))


def load_rows(path, partition, topk):
    rows = [json.loads(line) for line in open(path, encoding="utf-8") if line.strip()]
    if not rows:
        raise ValueError(f"empty partition: {path}")
    seen = set()
    candidate_count = None
    for row in rows:
        if set(row) != ROW_FIELDS:
            raise ValueError(f"row field mismatch: {row.get('instance_id')}")
        if row["partition"] != partition or row["instance_id"] in seen:
            raise ValueError(f"partition/instance violation: {row['instance_id']}")
        seen.add(row["instance_id"])
        validate_exchange_only_row(row, minimum_candidates=topk)
        if row["instruction_id"] != "loss":
            raise ValueError("GridRank-Select v1 has one fixed loss objective")
        if row["feedback_status"] != "authoritative-gridrank-select-v1":
            raise ValueError("non-authoritative row")
        if set(row["gate_anchor"]) != ANCHOR_FIELDS:
            raise ValueError(f"gate-anchor field mismatch: {row['instance_id']}")
        if (
            not row["gate_anchor"]["feedback_valid"]
            or not row["gate_anchor"]["feasible"]
            or not row["gate_anchor"]["accepted_by_gate"]
            or not _finite(row["gate_anchor"]["safe_utility"])
        ):
            raise ValueError(f"non-operational no-op anchor: {row['instance_id']}")
        if candidate_count is None:
            candidate_count = len(row["candidates"])
        if len(row["candidates"]) != candidate_count:
            raise ValueError("candidate count is not fixed")
        if any(set(candidate) != CANDIDATE_FIELDS for candidate in row["candidates"]):
            raise ValueError(f"candidate field mismatch: {row['instance_id']}")
        if any(not candidate["feedback_revealed"] for candidate in row["candidates"]):
            raise ValueError(f"unrevealed training/evaluation physics: {row['instance_id']}")
        if any(
            candidate["accepted_by_gate"] and not _finite(candidate["safe_utility"])
            for candidate in row["candidates"]
        ):
            raise ValueError(f"accepted candidate lacks safe utility: {row['instance_id']}")
        targets = [float(candidate["target_prob"]) for candidate in row["candidates"]]
        if any(value < 0 or not math.isfinite(value) for value in targets):
            raise ValueError("invalid target probability")
        if abs(sum(targets) - 1.0) > 1e-8:
            raise ValueError(f"target probabilities do not sum to one: {row['instance_id']}")
        optimal = [
            index for index, candidate in enumerate(row["candidates"])
            if candidate["is_ranking_optimal"] is True
        ]
        if not optimal or row["optimal_indices"] != optimal:
            raise ValueError(f"ranking optimum mismatch: {row['instance_id']}")
        if row["desired_index"] not in optimal:
            raise ValueError(f"desired action is not optimal: {row['instance_id']}")
        if row["candidates"][row["desired_index"]]["action"] != row["desired_action"]:
            raise ValueError(f"desired action mismatch: {row['instance_id']}")
    return rows


def parameter_copy(named):
    return {name: parameter.detach().float().cpu().clone() for name, parameter in named}


def parameter_delta(named, before):
    changed, squared, maximum = 0, 0.0, 0.0
    for name, parameter in named:
        delta = parameter.detach().float().cpu() - before[name]
        changed += int(bool((delta != 0).any()))
        squared += float((delta * delta).sum())
        maximum = max(maximum, float(delta.abs().max()))
    return {"changed_tensors": changed, "l2": math.sqrt(squared), "max_abs": maximum}


def adapter_initial_equality(default_lora, reference_lora):
    def canonical(name, adapter):
        return name.replace(f".{adapter}.", ".ADAPTER.")
    left = {canonical(name, "default"): parameter.detach().float().cpu()
            for name, parameter in default_lora}
    right = {canonical(name, "reference"): parameter.detach().float().cpu()
             for name, parameter in reference_lora}
    if set(left) != set(right):
        return {"same_tensor_set": False, "changed_tensors": None, "max_abs": None}
    deltas = [(left[name] - right[name]).abs() for name in left]
    return {
        "same_tensor_set": True,
        "changed_tensors": sum(bool((delta != 0).any()) for delta in deltas),
        "max_abs": max((float(delta.max()) for delta in deltas), default=0.0),
    }


def gradient_audit(default_lora, reference_lora):
    import torch
    gradients = [parameter.grad for _, parameter in default_lora if parameter.grad is not None]
    return {
        "gradient_tensors": len(gradients),
        "nonzero_gradient_tensors": sum(bool(torch.any(value != 0)) for value in gradients),
        "finite": all(bool(torch.isfinite(value).all()) for value in gradients),
        "reference_gradient_tensors": sum(
            parameter.grad is not None for _, parameter in reference_lora
        ),
    }


def score_row(model, tokenizer, row, args, require_grad, adapter="default"):
    model.set_adapter(adapter)
    return exchange_scores(
        model, tokenizer, row, max_length=args.max_length,
        candidate_batch_size=args.candidate_batch_size, require_grad=require_grad,
    )


def score_cache(model, tokenizer, rows, args, adapter):
    cache = {}
    for row in rows:
        cache[row["instance_id"]] = score_row(
            model, tokenizer, row, args, False, adapter=adapter
        ).detach().float().cpu()
    model.set_adapter("default")
    return cache


def class_weights(rows):
    labels = [bool(candidate["accepted_by_gate"])
              for row in rows for candidate in row["candidates"]]
    positive = sum(labels)
    negative = len(labels) - positive
    if positive <= 0 or negative <= 0:
        raise RuntimeError("acceptability BCE requires both positive and negative exchanges")
    return {
        "positive": len(labels) / (2.0 * positive),
        "negative": len(labels) / (2.0 * negative),
        "positive_count": positive,
        "negative_count": negative,
    }


def training_objective(scores, row, reference_scores, weights, args):
    import torch
    import torch.nn.functional as functional

    labels = torch.tensor(
        [float(bool(candidate["accepted_by_gate"])) for candidate in row["candidates"]],
        device=scores.device, dtype=torch.float32,
    )
    sample_weights = torch.where(
        labels > 0.5,
        torch.full_like(labels, float(weights["positive"])),
        torch.full_like(labels, float(weights["negative"])),
    )
    bce_each = functional.binary_cross_entropy_with_logits(
        scores.float(), labels, reduction="none"
    )


    bce = (bce_each * sample_weights).mean()

    target = torch.tensor(
        [float(candidate["target_prob"]) for candidate in row["candidates"]],
        device=scores.device, dtype=torch.float32,
    )
    log_policy = torch.log_softmax(scores.float() / args.list_temperature, dim=-1)
    listwise = -(target * log_policy).sum()

    positives = [index for index, value in enumerate(labels.tolist()) if value > 0.5]
    negatives = [index for index, value in enumerate(labels.tolist()) if value <= 0.5]
    if positives and negatives:
        best_positive = max(
            positives,
            key=lambda index: (
                float(row["candidates"][index]["safe_utility"]),
                row["candidates"][index]["action"],
            ),
        )
        hardest_negative = torch.stack([scores[index].float() for index in negatives]).max()
        hard_gap = scores[best_positive].float() - hardest_negative
        hard = functional.softplus(args.hard_margin - hard_gap)
    else:
        hard_gap = scores.new_zeros((), dtype=torch.float32)
        hard = scores.new_zeros((), dtype=torch.float32)

    reference = reference_scores.to(scores.device).float()
    reference_probability = torch.sigmoid(reference).clamp(1e-6, 1.0 - 1e-6)
    policy_log_positive = functional.logsigmoid(scores.float())
    policy_log_negative = functional.logsigmoid(-scores.float())
    reference_kl = (
        reference_probability
        * (torch.log(reference_probability) - policy_log_positive)
        + (1.0 - reference_probability)
        * (torch.log(1.0 - reference_probability) - policy_log_negative)
    ).mean()
    total = (
        args.lambda_bce * bce
        + args.lambda_listwise * listwise
        + args.lambda_hard * hard
        + args.beta_reference * reference_kl
    )
    if not bool(torch.isfinite(total)):
        raise FloatingPointError(f"non-finite objective: {row['instance_id']}")
    return {
        "total": total, "bce": bce, "listwise": listwise, "hard": hard,
        "hard_gap": hard_gap, "reference_kl": reference_kl,
    }


def optimizer_step(optimizer, parameters, max_norm):
    import torch
    norm = torch.nn.utils.clip_grad_norm_(parameters, max_norm, error_if_nonfinite=True)
    optimizer.step()
    optimizer.zero_grad(set_to_none=True)
    return float(norm)


def train(model, tokenizer, rows, references, default_lora, reference_lora, weights, args):
    import torch

    parameters = [parameter for _, parameter in default_lora]
    optimizer = torch.optim.AdamW(parameters, lr=args.learning_rate, weight_decay=0.0)
    rng = random.Random(args.seed + 701)
    history, first_gradient = [], None
    optimizer_steps = 0
    for epoch in range(1, args.epochs + 1):
        schedule = list(rows)
        rng.shuffle(schedule)
        optimizer.zero_grad(set_to_none=True)
        records = []
        for micro, row in enumerate(schedule, start=1):
            scores = score_row(model, tokenizer, row, args, True)
            terms = training_objective(
                scores, row, references[row["instance_id"]], weights, args
            )
            (terms["total"] / args.grad_accum).backward()
            if first_gradient is None:
                first_gradient = gradient_audit(default_lora, reference_lora)
                if (
                    first_gradient["nonzero_gradient_tensors"] <= 0
                    or not first_gradient["finite"]
                    or first_gradient["reference_gradient_tensors"] != 0
                ):
                    raise RuntimeError(f"first-gradient audit failed: {first_gradient}")
            records.append({key: float(value.detach()) for key, value in terms.items()})
            if micro % args.grad_accum == 0:
                optimizer_step(optimizer, parameters, args.max_grad_norm)
                optimizer_steps += 1
        remainder = len(schedule) % args.grad_accum
        if remainder:
            scale = args.grad_accum / remainder
            for parameter in parameters:
                if parameter.grad is not None:
                    parameter.grad.mul_(scale)
            optimizer_step(optimizer, parameters, args.max_grad_norm)
            optimizer_steps += 1
        history.append({
            "epoch": epoch,
            **{key: sum(record[key] for record in records) / len(records)
               for key in ("total", "bce", "listwise", "hard", "hard_gap", "reference_kl")},
        })
        print(json.dumps({
            "msg": "GridRank-Select epoch",
            **history[-1],
            "optimizer_steps_total": optimizer_steps,
        }, ensure_ascii=False), flush=True)
    return {
        "class_weights": weights, "history": history,
        "first_gradient": first_gradient, "optimizer_steps": optimizer_steps,
    }


def _safe_value(candidate):
    value = candidate.get("safe_utility")
    return -math.inf if value is None else float(value)


def _accepted(candidate):
    return bool(
        candidate.get("feedback_valid")
        and candidate.get("feasible")
        and candidate.get("accepted_by_gate")
        and _finite(candidate.get("safe_utility"))
    )


def _best_safe(row, candidate_indices=None):
    choices = [("anchor", None, row["gate_anchor"])]
    if candidate_indices is None:
        candidate_indices = range(len(row["candidates"]))
    choices.extend(("exchange", index, row["candidates"][index]) for index in candidate_indices)
    accepted = [item for item in choices if _accepted(item[2])]
    if not accepted:
        return ("anchor", None, row["gate_anchor"])
    return max(
        accepted,
        key=lambda item: (
            _safe_value(item[2]), item[0] == "anchor", item[2]["action"]
        ),
    )


def record_from_scores(row, scores, topk):
    values = [float(value) for value in scores]
    queried = topk_exchange_indices(values, row, topk)
    if len(queried) != topk or any(
        row["candidates"][index]["action"] == NOOP for index in queried
    ):
        raise RuntimeError("fixed exchange-only Top-k violated")
    top1 = queried[0]
    accepted_indices = [
        index for index, candidate in enumerate(row["candidates"]) if _accepted(candidate)
    ]
    anchor_value = _safe_value(row["gate_anchor"])
    improvable = [
        index for index in accepted_indices
        if _safe_value(row["candidates"][index]) > anchor_value + 1e-12
    ]
    if improvable:
        best_value = max(_safe_value(row["candidates"][index]) for index in improvable)
        optimal_improvable = {
            index for index in improvable
            if abs(_safe_value(row["candidates"][index]) - best_value) <= 1e-12
        }
    else:
        optimal_improvable = set()
    pool_best = _best_safe(row)
    selected = _best_safe(row, queried)
    pool_best_value = _safe_value(pool_best[2])
    selected_value = _safe_value(selected[2])
    anchor_regret = max(0.0, pool_best_value - anchor_value)
    safe_regret = max(0.0, pool_best_value - selected_value)
    true_labels = [bool(candidate["accepted_by_gate"]) for candidate in row["candidates"]]
    predicted = [value >= 0.0 for value in values]
    shortlist_accepted = sum(true_labels[index] for index in queried)
    return {
        "instance_id": row["instance_id"],
        "network": str(row["network_id"]),
        "load_id": row["load_id"],
        "physical_state_sha256": row["physical_state_sha256"],
        "top1_index": top1,
        "top1_action": row["candidates"][top1]["action"],
        "topk_indices": queried,
        "topk_actions": [row["candidates"][index]["action"] for index in queried],
        "noop_in_ranking": any(row["candidates"][index]["action"] == NOOP for index in queried),
        "improvable": bool(improvable),
        "exchange_top1_recall": None if not improvable else top1 in optimal_improvable,
        "exchange_topk_recall": None if not improvable else bool(optimal_improvable.intersection(queried)),
        "accepted_pool_count": len(accepted_indices),
        "accepted_shortlist_count": shortlist_accepted,
        "shortlist_precision_numerator": shortlist_accepted,
        "shortlist_precision_denominator": topk,
        "shortlist_recall_numerator": shortlist_accepted,
        "shortlist_recall_denominator": len(accepted_indices),
        "classification_tp": sum(a and b for a, b in zip(true_labels, predicted)),
        "classification_fp": sum((not a) and b for a, b in zip(true_labels, predicted)),
        "classification_fn": sum(a and (not b) for a, b in zip(true_labels, predicted)),
        "classification_tn": sum((not a) and (not b) for a, b in zip(true_labels, predicted)),
        "safe_action": selected[2]["action"],
        "safe_is_exchange": selected[0] == "exchange",
        "safe_utility": selected_value,
        "safe_regret": safe_regret,
        "safe_feasible": bool(selected[2].get("feasible")),
        "safe_reduction_pct": 0.0 if selected[0] == "anchor" else float(selected[2]["reduction_pct"]),
        "always_noop_action": NOOP,
        "always_noop_safe_regret": anchor_regret,
        "always_noop_feasible": bool(row["gate_anchor"].get("feasible")),
        "logical_queries": topk + 1,
        "candidate_power_flows": topk,
        "anchor_power_flows": 1,
        "full_pool_cached_candidates": len(row["candidates"]),
        "full_pool_power_flows": len(row["candidates"]) + 1,
        "fixed_budget_call_reduction": 1.0 - (topk + 1) / (len(row["candidates"]) + 1),
        "scores": values,
    }


def evaluate(model, tokenizer, rows, args):
    output = []
    for row in rows:
        scores = score_row(model, tokenizer, row, args, False).detach().float().cpu()
        output.append(record_from_scores(row, scores, args.topk))
    return output


def _ratio(numerator, denominator):
    return None if denominator <= 0 else numerator / denominator


def _metric_not_worse(value, baseline, tolerance=1e-12):
    return value is not None and baseline is not None and value >= baseline - tolerance


def summarise(records):
    n = len(records)
    improvable = [record for record in records if record["improvable"]]
    tp = sum(record["classification_tp"] for record in records)
    fp = sum(record["classification_fp"] for record in records)
    fn = sum(record["classification_fn"] for record in records)
    shortlist_tp = sum(record["shortlist_precision_numerator"] for record in records)
    shortlist_all = sum(record["shortlist_precision_denominator"] for record in records)
    accepted_all = sum(record["shortlist_recall_denominator"] for record in records)
    return {
        "n": n,
        "base_states": len({record["physical_state_sha256"] for record in records}),
        "loads": len({record["load_id"] for record in records}),
        "improvable_rows": len(improvable),
        "exchange_top1_recall_on_improvable": _ratio(
            sum(record["exchange_top1_recall"] for record in improvable), len(improvable)
        ),
        "exchange_topk_recall_on_improvable": _ratio(
            sum(record["exchange_topk_recall"] for record in improvable), len(improvable)
        ),
        "accepted_candidate_precision_at_zero": _ratio(tp, tp + fp),
        "accepted_candidate_recall_at_zero": _ratio(tp, tp + fn),
        "accepted_shortlist_precision": _ratio(shortlist_tp, shortlist_all),
        "accepted_shortlist_recall": _ratio(shortlist_tp, accepted_all),
        "safe_regret_mean": sum(record["safe_regret"] for record in records) / n,
        "safe_utility_mean": sum(record["safe_utility"] for record in records) / n,
        "safe_feasible_rate": sum(record["safe_feasible"] for record in records) / n,
        "safe_exchange_rate": sum(record["safe_is_exchange"] for record in records) / n,
        "safe_reduction_pct_mean": sum(record["safe_reduction_pct"] for record in records) / n,
        "always_noop_safe_regret_mean": sum(
            record["always_noop_safe_regret"] for record in records
        ) / n,
        "always_noop_feasible_rate": sum(record["always_noop_feasible"] for record in records) / n,
        "logical_queries_mean": sum(record["logical_queries"] for record in records) / n,
        "candidate_power_flows_mean": sum(record["candidate_power_flows"] for record in records) / n,
        "anchor_power_flows_mean": sum(record["anchor_power_flows"] for record in records) / n,
        "full_pool_power_flows_mean": sum(
            record["full_pool_power_flows"] for record in records
        ) / n,
        "fixed_budget_call_reduction_mean": sum(
            record["fixed_budget_call_reduction"] for record in records
        ) / n,
        "noop_in_ranking_rows": sum(record["noop_in_ranking"] for record in records),
    }


def breakdown(records):
    return {
        network: summarise([record for record in records if record["network"] == network])
        for network in sorted({record["network"] for record in records})
    }


def paired(before, after, reps, seed):
    if [item["instance_id"] for item in before] != [item["instance_id"] for item in after]:
        raise RuntimeError("paired row order changed")
    deltas = [old["safe_regret"] - new["safe_regret"] for old, new in zip(before, after)]
    groups = defaultdict(list)
    for delta, row in zip(deltas, before):
        groups[(row["network"], row["physical_state_sha256"])].append(delta)
    clusters = [sum(values) / len(values) for values in groups.values()]
    rng = random.Random(seed)
    samples = []
    for _ in range(reps):
        draw = [clusters[rng.randrange(len(clusters))] for _ in clusters]
        samples.append(sum(draw) / len(draw))
    samples.sort()
    return {
        "n_rows": len(deltas),
        "n_state_clusters": len(clusters),
        "safe_regret_improvement_mean": sum(deltas) / len(deltas),
        "state_cluster_improvement_mean": sum(clusters) / len(clusters),
        "state_cluster_bootstrap_ci95": [
            samples[int(0.025 * (len(samples) - 1))],
            samples[int(0.975 * (len(samples) - 1))],
        ],
        "rows_better": sum(value > 1e-12 for value in deltas),
        "rows_worse": sum(value < -1e-12 for value in deltas),
        "rows_tied": sum(abs(value) <= 1e-12 for value in deltas),
    }


def paired_by_network(before, after, reps, seed):
    output = {}
    for offset, network in enumerate(sorted({row["network"] for row in before})):
        old = [row for row in before if row["network"] == network]
        new_by_id = {row["instance_id"]: row for row in after if row["network"] == network}
        new = [new_by_id[row["instance_id"]] for row in old]
        output[network] = paired(old, new, reps, seed + offset)
    return output


def _live_anchor(row, detail):
    template = row["gate_anchor"]
    minimum = detail.get("anchor_min_vm_pu")
    maximum = detail.get("anchor_max_vm_pu")
    valid = bool(
        detail.get("feedback_valid")
        and _finite(detail.get("anchor_loss_kw"))
        and _finite(minimum)
        and _finite(maximum)
    )
    output = {key: template.get(key) for key in ANCHOR_FIELDS}
    output.update({
        "role": "noop-anchor-only", "action": NOOP,
        "feedback_revealed": True, "feedback_valid": valid,
        "feasible": bool(
            valid and reward.VMIN <= float(minimum) <= reward.VMAX
            and reward.VMIN <= float(maximum) <= reward.VMAX
        ),
        "reason": "ok" if valid else "invalid_anchor",
        "reduction_pct": 0.0 if valid else None,
        "anchor_loss_kw": detail.get("anchor_loss_kw"),
        "candidate_loss_kw": detail.get("anchor_loss_kw"),
        "anchor_min_vm_pu": minimum,
        "candidate_min_vm_pu": minimum,
        "candidate_max_vm_pu": maximum,
    })
    return output


def _close(left, right, tolerance=1e-6):
    if left is None or right is None:
        return left is None and right is None
    return abs(float(left) - float(right)) <= tolerance * max(1.0, abs(float(right)))


def live_topk_replay(rows, records, args):
    

    output = []
    for row, record in zip(rows, records):
        if row["instance_id"] != record["instance_id"]:
            raise RuntimeError("live replay row order mismatch")
        indices = list(record["topk_indices"])
        actions = [row["candidates"][index]["action"] for index in indices]
        if len(actions) != args.topk or NOOP in actions:
            raise RuntimeError("live replay received invalid exchange Top-k")
        error = None
        try:
            evaluated = reward.score_completions(
                row["state_text"], actions, return_detail=True, action_mode="delta",
                physics_backend="pandapower-subprocess", physics_python=args.physics_python,
                physics_timeout_s=args.physics_timeout_s,
            )
        except Exception as exc:
            evaluated = []
            error = f"{type(exc).__name__}: {exc}"
        if len(evaluated) != len(actions):
            error = error or f"outcome count {len(evaluated)} != {len(actions)}"
        live_selected = row["gate_anchor"]
        cache_match = False
        if error is None:
            anchor = _live_anchor(row, evaluated[0][2])
            probed = [
                sanitize_feedback(row["candidates"][index], result)
                for index, result in zip(indices, evaluated)
            ]
            if not anchor["feedback_valid"] or not anchor["feasible"] or not all(
                candidate["feedback_valid"] for candidate in probed
            ):
                error = "invalid or non-operational live physics feedback"
            else:
                _, labelled = label_candidates("loss", [anchor, *probed], 0.20)
                by_action = {candidate["action"]: candidate for candidate in labelled}
                cached = [row["gate_anchor"], *[row["candidates"][index] for index in indices]]
                cache_match = all(
                    action in by_action
                    and bool(by_action[action]["feedback_valid"]) == bool(candidate["feedback_valid"])
                    and bool(by_action[action]["feasible"]) == bool(candidate["feasible"])
                    and bool(by_action[action]["accepted_by_gate"]) == bool(candidate["accepted_by_gate"])
                    and _close(by_action[action].get("reduction_pct"), candidate.get("reduction_pct"))
                    for candidate in cached
                    for action in [candidate["action"]]
                )
                if not cache_match:
                    error = "live physics does not match cached authoritative labels"
                else:
                    eligible = [candidate for candidate in labelled if _accepted(candidate)]
                    live_selected = max(
                        eligible,
                        key=lambda candidate: (
                            _safe_value(candidate), candidate["action"] == NOOP,
                            candidate["action"],
                        ),
                    ) if eligible else anchor
        if error is not None:
            live_selected = row["gate_anchor"]
        output.append({
            "instance_id": row["instance_id"],
            "network": str(row["network_id"]),
            "topk_actions": actions,
            "noop_ranked": NOOP in actions,
            "feedback_valid": error is None,
            "fail_closed": error is not None and live_selected["action"] == NOOP,
            "error": error,
            "cache_labels_match": cache_match,
            "selected_action": live_selected["action"],
            "selected_feasible": bool(live_selected.get("feasible")),
            "matches_cached_gate": error is None and live_selected["action"] == record["safe_action"],
            "candidate_power_flows": args.topk,
            "anchor_power_flows": 1,
            "backend_power_flows": args.topk + 1,
        })
    n = len(output)
    return {
        "rows": output,
        "summary": {
            "n": n,
            "valid_rate": sum(row["feedback_valid"] for row in output) / n,
            "fail_closed_rows": sum(row["fail_closed"] for row in output),
            "cache_labels_match_rate": sum(row["cache_labels_match"] for row in output) / n,
            "matches_cached_gate_rate": sum(row["matches_cached_gate"] for row in output) / n,
            "selected_feasible_rate": sum(row["selected_feasible"] for row in output) / n,
            "noop_ranked_rows": sum(row["noop_ranked"] for row in output),
            "candidate_power_flows": sum(row["candidate_power_flows"] for row in output),
            "anchor_power_flows": sum(row["anchor_power_flows"] for row in output),
            "backend_power_flows": sum(row["backend_power_flows"] for row in output),
        },
    }


def validate_saved_adapter(path):
    path = Path(path)
    config = path / "adapter_config.json"
    weights = path / "adapter_model.safetensors"
    result = {"path": str(path), "valid": False, "sha256": {}}
    try:
        if not config.is_file() or not weights.is_file() or weights.stat().st_size <= 0:
            raise RuntimeError("adapter config/weights missing or empty")
        json.loads(config.read_text(encoding="utf-8"))
        from safetensors import safe_open
        with safe_open(str(weights), framework="pt", device="cpu") as handle:
            keys = list(handle.keys())
        if not keys:
            raise RuntimeError("adapter has no tensors")
        result.update({
            "valid": True, "tensor_count": len(keys),
            "sha256": {
                "adapter_config_json": file_sha256(config),
                "adapter_model_safetensors": file_sha256(weights),
            },
        })
    except Exception as exc:
        result["error"] = f"{type(exc).__name__}: {exc}"
    return result


def main():
    import torch
    import grpo_train as training

    args = parse_args()
    positive = (
        args.max_length, args.candidate_batch_size, args.epochs, args.topk,
        args.learning_rate, args.grad_accum, args.max_grad_norm, args.list_temperature,
        args.lambda_bce, args.lambda_listwise, args.lambda_hard, args.hard_margin,
        args.beta_reference, args.physics_timeout_s, args.bootstrap_reps,
    )
    if any(value <= 0 for value in positive):
        raise SystemExit("all schedule values must be positive")
    if args.topk != 3:
        raise SystemExit("GridRank-Select kill gate is locked to K=3 exchanges")
    manifest = verify_preflight(args)
    if not torch.cuda.is_available():
        raise RuntimeError("GridRank-Select GPU stage requires CUDA")
    random.seed(args.seed)
    torch.manual_seed(args.seed)
    torch.cuda.manual_seed_all(args.seed)

    train_rows = load_rows(args.train_jsonl, "train", args.topk)
    test_rows = load_rows(args.test_jsonl, "test", args.topk)
    if {row["physical_state_sha256"] for row in train_rows}.intersection(
        {row["physical_state_sha256"] for row in test_rows}
    ):
        raise RuntimeError("train state leaked into held-out test")
    if {row["load_id"] for row in train_rows}.intersection(
        {row["load_id"] for row in test_rows}
    ):
        raise RuntimeError("train load leaked into held-out test")

    model, tokenizer = training.build_model_and_tokenizer(args)
    tokenizer.pad_token = tokenizer.eos_token
    model.config.pad_token_id = tokenizer.pad_token_id
    default_lora = [(name, parameter) for name, parameter in model.named_parameters()
                    if "lora_" in name and ".default." in name]
    reference_lora = [(name, parameter) for name, parameter in model.named_parameters()
                      if "lora_" in name and ".reference." in name]
    if not default_lora or not reference_lora:
        raise RuntimeError("policy/reference LoRA adapters are required")
    for _, parameter in default_lora:
        parameter.requires_grad_(True)
    for _, parameter in reference_lora:
        parameter.requires_grad_(False)
    initial_equality = adapter_initial_equality(default_lora, reference_lora)
    if not initial_equality["same_tensor_set"] or initial_equality["changed_tensors"] != 0:
        raise RuntimeError(f"policy/reference differ at start: {initial_equality}")

    initial_policy = parameter_copy(default_lora)
    initial_reference = parameter_copy(reference_lora)
    references = score_cache(model, tokenizer, train_rows, args, "reference")
    sft_records = evaluate(model, tokenizer, test_rows, args)
    weights = class_weights(train_rows)
    training_result = train(
        model, tokenizer, train_rows, references,
        default_lora, reference_lora, weights, args,
    )
    distilled_records = evaluate(model, tokenizer, test_rows, args)
    live_gate = live_topk_replay(test_rows, distilled_records, args)

    
    permutation_rows = test_rows[: min(8, len(test_rows))]
    permutation_max_delta = 0.0
    permutation_matches = 0
    for row in permutation_rows:
        original = score_row(model, tokenizer, row, args, False).detach().float().cpu()
        order = list(reversed(range(len(row["candidates"]))))
        permuted = score_row(
            model, tokenizer, reordered_exchange_row(row, order), args, False
        ).detach().float().cpu()
        remapped = [0.0] * len(order)
        for new_index, old_index in enumerate(order):
            remapped[old_index] = float(permuted[new_index])
        permutation_max_delta = max(
            permutation_max_delta,
            max(abs(float(a) - float(b)) for a, b in zip(original, remapped)),
        )
        permutation_matches += int(
            rank_exchange_indices(original, row) == rank_exchange_indices(remapped, row)
        )
    permutation_rate = permutation_matches / len(permutation_rows)

    summaries = {
        "sft": summarise(sft_records),
        "distilled": summarise(distilled_records),
        "always_noop": {
            "n": len(distilled_records),
            "safe_regret_mean": sum(
                row["always_noop_safe_regret"] for row in distilled_records
            ) / len(distilled_records),
            "feasible_rate": sum(row["always_noop_feasible"] for row in distilled_records)
            / len(distilled_records),
            "logical_queries_mean": 1.0,
            "candidate_power_flows_mean": 0.0,
            "anchor_power_flows_mean": 1.0,
        },
    }
    by_network = {
        "sft": breakdown(sft_records),
        "distilled": breakdown(distilled_records),
    }
    paired_result = {
        "distilled_vs_sft": paired(
            sft_records, distilled_records, args.bootstrap_reps, args.seed + 800
        ),
        "distilled_vs_sft_by_network": paired_by_network(
            sft_records, distilled_records, args.bootstrap_reps, args.seed + 900
        ),
    }
    policy_delta = parameter_delta(default_lora, initial_policy)
    reference_delta = parameter_delta(reference_lora, initial_reference)
    shortlist_changes = sum(
        set(old["topk_actions"]) != set(new["topk_actions"])
        for old, new in zip(sft_records, distilled_records)
    )
    safe_decision_changes = sum(
        old["safe_action"] != new["safe_action"]
        for old, new in zip(sft_records, distilled_records)
    )

    output = Path(args.output_dir)
    output.mkdir(parents=True, exist_ok=False)
    diagnostic_adapter = {"attempted": True, "valid": False}
    try:
        returned = bool(training.save_policy_adapter(
            model, output / "diagnostic_adapter", args.epochs
        ))
        diagnostic_adapter = validate_saved_adapter(output / "diagnostic_adapter")
        diagnostic_adapter["attempted"] = True
        diagnostic_adapter["save_function_returned"] = returned
        diagnostic_adapter["valid"] = bool(diagnostic_adapter["valid"] and returned)
    except Exception as exc:
        diagnostic_adapter = {
            "attempted": True, "valid": False,
            "error": f"{type(exc).__name__}: {exc}",
        }

    mechanism_checks = {
        "gradient_nonzero_finite": bool(
            training_result["first_gradient"]
            and training_result["first_gradient"]["nonzero_gradient_tensors"] > 0
            and training_result["first_gradient"]["finite"]
        ),
        "reference_adapter_frozen": reference_delta["changed_tensors"] == 0,
        "reference_equals_policy_at_start": initial_equality["changed_tensors"] == 0,
        "policy_parameters_changed": policy_delta["changed_tensors"] > 0,
        "heldout_exchange_shortlist_changed": shortlist_changes > 0,
        "heldout_safe_decision_changed": safe_decision_changes > 0,
        "no_noop_entered_any_ranking": (
            summaries["sft"]["noop_in_ranking_rows"] == 0
            and summaries["distilled"]["noop_in_ranking_rows"] == 0
            and live_gate["summary"]["noop_ranked_rows"] == 0
        ),
        "fixed_k3_plus_anchor_budget": all(
            row["logical_queries"] == 4 and row["candidate_power_flows"] == 3
            and row["anchor_power_flows"] == 1
            for row in [*sft_records, *distilled_records]
        ),
        "candidate_order_invariant": permutation_rate == 1.0,
        "diagnostic_adapter_saved_and_hashed": diagnostic_adapter["valid"],
    }
    efficacy_checks = {
        "distilled_safe_regret_not_worse_than_sft": (
            summaries["distilled"]["safe_regret_mean"]
            <= summaries["sft"]["safe_regret_mean"] + 1e-12
        ),
        "distilled_each_network_not_worse_than_sft": all(
            by_network["distilled"][network]["safe_regret_mean"]
            <= by_network["sft"][network]["safe_regret_mean"] + 1e-12
            for network in ("33", "69")
        ),
        "distilled_topk_recall_not_worse_than_sft": (
            _metric_not_worse(
                summaries["distilled"]["exchange_topk_recall_on_improvable"],
                summaries["sft"]["exchange_topk_recall_on_improvable"],
            )
        ),
        "distilled_accepted_recall_not_worse_than_sft": (
            _metric_not_worse(
                summaries["distilled"]["accepted_shortlist_recall"],
                summaries["sft"]["accepted_shortlist_recall"],
            )
        ),
        "distilled_topk_recall_each_network_not_worse": all(
            _metric_not_worse(
                by_network["distilled"][network]["exchange_topk_recall_on_improvable"],
                by_network["sft"][network]["exchange_topk_recall_on_improvable"],
            )
            for network in ("33", "69")
        ),
        "distilled_accepted_recall_each_network_not_worse": all(
            _metric_not_worse(
                by_network["distilled"][network]["accepted_shortlist_recall"],
                by_network["sft"][network]["accepted_shortlist_recall"],
            )
            for network in ("33", "69")
        ),
        "distilled_strictly_beats_sft": bool(
            summaries["distilled"]["safe_regret_mean"]
            < summaries["sft"]["safe_regret_mean"] - 1e-12
        ),
        "distilled_strictly_beats_always_noop": bool(
            summaries["distilled"]["safe_regret_mean"]
            < summaries["always_noop"]["safe_regret_mean"] - 1e-12
        ),
        "distilled_executes_verified_exchange": summaries["distilled"]["safe_exchange_rate"] > 0.0,
    }
    safety_checks = {
        "cached_gate_all_feasible": summaries["distilled"]["safe_feasible_rate"] == 1.0,
        "live_topk_all_valid": live_gate["summary"]["valid_rate"] == 1.0,
        "live_topk_cache_labels_match": live_gate["summary"]["cache_labels_match_rate"] == 1.0,
        "live_topk_selected_action_matches_cached": (
            live_gate["summary"]["matches_cached_gate_rate"] == 1.0
        ),
        "live_topk_all_selected_feasible": live_gate["summary"]["selected_feasible_rate"] == 1.0,
    }
    engineering_gate_pass = all({
        **mechanism_checks, **efficacy_checks, **safety_checks
    }.values())
    paper_checks = {
        "engineering_gate_pass": engineering_gate_pass,
        "distilled_vs_sft_ci_lower_positive": paired_result[
            "distilled_vs_sft"
        ]["state_cluster_bootstrap_ci95"][0] > 0.0,
        "distilled_strictly_better_each_network": all(
            paired_result["distilled_vs_sft_by_network"][network][
                "safe_regret_improvement_mean"
            ] > 0.0
            for network in ("33", "69")
        ),
    }
    result = {
        "msg": "GridRank-Select exchange-only physics distillation gate",
        "architecture": (
            "state + fixed loss objective + one non-noop exchange + non-AC features -> "
            "native LLM YES/NO score; no-op is an unranked physics-gate anchor"
        ),
        "decision_protocol": "exactly Top-3 exchanges + common no-op -> live Pandapower gate",
        "preflight_sha256": file_sha256(args.preflight_manifest),
        "locked_manifest": manifest,
        "training_schedule": schedule_manifest(args),
        "training": training_result,
        "parameter_delta": policy_delta,
        "reference_parameter_delta": reference_delta,
        "initial_adapter_equality": initial_equality,
        "heldout_topk_membership_changed_rows": shortlist_changes,
        "heldout_safe_action_changed_rows": safe_decision_changes,
        "candidate_permutation_probe_rate": permutation_rate,
        "candidate_permutation_score_max_abs_delta": permutation_max_delta,
        "summaries": summaries,
        "by_network": by_network,
        "paired": paired_result,
        "live_topk_gate": live_gate,
        "diagnostic_adapter": diagnostic_adapter,
        "mechanism_checks": mechanism_checks,
        "efficacy_checks": efficacy_checks,
        "safety_checks": safety_checks,
        "engineering_gate_pass": engineering_gate_pass,
        "paper_checks": paper_checks,
        "paper_gate_pass": all(paper_checks.values()),
    }
    (output / "gridrank_select_gate.json").write_text(
        json.dumps(result, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    print(json.dumps(result, ensure_ascii=False))
    if not engineering_gate_pass:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
