"""Validate GridRank select."""

from __future__ import annotations

import copy
import json
import math
import tempfile
from pathlib import Path

from build_gridrank_select import (
    CANDIDATE_FIELDS,
    GATE_ANCHOR_FIELDS,
    INSTRUCTION_IDS,
    NOOP,
    ROW_FIELDS,
    SOURCE_CANDIDATE_FIELDS,
    SOURCE_ROW_FIELDS,
    derive_row,
    file_sha256,
    validate_derived_row,
    validate_source_rows,
    validate_upstream,
)


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def source_candidate(action, reduction, *, feasible=True, accepted=False, target=0.0):
    candidate = {
        "action": action,
        "candidate_feature_text": f"topology-only={action}",
        "feedback_revealed": True,
        "feedback_valid": True,
        "feasible": feasible,
        "reason": "ok" if feasible else "voltage",
        "reduction_pct": reduction,
        "anchor_loss_kw": 100.0,
        "candidate_loss_kw": None if reduction is None else 100.0 * (1.0 - reduction / 100.0),
        "anchor_min_vm_pu": 0.95,
        "candidate_min_vm_pu": 0.95 if feasible else 0.80,
        "candidate_max_vm_pu": 1.02,
        "instruction_utility": reduction,
        "safe_utility": reduction if accepted or action == NOOP else None,
        "accepted_by_gate": bool(accepted or action == NOOP),
        "is_physics_optimal": action == NOOP,
        "fallback_candidate": action == NOOP,
        "normalised_regret": 0.0 if action == NOOP else 1.0,
        "physics_rank": 0 if action == NOOP else 1,
        "target_prob": target,
    }
    require(set(candidate) == SOURCE_CANDIDATE_FIELDS, "synthetic source candidate schema drift")
    return candidate


def source_row(instruction="loss", network="33", state="state-a", load="33:load-a"):
    candidates = [
        source_candidate(NOOP, 0.0, target=1.0),
        source_candidate("Action: Replace (1, 2) with (2, 3)", -0.2),
        source_candidate("Action: Replace (2, 3) with (3, 4)", -1.0),
        source_candidate("Action: Replace (3, 4) with (4, 5)", None, feasible=False),
    ]
    row = {
        "instance_id": f"offline_train:{network}:raw:{instruction}",
        "partition": "offline_train",
        "source_split": "train",
        "instruction_id": instruction,
        "instruction_style": "train",
        "instruction_text": f"synthetic {instruction} directive",
        "source_instance_id": "raw",
        "load_id": load,
        "network_id": network,
        "state_text": "canonical synthetic physical state",
        "physical_state_sha256": state,
        "full_candidate_count": 4,
        "candidate_pool_sha256": "pool",
        "feedback_status": "authoritative-full-pool",
        "desired_index": 0,
        "desired_action": NOOP,
        "optimal_indices": [0],
        "optimal_actions": [NOOP],
        "candidates": candidates,
    }
    require(set(row) == SOURCE_ROW_FIELDS, "synthetic source row schema drift")
    return row


def expect_failure(function, message):
    try:
        function()
    except (ValueError, RuntimeError):
        return
    raise RuntimeError(message)


def hash_lock_regression():
    with tempfile.TemporaryDirectory() as directory:
        root = Path(directory)
        offline = root / "offline.jsonl"
        test = root / "test.jsonl"
        online = root / "online.jsonl"
        offline.write_text("offline\n", encoding="utf-8")
        test.write_text("test\n", encoding="utf-8")
        online.write_text("online\n", encoding="utf-8")
        artifacts = {
            "offline_train": {"path": str(offline), "sha256": file_sha256(offline)},
            "online_stream": {"path": str(online), "sha256": file_sha256(online)},
            "test": {"path": str(test), "sha256": file_sha256(test)},
        }
        summary_path = root / "summary.json"
        summary = {
            "schema": "gridrank-feedback-v1",
            "coverage_pass": True,
            "candidate_pool_size": 4,
            "artifacts": artifacts,
        }
        summary_path.write_text(json.dumps(summary), encoding="utf-8")
        audit_path = root / "audit.json"
        audit = {
            "summary_sha256": file_sha256(summary_path),
            "artifact_sha256": {name: value["sha256"] for name, value in artifacts.items()},
            "checks": {"locked": True},
            "audit_pass": True,
        }
        audit_path.write_text(json.dumps(audit), encoding="utf-8")
        validate_upstream(
            summary_path, audit_path,
            {"offline_train": offline, "test": test},
        )
        offline.write_text("mutated\n", encoding="utf-8")
        expect_failure(
            lambda: validate_upstream(
                summary_path, audit_path,
                {"offline_train": offline, "test": test},
            ),
            "mutated upstream artifact passed the hash lock",
        )


def main():
    source = source_row()
    selected = derive_row(source, "train", 0.20)
    require(set(selected) == ROW_FIELDS, "derived row field set drift")
    require(all(set(candidate) == CANDIDATE_FIELDS for candidate in selected["candidates"]),
            "derived candidate field set drift")
    require(set(selected["gate_anchor"]) == GATE_ANCHOR_FIELDS,
            "gate anchor field set drift")
    require(all(candidate["action"] != NOOP for candidate in selected["candidates"]),
            "no-op remains in the LLM ranking list")
    require(selected["gate_anchor"]["action"] == NOOP,
            "no-op was not retained as the separate gate anchor")
    require(selected["desired_action"] != NOOP,
            "source always-noop target survived derivation")
    require(selected["desired_action"] == "Action: Replace (1, 2) with (2, 3)",
            "best feasible non-noop was not selected")
    require(math.isclose(sum(item["target_prob"] for item in selected["candidates"]), 1.0),
            "non-noop targets were not re-normalised")
    require(selected["candidates"][2]["target_prob"] == 0.0,
            "infeasible exchange received ranking target mass")
    require(all(not item["accepted_by_gate"] for item in selected["candidates"]),
            "synthetic always-noop premise is invalid")

    accepted_source = copy.deepcopy(source)
    accepted_source["candidates"][1]["reduction_pct"] = 3.0
    accepted_source["candidates"][1]["instruction_utility"] = 3.0
    accepted_source["candidates"][1]["safe_utility"] = 3.0
    accepted_source["candidates"][1]["accepted_by_gate"] = True
    accepted = derive_row(accepted_source, "train", 0.20)
    require(any(item["accepted_by_gate"] for item in accepted["candidates"])
            and any(not item["accepted_by_gate"] for item in accepted["candidates"]),
            "accepted/unsafe labels were not preserved")

    leaked = copy.deepcopy(selected)
    leaked["candidates"].append(dict(selected["gate_anchor"], **{
        "ranking_utility": 0.0,
        "ranking_eligible": True,
        "is_ranking_optimal": False,
        "ranking_regret": 1.0,
        "ranking_rank": len(selected["candidates"]),
        "target_prob": 0.0,
    }))
    leaked["candidates"][-1].pop("role")
    expect_failure(
        lambda: validate_derived_row(leaked, "train", 4),
        "no-op injection into the ranking list was accepted",
    )

    no_rankable = copy.deepcopy(source)
    for candidate in no_rankable["candidates"]:
        if candidate["action"] != NOOP:
            candidate["feasible"] = False
            candidate["reduction_pct"] = None
    expect_failure(
        lambda: derive_row(no_rankable, "train", 0.20),
        "row without a rankable non-noop candidate was accepted",
    )

    four_directives = [source_row(instruction=kind) for kind in sorted(INSTRUCTION_IDS)]
    selected_sources = validate_source_rows(four_directives, "offline_train", 4)
    require(len(selected_sources) == 1 and selected_sources[0]["instruction_id"] == "loss",
            "one-loss-row-per-state derivation failed")
    duplicated_loss = copy.deepcopy(four_directives)
    duplicated_loss[-1]["instruction_id"] = "loss"
    expect_failure(
        lambda: validate_source_rows(duplicated_loss, "offline_train", 4),
        "malformed directive set was accepted",
    )
    hash_lock_regression()
    print(json.dumps({
        "msg": "GridRank-Select dependency-light verification PASS",
        "always_noop_policy_impossible": True,
        "noop_absent_from_llm_candidates": True,
        "noop_anchor_separate": True,
        "target_renormalisation": True,
        "accepted_unsafe_labels_preserved": True,
        "one_loss_row_per_state": True,
        "upstream_hash_mutation_rejected": True,
    }, ensure_ascii=False))


if __name__ == "__main__":
    main()
