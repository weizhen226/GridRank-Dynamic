"""Gridrank select llm utilities."""

from __future__ import annotations

from typing import Iterable, Sequence


NOOP = "Action: none"
POSITIVE_TOKEN = "YES"
NEGATIVE_TOKEN = "NO"


def validate_exchange_only_row(row: dict, *, minimum_candidates: int = 1) -> None:
    

    if row.get("schema") != "gridrank-select-row-v1":
        raise ValueError("expected gridrank-select-row-v1")
    candidates = row.get("candidates")
    if not isinstance(candidates, list) or len(candidates) < minimum_candidates:
        raise ValueError("insufficient exchange candidates")
    actions = [candidate.get("action") for candidate in candidates]
    if any(not action or action == NOOP for action in actions):
        raise ValueError("no-op/malformed action entered exchange candidates")
    if len(actions) != len(set(actions)):
        raise ValueError("duplicate exchange action")
    anchor = row.get("gate_anchor")
    if not isinstance(anchor, dict) or anchor.get("action") != NOOP:
        raise ValueError("gate_anchor must be the separate no-op")
    if anchor.get("role") != "noop-anchor-only":
        raise ValueError("invalid no-op anchor role")


def resolve_preference_token_ids(tokenizer) -> tuple[int, int]:
    values = []
    for surface in (POSITIVE_TOKEN, NEGATIVE_TOKEN):
        encoded = tokenizer.encode(surface, add_special_tokens=False)
        if len(encoded) != 1:
            raise RuntimeError(
                f"readout token must be one tokenizer token: {surface!r} -> {encoded}"
            )
        values.append(int(encoded[0]))
    if values[0] == values[1]:
        raise RuntimeError("YES/NO token IDs are identical")
    return values[0], values[1]


def exchange_question(row: dict, candidate: dict) -> str:
    

    if candidate.get("action") == NOOP:
        raise ValueError("no-op must never enter the LLM scorer")
    features = candidate.get("candidate_feature_text")
    if not features:
        raise ValueError("candidate_feature_text is required")
    return (
        "State:\n"
        f"{row['state_text']}\n\n"
        "Objective:\n"
        f"{row['instruction_text']}\n\n"
        "Exchange:\n"
        f"{candidate['action']}\n\n"
        "Non-AC features:\n"
        f"{features}\n\n"
        f"Physics-gate acceptance? {POSITIVE_TOKEN} or {NEGATIVE_TOKEN}."
    )


def render_exchange_prompt(tokenizer, row: dict, candidate: dict) -> str:
    question = exchange_question(row, candidate)
    if getattr(tokenizer, "chat_template", None):
        return tokenizer.apply_chat_template(
            [{"role": "user", "content": question}],
            tokenize=False,
            add_generation_prompt=True,
        )
    return f"<|user|>\n{question}</s>\n<|assistant|>\n"


def _chunks(values: Sequence, size: int) -> Iterable[Sequence]:
    if size <= 0:
        raise ValueError("candidate_batch_size must be positive")
    for offset in range(0, len(values), size):
        yield values[offset : offset + size]


def canonical_exchange_indices(row: dict) -> list[int]:
    

    validate_exchange_only_row(row)
    return sorted(
        range(len(row["candidates"])),
        key=lambda index: row["candidates"][index]["action"],
    )


def exchange_scores(
    model,
    tokenizer,
    row: dict,
    *,
    max_length: int,
    candidate_batch_size: int,
    require_grad: bool,
):
    

    import torch

    validate_exchange_only_row(row)
    candidates = list(row["candidates"])
    canonical_indices = canonical_exchange_indices(row)
    canonical_candidates = [candidates[index] for index in canonical_indices]
    positive_id, negative_id = resolve_preference_token_ids(tokenizer)
    device = next(model.parameters()).device
    old_truncation = tokenizer.truncation_side
    old_padding = tokenizer.padding_side
    tokenizer.truncation_side = "left"
    tokenizer.padding_side = "right"
    output = []
    try:
        for chunk in _chunks(canonical_candidates, candidate_batch_size):
            texts = [render_exchange_prompt(tokenizer, row, candidate) for candidate in chunk]
            encoded = tokenizer(
                texts,
                return_tensors="pt",
                padding=True,
                truncation=True,
                max_length=max_length,
                add_special_tokens=False,
            )
            encoded = {key: value.to(device) for key, value in encoded.items()}
            context = torch.enable_grad() if require_grad else torch.no_grad()
            with context:
                result = model(**encoded, use_cache=False, return_dict=True)
                last = encoded["attention_mask"].sum(dim=1).long() - 1
                batch = torch.arange(last.shape[0], device=device)
                logits = result.logits[batch, last].float()
                output.append(logits[:, positive_id] - logits[:, negative_id])
    finally:
        tokenizer.truncation_side = old_truncation
        tokenizer.padding_side = old_padding
    canonical_scores = torch.cat(output, dim=0)
    canonical_position = {
        original_index: position
        for position, original_index in enumerate(canonical_indices)
    }
    scores = torch.stack([
        canonical_scores[canonical_position[index]]
        for index in range(len(candidates))
    ])
    if scores.shape != (len(candidates),):
        raise RuntimeError("exchange score shape mismatch")
    if not bool(torch.isfinite(scores).all()):
        raise FloatingPointError("exchange scorer produced NaN/Inf")
    return scores


def rank_exchange_indices(scores, row: dict) -> list[int]:
    

    validate_exchange_only_row(row)
    values = [float(value) for value in scores]
    if len(values) != len(row["candidates"]):
        raise ValueError("score/candidate length mismatch")
    return sorted(
        range(len(values)),
        key=lambda index: (-values[index], row["candidates"][index]["action"]),
    )


def topk_exchange_indices(scores, row: dict, topk: int) -> list[int]:
    if topk <= 0 or topk > len(row.get("candidates") or []):
        raise ValueError("topk must fit the fixed exchange pool")
    selected = rank_exchange_indices(scores, row)[:topk]
    if any(row["candidates"][index]["action"] == NOOP for index in selected):
        raise RuntimeError("no-op entered exchange Top-k")
    return selected


def reordered_exchange_row(row: dict, order: Sequence[int]) -> dict:
    candidates = list(row["candidates"])
    if sorted(order) != list(range(len(candidates))):
        raise ValueError("order must be an exchange-candidate permutation")
    output = dict(row)
    output["candidates"] = [candidates[index] for index in order]
    return output
