# GridRank-Dynamic research materials

Simulation-derived datasets, evaluation records, source code, and experimental
protocols supporting *GridRank-Dynamic: Safe Distribution Network
Reconfiguration with Large Language Models under Dynamic Operating Instructions*.

## Contents

| Directory | Contents |
|---|---|
| `artifacts/` | Dataset construction, training, evaluation, analysis code, and recorded experiments |
| `derived/` | Selected dynamic training and development partitions |
| `code/variants/` | Source implementations associated with experiment hashes |
| `environment/` | Software requirements and recorded runtimes |
| `manifests/` | Data inventory, file provenance, model catalog, and validation scope |
| `docs/` | Data definitions, manuscript mapping, reproduction instructions, and rights |

Model assets are provided separately as `GridRank_Dynamic_Core_LoRA.tar.gz`
and `GridRank_Dynamic_Supplementary_LoRA.tar.gz`. The external
Meta-Llama-3.1-8B-Instruct base model is not included.

## Quick start

Run from the extracted package root with Python 3.10 or later:

```bash
python -B tools/verify_package.py
python -B tools/recompute_point_estimates.py
```

These commands use the Python standard library, validate the stored data, and
recompute principal point estimates without training models or calling AC
power flow. Complete GPU training and inference are not covered by these checks.

See [Data dictionary](docs/DATA_DICTIONARY.md),
[Manuscript-to-artifact map](docs/PAPER_ARTIFACT_MAP.md), and
[Reproduction workflow](docs/REPRODUCTION_WORKFLOW.md) for details.
Reuse conditions and external dependencies are described in
[Rights and attribution](docs/RIGHTS_AND_THIRD_PARTY.md).
