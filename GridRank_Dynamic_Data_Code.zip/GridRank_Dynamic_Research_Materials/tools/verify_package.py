#!/usr/bin/env python3
"""Validate package integrity and benchmark alignment without model loading."""
from __future__ import annotations
import ast
import hashlib
import json
from collections import Counter, defaultdict
from pathlib import Path, PurePosixPath

ROOT = Path(__file__).resolve().parents[1]
P = ROOT / "artifacts/Model-Notebooks/llama3-notebooks"


def load_rows(path):
    def reject_constant(value):
        raise ValueError(f"Non-finite JSON constant: {value}")
    return [json.loads(line, parse_constant=reject_constant)
            for line in path.read_bytes().splitlines() if line.strip()]


def check_pair_cache(stem, states, cache_count, candidate_count):
    rows = load_rows(P / (stem + "_pairs.jsonl"))
    cache = load_rows(P / (stem + "_physics_cache.jsonl"))
    assert len(rows) == 192 and len({r["instance_id"] for r in rows}) == 192
    assert len({r["physical_state_sha256"] for r in rows}) == states
    assert len(cache) == cache_count
    indexed = {(r["network_id"], r["physical_state_sha256"]): r for r in cache}
    assert len(indexed) == cache_count
    pairs = defaultdict(list)
    for row in rows:
        pairs[row["pair_id"]].append(row)
        actions = {c["action"] for c in row["candidates"]}
        cached_actions = {c["action"] for c in indexed[(row["network_id"], row["physical_state_sha256"])]["candidates"]}
        assert len(actions) == candidate_count
        assert cached_actions == actions | {"Action: none"}
        assert row["desired_action"] in cached_actions
    assert len(pairs) == 96
    assert all(len(rs) == 2 and {r["pair_side"] for r in rs} == {"left", "right"}
               and len({r["physical_state_sha256"] for r in rs}) == 1 for rs in pairs.values())
    primary = [r for r in rows if r["pair_type"] == "maintenance_voltage"]
    assert len(primary) == 96 and len({r["pair_id"] for r in primary}) == 48
    assert len({r["physical_state_sha256"] for r in primary}) == 48
    return rows


def main():
    checks = {}
    listed = set()
    for line in (ROOT / "SHA256SUMS.txt").read_text().splitlines():
        expected, name = line.split(None, 1)
        name = name.lstrip("*")
        pure = PurePosixPath(name)
        assert not pure.is_absolute() and ".." not in pure.parts
        path = ROOT / name
        assert path.is_file(), f"Missing file: {name}"
        assert hashlib.sha256(path.read_bytes()).hexdigest() == expected, f"Hash mismatch: {name}"
        listed.add(name)
    checks["file_checksums_verified"] = len(listed)

    for path in (ROOT / "artifacts").rglob("*.py"):
        ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
    for path in (ROOT / "code").rglob("*.py"):
        ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
    checks["python_source_syntax"] = "passed"
    all_jsonl = list((ROOT / "artifacts").rglob("*.jsonl")) + list((ROOT / "derived").glob("*.jsonl"))
    checks["jsonl_files_parsed"] = len(all_jsonl)
    checks["jsonl_records_parsed"] = sum(len(load_rows(path)) for path in all_jsonl)

    ieee = check_pair_cache("gridrank_dynamic_confirmation_v1_20260829_hotfix1", 66, 116, 15)
    cross = check_pair_cache("gridrank_dynamic_cross_topology_v1_20260907", 63, 80, 32)
    checks["benchmark_pair_and_cache_integrity"] = "passed"
    ids_ieee = {r["instance_id"] for r in ieee}
    ids_cross = {r["instance_id"] for r in cross}
    for directory in ["output_gridrank_dynamic_confirmation_v1_20260829_hotfix1",
                      "output_gridrank_dynamic_confirmation_replication_v1_s123_20260831",
                      "output_gridrank_dynamic_confirmation_replication_v1_s2025_20260831",
                      "output_gridrank_dynamic_cross_topology_v1_20260907"]:
        basename = "gridrank_dynamic_cross_topology_records.jsonl" if "cross_topology" in directory else "gridrank_dynamic_confirmation_records.jsonl"
        records = load_rows(P / directory / basename)
        methods = defaultdict(list)
        for row in records: methods[row["method"]].append(row["instance_id"])
        expected = ids_cross if "cross_topology" in directory else ids_ieee
        assert all(len(v) == 192 and set(v) == expected for v in methods.values())
    checks["main_result_case_alignment"] = "passed"

    train = load_rows(ROOT / "derived/dynamic_selected_train_114.jsonl")
    development = load_rows(ROOT / "derived/dynamic_selected_development_96.jsonl")
    assert len(train) == 114 and len(development) == 96
    assert not any(r["base_objective"] == "voltage" and r["maintenance_constraint"] for r in train)
    checks["selected_train_development_and_holdout"] = "passed"

    robust = load_rows(P / "output_gridrank_dynamic_observation_robustness_v1_20260909_hotfix2/gridrank_dynamic_observation_robustness_records.jsonl")
    primary_ids = {r["instance_id"] for r in cross if r["pair_type"] == "maintenance_voltage"}
    assert len(robust) == 4032
    assert {r["instance_id"] for r in robust} == primary_ids
    groups = Counter((r["experiment_axis"], r["condition"], r["seed"], r["noise_replicate"]) for r in robust)
    assert len(groups) == 42 and all(n == 96 for n in groups.values())
    checks["robustness_schedule_and_cases"] = "passed"

    provenance = {item["path"]: item for item in json.loads((ROOT / "manifests/file_provenance.json").read_text())}
    bindings = json.loads((ROOT / "manifests/experiment_hash_bindings.json").read_text())
    for binding in bindings:
        assert binding["package_files"]
        for name in binding["package_files"]:
            item = provenance[name]
            assert binding["experiment_source_sha256"] in {
                item["experiment_source_sha256"], item["content_sha256"]
            }
            assert hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == item["sha256"]
    checks["experiment_source_associations_verified"] = len(bindings)
    checks["experiment_source_association_is_not_a_whole_file_byte_identity_claim"] = True
    checks["model_loading_or_new_training"] = False
    checks["new_ac_power_flow_evaluation"] = False
    checks["complete_gpu_reproduction_verified"] = False
    print(json.dumps({"integrity_pass": True, "checks": checks}, indent=2))


if __name__ == "__main__":
    main()
