# GridRank-Dynamic research materials

Simulation-derived datasets, evaluation results, source code, and experimental
protocols supporting *GridRank-Dynamic: Safe Distribution Network
Reconfiguration with Large Language Models under Dynamic Operating Instructions*.

## Contents

| Directory | Contents |
|---|---|
| `datasets/` | Instruction data, physical-feedback data, fixed benchmarks, and train/development partitions |
| `src/` | Dataset construction, model training, inference, evaluation, and statistical analysis code |
| `results/` | Main comparisons, ablations, robustness studies, and latency measurements |
| `protocols/` | Experimental definitions and statistical protocols |
| `models/` | Task-specific adapters, supplied in two separate model archives |
| `environment/` | Software requirements and recorded runtimes |
| `manifests/` | Dataset inventory, file locations, model catalog, and source associations |
| `docs/` | Data definitions, manuscript mapping, reproduction instructions, and rights |
| `tools/` | File verification, point-estimate analysis, and the experiment entry point |

## Installation and checks

Extract `GridRank_Dynamic_Data_Code.zip`. Both model archives can be extracted
into the same parent directory; their `gridrank_dynamic/` paths merge with
the data/code directory without replacing its README.

From `gridrank_dynamic/`, use Python 3.10 or later:

```bash
python -B tools/verify_package.py
python -B tools/recompute_point_estimates.py
```

These standard-library commands validate the stored files and recompute
principal point estimates. They do not train a model, perform GPU inference,
or generate new AC power-flow outcomes.

## Experiment entry point

Use the common entry point to execute experiment scripts in a separate workspace:

```bash
python -B tools/run_experiment.py \
  --script verify_gridrank_dynamic_cross_topology_dependencies.py \
  --without-models
```

The entry point supplies the relative input names expected by the scripts and
copies files into a new workspace. It does not write into the supplied data,
results, or model directories. Model-dependent experiments require the adapter
archives, a separately obtained base model, and a compatible runtime.

See [Data dictionary](docs/DATA_DICTIONARY.md),
[Manuscript-to-artifact map](docs/PAPER_ARTIFACT_MAP.md), and
[Reproduction workflow](docs/REPRODUCTION_WORKFLOW.md).

## Models and rights

The adapter family is **Llama-GridRank-Dynamic**. Built with Llama.
Meta-Llama-3.1-8B-Instruct base-model weights are not included.

Reuse conditions and third-party dependencies are described in
[Rights and attribution](docs/RIGHTS_AND_THIRD_PARTY.md). Each model archive
contains the Llama 3.1 Community License and attribution notice.
