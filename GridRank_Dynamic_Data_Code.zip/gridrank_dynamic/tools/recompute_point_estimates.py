#!/usr/bin/env python3
"""Recompute principal point estimates from stored evaluation records."""
from __future__ import annotations
import json
from collections import defaultdict
from pathlib import Path
from statistics import mean

from package_layout import ExperimentFiles
P = ExperimentFiles(Path(__file__).resolve().parents[1])


def rows(path):
    return [json.loads(line) for line in path.read_bytes().splitlines() if line.strip()]


def summarize(records, primary=False):
    by_method = defaultdict(list)
    for record in records:
        if not primary or record["pair_type"] == "maintenance_voltage":
            by_method[record["method"]].append(record)
    return {name: {"n": len(rs), "regret": mean(r["normalised_regret"] for r in rs),
                   "hit_rate": mean(float(r["physics_optimal"]) for r in rs),
                   "joint_accuracy": mean(float(r["semantic_correct"]) for r in rs)}
            for name, rs in sorted(by_method.items())}


def main():
    ieee = {}
    for seed, directory in [(42, "output_gridrank_dynamic_confirmation_v1_20260829_hotfix1"),
                            (123, "output_gridrank_dynamic_confirmation_replication_v1_s123_20260831"),
                            (2025, "output_gridrank_dynamic_confirmation_replication_v1_s2025_20260831")]:
        record_set = rows(P / directory / "gridrank_dynamic_confirmation_records.jsonl")
        ieee[str(seed)] = {"full": summarize(record_set), "primary": summarize(record_set, True)}
    main_method = "physics_aligned_factorized_llm"
    baseline = "tfidf_logreg_withheld_composition"
    held_main = mean(ieee[str(s)]["primary"][main_method]["regret"] for s in [42, 123, 2025])
    held_baseline = mean(ieee[str(s)]["primary"][baseline]["regret"] for s in [42, 123, 2025])
    cross = rows(P / "output_gridrank_dynamic_cross_topology_v1_20260907/gridrank_dynamic_cross_topology_records.jsonl")
    cross_stats = {"full": summarize(cross), "primary": summarize(cross, True)}
    cross_mean = {split: mean(cross_stats[split][f"physics_aligned_factorized_llm_s{s}"]["regret"] for s in [42, 123, 2025])
                  for split in ["full", "primary"]}
    static = json.loads((P / "output_gridrank_select_extension_v2_20260726/gridrank_select_extension_gate.json").read_text())
    static_rows = [row for seed in ["42", "123", "2025"] for row in static["extension_state_evidence"][seed]]
    static_sft = mean(row["sft_safe_regret"] for row in static_rows)
    static_method = mean(row["distilled_safe_regret"] for row in static_rows)
    latency = json.loads((P / "gridrank_dynamic_supplement_v1_20260908_hotfix2_latency.json").read_text())
    result = {
        "scope": "Stored-record point estimates; confidence intervals and hardware timing are not re-estimated.",
        "static_extended_64_three_seed": {"n_states": 64, "n_seed_state_records": len(static_rows), "frozen_sft_regret": static_sft,
                                       "gridrank_select_regret": static_method,
                                       "relative_reduction_pct": 100 * (static_sft - static_method) / static_sft},
        "ieee_per_seed": ieee,
        "ieee_primary_three_seed": {"gridrank_regret": held_main, "tfidf_regret": held_baseline,
                                     "paired_improvement": held_baseline - held_main,
                                     "relative_reduction_pct": 100 * (held_baseline - held_main) / held_baseline},
        "cross_topology_methods": cross_stats, "cross_topology_three_seed_regret": cross_mean,
        "latency_row_count": len(latency["rows"]),
    }
    assert abs(result["static_extended_64_three_seed"]["gridrank_select_regret"] - 2.9167) < 0.00005
    assert abs(result["ieee_per_seed"]["42"]["full"][main_method]["regret"] - 0.0600) < 0.00005
    assert abs(cross_mean["full"] - 0.1351) < 0.00005
    assert abs(cross_mean["primary"] - 0.1805) < 0.00005
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
