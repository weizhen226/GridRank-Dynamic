"""Resolve experiment inputs within the research-materials package."""
from __future__ import annotations

import json
from pathlib import Path, PurePosixPath


def read_registry(root):
    root = Path(root).resolve()
    registry = json.loads((root / "manifests/path_registry.json").read_text())
    for entry in registry["files"] + registry["models"]:
        for key in ("path", "workspace_path"):
            value = PurePosixPath(entry[key])
            if value.is_absolute() or ".." in value.parts:
                raise ValueError(f"Unsafe registered path: {entry[key]}")
    return registry


class ExperimentFiles:
    """Locate stored files by the relative names used in experiment scripts."""

    def __init__(self, root, relative="", registry=None):
        self.root = Path(root).resolve()
        self.relative = relative
        self.registry = registry if registry is not None else read_registry(self.root)

    def __truediv__(self, name):
        relative = str(PurePosixPath(self.relative) / str(name))
        directory = self.registry["working_directory"]
        wanted = f"{directory}/{relative}"
        for entry in self.registry["files"]:
            if entry["workspace_path"] == wanted:
                return self.root / entry["path"]
        if any(entry["workspace_path"].startswith(wanted + "/")
               for entry in self.registry["files"]):
            return ExperimentFiles(self.root, relative, self.registry)
        raise KeyError(f"No packaged experiment file: {relative}")
