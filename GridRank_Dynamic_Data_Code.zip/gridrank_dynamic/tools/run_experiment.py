#!/usr/bin/env python3
"""Run an experiment in a separate workspace without overwriting supplied files."""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path, PurePosixPath
import shutil
import subprocess
import sys
import tempfile

from package_layout import read_registry

ROOT = Path(__file__).resolve().parents[1]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--script", required=True,
                        help="Experiment script filename, for example verify_gridrank_dynamic_cross_topology_dependencies.py")
    parser.add_argument("--workdir", type=Path,
                        help="New workspace directory; must not already exist or be inside the package")
    parser.add_argument("--prepare-only", action="store_true")
    parser.add_argument("--without-models", action="store_true",
                        help="Prepare data/code checks without copying adapter weights")
    parser.add_argument("arguments", nargs=argparse.REMAINDER)
    args = parser.parse_args()
    registry = read_registry(ROOT)
    scripts = [entry for entry in registry["files"]
               if entry["path"].startswith("src/")
               and PurePosixPath(entry["workspace_path"]).parent.as_posix() == registry["working_directory"]
               and PurePosixPath(entry["path"]).name == args.script]
    if len(scripts) != 1 or Path(args.script).suffix not in {".py", ".sh"}:
        parser.error("--script must name one packaged Python or shell experiment script")

    if args.workdir:
        workspace = args.workdir.expanduser().resolve()
        if workspace == ROOT or ROOT in workspace.parents:
            parser.error("Choose a workdir outside the supplied research package")
        if workspace.exists():
            parser.error("The workdir already exists; choose a new directory")
        workspace.mkdir(parents=True)
    else:
        workspace = Path(tempfile.mkdtemp(prefix="gridrank_run_"))

    copied = 0
    for entry in registry["files"]:
        source = ROOT / entry["path"]
        if not source.is_file():
            raise FileNotFoundError(source)
        destination = workspace / entry["workspace_path"]
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, destination)
        copied += 1

    model_files = 0
    missing_models = []
    if not args.without_models:
        for entry in registry["models"]:
            source = ROOT / entry["path"]
            if not source.is_file():
                missing_models.append(entry["path"])
                continue
            destination = workspace / entry["workspace_path"]
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, destination)
            model_files += 1

    working_directory = workspace / registry["working_directory"]
    report = {"workspace": str(workspace), "working_directory": str(working_directory),
              "data_code_files_copied": copied, "model_files_copied": model_files,
              "model_files_not_present": missing_models}
    print(json.dumps(report, indent=2), flush=True)
    if args.prepare_only:
        return
    forwarded = args.arguments[1:] if args.arguments[:1] == ["--"] else args.arguments
    interpreter = "bash" if args.script.endswith(".sh") else sys.executable
    command = [interpreter] + ([] if args.script.endswith(".sh") else ["-B"])
    command += [args.script] + forwarded
    environment = os.environ.copy()
    environment["PYTHONDONTWRITEBYTECODE"] = "1"
    result = subprocess.run(command, cwd=working_directory, env=environment, check=False)
    raise SystemExit(result.returncode)


if __name__ == "__main__":
    main()
