# Reproduction workflow

## Stored-data analysis

From the package root:

```bash
python -B tools/verify_package.py
python -B tools/recompute_point_estimates.py
```

The first command validates checksums, schemas, benchmark alignment, selected
partitions, and the robustness schedule. The second recomputes principal
point estimates from stored records. Neither command loads a model or
generates new AC outcomes. The point-estimate tool does not re-estimate every
confidence interval or timing measurement.

Statistical implementations are the `aggregate_*` and `verify_*` scripts in
`src/`; their experimental definitions
are in `protocols/`. Source-hash relationships are recorded in
`manifests/file_provenance.json` and `manifests/experiment_hash_bindings.json`.
Stored experiment hashes describe their source artifacts; current package
hashes are listed separately in `SHA256SUMS.txt`.

The cross-topology result corpus contains the 14 methods and conditions used
in the article. Use the method identifiers and evaluation scopes defined in
the data dictionary when aggregating results.

## Model inference and AC replay

1. Extract the data/code archive and both adapter archives into the same parent
   directory. The resulting `gridrank_dynamic/` contains all supplied materials.
2. Obtain Meta-Llama-3.1-8B-Instruct separately under its own terms. Set
   `BASE_MODEL` to its absolute directory.
3. Prepare a compatible Linux/CUDA runtime using `environment/`.
4. Execute the selected experiment through `tools/run_experiment.py`. The entry
   point copies the inputs and code into a separate workspace, preserving the
   relative names expected by the experiment scripts. Supplied files are not
   overwritten. Model files are copied when present; `--without-models` omits
   them for data/code-only checks.

For example, from the package root:

```bash
python -B tools/run_experiment.py \
  --script verify_gridrank_dynamic_cross_topology_dependencies.py \
  --without-models
```

To prepare a persistent workspace without starting a script, supply a new
absolute `--workdir` and `--prepare-only`. Subsequent outputs remain in that
workspace. A model-dependent shell runner can be selected with `--script`;
its existing environment variables and CLI arguments still apply. Use a new
`TAG` and output directory rather than the supplied experiment identifiers.

The recorded manifests preserve experiment-host paths and source fingerprints.
They document the evaluated runs, not execution locks for another host. Generate
a preflight for the inputs, source, runtime, and model files actually used for
a new run. The static preflight's 16-state exclusion inputs are separation
checks, not additional final test observations.

The cross-topology runner uses the fixed SimBench pairs and three factorized
adapters. Its default is CPU preflight only; full inference also requires
the external base model and `PREFLIGHT_ONLY=0`. Complete GPU inference and
retraining are outside the supplied package-validation checks.

The recorded GPU is an RTX 4090 with 24 GB memory. Four-bit CUDA loading and
timing measurements depend on hardware and software. A macOS CPU run does
not establish those timing results. Load only trusted model files.

## Retraining and interpretation

Use 64 static training states and the 114/96 selected dynamic
training/development records. Follow the recorded schedules and seeds
42, 123, and 2025. Test labels must not enter fitting, threshold selection,
or checkpoint selection. Matching seeds alone does not ensure bitwise
identical GPU training.

The seed replications and supplementary ablations use the same fixed
confirmation benchmark, not additional independent test datasets. Report
negative effects and intervals crossing zero. Safety results depend on the
evaluated physical settings and, where stated, a feasible initial no-op.
