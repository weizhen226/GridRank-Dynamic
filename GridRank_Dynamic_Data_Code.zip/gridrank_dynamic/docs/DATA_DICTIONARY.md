# Data dictionary

## Data origin and populations

The instruction examples and AC-feedback labels were generated for this study
by simulation. IEEE 33-bus, IEEE 69-bus, and SimBench are the underlying physical
benchmarks, not ready-made language-instruction datasets.

| Population | Size and interpretation |
|---|---|
| Static training | 64 states, balanced across IEEE 33-bus and 69-bus networks |
| Static test | 64 confirmation states and 64 independent extension states |
| Dynamic training/development | 114 selected training records and 96 development records; selections are defined by the training preflight |
| IEEE locked test | 192 instruction records, 96 pairs, 66 physical states; 15 exchanges per state |
| SimBench locked test | 192 instruction records, 96 pairs, 63 physical states; 32 exchanges per state |
| Held-out combination | `maintenance_voltage`: 96 records, 48 pairs, 48 physical states in each dynamic benchmark |
| Cross-topology evaluation | 2,688 records covering 14 methods/conditions and the 192 SimBench instructions |
| Observation robustness | 4,032 records: 1,440 operating-shift and 2,592 measurement-noise evaluations |
| Safety/ranking evaluation | 576 records per cached analysis: 192 instructions evaluated with three model seeds |
| Timing evaluation | 128 measurements: 32 instruction-state records evaluated with four methods |

The upstream dynamic training/development containers contain 180/192 records.
Use the selected IDs in the preflight or the copies in `datasets/dynamic/selected/`, not the full
containers, for the final dynamic training schedule. The held-out voltage and
maintenance combination has no training examples.

Static figure panels (a)-(b) use the 64-state extension averaged over three
seeds. The matched-label panel uses the combined 128-state population.
The 16-state exclusion input is used only by the static preflight to check
separation from previously evaluated states; it is not part of either final
static test population.

## Instruction records (`.jsonl`)

| Field | Meaning |
|---|---|
| `instance_id` | Instruction-state record identifier |
| `pair_id`, `pair_side`, `pair_type` | Paired intervention identifier, endpoint, and intervention type |
| `network_id`, `simbench_code` | Physical network identifier |
| `physical_state_sha256`, `load_id` | Physical-state and load identifiers for partition checks and clustering |
| `state_text` | Serialized operating state for the physical execution layer |
| `instruction_text` | Natural-language operating instruction |
| `base_objective`, `maintenance_constraint` | Reference objective and constraint labels |
| `oracle_structured_instruction`, `desired_action`, `desired_is_noop` | Supervision/evaluation targets; not inputs to the language model at inference |
| `forbidden_edges` | Branch restrictions supplied to the execution protocol |
| `candidate_count`, `candidates` | Exchange candidates and their features/feedback |
| `gate_anchor` | Independent no-op reference for certification and metrics |
| `partition`, `schema`, template/style identifiers | Dataset partition and construction identifiers |

Candidate lists contain exchanges only. Physics caches contain these exchanges
plus `Action: none`: 16 entries for IEEE and 33 for SimBench. No-op remains
available through the cache and the anchor even when it is the desired action.
AC outcomes and reference utilities are supervision/evaluation information;
they are not rendered in language-model inference prompts.

## Physics caches and evaluation records

Physics caches join on `(network_id, physical_state_sha256)`. The IEEE cache
contains 116 scanned states and the SimBench cache 80; unused scanned states
are not additional test examples.

Evaluation fields include `method`, `instance_id`, `pair_id`, `pair_type`,
`network`, `normalised_regret`, `physics_optimal`, `semantic_correct`,
`selected_card`, `safe_action`, `safe_feasible`, and `constraint_violation`.
`physics_aligned_factorized_llm` and its seed-specific forms identify
GridRank-Dynamic. The cross-topology records cover the methods in the article;
file provenance records their relationship to the source experiment.

Robustness records also identify perturbation conditions, noise replicas,
observed-anchor feasibility, deployed actions, and true-state feasibility.
A no-op in an initially infeasible state does not guarantee feasible operation.

Strict IEEE state views contain `instance_id`, `load_id`, `prompt`, and `split`.
Their `validation` role label belongs to the construction interface; it does
not imply use of the final confirmation states for model development.

## Statistical units

Training seeds are 42, 123, and 2025; bootstrap analyses use 10,000 resamples.
Instruction endpoints, model seeds, and noise replicas within a physical state
are dependent observations. Follow the pair/state/seed aggregation in the
associated protocol rather than treating every row as independent.

GT-semantics results use reference objective/constraint labels. Exhaustive AC
results evaluate the complete candidate pool. They are privileged references,
not equal-information or equal-query-budget deployment baselines. Integrity
checks and scientific significance tests are separate; inconclusive and
negative results remain part of the evaluation evidence.
