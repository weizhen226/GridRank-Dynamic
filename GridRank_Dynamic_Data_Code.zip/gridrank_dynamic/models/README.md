# Model adapters

Extract both model archives beside the data/code archive.
Core adapters are in `core/`; additional experimental conditions are in
`supplementary/`. Consult `../manifests/model_catalog.json` for identities,
file hashes, and article roles. Built with Llama.
